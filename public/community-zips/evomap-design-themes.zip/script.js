/*
 * Bundled hero engine for the MuseHub `evomap-design-themes` showcase.
 * Compiled from the upstream src/main.js entry plus relative deps and
 * the locally-vendored three.js build (no remote imports remain).
 * Source: vendor/evomap-design-themes-source/src/
 */

(function() {
	//#region \0rolldown/runtime.js
	var __defProp = Object.defineProperty;
	var __exportAll = (all, no_symbols) => {
		let target = {};
		for (var name in all) __defProp(target, name, {
			get: all[name],
			enumerable: true
		});
		if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
		return target;
	};
	//#endregion
	//#region node_modules/three/build/three.module.min.js
	var three_module_min_exports = /* @__PURE__ */ __exportAll({
		ACESFilmicToneMapping: () => 4,
		AddEquation: () => 100,
		AddOperation: () => 2,
		AdditiveAnimationBlendMode: () => ze,
		AdditiveBlending: () => 2,
		AgXToneMapping: () => 6,
		AlphaFormat: () => Bt,
		AlwaysCompare: () => 519,
		AlwaysDepth: () => 1,
		AlwaysStencilFunc: () => 519,
		AmbientLight: () => xp,
		AnimationAction: () => lm,
		AnimationClip: () => Gd,
		AnimationLoader: () => $d,
		AnimationMixer: () => hm,
		AnimationObjectGroup: () => om,
		AnimationUtils: () => Pd,
		ArcCurve: () => Yh,
		ArrayCamera: () => Yl,
		ArrowHelper: () => rf,
		AttachedBindMode: () => st,
		Audio: () => jp,
		AudioAnalyser: () => $p,
		AudioContext: () => Up,
		AudioListener: () => Xp,
		AudioLoader: () => Np,
		AxesHelper: () => sf,
		BackSide: () => 1,
		BasicDepthPacking: () => Ge,
		BasicShadowMap: () => 0,
		BatchedMesh: () => _h,
		Bone: () => kc,
		BooleanKeyframeTrack: () => Od,
		Box2: () => wm,
		Box3: () => Di,
		Box3Helper: () => $m,
		BoxGeometry: () => Gs,
		BoxHelper: () => Km,
		BufferAttribute: () => ds,
		BufferGeometry: () => Cs,
		BufferGeometryLoader: () => Ep,
		ByteType: () => At,
		Cache: () => Xd,
		Camera: () => Zs,
		CameraHelper: () => Ym,
		CanvasTexture: () => Xh,
		CapsuleGeometry: () => fu,
		CatmullRomCurve3: () => tu,
		CineonToneMapping: () => 3,
		CircleGeometry: () => gu,
		ClampToEdgeWrapping: () => mt,
		Clock: () => zp,
		Color: () => ts,
		ColorKeyframeTrack: () => Fd,
		ColorManagement: () => mi,
		CompressedArrayTexture: () => Gh,
		CompressedCubeTexture: () => Wh,
		CompressedTexture: () => Hh,
		CompressedTextureLoader: () => Qd,
		ConeGeometry: () => _u,
		ConstantAlphaFactor: () => 213,
		ConstantColorFactor: () => 211,
		Controls: () => of,
		CubeCamera: () => ea,
		CubeReflectionMapping: () => 301,
		CubeRefractionMapping: () => 302,
		CubeTexture: () => na,
		CubeTextureLoader: () => ep,
		CubeUVReflectionMapping: () => 306,
		CubicBezierCurve: () => ru,
		CubicBezierCurve3: () => su,
		CubicInterpolant: () => Ld,
		CullFaceBack: () => 1,
		CullFaceFront: () => 2,
		CullFaceFrontBack: () => 3,
		CullFaceNone: () => 0,
		Curve: () => jh,
		CurvePath: () => du,
		CustomBlending: () => 5,
		CustomToneMapping: () => 5,
		CylinderGeometry: () => vu,
		Cylindrical: () => Mm,
		Data3DTexture: () => Ci,
		DataArrayTexture: () => Ai,
		DataTexture: () => Vc,
		DataTextureLoader: () => np,
		DataUtils: () => cs,
		DecrementStencilOp: () => cn,
		DecrementWrapStencilOp: () => un,
		DefaultLoadingManager: () => qd,
		DepthFormat: () => Gt,
		DepthStencilFormat: () => Wt,
		DepthTexture: () => Ka,
		DetachedBindMode: () => at,
		DirectionalLight: () => _p,
		DirectionalLightHelper: () => Xm,
		DiscreteInterpolant: () => Nd,
		DisplayP3ColorSpace: () => $e,
		DodecahedronGeometry: () => yu,
		DoubleSide: () => 2,
		DstAlphaFactor: () => 206,
		DstColorFactor: () => 208,
		DynamicCopyUsage: () => On,
		DynamicDrawUsage: () => Pn,
		DynamicReadUsage: () => Un,
		EdgesGeometry: () => Tu,
		EllipseCurve: () => qh,
		EqualCompare: () => 514,
		EqualDepth: () => 4,
		EqualStencilFunc: () => 514,
		EquirectangularReflectionMapping: () => 303,
		EquirectangularRefractionMapping: () => 304,
		Euler: () => _r,
		EventDispatcher: () => Hn,
		ExtrudeGeometry: () => ed,
		FileLoader: () => Kd,
		Float16BufferAttribute: () => ys,
		Float32BufferAttribute: () => Ms,
		FloatType: () => Lt,
		Fog: () => ac,
		FogExp2: () => sc,
		FramebufferTexture: () => Vh,
		FrontSide: () => 0,
		Frustum: () => ha,
		GLBufferAttribute: () => fm,
		GLSL1: () => "100",
		GLSL3: () => zn,
		GreaterCompare: () => 516,
		GreaterDepth: () => 6,
		GreaterEqualCompare: () => 518,
		GreaterEqualDepth: () => 5,
		GreaterEqualStencilFunc: () => 518,
		GreaterStencilFunc: () => 516,
		GridHelper: () => km,
		Group: () => Zl,
		HalfFloatType: () => Ut,
		HemisphereLight: () => sp,
		HemisphereLightHelper: () => zm,
		IcosahedronGeometry: () => id,
		ImageBitmapLoader: () => Ip,
		ImageLoader: () => tp,
		ImageUtils: () => _i,
		IncrementStencilOp: () => ln,
		IncrementWrapStencilOp: () => hn,
		InstancedBufferAttribute: () => Xc,
		InstancedBufferGeometry: () => Tp,
		InstancedInterleavedBuffer: () => mm,
		InstancedMesh: () => Qc,
		Int16BufferAttribute: () => gs,
		Int32BufferAttribute: () => _s,
		Int8BufferAttribute: () => ps,
		IntType: () => Pt,
		InterleavedBuffer: () => lc,
		InterleavedBufferAttribute: () => hc,
		Interpolant: () => Id,
		InterpolateDiscrete: () => Le,
		InterpolateLinear: () => Ue,
		InterpolateSmooth: () => Ne,
		InvertStencilOp: () => dn,
		KeepStencilOp: () => an,
		KeyframeTrack: () => Dd,
		LOD: () => Cc,
		LatheGeometry: () => mu,
		Layers: () => xr,
		LessCompare: () => 513,
		LessDepth: () => 2,
		LessEqualCompare: () => 515,
		LessEqualDepth: () => 3,
		LessEqualStencilFunc: () => 515,
		LessStencilFunc: () => 513,
		Light: () => rp,
		LightProbe: () => Sp,
		Line: () => Ah,
		Line3: () => Am,
		LineBasicMaterial: () => xh,
		LineCurve: () => au,
		LineCurve3: () => ou,
		LineDashedMaterial: () => wd,
		LineLoop: () => Lh,
		LineSegments: () => Ih,
		LinearDisplayP3ColorSpace: () => Qe,
		LinearFilter: () => Mt,
		LinearInterpolant: () => Ud,
		LinearMipMapLinearFilter: () => Tt,
		LinearMipMapNearestFilter: () => bt,
		LinearMipmapLinearFilter: () => wt,
		LinearMipmapNearestFilter: () => St,
		LinearSRGBColorSpace: () => Ke,
		LinearToneMapping: () => 1,
		LinearTransfer: () => tn,
		Loader: () => Yd,
		LoaderUtils: () => wp,
		LoadingManager: () => jd,
		LoopOnce: () => Ce,
		LoopPingPong: () => Ie,
		LoopRepeat: () => Pe,
		LuminanceAlphaFormat: () => Ht,
		LuminanceFormat: () => Vt,
		MOUSE: () => e,
		Material: () => is,
		MaterialLoader: () => bp,
		MathUtils: () => Qn,
		Matrix2: () => Sm,
		Matrix3: () => ei,
		Matrix4: () => lr,
		MaxEquation: () => 104,
		Mesh: () => Vs,
		MeshBasicMaterial: () => rs,
		MeshDepthMaterial: () => zl,
		MeshDistanceMaterial: () => kl,
		MeshLambertMaterial: () => Sd,
		MeshMatcapMaterial: () => bd,
		MeshNormalMaterial: () => Md,
		MeshPhongMaterial: () => xd,
		MeshPhysicalMaterial: () => _d,
		MeshStandardMaterial: () => vd,
		MeshToonMaterial: () => yd,
		MinEquation: () => 103,
		MirroredRepeatWrapping: () => ft,
		MixOperation: () => 1,
		MultiplyBlending: () => 4,
		MultiplyOperation: () => 0,
		NearestFilter: () => gt,
		NearestMipMapLinearFilter: () => yt,
		NearestMipMapNearestFilter: () => _t,
		NearestMipmapLinearFilter: () => xt,
		NearestMipmapNearestFilter: () => vt,
		NeutralToneMapping: () => 7,
		NeverCompare: () => 512,
		NeverDepth: () => 0,
		NeverStencilFunc: () => 512,
		NoBlending: () => 0,
		NoColorSpace: () => "",
		NoToneMapping: () => 0,
		NormalAnimationBlendMode: () => Be,
		NormalBlending: () => 1,
		NotEqualCompare: () => 517,
		NotEqualDepth: () => 7,
		NotEqualStencilFunc: () => 517,
		NumberKeyframeTrack: () => Bd,
		Object3D: () => Dr,
		ObjectLoader: () => Ap,
		ObjectSpaceNormalMap: () => 1,
		OctahedronGeometry: () => rd,
		OneFactor: () => 201,
		OneMinusConstantAlphaFactor: () => 214,
		OneMinusConstantColorFactor: () => 212,
		OneMinusDstAlphaFactor: () => 207,
		OneMinusDstColorFactor: () => 209,
		OneMinusSrcAlphaFactor: () => 205,
		OneMinusSrcColorFactor: () => 203,
		OrthographicCamera: () => Ea,
		P3Primaries: () => "p3",
		PCFShadowMap: () => 1,
		PCFSoftShadowMap: () => 2,
		PMREMGenerator: () => Ba,
		Path: () => pu,
		PerspectiveCamera: () => Qs,
		Plane: () => oa,
		PlaneGeometry: () => pa,
		PlaneHelper: () => Qm,
		PointLight: () => gp,
		PointLightHelper: () => Dm,
		Points: () => Bh,
		PointsMaterial: () => Uh,
		PolarGridHelper: () => Vm,
		PolyhedronGeometry: () => xu,
		PositionalAudio: () => Kp,
		PropertyBinding: () => am,
		PropertyMixer: () => Qp,
		QuadraticBezierCurve: () => lu,
		QuadraticBezierCurve3: () => cu,
		Quaternion: () => Ii,
		QuaternionKeyframeTrack: () => kd,
		QuaternionLinearInterpolant: () => zd,
		RED_GREEN_RGTC2_Format: () => Ae,
		RED_RGTC1_Format: () => Te,
		REVISION: () => "169",
		RGBADepthPacking: () => We,
		RGBAFormat: () => kt,
		RGBAIntegerFormat: () => Jt,
		RGBA_ASTC_10x10_Format: () => xe,
		RGBA_ASTC_10x5_Format: () => ge,
		RGBA_ASTC_10x6_Format: () => ve,
		RGBA_ASTC_10x8_Format: () => _e,
		RGBA_ASTC_12x10_Format: () => ye,
		RGBA_ASTC_12x12_Format: () => Me,
		RGBA_ASTC_4x4_Format: () => le,
		RGBA_ASTC_5x4_Format: () => ce,
		RGBA_ASTC_5x5_Format: () => he,
		RGBA_ASTC_6x5_Format: () => ue,
		RGBA_ASTC_6x6_Format: () => de,
		RGBA_ASTC_8x5_Format: () => pe,
		RGBA_ASTC_8x6_Format: () => me,
		RGBA_ASTC_8x8_Format: () => fe,
		RGBA_BPTC_Format: () => Se,
		RGBA_ETC2_EAC_Format: () => oe,
		RGBA_PVRTC_2BPPV1_Format: () => re,
		RGBA_PVRTC_4BPPV1_Format: () => ie,
		RGBA_S3TC_DXT1_Format: () => $t,
		RGBA_S3TC_DXT3_Format: () => Qt,
		RGBA_S3TC_DXT5_Format: () => te,
		RGBDepthPacking: () => Xe,
		RGBFormat: () => zt,
		RGBIntegerFormat: () => Zt,
		RGB_BPTC_SIGNED_Format: () => be,
		RGB_BPTC_UNSIGNED_Format: () => we,
		RGB_ETC1_Format: () => se,
		RGB_ETC2_Format: () => ae,
		RGB_PVRTC_2BPPV1_Format: () => ne,
		RGB_PVRTC_4BPPV1_Format: () => ee,
		RGB_S3TC_DXT1_Format: () => Kt,
		RGDepthPacking: () => je,
		RGFormat: () => qt,
		RGIntegerFormat: () => Yt,
		RawShaderMaterial: () => gd,
		Ray: () => or,
		Raycaster: () => vm,
		Rec709Primaries: () => nn,
		RectAreaLight: () => yp,
		RedFormat: () => Xt,
		RedIntegerFormat: () => jt,
		ReinhardToneMapping: () => 2,
		RenderTarget: () => Ti,
		RepeatWrapping: () => pt,
		ReplaceStencilOp: () => on,
		ReverseSubtractEquation: () => 102,
		RingGeometry: () => sd,
		SIGNED_RED_GREEN_RGTC2_Format: () => Re,
		SIGNED_RED_RGTC1_Format: () => Ee,
		SRGBColorSpace: () => Je,
		SRGBTransfer: () => en,
		Scene: () => oc,
		ShaderChunk: () => ma,
		ShaderLib: () => ga,
		ShaderMaterial: () => Ys,
		ShadowMaterial: () => fd,
		Shape: () => Eu,
		ShapeGeometry: () => ad,
		ShapePath: () => af,
		ShapeUtils: () => $u,
		ShortType: () => Rt,
		Skeleton: () => Wc,
		SkeletonHelper: () => Um,
		SkinnedMesh: () => zc,
		Source: () => yi,
		Sphere: () => Qi,
		SphereGeometry: () => od,
		Spherical: () => ym,
		SphericalHarmonics3: () => Mp,
		SplineCurve: () => hu,
		SpotLight: () => up,
		SpotLightHelper: () => Cm,
		Sprite: () => Tc,
		SpriteMaterial: () => uc,
		SrcAlphaFactor: () => 204,
		SrcAlphaSaturateFactor: () => 210,
		SrcColorFactor: () => 202,
		StaticCopyUsage: () => Dn,
		StaticDrawUsage: () => Cn,
		StaticReadUsage: () => Ln,
		StereoCamera: () => Bp,
		StreamCopyUsage: () => Fn,
		StreamDrawUsage: () => In,
		StreamReadUsage: () => Nn,
		StringKeyframeTrack: () => Vd,
		SubtractEquation: () => 101,
		SubtractiveBlending: () => 3,
		TOUCH: () => n,
		TangentSpaceNormalMap: () => 0,
		TetrahedronGeometry: () => ld,
		Texture: () => bi,
		TextureLoader: () => ip,
		TextureUtils: () => Xl,
		TorusGeometry: () => cd,
		TorusKnotGeometry: () => hd,
		Triangle: () => Zr,
		TriangleFanDrawMode: () => 2,
		TriangleStripDrawMode: () => 1,
		TrianglesDrawMode: () => 0,
		TubeGeometry: () => ud,
		UVMapping: () => 300,
		Uint16BufferAttribute: () => vs,
		Uint32BufferAttribute: () => xs,
		Uint8BufferAttribute: () => ms,
		Uint8ClampedBufferAttribute: () => fs,
		Uniform: () => um,
		UniformsGroup: () => pm,
		UniformsLib: () => fa,
		UniformsUtils: () => qs,
		UnsignedByteType: () => Et,
		UnsignedInt248Type: () => Ot,
		UnsignedInt5999Type: () => Ft,
		UnsignedIntType: () => It,
		UnsignedShort4444Type: () => Nt,
		UnsignedShort5551Type: () => Dt,
		UnsignedShortType: () => Ct,
		VSMShadowMap: () => 3,
		Vector2: () => ti,
		Vector3: () => Li,
		Vector4: () => wi,
		VectorKeyframeTrack: () => Hd,
		VideoTexture: () => kh,
		WebGL3DRenderTarget: () => Pi,
		WebGLArrayRenderTarget: () => Ri,
		WebGLCoordinateSystem: () => kn,
		WebGLCubeRenderTarget: () => ia,
		WebGLMultipleRenderTargets: () => lf,
		WebGLRenderTarget: () => Ei,
		WebGLRenderer: () => rc,
		WebGLUtils: () => ql,
		WebGPUCoordinateSystem: () => Vn,
		WireframeGeometry: () => dd,
		WrapAroundEnding: () => Fe,
		ZeroCurvatureEnding: () => De,
		ZeroFactor: () => 200,
		ZeroSlopeEnding: () => Oe,
		ZeroStencilOp: () => 0,
		createCanvasElement: () => oi
	});
	/**
	* @license
	* Copyright 2010-2024 Three.js Authors
	* SPDX-License-Identifier: MIT
	*/
	const e = {
		LEFT: 0,
		MIDDLE: 1,
		RIGHT: 2,
		ROTATE: 0,
		DOLLY: 1,
		PAN: 2
	}, n = {
		ROTATE: 0,
		PAN: 1,
		DOLLY_PAN: 2,
		DOLLY_ROTATE: 3
	}, st = "attached", at = "detached", pt = 1e3, mt = 1001, ft = 1002, gt = 1003, vt = 1004, _t = 1004, xt = 1005, yt = 1005, Mt = 1006, St = 1007, bt = 1007, wt = 1008, Tt = 1008, Et = 1009, At = 1010, Rt = 1011, Ct = 1012, Pt = 1013, It = 1014, Lt = 1015, Ut = 1016, Nt = 1017, Dt = 1018, Ot = 1020, Ft = 35902, Bt = 1021, zt = 1022, kt = 1023, Vt = 1024, Ht = 1025, Gt = 1026, Wt = 1027, Xt = 1028, jt = 1029, qt = 1030, Yt = 1031, Zt = 1032, Jt = 1033, Kt = 33776, $t = 33777, Qt = 33778, te = 33779, ee = 35840, ne = 35841, ie = 35842, re = 35843, se = 36196, ae = 37492, oe = 37496, le = 37808, ce = 37809, he = 37810, ue = 37811, de = 37812, pe = 37813, me = 37814, fe = 37815, ge = 37816, ve = 37817, _e = 37818, xe = 37819, ye = 37820, Me = 37821, Se = 36492, be = 36494, we = 36495, Te = 36283, Ee = 36284, Ae = 36285, Re = 36286, Ce = 2200, Pe = 2201, Ie = 2202, Le = 2300, Ue = 2301, Ne = 2302, De = 2400, Oe = 2401, Fe = 2402, Be = 2500, ze = 2501, Ge = 3200, We = 3201, Xe = 3202, je = 3203, Je = "srgb", Ke = "srgb-linear", $e = "display-p3", Qe = "display-p3-linear", tn = "linear", en = "srgb", nn = "rec709", an = 7680, on = 7681, ln = 7682, cn = 7683, hn = 34055, un = 34056, dn = 5386, Cn = 35044, Pn = 35048, In = 35040, Ln = 35045, Un = 35049, Nn = 35041, Dn = 35046, On = 35050, Fn = 35042, zn = "300 es", kn = 2e3, Vn = 2001;
	var Hn = class {
		addEventListener(t, e) {
			void 0 === this._listeners && (this._listeners = {});
			const n = this._listeners;
			void 0 === n[t] && (n[t] = []), -1 === n[t].indexOf(e) && n[t].push(e);
		}
		hasEventListener(t, e) {
			if (void 0 === this._listeners) return !1;
			const n = this._listeners;
			return void 0 !== n[t] && -1 !== n[t].indexOf(e);
		}
		removeEventListener(t, e) {
			if (void 0 === this._listeners) return;
			const n = this._listeners[t];
			if (void 0 !== n) {
				const t = n.indexOf(e);
				-1 !== t && n.splice(t, 1);
			}
		}
		dispatchEvent(t) {
			if (void 0 === this._listeners) return;
			const e = this._listeners[t.type];
			if (void 0 !== e) {
				t.target = this;
				const n = e.slice(0);
				for (let e = 0, i = n.length; e < i; e++) n[e].call(this, t);
				t.target = null;
			}
		}
	};
	const Gn = [
		"00",
		"01",
		"02",
		"03",
		"04",
		"05",
		"06",
		"07",
		"08",
		"09",
		"0a",
		"0b",
		"0c",
		"0d",
		"0e",
		"0f",
		"10",
		"11",
		"12",
		"13",
		"14",
		"15",
		"16",
		"17",
		"18",
		"19",
		"1a",
		"1b",
		"1c",
		"1d",
		"1e",
		"1f",
		"20",
		"21",
		"22",
		"23",
		"24",
		"25",
		"26",
		"27",
		"28",
		"29",
		"2a",
		"2b",
		"2c",
		"2d",
		"2e",
		"2f",
		"30",
		"31",
		"32",
		"33",
		"34",
		"35",
		"36",
		"37",
		"38",
		"39",
		"3a",
		"3b",
		"3c",
		"3d",
		"3e",
		"3f",
		"40",
		"41",
		"42",
		"43",
		"44",
		"45",
		"46",
		"47",
		"48",
		"49",
		"4a",
		"4b",
		"4c",
		"4d",
		"4e",
		"4f",
		"50",
		"51",
		"52",
		"53",
		"54",
		"55",
		"56",
		"57",
		"58",
		"59",
		"5a",
		"5b",
		"5c",
		"5d",
		"5e",
		"5f",
		"60",
		"61",
		"62",
		"63",
		"64",
		"65",
		"66",
		"67",
		"68",
		"69",
		"6a",
		"6b",
		"6c",
		"6d",
		"6e",
		"6f",
		"70",
		"71",
		"72",
		"73",
		"74",
		"75",
		"76",
		"77",
		"78",
		"79",
		"7a",
		"7b",
		"7c",
		"7d",
		"7e",
		"7f",
		"80",
		"81",
		"82",
		"83",
		"84",
		"85",
		"86",
		"87",
		"88",
		"89",
		"8a",
		"8b",
		"8c",
		"8d",
		"8e",
		"8f",
		"90",
		"91",
		"92",
		"93",
		"94",
		"95",
		"96",
		"97",
		"98",
		"99",
		"9a",
		"9b",
		"9c",
		"9d",
		"9e",
		"9f",
		"a0",
		"a1",
		"a2",
		"a3",
		"a4",
		"a5",
		"a6",
		"a7",
		"a8",
		"a9",
		"aa",
		"ab",
		"ac",
		"ad",
		"ae",
		"af",
		"b0",
		"b1",
		"b2",
		"b3",
		"b4",
		"b5",
		"b6",
		"b7",
		"b8",
		"b9",
		"ba",
		"bb",
		"bc",
		"bd",
		"be",
		"bf",
		"c0",
		"c1",
		"c2",
		"c3",
		"c4",
		"c5",
		"c6",
		"c7",
		"c8",
		"c9",
		"ca",
		"cb",
		"cc",
		"cd",
		"ce",
		"cf",
		"d0",
		"d1",
		"d2",
		"d3",
		"d4",
		"d5",
		"d6",
		"d7",
		"d8",
		"d9",
		"da",
		"db",
		"dc",
		"dd",
		"de",
		"df",
		"e0",
		"e1",
		"e2",
		"e3",
		"e4",
		"e5",
		"e6",
		"e7",
		"e8",
		"e9",
		"ea",
		"eb",
		"ec",
		"ed",
		"ee",
		"ef",
		"f0",
		"f1",
		"f2",
		"f3",
		"f4",
		"f5",
		"f6",
		"f7",
		"f8",
		"f9",
		"fa",
		"fb",
		"fc",
		"fd",
		"fe",
		"ff"
	];
	let Wn = 1234567;
	const Xn = Math.PI / 180, jn = 180 / Math.PI;
	function qn() {
		const t = 4294967295 * Math.random() | 0, e = 4294967295 * Math.random() | 0, n = 4294967295 * Math.random() | 0, i = 4294967295 * Math.random() | 0;
		return (Gn[255 & t] + Gn[t >> 8 & 255] + Gn[t >> 16 & 255] + Gn[t >> 24 & 255] + "-" + Gn[255 & e] + Gn[e >> 8 & 255] + "-" + Gn[e >> 16 & 15 | 64] + Gn[e >> 24 & 255] + "-" + Gn[63 & n | 128] + Gn[n >> 8 & 255] + "-" + Gn[n >> 16 & 255] + Gn[n >> 24 & 255] + Gn[255 & i] + Gn[i >> 8 & 255] + Gn[i >> 16 & 255] + Gn[i >> 24 & 255]).toLowerCase();
	}
	function Yn(t, e, n) {
		return Math.max(e, Math.min(n, t));
	}
	function Zn(t, e) {
		return (t % e + e) % e;
	}
	function Jn(t, e, n) {
		return (1 - n) * t + n * e;
	}
	function Kn(t, e) {
		switch (e.constructor) {
			case Float32Array: return t;
			case Uint32Array: return t / 4294967295;
			case Uint16Array: return t / 65535;
			case Uint8Array: return t / 255;
			case Int32Array: return Math.max(t / 2147483647, -1);
			case Int16Array: return Math.max(t / 32767, -1);
			case Int8Array: return Math.max(t / 127, -1);
			default: throw new Error("Invalid component type.");
		}
	}
	function $n(t, e) {
		switch (e.constructor) {
			case Float32Array: return t;
			case Uint32Array: return Math.round(4294967295 * t);
			case Uint16Array: return Math.round(65535 * t);
			case Uint8Array: return Math.round(255 * t);
			case Int32Array: return Math.round(2147483647 * t);
			case Int16Array: return Math.round(32767 * t);
			case Int8Array: return Math.round(127 * t);
			default: throw new Error("Invalid component type.");
		}
	}
	const Qn = {
		DEG2RAD: Xn,
		RAD2DEG: jn,
		generateUUID: qn,
		clamp: Yn,
		euclideanModulo: Zn,
		mapLinear: function(t, e, n, i, r) {
			return i + (t - e) * (r - i) / (n - e);
		},
		inverseLerp: function(t, e, n) {
			return t !== e ? (n - t) / (e - t) : 0;
		},
		lerp: Jn,
		damp: function(t, e, n, i) {
			return Jn(t, e, 1 - Math.exp(-n * i));
		},
		pingpong: function(t, e = 1) {
			return e - Math.abs(Zn(t, 2 * e) - e);
		},
		smoothstep: function(t, e, n) {
			return t <= e ? 0 : t >= n ? 1 : (t = (t - e) / (n - e)) * t * (3 - 2 * t);
		},
		smootherstep: function(t, e, n) {
			return t <= e ? 0 : t >= n ? 1 : (t = (t - e) / (n - e)) * t * t * (t * (6 * t - 15) + 10);
		},
		randInt: function(t, e) {
			return t + Math.floor(Math.random() * (e - t + 1));
		},
		randFloat: function(t, e) {
			return t + Math.random() * (e - t);
		},
		randFloatSpread: function(t) {
			return t * (.5 - Math.random());
		},
		seededRandom: function(t) {
			void 0 !== t && (Wn = t);
			let e = Wn += 1831565813;
			return e = Math.imul(e ^ e >>> 15, 1 | e), e ^= e + Math.imul(e ^ e >>> 7, 61 | e), ((e ^ e >>> 14) >>> 0) / 4294967296;
		},
		degToRad: function(t) {
			return t * Xn;
		},
		radToDeg: function(t) {
			return t * jn;
		},
		isPowerOfTwo: function(t) {
			return 0 == (t & t - 1) && 0 !== t;
		},
		ceilPowerOfTwo: function(t) {
			return Math.pow(2, Math.ceil(Math.log(t) / Math.LN2));
		},
		floorPowerOfTwo: function(t) {
			return Math.pow(2, Math.floor(Math.log(t) / Math.LN2));
		},
		setQuaternionFromProperEuler: function(t, e, n, i, r) {
			const s = Math.cos, a = Math.sin, o = s(n / 2), l = a(n / 2), c = s((e + i) / 2), h = a((e + i) / 2), u = s((e - i) / 2), d = a((e - i) / 2), p = s((i - e) / 2), m = a((i - e) / 2);
			switch (r) {
				case "XYX":
					t.set(o * h, l * u, l * d, o * c);
					break;
				case "YZY":
					t.set(l * d, o * h, l * u, o * c);
					break;
				case "ZXZ":
					t.set(l * u, l * d, o * h, o * c);
					break;
				case "XZX":
					t.set(o * h, l * m, l * p, o * c);
					break;
				case "YXY":
					t.set(l * p, o * h, l * m, o * c);
					break;
				case "ZYZ":
					t.set(l * m, l * p, o * h, o * c);
					break;
				default: console.warn("THREE.MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: " + r);
			}
		},
		normalize: $n,
		denormalize: Kn
	};
	var ti = class ti {
		constructor(t = 0, e = 0) {
			ti.prototype.isVector2 = !0, this.x = t, this.y = e;
		}
		get width() {
			return this.x;
		}
		set width(t) {
			this.x = t;
		}
		get height() {
			return this.y;
		}
		set height(t) {
			this.y = t;
		}
		set(t, e) {
			return this.x = t, this.y = e, this;
		}
		setScalar(t) {
			return this.x = t, this.y = t, this;
		}
		setX(t) {
			return this.x = t, this;
		}
		setY(t) {
			return this.y = t, this;
		}
		setComponent(t, e) {
			switch (t) {
				case 0:
					this.x = e;
					break;
				case 1:
					this.y = e;
					break;
				default: throw new Error("index is out of range: " + t);
			}
			return this;
		}
		getComponent(t) {
			switch (t) {
				case 0: return this.x;
				case 1: return this.y;
				default: throw new Error("index is out of range: " + t);
			}
		}
		clone() {
			return new this.constructor(this.x, this.y);
		}
		copy(t) {
			return this.x = t.x, this.y = t.y, this;
		}
		add(t) {
			return this.x += t.x, this.y += t.y, this;
		}
		addScalar(t) {
			return this.x += t, this.y += t, this;
		}
		addVectors(t, e) {
			return this.x = t.x + e.x, this.y = t.y + e.y, this;
		}
		addScaledVector(t, e) {
			return this.x += t.x * e, this.y += t.y * e, this;
		}
		sub(t) {
			return this.x -= t.x, this.y -= t.y, this;
		}
		subScalar(t) {
			return this.x -= t, this.y -= t, this;
		}
		subVectors(t, e) {
			return this.x = t.x - e.x, this.y = t.y - e.y, this;
		}
		multiply(t) {
			return this.x *= t.x, this.y *= t.y, this;
		}
		multiplyScalar(t) {
			return this.x *= t, this.y *= t, this;
		}
		divide(t) {
			return this.x /= t.x, this.y /= t.y, this;
		}
		divideScalar(t) {
			return this.multiplyScalar(1 / t);
		}
		applyMatrix3(t) {
			const e = this.x, n = this.y, i = t.elements;
			return this.x = i[0] * e + i[3] * n + i[6], this.y = i[1] * e + i[4] * n + i[7], this;
		}
		min(t) {
			return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this;
		}
		max(t) {
			return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this;
		}
		clamp(t, e) {
			return this.x = Math.max(t.x, Math.min(e.x, this.x)), this.y = Math.max(t.y, Math.min(e.y, this.y)), this;
		}
		clampScalar(t, e) {
			return this.x = Math.max(t, Math.min(e, this.x)), this.y = Math.max(t, Math.min(e, this.y)), this;
		}
		clampLength(t, e) {
			const n = this.length();
			return this.divideScalar(n || 1).multiplyScalar(Math.max(t, Math.min(e, n)));
		}
		floor() {
			return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this;
		}
		ceil() {
			return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this;
		}
		round() {
			return this.x = Math.round(this.x), this.y = Math.round(this.y), this;
		}
		roundToZero() {
			return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this;
		}
		negate() {
			return this.x = -this.x, this.y = -this.y, this;
		}
		dot(t) {
			return this.x * t.x + this.y * t.y;
		}
		cross(t) {
			return this.x * t.y - this.y * t.x;
		}
		lengthSq() {
			return this.x * this.x + this.y * this.y;
		}
		length() {
			return Math.sqrt(this.x * this.x + this.y * this.y);
		}
		manhattanLength() {
			return Math.abs(this.x) + Math.abs(this.y);
		}
		normalize() {
			return this.divideScalar(this.length() || 1);
		}
		angle() {
			return Math.atan2(-this.y, -this.x) + Math.PI;
		}
		angleTo(t) {
			const e = Math.sqrt(this.lengthSq() * t.lengthSq());
			if (0 === e) return Math.PI / 2;
			const n = this.dot(t) / e;
			return Math.acos(Yn(n, -1, 1));
		}
		distanceTo(t) {
			return Math.sqrt(this.distanceToSquared(t));
		}
		distanceToSquared(t) {
			const e = this.x - t.x, n = this.y - t.y;
			return e * e + n * n;
		}
		manhattanDistanceTo(t) {
			return Math.abs(this.x - t.x) + Math.abs(this.y - t.y);
		}
		setLength(t) {
			return this.normalize().multiplyScalar(t);
		}
		lerp(t, e) {
			return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this;
		}
		lerpVectors(t, e, n) {
			return this.x = t.x + (e.x - t.x) * n, this.y = t.y + (e.y - t.y) * n, this;
		}
		equals(t) {
			return t.x === this.x && t.y === this.y;
		}
		fromArray(t, e = 0) {
			return this.x = t[e], this.y = t[e + 1], this;
		}
		toArray(t = [], e = 0) {
			return t[e] = this.x, t[e + 1] = this.y, t;
		}
		fromBufferAttribute(t, e) {
			return this.x = t.getX(e), this.y = t.getY(e), this;
		}
		rotateAround(t, e) {
			const n = Math.cos(e), i = Math.sin(e), r = this.x - t.x, s = this.y - t.y;
			return this.x = r * n - s * i + t.x, this.y = r * i + s * n + t.y, this;
		}
		random() {
			return this.x = Math.random(), this.y = Math.random(), this;
		}
		*[Symbol.iterator]() {
			yield this.x, yield this.y;
		}
	};
	var ei = class ei {
		constructor(t, e, n, i, r, s, a, o, l) {
			ei.prototype.isMatrix3 = !0, this.elements = [
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			], void 0 !== t && this.set(t, e, n, i, r, s, a, o, l);
		}
		set(t, e, n, i, r, s, a, o, l) {
			const c = this.elements;
			return c[0] = t, c[1] = i, c[2] = a, c[3] = e, c[4] = r, c[5] = o, c[6] = n, c[7] = s, c[8] = l, this;
		}
		identity() {
			return this.set(1, 0, 0, 0, 1, 0, 0, 0, 1), this;
		}
		copy(t) {
			const e = this.elements, n = t.elements;
			return e[0] = n[0], e[1] = n[1], e[2] = n[2], e[3] = n[3], e[4] = n[4], e[5] = n[5], e[6] = n[6], e[7] = n[7], e[8] = n[8], this;
		}
		extractBasis(t, e, n) {
			return t.setFromMatrix3Column(this, 0), e.setFromMatrix3Column(this, 1), n.setFromMatrix3Column(this, 2), this;
		}
		setFromMatrix4(t) {
			const e = t.elements;
			return this.set(e[0], e[4], e[8], e[1], e[5], e[9], e[2], e[6], e[10]), this;
		}
		multiply(t) {
			return this.multiplyMatrices(this, t);
		}
		premultiply(t) {
			return this.multiplyMatrices(t, this);
		}
		multiplyMatrices(t, e) {
			const n = t.elements, i = e.elements, r = this.elements, s = n[0], a = n[3], o = n[6], l = n[1], c = n[4], h = n[7], u = n[2], d = n[5], p = n[8], m = i[0], f = i[3], g = i[6], v = i[1], _ = i[4], x = i[7], y = i[2], M = i[5], S = i[8];
			return r[0] = s * m + a * v + o * y, r[3] = s * f + a * _ + o * M, r[6] = s * g + a * x + o * S, r[1] = l * m + c * v + h * y, r[4] = l * f + c * _ + h * M, r[7] = l * g + c * x + h * S, r[2] = u * m + d * v + p * y, r[5] = u * f + d * _ + p * M, r[8] = u * g + d * x + p * S, this;
		}
		multiplyScalar(t) {
			const e = this.elements;
			return e[0] *= t, e[3] *= t, e[6] *= t, e[1] *= t, e[4] *= t, e[7] *= t, e[2] *= t, e[5] *= t, e[8] *= t, this;
		}
		determinant() {
			const t = this.elements, e = t[0], n = t[1], i = t[2], r = t[3], s = t[4], a = t[5], o = t[6], l = t[7], c = t[8];
			return e * s * c - e * a * l - n * r * c + n * a * o + i * r * l - i * s * o;
		}
		invert() {
			const t = this.elements, e = t[0], n = t[1], i = t[2], r = t[3], s = t[4], a = t[5], o = t[6], l = t[7], c = t[8], h = c * s - a * l, u = a * o - c * r, d = l * r - s * o, p = e * h + n * u + i * d;
			if (0 === p) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0);
			const m = 1 / p;
			return t[0] = h * m, t[1] = (i * l - c * n) * m, t[2] = (a * n - i * s) * m, t[3] = u * m, t[4] = (c * e - i * o) * m, t[5] = (i * r - a * e) * m, t[6] = d * m, t[7] = (n * o - l * e) * m, t[8] = (s * e - n * r) * m, this;
		}
		transpose() {
			let t;
			const e = this.elements;
			return t = e[1], e[1] = e[3], e[3] = t, t = e[2], e[2] = e[6], e[6] = t, t = e[5], e[5] = e[7], e[7] = t, this;
		}
		getNormalMatrix(t) {
			return this.setFromMatrix4(t).invert().transpose();
		}
		transposeIntoArray(t) {
			const e = this.elements;
			return t[0] = e[0], t[1] = e[3], t[2] = e[6], t[3] = e[1], t[4] = e[4], t[5] = e[7], t[6] = e[2], t[7] = e[5], t[8] = e[8], this;
		}
		setUvTransform(t, e, n, i, r, s, a) {
			const o = Math.cos(r), l = Math.sin(r);
			return this.set(n * o, n * l, -n * (o * s + l * a) + s + t, -i * l, i * o, -i * (-l * s + o * a) + a + e, 0, 0, 1), this;
		}
		scale(t, e) {
			return this.premultiply(ni.makeScale(t, e)), this;
		}
		rotate(t) {
			return this.premultiply(ni.makeRotation(-t)), this;
		}
		translate(t, e) {
			return this.premultiply(ni.makeTranslation(t, e)), this;
		}
		makeTranslation(t, e) {
			return t.isVector2 ? this.set(1, 0, t.x, 0, 1, t.y, 0, 0, 1) : this.set(1, 0, t, 0, 1, e, 0, 0, 1), this;
		}
		makeRotation(t) {
			const e = Math.cos(t), n = Math.sin(t);
			return this.set(e, -n, 0, n, e, 0, 0, 0, 1), this;
		}
		makeScale(t, e) {
			return this.set(t, 0, 0, 0, e, 0, 0, 0, 1), this;
		}
		equals(t) {
			const e = this.elements, n = t.elements;
			for (let t = 0; t < 9; t++) if (e[t] !== n[t]) return !1;
			return !0;
		}
		fromArray(t, e = 0) {
			for (let n = 0; n < 9; n++) this.elements[n] = t[n + e];
			return this;
		}
		toArray(t = [], e = 0) {
			const n = this.elements;
			return t[e] = n[0], t[e + 1] = n[1], t[e + 2] = n[2], t[e + 3] = n[3], t[e + 4] = n[4], t[e + 5] = n[5], t[e + 6] = n[6], t[e + 7] = n[7], t[e + 8] = n[8], t;
		}
		clone() {
			return new this.constructor().fromArray(this.elements);
		}
	};
	const ni = new ei();
	function ii(t) {
		for (let e = t.length - 1; e >= 0; --e) if (t[e] >= 65535) return !0;
		return !1;
	}
	const ri = {
		Int8Array,
		Uint8Array,
		Uint8ClampedArray,
		Int16Array,
		Uint16Array,
		Int32Array,
		Uint32Array,
		Float32Array,
		Float64Array
	};
	function si(t, e) {
		return new ri[t](e);
	}
	function ai(t) {
		return document.createElementNS("http://www.w3.org/1999/xhtml", t);
	}
	function oi() {
		const t = ai("canvas");
		return t.style.display = "block", t;
	}
	const li = {};
	function ci(t) {
		t in li || (li[t] = !0, console.warn(t));
	}
	const hi = new ei().set(.8224621, .177538, 0, .0331941, .9668058, 0, .0170827, .0723974, .9105199), ui = new ei().set(1.2249401, -.2249404, 0, -.0420569, 1.0420571, 0, -.0196376, -.0786361, 1.0982735), di = {
		[Ke]: {
			transfer: tn,
			primaries: nn,
			luminanceCoefficients: [
				.2126,
				.7152,
				.0722
			],
			toReference: (t) => t,
			fromReference: (t) => t
		},
		[Je]: {
			transfer: en,
			primaries: nn,
			luminanceCoefficients: [
				.2126,
				.7152,
				.0722
			],
			toReference: (t) => t.convertSRGBToLinear(),
			fromReference: (t) => t.convertLinearToSRGB()
		},
		[Qe]: {
			transfer: tn,
			primaries: "p3",
			luminanceCoefficients: [
				.2289,
				.6917,
				.0793
			],
			toReference: (t) => t.applyMatrix3(ui),
			fromReference: (t) => t.applyMatrix3(hi)
		},
		[$e]: {
			transfer: en,
			primaries: "p3",
			luminanceCoefficients: [
				.2289,
				.6917,
				.0793
			],
			toReference: (t) => t.convertSRGBToLinear().applyMatrix3(ui),
			fromReference: (t) => t.applyMatrix3(hi).convertLinearToSRGB()
		}
	}, pi = new Set([Ke, Qe]), mi = {
		enabled: !0,
		_workingColorSpace: Ke,
		get workingColorSpace() {
			return this._workingColorSpace;
		},
		set workingColorSpace(t) {
			if (!pi.has(t)) throw new Error(`Unsupported working color space, "${t}".`);
			this._workingColorSpace = t;
		},
		convert: function(t, e, n) {
			if (!1 === this.enabled || e === n || !e || !n) return t;
			const i = di[e].toReference;
			return (0, di[n].fromReference)(i(t));
		},
		fromWorkingColorSpace: function(t, e) {
			return this.convert(t, this._workingColorSpace, e);
		},
		toWorkingColorSpace: function(t, e) {
			return this.convert(t, e, this._workingColorSpace);
		},
		getPrimaries: function(t) {
			return di[t].primaries;
		},
		getTransfer: function(t) {
			return t === "" ? tn : di[t].transfer;
		},
		getLuminanceCoefficients: function(t, e = this._workingColorSpace) {
			return t.fromArray(di[e].luminanceCoefficients);
		}
	};
	function fi(t) {
		return t < .04045 ? .0773993808 * t : Math.pow(.9478672986 * t + .0521327014, 2.4);
	}
	function gi(t) {
		return t < .0031308 ? 12.92 * t : 1.055 * Math.pow(t, .41666) - .055;
	}
	let vi;
	var _i = class {
		static getDataURL(t) {
			if (/^data:/i.test(t.src)) return t.src;
			if ("undefined" == typeof HTMLCanvasElement) return t.src;
			let e;
			if (t instanceof HTMLCanvasElement) e = t;
			else {
				void 0 === vi && (vi = ai("canvas")), vi.width = t.width, vi.height = t.height;
				const n = vi.getContext("2d");
				t instanceof ImageData ? n.putImageData(t, 0, 0) : n.drawImage(t, 0, 0, t.width, t.height), e = vi;
			}
			return e.width > 2048 || e.height > 2048 ? (console.warn("THREE.ImageUtils.getDataURL: Image converted to jpg for performance reasons", t), e.toDataURL("image/jpeg", .6)) : e.toDataURL("image/png");
		}
		static sRGBToLinear(t) {
			if ("undefined" != typeof HTMLImageElement && t instanceof HTMLImageElement || "undefined" != typeof HTMLCanvasElement && t instanceof HTMLCanvasElement || "undefined" != typeof ImageBitmap && t instanceof ImageBitmap) {
				const e = ai("canvas");
				e.width = t.width, e.height = t.height;
				const n = e.getContext("2d");
				n.drawImage(t, 0, 0, t.width, t.height);
				const i = n.getImageData(0, 0, t.width, t.height), r = i.data;
				for (let t = 0; t < r.length; t++) r[t] = 255 * fi(r[t] / 255);
				return n.putImageData(i, 0, 0), e;
			}
			if (t.data) {
				const e = t.data.slice(0);
				for (let t = 0; t < e.length; t++) e instanceof Uint8Array || e instanceof Uint8ClampedArray ? e[t] = Math.floor(255 * fi(e[t] / 255)) : e[t] = fi(e[t]);
				return {
					data: e,
					width: t.width,
					height: t.height
				};
			}
			return console.warn("THREE.ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."), t;
		}
	};
	let xi = 0;
	var yi = class {
		constructor(t = null) {
			this.isSource = !0, Object.defineProperty(this, "id", { value: xi++ }), this.uuid = qn(), this.data = t, this.dataReady = !0, this.version = 0;
		}
		set needsUpdate(t) {
			!0 === t && this.version++;
		}
		toJSON(t) {
			const e = void 0 === t || "string" == typeof t;
			if (!e && void 0 !== t.images[this.uuid]) return t.images[this.uuid];
			const n = {
				uuid: this.uuid,
				url: ""
			}, i = this.data;
			if (null !== i) {
				let t;
				if (Array.isArray(i)) {
					t = [];
					for (let e = 0, n = i.length; e < n; e++) i[e].isDataTexture ? t.push(Mi(i[e].image)) : t.push(Mi(i[e]));
				} else t = Mi(i);
				n.url = t;
			}
			return e || (t.images[this.uuid] = n), n;
		}
	};
	function Mi(t) {
		return "undefined" != typeof HTMLImageElement && t instanceof HTMLImageElement || "undefined" != typeof HTMLCanvasElement && t instanceof HTMLCanvasElement || "undefined" != typeof ImageBitmap && t instanceof ImageBitmap ? _i.getDataURL(t) : t.data ? {
			data: Array.from(t.data),
			width: t.width,
			height: t.height,
			type: t.data.constructor.name
		} : (console.warn("THREE.Texture: Unable to serialize Texture."), {});
	}
	let Si = 0;
	var bi = class bi extends Hn {
		constructor(t = bi.DEFAULT_IMAGE, e = bi.DEFAULT_MAPPING, n = 1001, i = 1001, r = 1006, s = 1008, a = kt, o = Et, l = bi.DEFAULT_ANISOTROPY, c = "") {
			super(), this.isTexture = !0, Object.defineProperty(this, "id", { value: Si++ }), this.uuid = qn(), this.name = "", this.source = new yi(t), this.mipmaps = [], this.mapping = e, this.channel = 0, this.wrapS = n, this.wrapT = i, this.magFilter = r, this.minFilter = s, this.anisotropy = l, this.format = a, this.internalFormat = null, this.type = o, this.offset = new ti(0, 0), this.repeat = new ti(1, 1), this.center = new ti(0, 0), this.rotation = 0, this.matrixAutoUpdate = !0, this.matrix = new ei(), this.generateMipmaps = !0, this.premultiplyAlpha = !1, this.flipY = !0, this.unpackAlignment = 4, this.colorSpace = c, this.userData = {}, this.version = 0, this.onUpdate = null, this.isRenderTargetTexture = !1, this.pmremVersion = 0;
		}
		get image() {
			return this.source.data;
		}
		set image(t = null) {
			this.source.data = t;
		}
		updateMatrix() {
			this.matrix.setUvTransform(this.offset.x, this.offset.y, this.repeat.x, this.repeat.y, this.rotation, this.center.x, this.center.y);
		}
		clone() {
			return new this.constructor().copy(this);
		}
		copy(t) {
			return this.name = t.name, this.source = t.source, this.mipmaps = t.mipmaps.slice(0), this.mapping = t.mapping, this.channel = t.channel, this.wrapS = t.wrapS, this.wrapT = t.wrapT, this.magFilter = t.magFilter, this.minFilter = t.minFilter, this.anisotropy = t.anisotropy, this.format = t.format, this.internalFormat = t.internalFormat, this.type = t.type, this.offset.copy(t.offset), this.repeat.copy(t.repeat), this.center.copy(t.center), this.rotation = t.rotation, this.matrixAutoUpdate = t.matrixAutoUpdate, this.matrix.copy(t.matrix), this.generateMipmaps = t.generateMipmaps, this.premultiplyAlpha = t.premultiplyAlpha, this.flipY = t.flipY, this.unpackAlignment = t.unpackAlignment, this.colorSpace = t.colorSpace, this.userData = JSON.parse(JSON.stringify(t.userData)), this.needsUpdate = !0, this;
		}
		toJSON(t) {
			const e = void 0 === t || "string" == typeof t;
			if (!e && void 0 !== t.textures[this.uuid]) return t.textures[this.uuid];
			const n = {
				metadata: {
					version: 4.6,
					type: "Texture",
					generator: "Texture.toJSON"
				},
				uuid: this.uuid,
				name: this.name,
				image: this.source.toJSON(t).uuid,
				mapping: this.mapping,
				channel: this.channel,
				repeat: [this.repeat.x, this.repeat.y],
				offset: [this.offset.x, this.offset.y],
				center: [this.center.x, this.center.y],
				rotation: this.rotation,
				wrap: [this.wrapS, this.wrapT],
				format: this.format,
				internalFormat: this.internalFormat,
				type: this.type,
				colorSpace: this.colorSpace,
				minFilter: this.minFilter,
				magFilter: this.magFilter,
				anisotropy: this.anisotropy,
				flipY: this.flipY,
				generateMipmaps: this.generateMipmaps,
				premultiplyAlpha: this.premultiplyAlpha,
				unpackAlignment: this.unpackAlignment
			};
			return Object.keys(this.userData).length > 0 && (n.userData = this.userData), e || (t.textures[this.uuid] = n), n;
		}
		dispose() {
			this.dispatchEvent({ type: "dispose" });
		}
		transformUv(t) {
			if (this.mapping !== 300) return t;
			if (t.applyMatrix3(this.matrix), t.x < 0 || t.x > 1) switch (this.wrapS) {
				case pt:
					t.x = t.x - Math.floor(t.x);
					break;
				case mt:
					t.x = t.x < 0 ? 0 : 1;
					break;
				case ft: 1 === Math.abs(Math.floor(t.x) % 2) ? t.x = Math.ceil(t.x) - t.x : t.x = t.x - Math.floor(t.x);
			}
			if (t.y < 0 || t.y > 1) switch (this.wrapT) {
				case pt:
					t.y = t.y - Math.floor(t.y);
					break;
				case mt:
					t.y = t.y < 0 ? 0 : 1;
					break;
				case ft: 1 === Math.abs(Math.floor(t.y) % 2) ? t.y = Math.ceil(t.y) - t.y : t.y = t.y - Math.floor(t.y);
			}
			return this.flipY && (t.y = 1 - t.y), t;
		}
		set needsUpdate(t) {
			!0 === t && (this.version++, this.source.needsUpdate = !0);
		}
		set needsPMREMUpdate(t) {
			!0 === t && this.pmremVersion++;
		}
	};
	bi.DEFAULT_IMAGE = null, bi.DEFAULT_MAPPING = 300, bi.DEFAULT_ANISOTROPY = 1;
	var wi = class wi {
		constructor(t = 0, e = 0, n = 0, i = 1) {
			wi.prototype.isVector4 = !0, this.x = t, this.y = e, this.z = n, this.w = i;
		}
		get width() {
			return this.z;
		}
		set width(t) {
			this.z = t;
		}
		get height() {
			return this.w;
		}
		set height(t) {
			this.w = t;
		}
		set(t, e, n, i) {
			return this.x = t, this.y = e, this.z = n, this.w = i, this;
		}
		setScalar(t) {
			return this.x = t, this.y = t, this.z = t, this.w = t, this;
		}
		setX(t) {
			return this.x = t, this;
		}
		setY(t) {
			return this.y = t, this;
		}
		setZ(t) {
			return this.z = t, this;
		}
		setW(t) {
			return this.w = t, this;
		}
		setComponent(t, e) {
			switch (t) {
				case 0:
					this.x = e;
					break;
				case 1:
					this.y = e;
					break;
				case 2:
					this.z = e;
					break;
				case 3:
					this.w = e;
					break;
				default: throw new Error("index is out of range: " + t);
			}
			return this;
		}
		getComponent(t) {
			switch (t) {
				case 0: return this.x;
				case 1: return this.y;
				case 2: return this.z;
				case 3: return this.w;
				default: throw new Error("index is out of range: " + t);
			}
		}
		clone() {
			return new this.constructor(this.x, this.y, this.z, this.w);
		}
		copy(t) {
			return this.x = t.x, this.y = t.y, this.z = t.z, this.w = void 0 !== t.w ? t.w : 1, this;
		}
		add(t) {
			return this.x += t.x, this.y += t.y, this.z += t.z, this.w += t.w, this;
		}
		addScalar(t) {
			return this.x += t, this.y += t, this.z += t, this.w += t, this;
		}
		addVectors(t, e) {
			return this.x = t.x + e.x, this.y = t.y + e.y, this.z = t.z + e.z, this.w = t.w + e.w, this;
		}
		addScaledVector(t, e) {
			return this.x += t.x * e, this.y += t.y * e, this.z += t.z * e, this.w += t.w * e, this;
		}
		sub(t) {
			return this.x -= t.x, this.y -= t.y, this.z -= t.z, this.w -= t.w, this;
		}
		subScalar(t) {
			return this.x -= t, this.y -= t, this.z -= t, this.w -= t, this;
		}
		subVectors(t, e) {
			return this.x = t.x - e.x, this.y = t.y - e.y, this.z = t.z - e.z, this.w = t.w - e.w, this;
		}
		multiply(t) {
			return this.x *= t.x, this.y *= t.y, this.z *= t.z, this.w *= t.w, this;
		}
		multiplyScalar(t) {
			return this.x *= t, this.y *= t, this.z *= t, this.w *= t, this;
		}
		applyMatrix4(t) {
			const e = this.x, n = this.y, i = this.z, r = this.w, s = t.elements;
			return this.x = s[0] * e + s[4] * n + s[8] * i + s[12] * r, this.y = s[1] * e + s[5] * n + s[9] * i + s[13] * r, this.z = s[2] * e + s[6] * n + s[10] * i + s[14] * r, this.w = s[3] * e + s[7] * n + s[11] * i + s[15] * r, this;
		}
		divideScalar(t) {
			return this.multiplyScalar(1 / t);
		}
		setAxisAngleFromQuaternion(t) {
			this.w = 2 * Math.acos(t.w);
			const e = Math.sqrt(1 - t.w * t.w);
			return e < 1e-4 ? (this.x = 1, this.y = 0, this.z = 0) : (this.x = t.x / e, this.y = t.y / e, this.z = t.z / e), this;
		}
		setAxisAngleFromRotationMatrix(t) {
			let e, n, i, r;
			const s = .01, a = .1, o = t.elements, l = o[0], c = o[4], h = o[8], u = o[1], d = o[5], p = o[9], m = o[2], f = o[6], g = o[10];
			if (Math.abs(c - u) < s && Math.abs(h - m) < s && Math.abs(p - f) < s) {
				if (Math.abs(c + u) < a && Math.abs(h + m) < a && Math.abs(p + f) < a && Math.abs(l + d + g - 3) < a) return this.set(1, 0, 0, 0), this;
				e = Math.PI;
				const t = (l + 1) / 2, o = (d + 1) / 2, v = (g + 1) / 2, _ = (c + u) / 4, x = (h + m) / 4, y = (p + f) / 4;
				return t > o && t > v ? t < s ? (n = 0, i = .707106781, r = .707106781) : (n = Math.sqrt(t), i = _ / n, r = x / n) : o > v ? o < s ? (n = .707106781, i = 0, r = .707106781) : (i = Math.sqrt(o), n = _ / i, r = y / i) : v < s ? (n = .707106781, i = .707106781, r = 0) : (r = Math.sqrt(v), n = x / r, i = y / r), this.set(n, i, r, e), this;
			}
			let v = Math.sqrt((f - p) * (f - p) + (h - m) * (h - m) + (u - c) * (u - c));
			return Math.abs(v) < .001 && (v = 1), this.x = (f - p) / v, this.y = (h - m) / v, this.z = (u - c) / v, this.w = Math.acos((l + d + g - 1) / 2), this;
		}
		setFromMatrixPosition(t) {
			const e = t.elements;
			return this.x = e[12], this.y = e[13], this.z = e[14], this.w = e[15], this;
		}
		min(t) {
			return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this.z = Math.min(this.z, t.z), this.w = Math.min(this.w, t.w), this;
		}
		max(t) {
			return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this.z = Math.max(this.z, t.z), this.w = Math.max(this.w, t.w), this;
		}
		clamp(t, e) {
			return this.x = Math.max(t.x, Math.min(e.x, this.x)), this.y = Math.max(t.y, Math.min(e.y, this.y)), this.z = Math.max(t.z, Math.min(e.z, this.z)), this.w = Math.max(t.w, Math.min(e.w, this.w)), this;
		}
		clampScalar(t, e) {
			return this.x = Math.max(t, Math.min(e, this.x)), this.y = Math.max(t, Math.min(e, this.y)), this.z = Math.max(t, Math.min(e, this.z)), this.w = Math.max(t, Math.min(e, this.w)), this;
		}
		clampLength(t, e) {
			const n = this.length();
			return this.divideScalar(n || 1).multiplyScalar(Math.max(t, Math.min(e, n)));
		}
		floor() {
			return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), this.w = Math.floor(this.w), this;
		}
		ceil() {
			return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), this.w = Math.ceil(this.w), this;
		}
		round() {
			return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), this.w = Math.round(this.w), this;
		}
		roundToZero() {
			return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this.z = Math.trunc(this.z), this.w = Math.trunc(this.w), this;
		}
		negate() {
			return this.x = -this.x, this.y = -this.y, this.z = -this.z, this.w = -this.w, this;
		}
		dot(t) {
			return this.x * t.x + this.y * t.y + this.z * t.z + this.w * t.w;
		}
		lengthSq() {
			return this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w;
		}
		length() {
			return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z + this.w * this.w);
		}
		manhattanLength() {
			return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z) + Math.abs(this.w);
		}
		normalize() {
			return this.divideScalar(this.length() || 1);
		}
		setLength(t) {
			return this.normalize().multiplyScalar(t);
		}
		lerp(t, e) {
			return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this.z += (t.z - this.z) * e, this.w += (t.w - this.w) * e, this;
		}
		lerpVectors(t, e, n) {
			return this.x = t.x + (e.x - t.x) * n, this.y = t.y + (e.y - t.y) * n, this.z = t.z + (e.z - t.z) * n, this.w = t.w + (e.w - t.w) * n, this;
		}
		equals(t) {
			return t.x === this.x && t.y === this.y && t.z === this.z && t.w === this.w;
		}
		fromArray(t, e = 0) {
			return this.x = t[e], this.y = t[e + 1], this.z = t[e + 2], this.w = t[e + 3], this;
		}
		toArray(t = [], e = 0) {
			return t[e] = this.x, t[e + 1] = this.y, t[e + 2] = this.z, t[e + 3] = this.w, t;
		}
		fromBufferAttribute(t, e) {
			return this.x = t.getX(e), this.y = t.getY(e), this.z = t.getZ(e), this.w = t.getW(e), this;
		}
		random() {
			return this.x = Math.random(), this.y = Math.random(), this.z = Math.random(), this.w = Math.random(), this;
		}
		*[Symbol.iterator]() {
			yield this.x, yield this.y, yield this.z, yield this.w;
		}
	};
	var Ti = class extends Hn {
		constructor(t = 1, e = 1, n = {}) {
			super(), this.isRenderTarget = !0, this.width = t, this.height = e, this.depth = 1, this.scissor = new wi(0, 0, t, e), this.scissorTest = !1, this.viewport = new wi(0, 0, t, e);
			const i = {
				width: t,
				height: e,
				depth: 1
			};
			n = Object.assign({
				generateMipmaps: !1,
				internalFormat: null,
				minFilter: Mt,
				depthBuffer: !0,
				stencilBuffer: !1,
				resolveDepthBuffer: !0,
				resolveStencilBuffer: !0,
				depthTexture: null,
				samples: 0,
				count: 1
			}, n);
			const r = new bi(i, n.mapping, n.wrapS, n.wrapT, n.magFilter, n.minFilter, n.format, n.type, n.anisotropy, n.colorSpace);
			r.flipY = !1, r.generateMipmaps = n.generateMipmaps, r.internalFormat = n.internalFormat, this.textures = [];
			const s = n.count;
			for (let t = 0; t < s; t++) this.textures[t] = r.clone(), this.textures[t].isRenderTargetTexture = !0;
			this.depthBuffer = n.depthBuffer, this.stencilBuffer = n.stencilBuffer, this.resolveDepthBuffer = n.resolveDepthBuffer, this.resolveStencilBuffer = n.resolveStencilBuffer, this.depthTexture = n.depthTexture, this.samples = n.samples;
		}
		get texture() {
			return this.textures[0];
		}
		set texture(t) {
			this.textures[0] = t;
		}
		setSize(t, e, n = 1) {
			if (this.width !== t || this.height !== e || this.depth !== n) {
				this.width = t, this.height = e, this.depth = n;
				for (let i = 0, r = this.textures.length; i < r; i++) this.textures[i].image.width = t, this.textures[i].image.height = e, this.textures[i].image.depth = n;
				this.dispose();
			}
			this.viewport.set(0, 0, t, e), this.scissor.set(0, 0, t, e);
		}
		clone() {
			return new this.constructor().copy(this);
		}
		copy(t) {
			this.width = t.width, this.height = t.height, this.depth = t.depth, this.scissor.copy(t.scissor), this.scissorTest = t.scissorTest, this.viewport.copy(t.viewport), this.textures.length = 0;
			for (let e = 0, n = t.textures.length; e < n; e++) this.textures[e] = t.textures[e].clone(), this.textures[e].isRenderTargetTexture = !0;
			const e = Object.assign({}, t.texture.image);
			return this.texture.source = new yi(e), this.depthBuffer = t.depthBuffer, this.stencilBuffer = t.stencilBuffer, this.resolveDepthBuffer = t.resolveDepthBuffer, this.resolveStencilBuffer = t.resolveStencilBuffer, null !== t.depthTexture && (this.depthTexture = t.depthTexture.clone()), this.samples = t.samples, this;
		}
		dispose() {
			this.dispatchEvent({ type: "dispose" });
		}
	};
	var Ei = class extends Ti {
		constructor(t = 1, e = 1, n = {}) {
			super(t, e, n), this.isWebGLRenderTarget = !0;
		}
	};
	var Ai = class extends bi {
		constructor(t = null, e = 1, n = 1, i = 1) {
			super(null), this.isDataArrayTexture = !0, this.image = {
				data: t,
				width: e,
				height: n,
				depth: i
			}, this.magFilter = gt, this.minFilter = gt, this.wrapR = mt, this.generateMipmaps = !1, this.flipY = !1, this.unpackAlignment = 1, this.layerUpdates = /* @__PURE__ */ new Set();
		}
		addLayerUpdate(t) {
			this.layerUpdates.add(t);
		}
		clearLayerUpdates() {
			this.layerUpdates.clear();
		}
	};
	var Ri = class extends Ei {
		constructor(t = 1, e = 1, n = 1, i = {}) {
			super(t, e, i), this.isWebGLArrayRenderTarget = !0, this.depth = n, this.texture = new Ai(null, t, e, n), this.texture.isRenderTargetTexture = !0;
		}
	};
	var Ci = class extends bi {
		constructor(t = null, e = 1, n = 1, i = 1) {
			super(null), this.isData3DTexture = !0, this.image = {
				data: t,
				width: e,
				height: n,
				depth: i
			}, this.magFilter = gt, this.minFilter = gt, this.wrapR = mt, this.generateMipmaps = !1, this.flipY = !1, this.unpackAlignment = 1;
		}
	};
	var Pi = class extends Ei {
		constructor(t = 1, e = 1, n = 1, i = {}) {
			super(t, e, i), this.isWebGL3DRenderTarget = !0, this.depth = n, this.texture = new Ci(null, t, e, n), this.texture.isRenderTargetTexture = !0;
		}
	};
	var Ii = class {
		constructor(t = 0, e = 0, n = 0, i = 1) {
			this.isQuaternion = !0, this._x = t, this._y = e, this._z = n, this._w = i;
		}
		static slerpFlat(t, e, n, i, r, s, a) {
			let o = n[i + 0], l = n[i + 1], c = n[i + 2], h = n[i + 3];
			const u = r[s + 0], d = r[s + 1], p = r[s + 2], m = r[s + 3];
			if (0 === a) return t[e + 0] = o, t[e + 1] = l, t[e + 2] = c, void (t[e + 3] = h);
			if (1 === a) return t[e + 0] = u, t[e + 1] = d, t[e + 2] = p, void (t[e + 3] = m);
			if (h !== m || o !== u || l !== d || c !== p) {
				let t = 1 - a;
				const e = o * u + l * d + c * p + h * m, n = e >= 0 ? 1 : -1, i = 1 - e * e;
				if (i > Number.EPSILON) {
					const r = Math.sqrt(i), s = Math.atan2(r, e * n);
					t = Math.sin(t * s) / r, a = Math.sin(a * s) / r;
				}
				const r = a * n;
				if (o = o * t + u * r, l = l * t + d * r, c = c * t + p * r, h = h * t + m * r, t === 1 - a) {
					const t = 1 / Math.sqrt(o * o + l * l + c * c + h * h);
					o *= t, l *= t, c *= t, h *= t;
				}
			}
			t[e] = o, t[e + 1] = l, t[e + 2] = c, t[e + 3] = h;
		}
		static multiplyQuaternionsFlat(t, e, n, i, r, s) {
			const a = n[i], o = n[i + 1], l = n[i + 2], c = n[i + 3], h = r[s], u = r[s + 1], d = r[s + 2], p = r[s + 3];
			return t[e] = a * p + c * h + o * d - l * u, t[e + 1] = o * p + c * u + l * h - a * d, t[e + 2] = l * p + c * d + a * u - o * h, t[e + 3] = c * p - a * h - o * u - l * d, t;
		}
		get x() {
			return this._x;
		}
		set x(t) {
			this._x = t, this._onChangeCallback();
		}
		get y() {
			return this._y;
		}
		set y(t) {
			this._y = t, this._onChangeCallback();
		}
		get z() {
			return this._z;
		}
		set z(t) {
			this._z = t, this._onChangeCallback();
		}
		get w() {
			return this._w;
		}
		set w(t) {
			this._w = t, this._onChangeCallback();
		}
		set(t, e, n, i) {
			return this._x = t, this._y = e, this._z = n, this._w = i, this._onChangeCallback(), this;
		}
		clone() {
			return new this.constructor(this._x, this._y, this._z, this._w);
		}
		copy(t) {
			return this._x = t.x, this._y = t.y, this._z = t.z, this._w = t.w, this._onChangeCallback(), this;
		}
		setFromEuler(t, e = !0) {
			const n = t._x, i = t._y, r = t._z, s = t._order, a = Math.cos, o = Math.sin, l = a(n / 2), c = a(i / 2), h = a(r / 2), u = o(n / 2), d = o(i / 2), p = o(r / 2);
			switch (s) {
				case "XYZ":
					this._x = u * c * h + l * d * p, this._y = l * d * h - u * c * p, this._z = l * c * p + u * d * h, this._w = l * c * h - u * d * p;
					break;
				case "YXZ":
					this._x = u * c * h + l * d * p, this._y = l * d * h - u * c * p, this._z = l * c * p - u * d * h, this._w = l * c * h + u * d * p;
					break;
				case "ZXY":
					this._x = u * c * h - l * d * p, this._y = l * d * h + u * c * p, this._z = l * c * p + u * d * h, this._w = l * c * h - u * d * p;
					break;
				case "ZYX":
					this._x = u * c * h - l * d * p, this._y = l * d * h + u * c * p, this._z = l * c * p - u * d * h, this._w = l * c * h + u * d * p;
					break;
				case "YZX":
					this._x = u * c * h + l * d * p, this._y = l * d * h + u * c * p, this._z = l * c * p - u * d * h, this._w = l * c * h - u * d * p;
					break;
				case "XZY":
					this._x = u * c * h - l * d * p, this._y = l * d * h - u * c * p, this._z = l * c * p + u * d * h, this._w = l * c * h + u * d * p;
					break;
				default: console.warn("THREE.Quaternion: .setFromEuler() encountered an unknown order: " + s);
			}
			return !0 === e && this._onChangeCallback(), this;
		}
		setFromAxisAngle(t, e) {
			const n = e / 2, i = Math.sin(n);
			return this._x = t.x * i, this._y = t.y * i, this._z = t.z * i, this._w = Math.cos(n), this._onChangeCallback(), this;
		}
		setFromRotationMatrix(t) {
			const e = t.elements, n = e[0], i = e[4], r = e[8], s = e[1], a = e[5], o = e[9], l = e[2], c = e[6], h = e[10], u = n + a + h;
			if (u > 0) {
				const t = .5 / Math.sqrt(u + 1);
				this._w = .25 / t, this._x = (c - o) * t, this._y = (r - l) * t, this._z = (s - i) * t;
			} else if (n > a && n > h) {
				const t = 2 * Math.sqrt(1 + n - a - h);
				this._w = (c - o) / t, this._x = .25 * t, this._y = (i + s) / t, this._z = (r + l) / t;
			} else if (a > h) {
				const t = 2 * Math.sqrt(1 + a - n - h);
				this._w = (r - l) / t, this._x = (i + s) / t, this._y = .25 * t, this._z = (o + c) / t;
			} else {
				const t = 2 * Math.sqrt(1 + h - n - a);
				this._w = (s - i) / t, this._x = (r + l) / t, this._y = (o + c) / t, this._z = .25 * t;
			}
			return this._onChangeCallback(), this;
		}
		setFromUnitVectors(t, e) {
			let n = t.dot(e) + 1;
			return n < Number.EPSILON ? (n = 0, Math.abs(t.x) > Math.abs(t.z) ? (this._x = -t.y, this._y = t.x, this._z = 0, this._w = n) : (this._x = 0, this._y = -t.z, this._z = t.y, this._w = n)) : (this._x = t.y * e.z - t.z * e.y, this._y = t.z * e.x - t.x * e.z, this._z = t.x * e.y - t.y * e.x, this._w = n), this.normalize();
		}
		angleTo(t) {
			return 2 * Math.acos(Math.abs(Yn(this.dot(t), -1, 1)));
		}
		rotateTowards(t, e) {
			const n = this.angleTo(t);
			if (0 === n) return this;
			const i = Math.min(1, e / n);
			return this.slerp(t, i), this;
		}
		identity() {
			return this.set(0, 0, 0, 1);
		}
		invert() {
			return this.conjugate();
		}
		conjugate() {
			return this._x *= -1, this._y *= -1, this._z *= -1, this._onChangeCallback(), this;
		}
		dot(t) {
			return this._x * t._x + this._y * t._y + this._z * t._z + this._w * t._w;
		}
		lengthSq() {
			return this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w;
		}
		length() {
			return Math.sqrt(this._x * this._x + this._y * this._y + this._z * this._z + this._w * this._w);
		}
		normalize() {
			let t = this.length();
			return 0 === t ? (this._x = 0, this._y = 0, this._z = 0, this._w = 1) : (t = 1 / t, this._x = this._x * t, this._y = this._y * t, this._z = this._z * t, this._w = this._w * t), this._onChangeCallback(), this;
		}
		multiply(t) {
			return this.multiplyQuaternions(this, t);
		}
		premultiply(t) {
			return this.multiplyQuaternions(t, this);
		}
		multiplyQuaternions(t, e) {
			const n = t._x, i = t._y, r = t._z, s = t._w, a = e._x, o = e._y, l = e._z, c = e._w;
			return this._x = n * c + s * a + i * l - r * o, this._y = i * c + s * o + r * a - n * l, this._z = r * c + s * l + n * o - i * a, this._w = s * c - n * a - i * o - r * l, this._onChangeCallback(), this;
		}
		slerp(t, e) {
			if (0 === e) return this;
			if (1 === e) return this.copy(t);
			const n = this._x, i = this._y, r = this._z, s = this._w;
			let a = s * t._w + n * t._x + i * t._y + r * t._z;
			if (a < 0 ? (this._w = -t._w, this._x = -t._x, this._y = -t._y, this._z = -t._z, a = -a) : this.copy(t), a >= 1) return this._w = s, this._x = n, this._y = i, this._z = r, this;
			const o = 1 - a * a;
			if (o <= Number.EPSILON) {
				const t = 1 - e;
				return this._w = t * s + e * this._w, this._x = t * n + e * this._x, this._y = t * i + e * this._y, this._z = t * r + e * this._z, this.normalize(), this;
			}
			const l = Math.sqrt(o), c = Math.atan2(l, a), h = Math.sin((1 - e) * c) / l, u = Math.sin(e * c) / l;
			return this._w = s * h + this._w * u, this._x = n * h + this._x * u, this._y = i * h + this._y * u, this._z = r * h + this._z * u, this._onChangeCallback(), this;
		}
		slerpQuaternions(t, e, n) {
			return this.copy(t).slerp(e, n);
		}
		random() {
			const t = 2 * Math.PI * Math.random(), e = 2 * Math.PI * Math.random(), n = Math.random(), i = Math.sqrt(1 - n), r = Math.sqrt(n);
			return this.set(i * Math.sin(t), i * Math.cos(t), r * Math.sin(e), r * Math.cos(e));
		}
		equals(t) {
			return t._x === this._x && t._y === this._y && t._z === this._z && t._w === this._w;
		}
		fromArray(t, e = 0) {
			return this._x = t[e], this._y = t[e + 1], this._z = t[e + 2], this._w = t[e + 3], this._onChangeCallback(), this;
		}
		toArray(t = [], e = 0) {
			return t[e] = this._x, t[e + 1] = this._y, t[e + 2] = this._z, t[e + 3] = this._w, t;
		}
		fromBufferAttribute(t, e) {
			return this._x = t.getX(e), this._y = t.getY(e), this._z = t.getZ(e), this._w = t.getW(e), this._onChangeCallback(), this;
		}
		toJSON() {
			return this.toArray();
		}
		_onChange(t) {
			return this._onChangeCallback = t, this;
		}
		_onChangeCallback() {}
		*[Symbol.iterator]() {
			yield this._x, yield this._y, yield this._z, yield this._w;
		}
	};
	var Li = class Li {
		constructor(t = 0, e = 0, n = 0) {
			Li.prototype.isVector3 = !0, this.x = t, this.y = e, this.z = n;
		}
		set(t, e, n) {
			return void 0 === n && (n = this.z), this.x = t, this.y = e, this.z = n, this;
		}
		setScalar(t) {
			return this.x = t, this.y = t, this.z = t, this;
		}
		setX(t) {
			return this.x = t, this;
		}
		setY(t) {
			return this.y = t, this;
		}
		setZ(t) {
			return this.z = t, this;
		}
		setComponent(t, e) {
			switch (t) {
				case 0:
					this.x = e;
					break;
				case 1:
					this.y = e;
					break;
				case 2:
					this.z = e;
					break;
				default: throw new Error("index is out of range: " + t);
			}
			return this;
		}
		getComponent(t) {
			switch (t) {
				case 0: return this.x;
				case 1: return this.y;
				case 2: return this.z;
				default: throw new Error("index is out of range: " + t);
			}
		}
		clone() {
			return new this.constructor(this.x, this.y, this.z);
		}
		copy(t) {
			return this.x = t.x, this.y = t.y, this.z = t.z, this;
		}
		add(t) {
			return this.x += t.x, this.y += t.y, this.z += t.z, this;
		}
		addScalar(t) {
			return this.x += t, this.y += t, this.z += t, this;
		}
		addVectors(t, e) {
			return this.x = t.x + e.x, this.y = t.y + e.y, this.z = t.z + e.z, this;
		}
		addScaledVector(t, e) {
			return this.x += t.x * e, this.y += t.y * e, this.z += t.z * e, this;
		}
		sub(t) {
			return this.x -= t.x, this.y -= t.y, this.z -= t.z, this;
		}
		subScalar(t) {
			return this.x -= t, this.y -= t, this.z -= t, this;
		}
		subVectors(t, e) {
			return this.x = t.x - e.x, this.y = t.y - e.y, this.z = t.z - e.z, this;
		}
		multiply(t) {
			return this.x *= t.x, this.y *= t.y, this.z *= t.z, this;
		}
		multiplyScalar(t) {
			return this.x *= t, this.y *= t, this.z *= t, this;
		}
		multiplyVectors(t, e) {
			return this.x = t.x * e.x, this.y = t.y * e.y, this.z = t.z * e.z, this;
		}
		applyEuler(t) {
			return this.applyQuaternion(Ni.setFromEuler(t));
		}
		applyAxisAngle(t, e) {
			return this.applyQuaternion(Ni.setFromAxisAngle(t, e));
		}
		applyMatrix3(t) {
			const e = this.x, n = this.y, i = this.z, r = t.elements;
			return this.x = r[0] * e + r[3] * n + r[6] * i, this.y = r[1] * e + r[4] * n + r[7] * i, this.z = r[2] * e + r[5] * n + r[8] * i, this;
		}
		applyNormalMatrix(t) {
			return this.applyMatrix3(t).normalize();
		}
		applyMatrix4(t) {
			const e = this.x, n = this.y, i = this.z, r = t.elements, s = 1 / (r[3] * e + r[7] * n + r[11] * i + r[15]);
			return this.x = (r[0] * e + r[4] * n + r[8] * i + r[12]) * s, this.y = (r[1] * e + r[5] * n + r[9] * i + r[13]) * s, this.z = (r[2] * e + r[6] * n + r[10] * i + r[14]) * s, this;
		}
		applyQuaternion(t) {
			const e = this.x, n = this.y, i = this.z, r = t.x, s = t.y, a = t.z, o = t.w, l = 2 * (s * i - a * n), c = 2 * (a * e - r * i), h = 2 * (r * n - s * e);
			return this.x = e + o * l + s * h - a * c, this.y = n + o * c + a * l - r * h, this.z = i + o * h + r * c - s * l, this;
		}
		project(t) {
			return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix);
		}
		unproject(t) {
			return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld);
		}
		transformDirection(t) {
			const e = this.x, n = this.y, i = this.z, r = t.elements;
			return this.x = r[0] * e + r[4] * n + r[8] * i, this.y = r[1] * e + r[5] * n + r[9] * i, this.z = r[2] * e + r[6] * n + r[10] * i, this.normalize();
		}
		divide(t) {
			return this.x /= t.x, this.y /= t.y, this.z /= t.z, this;
		}
		divideScalar(t) {
			return this.multiplyScalar(1 / t);
		}
		min(t) {
			return this.x = Math.min(this.x, t.x), this.y = Math.min(this.y, t.y), this.z = Math.min(this.z, t.z), this;
		}
		max(t) {
			return this.x = Math.max(this.x, t.x), this.y = Math.max(this.y, t.y), this.z = Math.max(this.z, t.z), this;
		}
		clamp(t, e) {
			return this.x = Math.max(t.x, Math.min(e.x, this.x)), this.y = Math.max(t.y, Math.min(e.y, this.y)), this.z = Math.max(t.z, Math.min(e.z, this.z)), this;
		}
		clampScalar(t, e) {
			return this.x = Math.max(t, Math.min(e, this.x)), this.y = Math.max(t, Math.min(e, this.y)), this.z = Math.max(t, Math.min(e, this.z)), this;
		}
		clampLength(t, e) {
			const n = this.length();
			return this.divideScalar(n || 1).multiplyScalar(Math.max(t, Math.min(e, n)));
		}
		floor() {
			return this.x = Math.floor(this.x), this.y = Math.floor(this.y), this.z = Math.floor(this.z), this;
		}
		ceil() {
			return this.x = Math.ceil(this.x), this.y = Math.ceil(this.y), this.z = Math.ceil(this.z), this;
		}
		round() {
			return this.x = Math.round(this.x), this.y = Math.round(this.y), this.z = Math.round(this.z), this;
		}
		roundToZero() {
			return this.x = Math.trunc(this.x), this.y = Math.trunc(this.y), this.z = Math.trunc(this.z), this;
		}
		negate() {
			return this.x = -this.x, this.y = -this.y, this.z = -this.z, this;
		}
		dot(t) {
			return this.x * t.x + this.y * t.y + this.z * t.z;
		}
		lengthSq() {
			return this.x * this.x + this.y * this.y + this.z * this.z;
		}
		length() {
			return Math.sqrt(this.x * this.x + this.y * this.y + this.z * this.z);
		}
		manhattanLength() {
			return Math.abs(this.x) + Math.abs(this.y) + Math.abs(this.z);
		}
		normalize() {
			return this.divideScalar(this.length() || 1);
		}
		setLength(t) {
			return this.normalize().multiplyScalar(t);
		}
		lerp(t, e) {
			return this.x += (t.x - this.x) * e, this.y += (t.y - this.y) * e, this.z += (t.z - this.z) * e, this;
		}
		lerpVectors(t, e, n) {
			return this.x = t.x + (e.x - t.x) * n, this.y = t.y + (e.y - t.y) * n, this.z = t.z + (e.z - t.z) * n, this;
		}
		cross(t) {
			return this.crossVectors(this, t);
		}
		crossVectors(t, e) {
			const n = t.x, i = t.y, r = t.z, s = e.x, a = e.y, o = e.z;
			return this.x = i * o - r * a, this.y = r * s - n * o, this.z = n * a - i * s, this;
		}
		projectOnVector(t) {
			const e = t.lengthSq();
			if (0 === e) return this.set(0, 0, 0);
			const n = t.dot(this) / e;
			return this.copy(t).multiplyScalar(n);
		}
		projectOnPlane(t) {
			return Ui.copy(this).projectOnVector(t), this.sub(Ui);
		}
		reflect(t) {
			return this.sub(Ui.copy(t).multiplyScalar(2 * this.dot(t)));
		}
		angleTo(t) {
			const e = Math.sqrt(this.lengthSq() * t.lengthSq());
			if (0 === e) return Math.PI / 2;
			const n = this.dot(t) / e;
			return Math.acos(Yn(n, -1, 1));
		}
		distanceTo(t) {
			return Math.sqrt(this.distanceToSquared(t));
		}
		distanceToSquared(t) {
			const e = this.x - t.x, n = this.y - t.y, i = this.z - t.z;
			return e * e + n * n + i * i;
		}
		manhattanDistanceTo(t) {
			return Math.abs(this.x - t.x) + Math.abs(this.y - t.y) + Math.abs(this.z - t.z);
		}
		setFromSpherical(t) {
			return this.setFromSphericalCoords(t.radius, t.phi, t.theta);
		}
		setFromSphericalCoords(t, e, n) {
			const i = Math.sin(e) * t;
			return this.x = i * Math.sin(n), this.y = Math.cos(e) * t, this.z = i * Math.cos(n), this;
		}
		setFromCylindrical(t) {
			return this.setFromCylindricalCoords(t.radius, t.theta, t.y);
		}
		setFromCylindricalCoords(t, e, n) {
			return this.x = t * Math.sin(e), this.y = n, this.z = t * Math.cos(e), this;
		}
		setFromMatrixPosition(t) {
			const e = t.elements;
			return this.x = e[12], this.y = e[13], this.z = e[14], this;
		}
		setFromMatrixScale(t) {
			const e = this.setFromMatrixColumn(t, 0).length(), n = this.setFromMatrixColumn(t, 1).length(), i = this.setFromMatrixColumn(t, 2).length();
			return this.x = e, this.y = n, this.z = i, this;
		}
		setFromMatrixColumn(t, e) {
			return this.fromArray(t.elements, 4 * e);
		}
		setFromMatrix3Column(t, e) {
			return this.fromArray(t.elements, 3 * e);
		}
		setFromEuler(t) {
			return this.x = t._x, this.y = t._y, this.z = t._z, this;
		}
		setFromColor(t) {
			return this.x = t.r, this.y = t.g, this.z = t.b, this;
		}
		equals(t) {
			return t.x === this.x && t.y === this.y && t.z === this.z;
		}
		fromArray(t, e = 0) {
			return this.x = t[e], this.y = t[e + 1], this.z = t[e + 2], this;
		}
		toArray(t = [], e = 0) {
			return t[e] = this.x, t[e + 1] = this.y, t[e + 2] = this.z, t;
		}
		fromBufferAttribute(t, e) {
			return this.x = t.getX(e), this.y = t.getY(e), this.z = t.getZ(e), this;
		}
		random() {
			return this.x = Math.random(), this.y = Math.random(), this.z = Math.random(), this;
		}
		randomDirection() {
			const t = Math.random() * Math.PI * 2, e = 2 * Math.random() - 1, n = Math.sqrt(1 - e * e);
			return this.x = n * Math.cos(t), this.y = e, this.z = n * Math.sin(t), this;
		}
		*[Symbol.iterator]() {
			yield this.x, yield this.y, yield this.z;
		}
	};
	const Ui = new Li(), Ni = new Ii();
	var Di = class {
		constructor(t = new Li(Infinity, Infinity, Infinity), e = new Li(-Infinity, -Infinity, -Infinity)) {
			this.isBox3 = !0, this.min = t, this.max = e;
		}
		set(t, e) {
			return this.min.copy(t), this.max.copy(e), this;
		}
		setFromArray(t) {
			this.makeEmpty();
			for (let e = 0, n = t.length; e < n; e += 3) this.expandByPoint(Fi.fromArray(t, e));
			return this;
		}
		setFromBufferAttribute(t) {
			this.makeEmpty();
			for (let e = 0, n = t.count; e < n; e++) this.expandByPoint(Fi.fromBufferAttribute(t, e));
			return this;
		}
		setFromPoints(t) {
			this.makeEmpty();
			for (let e = 0, n = t.length; e < n; e++) this.expandByPoint(t[e]);
			return this;
		}
		setFromCenterAndSize(t, e) {
			const n = Fi.copy(e).multiplyScalar(.5);
			return this.min.copy(t).sub(n), this.max.copy(t).add(n), this;
		}
		setFromObject(t, e = !1) {
			return this.makeEmpty(), this.expandByObject(t, e);
		}
		clone() {
			return new this.constructor().copy(this);
		}
		copy(t) {
			return this.min.copy(t.min), this.max.copy(t.max), this;
		}
		makeEmpty() {
			return this.min.x = this.min.y = this.min.z = Infinity, this.max.x = this.max.y = this.max.z = -Infinity, this;
		}
		isEmpty() {
			return this.max.x < this.min.x || this.max.y < this.min.y || this.max.z < this.min.z;
		}
		getCenter(t) {
			return this.isEmpty() ? t.set(0, 0, 0) : t.addVectors(this.min, this.max).multiplyScalar(.5);
		}
		getSize(t) {
			return this.isEmpty() ? t.set(0, 0, 0) : t.subVectors(this.max, this.min);
		}
		expandByPoint(t) {
			return this.min.min(t), this.max.max(t), this;
		}
		expandByVector(t) {
			return this.min.sub(t), this.max.add(t), this;
		}
		expandByScalar(t) {
			return this.min.addScalar(-t), this.max.addScalar(t), this;
		}
		expandByObject(t, e = !1) {
			t.updateWorldMatrix(!1, !1);
			const n = t.geometry;
			if (void 0 !== n) {
				const i = n.getAttribute("position");
				if (!0 === e && void 0 !== i && !0 !== t.isInstancedMesh) for (let e = 0, n = i.count; e < n; e++) !0 === t.isMesh ? t.getVertexPosition(e, Fi) : Fi.fromBufferAttribute(i, e), Fi.applyMatrix4(t.matrixWorld), this.expandByPoint(Fi);
				else void 0 !== t.boundingBox ? (null === t.boundingBox && t.computeBoundingBox(), Bi.copy(t.boundingBox)) : (null === n.boundingBox && n.computeBoundingBox(), Bi.copy(n.boundingBox)), Bi.applyMatrix4(t.matrixWorld), this.union(Bi);
			}
			const i = t.children;
			for (let t = 0, n = i.length; t < n; t++) this.expandByObject(i[t], e);
			return this;
		}
		containsPoint(t) {
			return t.x >= this.min.x && t.x <= this.max.x && t.y >= this.min.y && t.y <= this.max.y && t.z >= this.min.z && t.z <= this.max.z;
		}
		containsBox(t) {
			return this.min.x <= t.min.x && t.max.x <= this.max.x && this.min.y <= t.min.y && t.max.y <= this.max.y && this.min.z <= t.min.z && t.max.z <= this.max.z;
		}
		getParameter(t, e) {
			return e.set((t.x - this.min.x) / (this.max.x - this.min.x), (t.y - this.min.y) / (this.max.y - this.min.y), (t.z - this.min.z) / (this.max.z - this.min.z));
		}
		intersectsBox(t) {
			return t.max.x >= this.min.x && t.min.x <= this.max.x && t.max.y >= this.min.y && t.min.y <= this.max.y && t.max.z >= this.min.z && t.min.z <= this.max.z;
		}
		intersectsSphere(t) {
			return this.clampPoint(t.center, Fi), Fi.distanceToSquared(t.center) <= t.radius * t.radius;
		}
		intersectsPlane(t) {
			let e, n;
			return t.normal.x > 0 ? (e = t.normal.x * this.min.x, n = t.normal.x * this.max.x) : (e = t.normal.x * this.max.x, n = t.normal.x * this.min.x), t.normal.y > 0 ? (e += t.normal.y * this.min.y, n += t.normal.y * this.max.y) : (e += t.normal.y * this.max.y, n += t.normal.y * this.min.y), t.normal.z > 0 ? (e += t.normal.z * this.min.z, n += t.normal.z * this.max.z) : (e += t.normal.z * this.max.z, n += t.normal.z * this.min.z), e <= -t.constant && n >= -t.constant;
		}
		intersectsTriangle(t) {
			if (this.isEmpty()) return !1;
			this.getCenter(Xi), ji.subVectors(this.max, Xi), zi.subVectors(t.a, Xi), ki.subVectors(t.b, Xi), Vi.subVectors(t.c, Xi), Hi.subVectors(ki, zi), Gi.subVectors(Vi, ki), Wi.subVectors(zi, Vi);
			let e = [
				0,
				-Hi.z,
				Hi.y,
				0,
				-Gi.z,
				Gi.y,
				0,
				-Wi.z,
				Wi.y,
				Hi.z,
				0,
				-Hi.x,
				Gi.z,
				0,
				-Gi.x,
				Wi.z,
				0,
				-Wi.x,
				-Hi.y,
				Hi.x,
				0,
				-Gi.y,
				Gi.x,
				0,
				-Wi.y,
				Wi.x,
				0
			];
			return !!Zi(e, zi, ki, Vi, ji) && (e = [
				1,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1
			], !!Zi(e, zi, ki, Vi, ji) && (qi.crossVectors(Hi, Gi), e = [
				qi.x,
				qi.y,
				qi.z
			], Zi(e, zi, ki, Vi, ji)));
		}
		clampPoint(t, e) {
			return e.copy(t).clamp(this.min, this.max);
		}
		distanceToPoint(t) {
			return this.clampPoint(t, Fi).distanceTo(t);
		}
		getBoundingSphere(t) {
			return this.isEmpty() ? t.makeEmpty() : (this.getCenter(t.center), t.radius = .5 * this.getSize(Fi).length()), t;
		}
		intersect(t) {
			return this.min.max(t.min), this.max.min(t.max), this.isEmpty() && this.makeEmpty(), this;
		}
		union(t) {
			return this.min.min(t.min), this.max.max(t.max), this;
		}
		applyMatrix4(t) {
			return this.isEmpty() || (Oi[0].set(this.min.x, this.min.y, this.min.z).applyMatrix4(t), Oi[1].set(this.min.x, this.min.y, this.max.z).applyMatrix4(t), Oi[2].set(this.min.x, this.max.y, this.min.z).applyMatrix4(t), Oi[3].set(this.min.x, this.max.y, this.max.z).applyMatrix4(t), Oi[4].set(this.max.x, this.min.y, this.min.z).applyMatrix4(t), Oi[5].set(this.max.x, this.min.y, this.max.z).applyMatrix4(t), Oi[6].set(this.max.x, this.max.y, this.min.z).applyMatrix4(t), Oi[7].set(this.max.x, this.max.y, this.max.z).applyMatrix4(t), this.setFromPoints(Oi)), this;
		}
		translate(t) {
			return this.min.add(t), this.max.add(t), this;
		}
		equals(t) {
			return t.min.equals(this.min) && t.max.equals(this.max);
		}
	};
	const Oi = [
		new Li(),
		new Li(),
		new Li(),
		new Li(),
		new Li(),
		new Li(),
		new Li(),
		new Li()
	], Fi = new Li(), Bi = new Di(), zi = new Li(), ki = new Li(), Vi = new Li(), Hi = new Li(), Gi = new Li(), Wi = new Li(), Xi = new Li(), ji = new Li(), qi = new Li(), Yi = new Li();
	function Zi(t, e, n, i, r) {
		for (let s = 0, a = t.length - 3; s <= a; s += 3) {
			Yi.fromArray(t, s);
			const a = r.x * Math.abs(Yi.x) + r.y * Math.abs(Yi.y) + r.z * Math.abs(Yi.z), o = e.dot(Yi), l = n.dot(Yi), c = i.dot(Yi);
			if (Math.max(-Math.max(o, l, c), Math.min(o, l, c)) > a) return !1;
		}
		return !0;
	}
	const Ji = new Di(), Ki = new Li(), $i = new Li();
	var Qi = class {
		constructor(t = new Li(), e = -1) {
			this.isSphere = !0, this.center = t, this.radius = e;
		}
		set(t, e) {
			return this.center.copy(t), this.radius = e, this;
		}
		setFromPoints(t, e) {
			const n = this.center;
			void 0 !== e ? n.copy(e) : Ji.setFromPoints(t).getCenter(n);
			let i = 0;
			for (let e = 0, r = t.length; e < r; e++) i = Math.max(i, n.distanceToSquared(t[e]));
			return this.radius = Math.sqrt(i), this;
		}
		copy(t) {
			return this.center.copy(t.center), this.radius = t.radius, this;
		}
		isEmpty() {
			return this.radius < 0;
		}
		makeEmpty() {
			return this.center.set(0, 0, 0), this.radius = -1, this;
		}
		containsPoint(t) {
			return t.distanceToSquared(this.center) <= this.radius * this.radius;
		}
		distanceToPoint(t) {
			return t.distanceTo(this.center) - this.radius;
		}
		intersectsSphere(t) {
			const e = this.radius + t.radius;
			return t.center.distanceToSquared(this.center) <= e * e;
		}
		intersectsBox(t) {
			return t.intersectsSphere(this);
		}
		intersectsPlane(t) {
			return Math.abs(t.distanceToPoint(this.center)) <= this.radius;
		}
		clampPoint(t, e) {
			const n = this.center.distanceToSquared(t);
			return e.copy(t), n > this.radius * this.radius && (e.sub(this.center).normalize(), e.multiplyScalar(this.radius).add(this.center)), e;
		}
		getBoundingBox(t) {
			return this.isEmpty() ? (t.makeEmpty(), t) : (t.set(this.center, this.center), t.expandByScalar(this.radius), t);
		}
		applyMatrix4(t) {
			return this.center.applyMatrix4(t), this.radius = this.radius * t.getMaxScaleOnAxis(), this;
		}
		translate(t) {
			return this.center.add(t), this;
		}
		expandByPoint(t) {
			if (this.isEmpty()) return this.center.copy(t), this.radius = 0, this;
			Ki.subVectors(t, this.center);
			const e = Ki.lengthSq();
			if (e > this.radius * this.radius) {
				const t = Math.sqrt(e), n = .5 * (t - this.radius);
				this.center.addScaledVector(Ki, n / t), this.radius += n;
			}
			return this;
		}
		union(t) {
			return t.isEmpty() ? this : this.isEmpty() ? (this.copy(t), this) : (!0 === this.center.equals(t.center) ? this.radius = Math.max(this.radius, t.radius) : ($i.subVectors(t.center, this.center).setLength(t.radius), this.expandByPoint(Ki.copy(t.center).add($i)), this.expandByPoint(Ki.copy(t.center).sub($i))), this);
		}
		equals(t) {
			return t.center.equals(this.center) && t.radius === this.radius;
		}
		clone() {
			return new this.constructor().copy(this);
		}
	};
	const tr = new Li(), er = new Li(), nr = new Li(), ir = new Li(), rr = new Li(), sr = new Li(), ar = new Li();
	var or = class {
		constructor(t = new Li(), e = new Li(0, 0, -1)) {
			this.origin = t, this.direction = e;
		}
		set(t, e) {
			return this.origin.copy(t), this.direction.copy(e), this;
		}
		copy(t) {
			return this.origin.copy(t.origin), this.direction.copy(t.direction), this;
		}
		at(t, e) {
			return e.copy(this.origin).addScaledVector(this.direction, t);
		}
		lookAt(t) {
			return this.direction.copy(t).sub(this.origin).normalize(), this;
		}
		recast(t) {
			return this.origin.copy(this.at(t, tr)), this;
		}
		closestPointToPoint(t, e) {
			e.subVectors(t, this.origin);
			const n = e.dot(this.direction);
			return n < 0 ? e.copy(this.origin) : e.copy(this.origin).addScaledVector(this.direction, n);
		}
		distanceToPoint(t) {
			return Math.sqrt(this.distanceSqToPoint(t));
		}
		distanceSqToPoint(t) {
			const e = tr.subVectors(t, this.origin).dot(this.direction);
			return e < 0 ? this.origin.distanceToSquared(t) : (tr.copy(this.origin).addScaledVector(this.direction, e), tr.distanceToSquared(t));
		}
		distanceSqToSegment(t, e, n, i) {
			er.copy(t).add(e).multiplyScalar(.5), nr.copy(e).sub(t).normalize(), ir.copy(this.origin).sub(er);
			const r = .5 * t.distanceTo(e), s = -this.direction.dot(nr), a = ir.dot(this.direction), o = -ir.dot(nr), l = ir.lengthSq(), c = Math.abs(1 - s * s);
			let h, u, d, p;
			if (c > 0) if (h = s * o - a, u = s * a - o, p = r * c, h >= 0) if (u >= -p) if (u <= p) {
				const t = 1 / c;
				h *= t, u *= t, d = h * (h + s * u + 2 * a) + u * (s * h + u + 2 * o) + l;
			} else u = r, h = Math.max(0, -(s * u + a)), d = -h * h + u * (u + 2 * o) + l;
			else u = -r, h = Math.max(0, -(s * u + a)), d = -h * h + u * (u + 2 * o) + l;
			else u <= -p ? (h = Math.max(0, -(-s * r + a)), u = h > 0 ? -r : Math.min(Math.max(-r, -o), r), d = -h * h + u * (u + 2 * o) + l) : u <= p ? (h = 0, u = Math.min(Math.max(-r, -o), r), d = u * (u + 2 * o) + l) : (h = Math.max(0, -(s * r + a)), u = h > 0 ? r : Math.min(Math.max(-r, -o), r), d = -h * h + u * (u + 2 * o) + l);
			else u = s > 0 ? -r : r, h = Math.max(0, -(s * u + a)), d = -h * h + u * (u + 2 * o) + l;
			return n && n.copy(this.origin).addScaledVector(this.direction, h), i && i.copy(er).addScaledVector(nr, u), d;
		}
		intersectSphere(t, e) {
			tr.subVectors(t.center, this.origin);
			const n = tr.dot(this.direction), i = tr.dot(tr) - n * n, r = t.radius * t.radius;
			if (i > r) return null;
			const s = Math.sqrt(r - i), a = n - s, o = n + s;
			return o < 0 ? null : a < 0 ? this.at(o, e) : this.at(a, e);
		}
		intersectsSphere(t) {
			return this.distanceSqToPoint(t.center) <= t.radius * t.radius;
		}
		distanceToPlane(t) {
			const e = t.normal.dot(this.direction);
			if (0 === e) return 0 === t.distanceToPoint(this.origin) ? 0 : null;
			const n = -(this.origin.dot(t.normal) + t.constant) / e;
			return n >= 0 ? n : null;
		}
		intersectPlane(t, e) {
			const n = this.distanceToPlane(t);
			return null === n ? null : this.at(n, e);
		}
		intersectsPlane(t) {
			const e = t.distanceToPoint(this.origin);
			if (0 === e) return !0;
			return t.normal.dot(this.direction) * e < 0;
		}
		intersectBox(t, e) {
			let n, i, r, s, a, o;
			const l = 1 / this.direction.x, c = 1 / this.direction.y, h = 1 / this.direction.z, u = this.origin;
			return l >= 0 ? (n = (t.min.x - u.x) * l, i = (t.max.x - u.x) * l) : (n = (t.max.x - u.x) * l, i = (t.min.x - u.x) * l), c >= 0 ? (r = (t.min.y - u.y) * c, s = (t.max.y - u.y) * c) : (r = (t.max.y - u.y) * c, s = (t.min.y - u.y) * c), n > s || r > i ? null : ((r > n || isNaN(n)) && (n = r), (s < i || isNaN(i)) && (i = s), h >= 0 ? (a = (t.min.z - u.z) * h, o = (t.max.z - u.z) * h) : (a = (t.max.z - u.z) * h, o = (t.min.z - u.z) * h), n > o || a > i ? null : ((a > n || n != n) && (n = a), (o < i || i != i) && (i = o), i < 0 ? null : this.at(n >= 0 ? n : i, e)));
		}
		intersectsBox(t) {
			return null !== this.intersectBox(t, tr);
		}
		intersectTriangle(t, e, n, i, r) {
			rr.subVectors(e, t), sr.subVectors(n, t), ar.crossVectors(rr, sr);
			let s, a = this.direction.dot(ar);
			if (a > 0) {
				if (i) return null;
				s = 1;
			} else {
				if (!(a < 0)) return null;
				s = -1, a = -a;
			}
			ir.subVectors(this.origin, t);
			const o = s * this.direction.dot(sr.crossVectors(ir, sr));
			if (o < 0) return null;
			const l = s * this.direction.dot(rr.cross(ir));
			if (l < 0) return null;
			if (o + l > a) return null;
			const c = -s * ir.dot(ar);
			return c < 0 ? null : this.at(c / a, r);
		}
		applyMatrix4(t) {
			return this.origin.applyMatrix4(t), this.direction.transformDirection(t), this;
		}
		equals(t) {
			return t.origin.equals(this.origin) && t.direction.equals(this.direction);
		}
		clone() {
			return new this.constructor().copy(this);
		}
	};
	var lr = class lr {
		constructor(t, e, n, i, r, s, a, o, l, c, h, u, d, p, m, f) {
			lr.prototype.isMatrix4 = !0, this.elements = [
				1,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				0,
				1
			], void 0 !== t && this.set(t, e, n, i, r, s, a, o, l, c, h, u, d, p, m, f);
		}
		set(t, e, n, i, r, s, a, o, l, c, h, u, d, p, m, f) {
			const g = this.elements;
			return g[0] = t, g[4] = e, g[8] = n, g[12] = i, g[1] = r, g[5] = s, g[9] = a, g[13] = o, g[2] = l, g[6] = c, g[10] = h, g[14] = u, g[3] = d, g[7] = p, g[11] = m, g[15] = f, this;
		}
		identity() {
			return this.set(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), this;
		}
		clone() {
			return new lr().fromArray(this.elements);
		}
		copy(t) {
			const e = this.elements, n = t.elements;
			return e[0] = n[0], e[1] = n[1], e[2] = n[2], e[3] = n[3], e[4] = n[4], e[5] = n[5], e[6] = n[6], e[7] = n[7], e[8] = n[8], e[9] = n[9], e[10] = n[10], e[11] = n[11], e[12] = n[12], e[13] = n[13], e[14] = n[14], e[15] = n[15], this;
		}
		copyPosition(t) {
			const e = this.elements, n = t.elements;
			return e[12] = n[12], e[13] = n[13], e[14] = n[14], this;
		}
		setFromMatrix3(t) {
			const e = t.elements;
			return this.set(e[0], e[3], e[6], 0, e[1], e[4], e[7], 0, e[2], e[5], e[8], 0, 0, 0, 0, 1), this;
		}
		extractBasis(t, e, n) {
			return t.setFromMatrixColumn(this, 0), e.setFromMatrixColumn(this, 1), n.setFromMatrixColumn(this, 2), this;
		}
		makeBasis(t, e, n) {
			return this.set(t.x, e.x, n.x, 0, t.y, e.y, n.y, 0, t.z, e.z, n.z, 0, 0, 0, 0, 1), this;
		}
		extractRotation(t) {
			const e = this.elements, n = t.elements, i = 1 / cr.setFromMatrixColumn(t, 0).length(), r = 1 / cr.setFromMatrixColumn(t, 1).length(), s = 1 / cr.setFromMatrixColumn(t, 2).length();
			return e[0] = n[0] * i, e[1] = n[1] * i, e[2] = n[2] * i, e[3] = 0, e[4] = n[4] * r, e[5] = n[5] * r, e[6] = n[6] * r, e[7] = 0, e[8] = n[8] * s, e[9] = n[9] * s, e[10] = n[10] * s, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, this;
		}
		makeRotationFromEuler(t) {
			const e = this.elements, n = t.x, i = t.y, r = t.z, s = Math.cos(n), a = Math.sin(n), o = Math.cos(i), l = Math.sin(i), c = Math.cos(r), h = Math.sin(r);
			if ("XYZ" === t.order) {
				const t = s * c, n = s * h, i = a * c, r = a * h;
				e[0] = o * c, e[4] = -o * h, e[8] = l, e[1] = n + i * l, e[5] = t - r * l, e[9] = -a * o, e[2] = r - t * l, e[6] = i + n * l, e[10] = s * o;
			} else if ("YXZ" === t.order) {
				const t = o * c, n = o * h, i = l * c, r = l * h;
				e[0] = t + r * a, e[4] = i * a - n, e[8] = s * l, e[1] = s * h, e[5] = s * c, e[9] = -a, e[2] = n * a - i, e[6] = r + t * a, e[10] = s * o;
			} else if ("ZXY" === t.order) {
				const t = o * c, n = o * h, i = l * c, r = l * h;
				e[0] = t - r * a, e[4] = -s * h, e[8] = i + n * a, e[1] = n + i * a, e[5] = s * c, e[9] = r - t * a, e[2] = -s * l, e[6] = a, e[10] = s * o;
			} else if ("ZYX" === t.order) {
				const t = s * c, n = s * h, i = a * c, r = a * h;
				e[0] = o * c, e[4] = i * l - n, e[8] = t * l + r, e[1] = o * h, e[5] = r * l + t, e[9] = n * l - i, e[2] = -l, e[6] = a * o, e[10] = s * o;
			} else if ("YZX" === t.order) {
				const t = s * o, n = s * l, i = a * o, r = a * l;
				e[0] = o * c, e[4] = r - t * h, e[8] = i * h + n, e[1] = h, e[5] = s * c, e[9] = -a * c, e[2] = -l * c, e[6] = n * h + i, e[10] = t - r * h;
			} else if ("XZY" === t.order) {
				const t = s * o, n = s * l, i = a * o, r = a * l;
				e[0] = o * c, e[4] = -h, e[8] = l * c, e[1] = t * h + r, e[5] = s * c, e[9] = n * h - i, e[2] = i * h - n, e[6] = a * c, e[10] = r * h + t;
			}
			return e[3] = 0, e[7] = 0, e[11] = 0, e[12] = 0, e[13] = 0, e[14] = 0, e[15] = 1, this;
		}
		makeRotationFromQuaternion(t) {
			return this.compose(ur, t, dr);
		}
		lookAt(t, e, n) {
			const i = this.elements;
			return fr.subVectors(t, e), 0 === fr.lengthSq() && (fr.z = 1), fr.normalize(), pr.crossVectors(n, fr), 0 === pr.lengthSq() && (1 === Math.abs(n.z) ? fr.x += 1e-4 : fr.z += 1e-4, fr.normalize(), pr.crossVectors(n, fr)), pr.normalize(), mr.crossVectors(fr, pr), i[0] = pr.x, i[4] = mr.x, i[8] = fr.x, i[1] = pr.y, i[5] = mr.y, i[9] = fr.y, i[2] = pr.z, i[6] = mr.z, i[10] = fr.z, this;
		}
		multiply(t) {
			return this.multiplyMatrices(this, t);
		}
		premultiply(t) {
			return this.multiplyMatrices(t, this);
		}
		multiplyMatrices(t, e) {
			const n = t.elements, i = e.elements, r = this.elements, s = n[0], a = n[4], o = n[8], l = n[12], c = n[1], h = n[5], u = n[9], d = n[13], p = n[2], m = n[6], f = n[10], g = n[14], v = n[3], _ = n[7], x = n[11], y = n[15], M = i[0], S = i[4], b = i[8], w = i[12], T = i[1], E = i[5], A = i[9], R = i[13], C = i[2], P = i[6], I = i[10], L = i[14], U = i[3], N = i[7], D = i[11], O = i[15];
			return r[0] = s * M + a * T + o * C + l * U, r[4] = s * S + a * E + o * P + l * N, r[8] = s * b + a * A + o * I + l * D, r[12] = s * w + a * R + o * L + l * O, r[1] = c * M + h * T + u * C + d * U, r[5] = c * S + h * E + u * P + d * N, r[9] = c * b + h * A + u * I + d * D, r[13] = c * w + h * R + u * L + d * O, r[2] = p * M + m * T + f * C + g * U, r[6] = p * S + m * E + f * P + g * N, r[10] = p * b + m * A + f * I + g * D, r[14] = p * w + m * R + f * L + g * O, r[3] = v * M + _ * T + x * C + y * U, r[7] = v * S + _ * E + x * P + y * N, r[11] = v * b + _ * A + x * I + y * D, r[15] = v * w + _ * R + x * L + y * O, this;
		}
		multiplyScalar(t) {
			const e = this.elements;
			return e[0] *= t, e[4] *= t, e[8] *= t, e[12] *= t, e[1] *= t, e[5] *= t, e[9] *= t, e[13] *= t, e[2] *= t, e[6] *= t, e[10] *= t, e[14] *= t, e[3] *= t, e[7] *= t, e[11] *= t, e[15] *= t, this;
		}
		determinant() {
			const t = this.elements, e = t[0], n = t[4], i = t[8], r = t[12], s = t[1], a = t[5], o = t[9], l = t[13], c = t[2], h = t[6], u = t[10], d = t[14];
			return t[3] * (+r * o * h - i * l * h - r * a * u + n * l * u + i * a * d - n * o * d) + t[7] * (+e * o * d - e * l * u + r * s * u - i * s * d + i * l * c - r * o * c) + t[11] * (+e * l * h - e * a * d - r * s * h + n * s * d + r * a * c - n * l * c) + t[15] * (-i * a * c - e * o * h + e * a * u + i * s * h - n * s * u + n * o * c);
		}
		transpose() {
			const t = this.elements;
			let e;
			return e = t[1], t[1] = t[4], t[4] = e, e = t[2], t[2] = t[8], t[8] = e, e = t[6], t[6] = t[9], t[9] = e, e = t[3], t[3] = t[12], t[12] = e, e = t[7], t[7] = t[13], t[13] = e, e = t[11], t[11] = t[14], t[14] = e, this;
		}
		setPosition(t, e, n) {
			const i = this.elements;
			return t.isVector3 ? (i[12] = t.x, i[13] = t.y, i[14] = t.z) : (i[12] = t, i[13] = e, i[14] = n), this;
		}
		invert() {
			const t = this.elements, e = t[0], n = t[1], i = t[2], r = t[3], s = t[4], a = t[5], o = t[6], l = t[7], c = t[8], h = t[9], u = t[10], d = t[11], p = t[12], m = t[13], f = t[14], g = t[15], v = h * f * l - m * u * l + m * o * d - a * f * d - h * o * g + a * u * g, _ = p * u * l - c * f * l - p * o * d + s * f * d + c * o * g - s * u * g, x = c * m * l - p * h * l + p * a * d - s * m * d - c * a * g + s * h * g, y = p * h * o - c * m * o - p * a * u + s * m * u + c * a * f - s * h * f, M = e * v + n * _ + i * x + r * y;
			if (0 === M) return this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
			const S = 1 / M;
			return t[0] = v * S, t[1] = (m * u * r - h * f * r - m * i * d + n * f * d + h * i * g - n * u * g) * S, t[2] = (a * f * r - m * o * r + m * i * l - n * f * l - a * i * g + n * o * g) * S, t[3] = (h * o * r - a * u * r - h * i * l + n * u * l + a * i * d - n * o * d) * S, t[4] = _ * S, t[5] = (c * f * r - p * u * r + p * i * d - e * f * d - c * i * g + e * u * g) * S, t[6] = (p * o * r - s * f * r - p * i * l + e * f * l + s * i * g - e * o * g) * S, t[7] = (s * u * r - c * o * r + c * i * l - e * u * l - s * i * d + e * o * d) * S, t[8] = x * S, t[9] = (p * h * r - c * m * r - p * n * d + e * m * d + c * n * g - e * h * g) * S, t[10] = (s * m * r - p * a * r + p * n * l - e * m * l - s * n * g + e * a * g) * S, t[11] = (c * a * r - s * h * r - c * n * l + e * h * l + s * n * d - e * a * d) * S, t[12] = y * S, t[13] = (c * m * i - p * h * i + p * n * u - e * m * u - c * n * f + e * h * f) * S, t[14] = (p * a * i - s * m * i - p * n * o + e * m * o + s * n * f - e * a * f) * S, t[15] = (s * h * i - c * a * i + c * n * o - e * h * o - s * n * u + e * a * u) * S, this;
		}
		scale(t) {
			const e = this.elements, n = t.x, i = t.y, r = t.z;
			return e[0] *= n, e[4] *= i, e[8] *= r, e[1] *= n, e[5] *= i, e[9] *= r, e[2] *= n, e[6] *= i, e[10] *= r, e[3] *= n, e[7] *= i, e[11] *= r, this;
		}
		getMaxScaleOnAxis() {
			const t = this.elements, e = t[0] * t[0] + t[1] * t[1] + t[2] * t[2], n = t[4] * t[4] + t[5] * t[5] + t[6] * t[6], i = t[8] * t[8] + t[9] * t[9] + t[10] * t[10];
			return Math.sqrt(Math.max(e, n, i));
		}
		makeTranslation(t, e, n) {
			return t.isVector3 ? this.set(1, 0, 0, t.x, 0, 1, 0, t.y, 0, 0, 1, t.z, 0, 0, 0, 1) : this.set(1, 0, 0, t, 0, 1, 0, e, 0, 0, 1, n, 0, 0, 0, 1), this;
		}
		makeRotationX(t) {
			const e = Math.cos(t), n = Math.sin(t);
			return this.set(1, 0, 0, 0, 0, e, -n, 0, 0, n, e, 0, 0, 0, 0, 1), this;
		}
		makeRotationY(t) {
			const e = Math.cos(t), n = Math.sin(t);
			return this.set(e, 0, n, 0, 0, 1, 0, 0, -n, 0, e, 0, 0, 0, 0, 1), this;
		}
		makeRotationZ(t) {
			const e = Math.cos(t), n = Math.sin(t);
			return this.set(e, -n, 0, 0, n, e, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1), this;
		}
		makeRotationAxis(t, e) {
			const n = Math.cos(e), i = Math.sin(e), r = 1 - n, s = t.x, a = t.y, o = t.z, l = r * s, c = r * a;
			return this.set(l * s + n, l * a - i * o, l * o + i * a, 0, l * a + i * o, c * a + n, c * o - i * s, 0, l * o - i * a, c * o + i * s, r * o * o + n, 0, 0, 0, 0, 1), this;
		}
		makeScale(t, e, n) {
			return this.set(t, 0, 0, 0, 0, e, 0, 0, 0, 0, n, 0, 0, 0, 0, 1), this;
		}
		makeShear(t, e, n, i, r, s) {
			return this.set(1, n, r, 0, t, 1, s, 0, e, i, 1, 0, 0, 0, 0, 1), this;
		}
		compose(t, e, n) {
			const i = this.elements, r = e._x, s = e._y, a = e._z, o = e._w, l = r + r, c = s + s, h = a + a, u = r * l, d = r * c, p = r * h, m = s * c, f = s * h, g = a * h, v = o * l, _ = o * c, x = o * h, y = n.x, M = n.y, S = n.z;
			return i[0] = (1 - (m + g)) * y, i[1] = (d + x) * y, i[2] = (p - _) * y, i[3] = 0, i[4] = (d - x) * M, i[5] = (1 - (u + g)) * M, i[6] = (f + v) * M, i[7] = 0, i[8] = (p + _) * S, i[9] = (f - v) * S, i[10] = (1 - (u + m)) * S, i[11] = 0, i[12] = t.x, i[13] = t.y, i[14] = t.z, i[15] = 1, this;
		}
		decompose(t, e, n) {
			const i = this.elements;
			let r = cr.set(i[0], i[1], i[2]).length();
			const s = cr.set(i[4], i[5], i[6]).length(), a = cr.set(i[8], i[9], i[10]).length();
			this.determinant() < 0 && (r = -r), t.x = i[12], t.y = i[13], t.z = i[14], hr.copy(this);
			const o = 1 / r, l = 1 / s, c = 1 / a;
			return hr.elements[0] *= o, hr.elements[1] *= o, hr.elements[2] *= o, hr.elements[4] *= l, hr.elements[5] *= l, hr.elements[6] *= l, hr.elements[8] *= c, hr.elements[9] *= c, hr.elements[10] *= c, e.setFromRotationMatrix(hr), n.x = r, n.y = s, n.z = a, this;
		}
		makePerspective(t, e, n, i, r, s, a = 2e3) {
			const o = this.elements, l = 2 * r / (e - t), c = 2 * r / (n - i), h = (e + t) / (e - t), u = (n + i) / (n - i);
			let d, p;
			if (a === 2e3) d = -(s + r) / (s - r), p = -2 * s * r / (s - r);
			else {
				if (a !== 2001) throw new Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: " + a);
				d = -s / (s - r), p = -s * r / (s - r);
			}
			return o[0] = l, o[4] = 0, o[8] = h, o[12] = 0, o[1] = 0, o[5] = c, o[9] = u, o[13] = 0, o[2] = 0, o[6] = 0, o[10] = d, o[14] = p, o[3] = 0, o[7] = 0, o[11] = -1, o[15] = 0, this;
		}
		makeOrthographic(t, e, n, i, r, s, a = 2e3) {
			const o = this.elements, l = 1 / (e - t), c = 1 / (n - i), h = 1 / (s - r), u = (e + t) * l, d = (n + i) * c;
			let p, m;
			if (a === 2e3) p = (s + r) * h, m = -2 * h;
			else {
				if (a !== 2001) throw new Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: " + a);
				p = r * h, m = -1 * h;
			}
			return o[0] = 2 * l, o[4] = 0, o[8] = 0, o[12] = -u, o[1] = 0, o[5] = 2 * c, o[9] = 0, o[13] = -d, o[2] = 0, o[6] = 0, o[10] = m, o[14] = -p, o[3] = 0, o[7] = 0, o[11] = 0, o[15] = 1, this;
		}
		equals(t) {
			const e = this.elements, n = t.elements;
			for (let t = 0; t < 16; t++) if (e[t] !== n[t]) return !1;
			return !0;
		}
		fromArray(t, e = 0) {
			for (let n = 0; n < 16; n++) this.elements[n] = t[n + e];
			return this;
		}
		toArray(t = [], e = 0) {
			const n = this.elements;
			return t[e] = n[0], t[e + 1] = n[1], t[e + 2] = n[2], t[e + 3] = n[3], t[e + 4] = n[4], t[e + 5] = n[5], t[e + 6] = n[6], t[e + 7] = n[7], t[e + 8] = n[8], t[e + 9] = n[9], t[e + 10] = n[10], t[e + 11] = n[11], t[e + 12] = n[12], t[e + 13] = n[13], t[e + 14] = n[14], t[e + 15] = n[15], t;
		}
	};
	const cr = new Li(), hr = new lr(), ur = new Li(0, 0, 0), dr = new Li(1, 1, 1), pr = new Li(), mr = new Li(), fr = new Li(), gr = new lr(), vr = new Ii();
	var _r = class _r {
		constructor(t = 0, e = 0, n = 0, i = _r.DEFAULT_ORDER) {
			this.isEuler = !0, this._x = t, this._y = e, this._z = n, this._order = i;
		}
		get x() {
			return this._x;
		}
		set x(t) {
			this._x = t, this._onChangeCallback();
		}
		get y() {
			return this._y;
		}
		set y(t) {
			this._y = t, this._onChangeCallback();
		}
		get z() {
			return this._z;
		}
		set z(t) {
			this._z = t, this._onChangeCallback();
		}
		get order() {
			return this._order;
		}
		set order(t) {
			this._order = t, this._onChangeCallback();
		}
		set(t, e, n, i = this._order) {
			return this._x = t, this._y = e, this._z = n, this._order = i, this._onChangeCallback(), this;
		}
		clone() {
			return new this.constructor(this._x, this._y, this._z, this._order);
		}
		copy(t) {
			return this._x = t._x, this._y = t._y, this._z = t._z, this._order = t._order, this._onChangeCallback(), this;
		}
		setFromRotationMatrix(t, e = this._order, n = !0) {
			const i = t.elements, r = i[0], s = i[4], a = i[8], o = i[1], l = i[5], c = i[9], h = i[2], u = i[6], d = i[10];
			switch (e) {
				case "XYZ":
					this._y = Math.asin(Yn(a, -1, 1)), Math.abs(a) < .9999999 ? (this._x = Math.atan2(-c, d), this._z = Math.atan2(-s, r)) : (this._x = Math.atan2(u, l), this._z = 0);
					break;
				case "YXZ":
					this._x = Math.asin(-Yn(c, -1, 1)), Math.abs(c) < .9999999 ? (this._y = Math.atan2(a, d), this._z = Math.atan2(o, l)) : (this._y = Math.atan2(-h, r), this._z = 0);
					break;
				case "ZXY":
					this._x = Math.asin(Yn(u, -1, 1)), Math.abs(u) < .9999999 ? (this._y = Math.atan2(-h, d), this._z = Math.atan2(-s, l)) : (this._y = 0, this._z = Math.atan2(o, r));
					break;
				case "ZYX":
					this._y = Math.asin(-Yn(h, -1, 1)), Math.abs(h) < .9999999 ? (this._x = Math.atan2(u, d), this._z = Math.atan2(o, r)) : (this._x = 0, this._z = Math.atan2(-s, l));
					break;
				case "YZX":
					this._z = Math.asin(Yn(o, -1, 1)), Math.abs(o) < .9999999 ? (this._x = Math.atan2(-c, l), this._y = Math.atan2(-h, r)) : (this._x = 0, this._y = Math.atan2(a, d));
					break;
				case "XZY":
					this._z = Math.asin(-Yn(s, -1, 1)), Math.abs(s) < .9999999 ? (this._x = Math.atan2(u, l), this._y = Math.atan2(a, r)) : (this._x = Math.atan2(-c, d), this._y = 0);
					break;
				default: console.warn("THREE.Euler: .setFromRotationMatrix() encountered an unknown order: " + e);
			}
			return this._order = e, !0 === n && this._onChangeCallback(), this;
		}
		setFromQuaternion(t, e, n) {
			return gr.makeRotationFromQuaternion(t), this.setFromRotationMatrix(gr, e, n);
		}
		setFromVector3(t, e = this._order) {
			return this.set(t.x, t.y, t.z, e);
		}
		reorder(t) {
			return vr.setFromEuler(this), this.setFromQuaternion(vr, t);
		}
		equals(t) {
			return t._x === this._x && t._y === this._y && t._z === this._z && t._order === this._order;
		}
		fromArray(t) {
			return this._x = t[0], this._y = t[1], this._z = t[2], void 0 !== t[3] && (this._order = t[3]), this._onChangeCallback(), this;
		}
		toArray(t = [], e = 0) {
			return t[e] = this._x, t[e + 1] = this._y, t[e + 2] = this._z, t[e + 3] = this._order, t;
		}
		_onChange(t) {
			return this._onChangeCallback = t, this;
		}
		_onChangeCallback() {}
		*[Symbol.iterator]() {
			yield this._x, yield this._y, yield this._z, yield this._order;
		}
	};
	_r.DEFAULT_ORDER = "XYZ";
	var xr = class {
		constructor() {
			this.mask = 1;
		}
		set(t) {
			this.mask = (1 << t | 0) >>> 0;
		}
		enable(t) {
			this.mask |= 1 << t | 0;
		}
		enableAll() {
			this.mask = -1;
		}
		toggle(t) {
			this.mask ^= 1 << t | 0;
		}
		disable(t) {
			this.mask &= ~(1 << t | 0);
		}
		disableAll() {
			this.mask = 0;
		}
		test(t) {
			return 0 != (this.mask & t.mask);
		}
		isEnabled(t) {
			return 0 != (this.mask & (1 << t | 0));
		}
	};
	let yr = 0;
	const Mr = new Li(), Sr = new Ii(), br = new lr(), wr = new Li(), Tr = new Li(), Er = new Li(), Ar = new Ii(), Rr = new Li(1, 0, 0), Cr = new Li(0, 1, 0), Pr = new Li(0, 0, 1), Ir = { type: "added" }, Lr = { type: "removed" }, Ur = {
		type: "childadded",
		child: null
	}, Nr = {
		type: "childremoved",
		child: null
	};
	var Dr = class Dr extends Hn {
		constructor() {
			super(), this.isObject3D = !0, Object.defineProperty(this, "id", { value: yr++ }), this.uuid = qn(), this.name = "", this.type = "Object3D", this.parent = null, this.children = [], this.up = Dr.DEFAULT_UP.clone();
			const t = new Li(), e = new _r(), n = new Ii(), i = new Li(1, 1, 1);
			e._onChange((function() {
				n.setFromEuler(e, !1);
			})), n._onChange((function() {
				e.setFromQuaternion(n, void 0, !1);
			})), Object.defineProperties(this, {
				position: {
					configurable: !0,
					enumerable: !0,
					value: t
				},
				rotation: {
					configurable: !0,
					enumerable: !0,
					value: e
				},
				quaternion: {
					configurable: !0,
					enumerable: !0,
					value: n
				},
				scale: {
					configurable: !0,
					enumerable: !0,
					value: i
				},
				modelViewMatrix: { value: new lr() },
				normalMatrix: { value: new ei() }
			}), this.matrix = new lr(), this.matrixWorld = new lr(), this.matrixAutoUpdate = Dr.DEFAULT_MATRIX_AUTO_UPDATE, this.matrixWorldAutoUpdate = Dr.DEFAULT_MATRIX_WORLD_AUTO_UPDATE, this.matrixWorldNeedsUpdate = !1, this.layers = new xr(), this.visible = !0, this.castShadow = !1, this.receiveShadow = !1, this.frustumCulled = !0, this.renderOrder = 0, this.animations = [], this.userData = {};
		}
		onBeforeShadow() {}
		onAfterShadow() {}
		onBeforeRender() {}
		onAfterRender() {}
		applyMatrix4(t) {
			this.matrixAutoUpdate && this.updateMatrix(), this.matrix.premultiply(t), this.matrix.decompose(this.position, this.quaternion, this.scale);
		}
		applyQuaternion(t) {
			return this.quaternion.premultiply(t), this;
		}
		setRotationFromAxisAngle(t, e) {
			this.quaternion.setFromAxisAngle(t, e);
		}
		setRotationFromEuler(t) {
			this.quaternion.setFromEuler(t, !0);
		}
		setRotationFromMatrix(t) {
			this.quaternion.setFromRotationMatrix(t);
		}
		setRotationFromQuaternion(t) {
			this.quaternion.copy(t);
		}
		rotateOnAxis(t, e) {
			return Sr.setFromAxisAngle(t, e), this.quaternion.multiply(Sr), this;
		}
		rotateOnWorldAxis(t, e) {
			return Sr.setFromAxisAngle(t, e), this.quaternion.premultiply(Sr), this;
		}
		rotateX(t) {
			return this.rotateOnAxis(Rr, t);
		}
		rotateY(t) {
			return this.rotateOnAxis(Cr, t);
		}
		rotateZ(t) {
			return this.rotateOnAxis(Pr, t);
		}
		translateOnAxis(t, e) {
			return Mr.copy(t).applyQuaternion(this.quaternion), this.position.add(Mr.multiplyScalar(e)), this;
		}
		translateX(t) {
			return this.translateOnAxis(Rr, t);
		}
		translateY(t) {
			return this.translateOnAxis(Cr, t);
		}
		translateZ(t) {
			return this.translateOnAxis(Pr, t);
		}
		localToWorld(t) {
			return this.updateWorldMatrix(!0, !1), t.applyMatrix4(this.matrixWorld);
		}
		worldToLocal(t) {
			return this.updateWorldMatrix(!0, !1), t.applyMatrix4(br.copy(this.matrixWorld).invert());
		}
		lookAt(t, e, n) {
			t.isVector3 ? wr.copy(t) : wr.set(t, e, n);
			const i = this.parent;
			this.updateWorldMatrix(!0, !1), Tr.setFromMatrixPosition(this.matrixWorld), this.isCamera || this.isLight ? br.lookAt(Tr, wr, this.up) : br.lookAt(wr, Tr, this.up), this.quaternion.setFromRotationMatrix(br), i && (br.extractRotation(i.matrixWorld), Sr.setFromRotationMatrix(br), this.quaternion.premultiply(Sr.invert()));
		}
		add(t) {
			if (arguments.length > 1) {
				for (let t = 0; t < arguments.length; t++) this.add(arguments[t]);
				return this;
			}
			return t === this ? (console.error("THREE.Object3D.add: object can't be added as a child of itself.", t), this) : (t && t.isObject3D ? (t.removeFromParent(), t.parent = this, this.children.push(t), t.dispatchEvent(Ir), Ur.child = t, this.dispatchEvent(Ur), Ur.child = null) : console.error("THREE.Object3D.add: object not an instance of THREE.Object3D.", t), this);
		}
		remove(t) {
			if (arguments.length > 1) {
				for (let t = 0; t < arguments.length; t++) this.remove(arguments[t]);
				return this;
			}
			const e = this.children.indexOf(t);
			return -1 !== e && (t.parent = null, this.children.splice(e, 1), t.dispatchEvent(Lr), Nr.child = t, this.dispatchEvent(Nr), Nr.child = null), this;
		}
		removeFromParent() {
			const t = this.parent;
			return null !== t && t.remove(this), this;
		}
		clear() {
			return this.remove(...this.children);
		}
		attach(t) {
			return this.updateWorldMatrix(!0, !1), br.copy(this.matrixWorld).invert(), null !== t.parent && (t.parent.updateWorldMatrix(!0, !1), br.multiply(t.parent.matrixWorld)), t.applyMatrix4(br), t.removeFromParent(), t.parent = this, this.children.push(t), t.updateWorldMatrix(!1, !0), t.dispatchEvent(Ir), Ur.child = t, this.dispatchEvent(Ur), Ur.child = null, this;
		}
		getObjectById(t) {
			return this.getObjectByProperty("id", t);
		}
		getObjectByName(t) {
			return this.getObjectByProperty("name", t);
		}
		getObjectByProperty(t, e) {
			if (this[t] === e) return this;
			for (let n = 0, i = this.children.length; n < i; n++) {
				const i = this.children[n].getObjectByProperty(t, e);
				if (void 0 !== i) return i;
			}
		}
		getObjectsByProperty(t, e, n = []) {
			this[t] === e && n.push(this);
			const i = this.children;
			for (let r = 0, s = i.length; r < s; r++) i[r].getObjectsByProperty(t, e, n);
			return n;
		}
		getWorldPosition(t) {
			return this.updateWorldMatrix(!0, !1), t.setFromMatrixPosition(this.matrixWorld);
		}
		getWorldQuaternion(t) {
			return this.updateWorldMatrix(!0, !1), this.matrixWorld.decompose(Tr, t, Er), t;
		}
		getWorldScale(t) {
			return this.updateWorldMatrix(!0, !1), this.matrixWorld.decompose(Tr, Ar, t), t;
		}
		getWorldDirection(t) {
			this.updateWorldMatrix(!0, !1);
			const e = this.matrixWorld.elements;
			return t.set(e[8], e[9], e[10]).normalize();
		}
		raycast() {}
		traverse(t) {
			t(this);
			const e = this.children;
			for (let n = 0, i = e.length; n < i; n++) e[n].traverse(t);
		}
		traverseVisible(t) {
			if (!1 === this.visible) return;
			t(this);
			const e = this.children;
			for (let n = 0, i = e.length; n < i; n++) e[n].traverseVisible(t);
		}
		traverseAncestors(t) {
			const e = this.parent;
			null !== e && (t(e), e.traverseAncestors(t));
		}
		updateMatrix() {
			this.matrix.compose(this.position, this.quaternion, this.scale), this.matrixWorldNeedsUpdate = !0;
		}
		updateMatrixWorld(t) {
			this.matrixAutoUpdate && this.updateMatrix(), (this.matrixWorldNeedsUpdate || t) && (!0 === this.matrixWorldAutoUpdate && (null === this.parent ? this.matrixWorld.copy(this.matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix)), this.matrixWorldNeedsUpdate = !1, t = !0);
			const e = this.children;
			for (let n = 0, i = e.length; n < i; n++) e[n].updateMatrixWorld(t);
		}
		updateWorldMatrix(t, e) {
			const n = this.parent;
			if (!0 === t && null !== n && n.updateWorldMatrix(!0, !1), this.matrixAutoUpdate && this.updateMatrix(), !0 === this.matrixWorldAutoUpdate && (null === this.parent ? this.matrixWorld.copy(this.matrix) : this.matrixWorld.multiplyMatrices(this.parent.matrixWorld, this.matrix)), !0 === e) {
				const t = this.children;
				for (let e = 0, n = t.length; e < n; e++) t[e].updateWorldMatrix(!1, !0);
			}
		}
		toJSON(t) {
			const e = void 0 === t || "string" == typeof t, n = {};
			e && (t = {
				geometries: {},
				materials: {},
				textures: {},
				images: {},
				shapes: {},
				skeletons: {},
				animations: {},
				nodes: {}
			}, n.metadata = {
				version: 4.6,
				type: "Object",
				generator: "Object3D.toJSON"
			});
			const i = {};
			function r(e, n) {
				return void 0 === e[n.uuid] && (e[n.uuid] = n.toJSON(t)), n.uuid;
			}
			if (i.uuid = this.uuid, i.type = this.type, "" !== this.name && (i.name = this.name), !0 === this.castShadow && (i.castShadow = !0), !0 === this.receiveShadow && (i.receiveShadow = !0), !1 === this.visible && (i.visible = !1), !1 === this.frustumCulled && (i.frustumCulled = !1), 0 !== this.renderOrder && (i.renderOrder = this.renderOrder), Object.keys(this.userData).length > 0 && (i.userData = this.userData), i.layers = this.layers.mask, i.matrix = this.matrix.toArray(), i.up = this.up.toArray(), !1 === this.matrixAutoUpdate && (i.matrixAutoUpdate = !1), this.isInstancedMesh && (i.type = "InstancedMesh", i.count = this.count, i.instanceMatrix = this.instanceMatrix.toJSON(), null !== this.instanceColor && (i.instanceColor = this.instanceColor.toJSON())), this.isBatchedMesh && (i.type = "BatchedMesh", i.perObjectFrustumCulled = this.perObjectFrustumCulled, i.sortObjects = this.sortObjects, i.drawRanges = this._drawRanges, i.reservedRanges = this._reservedRanges, i.visibility = this._visibility, i.active = this._active, i.bounds = this._bounds.map(((t) => ({
				boxInitialized: t.boxInitialized,
				boxMin: t.box.min.toArray(),
				boxMax: t.box.max.toArray(),
				sphereInitialized: t.sphereInitialized,
				sphereRadius: t.sphere.radius,
				sphereCenter: t.sphere.center.toArray()
			}))), i.maxInstanceCount = this._maxInstanceCount, i.maxVertexCount = this._maxVertexCount, i.maxIndexCount = this._maxIndexCount, i.geometryInitialized = this._geometryInitialized, i.geometryCount = this._geometryCount, i.matricesTexture = this._matricesTexture.toJSON(t), null !== this._colorsTexture && (i.colorsTexture = this._colorsTexture.toJSON(t)), null !== this.boundingSphere && (i.boundingSphere = {
				center: i.boundingSphere.center.toArray(),
				radius: i.boundingSphere.radius
			}), null !== this.boundingBox && (i.boundingBox = {
				min: i.boundingBox.min.toArray(),
				max: i.boundingBox.max.toArray()
			})), this.isScene) this.background && (this.background.isColor ? i.background = this.background.toJSON() : this.background.isTexture && (i.background = this.background.toJSON(t).uuid)), this.environment && this.environment.isTexture && !0 !== this.environment.isRenderTargetTexture && (i.environment = this.environment.toJSON(t).uuid);
			else if (this.isMesh || this.isLine || this.isPoints) {
				i.geometry = r(t.geometries, this.geometry);
				const e = this.geometry.parameters;
				if (void 0 !== e && void 0 !== e.shapes) {
					const n = e.shapes;
					if (Array.isArray(n)) for (let e = 0, i = n.length; e < i; e++) {
						const i = n[e];
						r(t.shapes, i);
					}
					else r(t.shapes, n);
				}
			}
			if (this.isSkinnedMesh && (i.bindMode = this.bindMode, i.bindMatrix = this.bindMatrix.toArray(), void 0 !== this.skeleton && (r(t.skeletons, this.skeleton), i.skeleton = this.skeleton.uuid)), void 0 !== this.material) if (Array.isArray(this.material)) {
				const e = [];
				for (let n = 0, i = this.material.length; n < i; n++) e.push(r(t.materials, this.material[n]));
				i.material = e;
			} else i.material = r(t.materials, this.material);
			if (this.children.length > 0) {
				i.children = [];
				for (let e = 0; e < this.children.length; e++) i.children.push(this.children[e].toJSON(t).object);
			}
			if (this.animations.length > 0) {
				i.animations = [];
				for (let e = 0; e < this.animations.length; e++) {
					const n = this.animations[e];
					i.animations.push(r(t.animations, n));
				}
			}
			if (e) {
				const e = s(t.geometries), i = s(t.materials), r = s(t.textures), a = s(t.images), o = s(t.shapes), l = s(t.skeletons), c = s(t.animations), h = s(t.nodes);
				e.length > 0 && (n.geometries = e), i.length > 0 && (n.materials = i), r.length > 0 && (n.textures = r), a.length > 0 && (n.images = a), o.length > 0 && (n.shapes = o), l.length > 0 && (n.skeletons = l), c.length > 0 && (n.animations = c), h.length > 0 && (n.nodes = h);
			}
			return n.object = i, n;
			function s(t) {
				const e = [];
				for (const n in t) {
					const i = t[n];
					delete i.metadata, e.push(i);
				}
				return e;
			}
		}
		clone(t) {
			return new this.constructor().copy(this, t);
		}
		copy(t, e = !0) {
			if (this.name = t.name, this.up.copy(t.up), this.position.copy(t.position), this.rotation.order = t.rotation.order, this.quaternion.copy(t.quaternion), this.scale.copy(t.scale), this.matrix.copy(t.matrix), this.matrixWorld.copy(t.matrixWorld), this.matrixAutoUpdate = t.matrixAutoUpdate, this.matrixWorldAutoUpdate = t.matrixWorldAutoUpdate, this.matrixWorldNeedsUpdate = t.matrixWorldNeedsUpdate, this.layers.mask = t.layers.mask, this.visible = t.visible, this.castShadow = t.castShadow, this.receiveShadow = t.receiveShadow, this.frustumCulled = t.frustumCulled, this.renderOrder = t.renderOrder, this.animations = t.animations.slice(), this.userData = JSON.parse(JSON.stringify(t.userData)), !0 === e) for (let e = 0; e < t.children.length; e++) {
				const n = t.children[e];
				this.add(n.clone());
			}
			return this;
		}
	};
	Dr.DEFAULT_UP = new Li(0, 1, 0), Dr.DEFAULT_MATRIX_AUTO_UPDATE = !0, Dr.DEFAULT_MATRIX_WORLD_AUTO_UPDATE = !0;
	const Or = new Li(), Fr = new Li(), Br = new Li(), zr = new Li(), kr = new Li(), Vr = new Li(), Hr = new Li(), Gr = new Li(), Wr = new Li(), Xr = new Li(), jr = new wi(), qr = new wi(), Yr = new wi();
	var Zr = class Zr {
		constructor(t = new Li(), e = new Li(), n = new Li()) {
			this.a = t, this.b = e, this.c = n;
		}
		static getNormal(t, e, n, i) {
			i.subVectors(n, e), Or.subVectors(t, e), i.cross(Or);
			const r = i.lengthSq();
			return r > 0 ? i.multiplyScalar(1 / Math.sqrt(r)) : i.set(0, 0, 0);
		}
		static getBarycoord(t, e, n, i, r) {
			Or.subVectors(i, e), Fr.subVectors(n, e), Br.subVectors(t, e);
			const s = Or.dot(Or), a = Or.dot(Fr), o = Or.dot(Br), l = Fr.dot(Fr), c = Fr.dot(Br), h = s * l - a * a;
			if (0 === h) return r.set(0, 0, 0), null;
			const u = 1 / h, d = (l * o - a * c) * u, p = (s * c - a * o) * u;
			return r.set(1 - d - p, p, d);
		}
		static containsPoint(t, e, n, i) {
			return null !== this.getBarycoord(t, e, n, i, zr) && zr.x >= 0 && zr.y >= 0 && zr.x + zr.y <= 1;
		}
		static getInterpolation(t, e, n, i, r, s, a, o) {
			return null === this.getBarycoord(t, e, n, i, zr) ? (o.x = 0, o.y = 0, "z" in o && (o.z = 0), "w" in o && (o.w = 0), null) : (o.setScalar(0), o.addScaledVector(r, zr.x), o.addScaledVector(s, zr.y), o.addScaledVector(a, zr.z), o);
		}
		static getInterpolatedAttribute(t, e, n, i, r, s) {
			return jr.setScalar(0), qr.setScalar(0), Yr.setScalar(0), jr.fromBufferAttribute(t, e), qr.fromBufferAttribute(t, n), Yr.fromBufferAttribute(t, i), s.setScalar(0), s.addScaledVector(jr, r.x), s.addScaledVector(qr, r.y), s.addScaledVector(Yr, r.z), s;
		}
		static isFrontFacing(t, e, n, i) {
			return Or.subVectors(n, e), Fr.subVectors(t, e), Or.cross(Fr).dot(i) < 0;
		}
		set(t, e, n) {
			return this.a.copy(t), this.b.copy(e), this.c.copy(n), this;
		}
		setFromPointsAndIndices(t, e, n, i) {
			return this.a.copy(t[e]), this.b.copy(t[n]), this.c.copy(t[i]), this;
		}
		setFromAttributeAndIndices(t, e, n, i) {
			return this.a.fromBufferAttribute(t, e), this.b.fromBufferAttribute(t, n), this.c.fromBufferAttribute(t, i), this;
		}
		clone() {
			return new this.constructor().copy(this);
		}
		copy(t) {
			return this.a.copy(t.a), this.b.copy(t.b), this.c.copy(t.c), this;
		}
		getArea() {
			return Or.subVectors(this.c, this.b), Fr.subVectors(this.a, this.b), .5 * Or.cross(Fr).length();
		}
		getMidpoint(t) {
			return t.addVectors(this.a, this.b).add(this.c).multiplyScalar(1 / 3);
		}
		getNormal(t) {
			return Zr.getNormal(this.a, this.b, this.c, t);
		}
		getPlane(t) {
			return t.setFromCoplanarPoints(this.a, this.b, this.c);
		}
		getBarycoord(t, e) {
			return Zr.getBarycoord(t, this.a, this.b, this.c, e);
		}
		getInterpolation(t, e, n, i, r) {
			return Zr.getInterpolation(t, this.a, this.b, this.c, e, n, i, r);
		}
		containsPoint(t) {
			return Zr.containsPoint(t, this.a, this.b, this.c);
		}
		isFrontFacing(t) {
			return Zr.isFrontFacing(this.a, this.b, this.c, t);
		}
		intersectsBox(t) {
			return t.intersectsTriangle(this);
		}
		closestPointToPoint(t, e) {
			const n = this.a, i = this.b, r = this.c;
			let s, a;
			kr.subVectors(i, n), Vr.subVectors(r, n), Gr.subVectors(t, n);
			const o = kr.dot(Gr), l = Vr.dot(Gr);
			if (o <= 0 && l <= 0) return e.copy(n);
			Wr.subVectors(t, i);
			const c = kr.dot(Wr), h = Vr.dot(Wr);
			if (c >= 0 && h <= c) return e.copy(i);
			const u = o * h - c * l;
			if (u <= 0 && o >= 0 && c <= 0) return s = o / (o - c), e.copy(n).addScaledVector(kr, s);
			Xr.subVectors(t, r);
			const d = kr.dot(Xr), p = Vr.dot(Xr);
			if (p >= 0 && d <= p) return e.copy(r);
			const m = d * l - o * p;
			if (m <= 0 && l >= 0 && p <= 0) return a = l / (l - p), e.copy(n).addScaledVector(Vr, a);
			const f = c * p - d * h;
			if (f <= 0 && h - c >= 0 && d - p >= 0) return Hr.subVectors(r, i), a = (h - c) / (h - c + (d - p)), e.copy(i).addScaledVector(Hr, a);
			const g = 1 / (f + m + u);
			return s = m * g, a = u * g, e.copy(n).addScaledVector(kr, s).addScaledVector(Vr, a);
		}
		equals(t) {
			return t.a.equals(this.a) && t.b.equals(this.b) && t.c.equals(this.c);
		}
	};
	const Jr = {
		aliceblue: 15792383,
		antiquewhite: 16444375,
		aqua: 65535,
		aquamarine: 8388564,
		azure: 15794175,
		beige: 16119260,
		bisque: 16770244,
		black: 0,
		blanchedalmond: 16772045,
		blue: 255,
		blueviolet: 9055202,
		brown: 10824234,
		burlywood: 14596231,
		cadetblue: 6266528,
		chartreuse: 8388352,
		chocolate: 13789470,
		coral: 16744272,
		cornflowerblue: 6591981,
		cornsilk: 16775388,
		crimson: 14423100,
		cyan: 65535,
		darkblue: 139,
		darkcyan: 35723,
		darkgoldenrod: 12092939,
		darkgray: 11119017,
		darkgreen: 25600,
		darkgrey: 11119017,
		darkkhaki: 12433259,
		darkmagenta: 9109643,
		darkolivegreen: 5597999,
		darkorange: 16747520,
		darkorchid: 10040012,
		darkred: 9109504,
		darksalmon: 15308410,
		darkseagreen: 9419919,
		darkslateblue: 4734347,
		darkslategray: 3100495,
		darkslategrey: 3100495,
		darkturquoise: 52945,
		darkviolet: 9699539,
		deeppink: 16716947,
		deepskyblue: 49151,
		dimgray: 6908265,
		dimgrey: 6908265,
		dodgerblue: 2003199,
		firebrick: 11674146,
		floralwhite: 16775920,
		forestgreen: 2263842,
		fuchsia: 16711935,
		gainsboro: 14474460,
		ghostwhite: 16316671,
		gold: 16766720,
		goldenrod: 14329120,
		gray: 8421504,
		green: 32768,
		greenyellow: 11403055,
		grey: 8421504,
		honeydew: 15794160,
		hotpink: 16738740,
		indianred: 13458524,
		indigo: 4915330,
		ivory: 16777200,
		khaki: 15787660,
		lavender: 15132410,
		lavenderblush: 16773365,
		lawngreen: 8190976,
		lemonchiffon: 16775885,
		lightblue: 11393254,
		lightcoral: 15761536,
		lightcyan: 14745599,
		lightgoldenrodyellow: 16448210,
		lightgray: 13882323,
		lightgreen: 9498256,
		lightgrey: 13882323,
		lightpink: 16758465,
		lightsalmon: 16752762,
		lightseagreen: 2142890,
		lightskyblue: 8900346,
		lightslategray: 7833753,
		lightslategrey: 7833753,
		lightsteelblue: 11584734,
		lightyellow: 16777184,
		lime: 65280,
		limegreen: 3329330,
		linen: 16445670,
		magenta: 16711935,
		maroon: 8388608,
		mediumaquamarine: 6737322,
		mediumblue: 205,
		mediumorchid: 12211667,
		mediumpurple: 9662683,
		mediumseagreen: 3978097,
		mediumslateblue: 8087790,
		mediumspringgreen: 64154,
		mediumturquoise: 4772300,
		mediumvioletred: 13047173,
		midnightblue: 1644912,
		mintcream: 16121850,
		mistyrose: 16770273,
		moccasin: 16770229,
		navajowhite: 16768685,
		navy: 128,
		oldlace: 16643558,
		olive: 8421376,
		olivedrab: 7048739,
		orange: 16753920,
		orangered: 16729344,
		orchid: 14315734,
		palegoldenrod: 15657130,
		palegreen: 10025880,
		paleturquoise: 11529966,
		palevioletred: 14381203,
		papayawhip: 16773077,
		peachpuff: 16767673,
		peru: 13468991,
		pink: 16761035,
		plum: 14524637,
		powderblue: 11591910,
		purple: 8388736,
		rebeccapurple: 6697881,
		red: 16711680,
		rosybrown: 12357519,
		royalblue: 4286945,
		saddlebrown: 9127187,
		salmon: 16416882,
		sandybrown: 16032864,
		seagreen: 3050327,
		seashell: 16774638,
		sienna: 10506797,
		silver: 12632256,
		skyblue: 8900331,
		slateblue: 6970061,
		slategray: 7372944,
		slategrey: 7372944,
		snow: 16775930,
		springgreen: 65407,
		steelblue: 4620980,
		tan: 13808780,
		teal: 32896,
		thistle: 14204888,
		tomato: 16737095,
		turquoise: 4251856,
		violet: 15631086,
		wheat: 16113331,
		white: 16777215,
		whitesmoke: 16119285,
		yellow: 16776960,
		yellowgreen: 10145074
	}, Kr = {
		h: 0,
		s: 0,
		l: 0
	}, $r = {
		h: 0,
		s: 0,
		l: 0
	};
	function Qr(t, e, n) {
		return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? t + 6 * (e - t) * n : n < .5 ? e : n < 2 / 3 ? t + 6 * (e - t) * (2 / 3 - n) : t;
	}
	var ts = class {
		constructor(t, e, n) {
			return this.isColor = !0, this.r = 1, this.g = 1, this.b = 1, this.set(t, e, n);
		}
		set(t, e, n) {
			if (void 0 === e && void 0 === n) {
				const e = t;
				e && e.isColor ? this.copy(e) : "number" == typeof e ? this.setHex(e) : "string" == typeof e && this.setStyle(e);
			} else this.setRGB(t, e, n);
			return this;
		}
		setScalar(t) {
			return this.r = t, this.g = t, this.b = t, this;
		}
		setHex(t, e = Je) {
			return t = Math.floor(t), this.r = (t >> 16 & 255) / 255, this.g = (t >> 8 & 255) / 255, this.b = (255 & t) / 255, mi.toWorkingColorSpace(this, e), this;
		}
		setRGB(t, e, n, i = mi.workingColorSpace) {
			return this.r = t, this.g = e, this.b = n, mi.toWorkingColorSpace(this, i), this;
		}
		setHSL(t, e, n, i = mi.workingColorSpace) {
			if (t = Zn(t, 1), e = Yn(e, 0, 1), n = Yn(n, 0, 1), 0 === e) this.r = this.g = this.b = n;
			else {
				const i = n <= .5 ? n * (1 + e) : n + e - n * e, r = 2 * n - i;
				this.r = Qr(r, i, t + 1 / 3), this.g = Qr(r, i, t), this.b = Qr(r, i, t - 1 / 3);
			}
			return mi.toWorkingColorSpace(this, i), this;
		}
		setStyle(t, e = Je) {
			function n(e) {
				void 0 !== e && parseFloat(e) < 1 && console.warn("THREE.Color: Alpha component of " + t + " will be ignored.");
			}
			let i;
			if (i = /^(\w+)\(([^\)]*)\)/.exec(t)) {
				let r;
				const s = i[1], a = i[2];
				switch (s) {
					case "rgb":
					case "rgba":
						if (r = /^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a)) return n(r[4]), this.setRGB(Math.min(255, parseInt(r[1], 10)) / 255, Math.min(255, parseInt(r[2], 10)) / 255, Math.min(255, parseInt(r[3], 10)) / 255, e);
						if (r = /^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a)) return n(r[4]), this.setRGB(Math.min(100, parseInt(r[1], 10)) / 100, Math.min(100, parseInt(r[2], 10)) / 100, Math.min(100, parseInt(r[3], 10)) / 100, e);
						break;
					case "hsl":
					case "hsla":
						if (r = /^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a)) return n(r[4]), this.setHSL(parseFloat(r[1]) / 360, parseFloat(r[2]) / 100, parseFloat(r[3]) / 100, e);
						break;
					default: console.warn("THREE.Color: Unknown color model " + t);
				}
			} else if (i = /^\#([A-Fa-f\d]+)$/.exec(t)) {
				const n = i[1], r = n.length;
				if (3 === r) return this.setRGB(parseInt(n.charAt(0), 16) / 15, parseInt(n.charAt(1), 16) / 15, parseInt(n.charAt(2), 16) / 15, e);
				if (6 === r) return this.setHex(parseInt(n, 16), e);
				console.warn("THREE.Color: Invalid hex color " + t);
			} else if (t && t.length > 0) return this.setColorName(t, e);
			return this;
		}
		setColorName(t, e = Je) {
			const n = Jr[t.toLowerCase()];
			return void 0 !== n ? this.setHex(n, e) : console.warn("THREE.Color: Unknown color " + t), this;
		}
		clone() {
			return new this.constructor(this.r, this.g, this.b);
		}
		copy(t) {
			return this.r = t.r, this.g = t.g, this.b = t.b, this;
		}
		copySRGBToLinear(t) {
			return this.r = fi(t.r), this.g = fi(t.g), this.b = fi(t.b), this;
		}
		copyLinearToSRGB(t) {
			return this.r = gi(t.r), this.g = gi(t.g), this.b = gi(t.b), this;
		}
		convertSRGBToLinear() {
			return this.copySRGBToLinear(this), this;
		}
		convertLinearToSRGB() {
			return this.copyLinearToSRGB(this), this;
		}
		getHex(t = Je) {
			return mi.fromWorkingColorSpace(es.copy(this), t), 65536 * Math.round(Yn(255 * es.r, 0, 255)) + 256 * Math.round(Yn(255 * es.g, 0, 255)) + Math.round(Yn(255 * es.b, 0, 255));
		}
		getHexString(t = Je) {
			return ("000000" + this.getHex(t).toString(16)).slice(-6);
		}
		getHSL(t, e = mi.workingColorSpace) {
			mi.fromWorkingColorSpace(es.copy(this), e);
			const n = es.r, i = es.g, r = es.b, s = Math.max(n, i, r), a = Math.min(n, i, r);
			let o, l;
			const c = (a + s) / 2;
			if (a === s) o = 0, l = 0;
			else {
				const t = s - a;
				switch (l = c <= .5 ? t / (s + a) : t / (2 - s - a), s) {
					case n:
						o = (i - r) / t + (i < r ? 6 : 0);
						break;
					case i:
						o = (r - n) / t + 2;
						break;
					case r: o = (n - i) / t + 4;
				}
				o /= 6;
			}
			return t.h = o, t.s = l, t.l = c, t;
		}
		getRGB(t, e = mi.workingColorSpace) {
			return mi.fromWorkingColorSpace(es.copy(this), e), t.r = es.r, t.g = es.g, t.b = es.b, t;
		}
		getStyle(t = Je) {
			mi.fromWorkingColorSpace(es.copy(this), t);
			const e = es.r, n = es.g, i = es.b;
			return t !== "srgb" ? `color(${t} ${e.toFixed(3)} ${n.toFixed(3)} ${i.toFixed(3)})` : `rgb(${Math.round(255 * e)},${Math.round(255 * n)},${Math.round(255 * i)})`;
		}
		offsetHSL(t, e, n) {
			return this.getHSL(Kr), this.setHSL(Kr.h + t, Kr.s + e, Kr.l + n);
		}
		add(t) {
			return this.r += t.r, this.g += t.g, this.b += t.b, this;
		}
		addColors(t, e) {
			return this.r = t.r + e.r, this.g = t.g + e.g, this.b = t.b + e.b, this;
		}
		addScalar(t) {
			return this.r += t, this.g += t, this.b += t, this;
		}
		sub(t) {
			return this.r = Math.max(0, this.r - t.r), this.g = Math.max(0, this.g - t.g), this.b = Math.max(0, this.b - t.b), this;
		}
		multiply(t) {
			return this.r *= t.r, this.g *= t.g, this.b *= t.b, this;
		}
		multiplyScalar(t) {
			return this.r *= t, this.g *= t, this.b *= t, this;
		}
		lerp(t, e) {
			return this.r += (t.r - this.r) * e, this.g += (t.g - this.g) * e, this.b += (t.b - this.b) * e, this;
		}
		lerpColors(t, e, n) {
			return this.r = t.r + (e.r - t.r) * n, this.g = t.g + (e.g - t.g) * n, this.b = t.b + (e.b - t.b) * n, this;
		}
		lerpHSL(t, e) {
			this.getHSL(Kr), t.getHSL($r);
			const n = Jn(Kr.h, $r.h, e), i = Jn(Kr.s, $r.s, e), r = Jn(Kr.l, $r.l, e);
			return this.setHSL(n, i, r), this;
		}
		setFromVector3(t) {
			return this.r = t.x, this.g = t.y, this.b = t.z, this;
		}
		applyMatrix3(t) {
			const e = this.r, n = this.g, i = this.b, r = t.elements;
			return this.r = r[0] * e + r[3] * n + r[6] * i, this.g = r[1] * e + r[4] * n + r[7] * i, this.b = r[2] * e + r[5] * n + r[8] * i, this;
		}
		equals(t) {
			return t.r === this.r && t.g === this.g && t.b === this.b;
		}
		fromArray(t, e = 0) {
			return this.r = t[e], this.g = t[e + 1], this.b = t[e + 2], this;
		}
		toArray(t = [], e = 0) {
			return t[e] = this.r, t[e + 1] = this.g, t[e + 2] = this.b, t;
		}
		fromBufferAttribute(t, e) {
			return this.r = t.getX(e), this.g = t.getY(e), this.b = t.getZ(e), this;
		}
		toJSON() {
			return this.getHex();
		}
		*[Symbol.iterator]() {
			yield this.r, yield this.g, yield this.b;
		}
	};
	const es = new ts();
	ts.NAMES = Jr;
	let ns = 0;
	var is = class extends Hn {
		constructor() {
			super(), this.isMaterial = !0, Object.defineProperty(this, "id", { value: ns++ }), this.uuid = qn(), this.name = "", this.type = "Material", this.blending = 1, this.side = 0, this.vertexColors = !1, this.opacity = 1, this.transparent = !1, this.alphaHash = !1, this.blendSrc = 204, this.blendDst = 205, this.blendEquation = 100, this.blendSrcAlpha = null, this.blendDstAlpha = null, this.blendEquationAlpha = null, this.blendColor = new ts(0, 0, 0), this.blendAlpha = 0, this.depthFunc = 3, this.depthTest = !0, this.depthWrite = !0, this.stencilWriteMask = 255, this.stencilFunc = 519, this.stencilRef = 0, this.stencilFuncMask = 255, this.stencilFail = an, this.stencilZFail = an, this.stencilZPass = an, this.stencilWrite = !1, this.clippingPlanes = null, this.clipIntersection = !1, this.clipShadows = !1, this.shadowSide = null, this.colorWrite = !0, this.precision = null, this.polygonOffset = !1, this.polygonOffsetFactor = 0, this.polygonOffsetUnits = 0, this.dithering = !1, this.alphaToCoverage = !1, this.premultipliedAlpha = !1, this.forceSinglePass = !1, this.visible = !0, this.toneMapped = !0, this.userData = {}, this.version = 0, this._alphaTest = 0;
		}
		get alphaTest() {
			return this._alphaTest;
		}
		set alphaTest(t) {
			this._alphaTest > 0 != t > 0 && this.version++, this._alphaTest = t;
		}
		onBeforeRender() {}
		onBeforeCompile() {}
		customProgramCacheKey() {
			return this.onBeforeCompile.toString();
		}
		setValues(t) {
			if (void 0 !== t) for (const e in t) {
				const n = t[e];
				if (void 0 === n) {
					console.warn(`THREE.Material: parameter '${e}' has value of undefined.`);
					continue;
				}
				const i = this[e];
				void 0 !== i ? i && i.isColor ? i.set(n) : i && i.isVector3 && n && n.isVector3 ? i.copy(n) : this[e] = n : console.warn(`THREE.Material: '${e}' is not a property of THREE.${this.type}.`);
			}
		}
		toJSON(t) {
			const e = void 0 === t || "string" == typeof t;
			e && (t = {
				textures: {},
				images: {}
			});
			const n = { metadata: {
				version: 4.6,
				type: "Material",
				generator: "Material.toJSON"
			} };
			function i(t) {
				const e = [];
				for (const n in t) {
					const i = t[n];
					delete i.metadata, e.push(i);
				}
				return e;
			}
			if (n.uuid = this.uuid, n.type = this.type, "" !== this.name && (n.name = this.name), this.color && this.color.isColor && (n.color = this.color.getHex()), void 0 !== this.roughness && (n.roughness = this.roughness), void 0 !== this.metalness && (n.metalness = this.metalness), void 0 !== this.sheen && (n.sheen = this.sheen), this.sheenColor && this.sheenColor.isColor && (n.sheenColor = this.sheenColor.getHex()), void 0 !== this.sheenRoughness && (n.sheenRoughness = this.sheenRoughness), this.emissive && this.emissive.isColor && (n.emissive = this.emissive.getHex()), void 0 !== this.emissiveIntensity && 1 !== this.emissiveIntensity && (n.emissiveIntensity = this.emissiveIntensity), this.specular && this.specular.isColor && (n.specular = this.specular.getHex()), void 0 !== this.specularIntensity && (n.specularIntensity = this.specularIntensity), this.specularColor && this.specularColor.isColor && (n.specularColor = this.specularColor.getHex()), void 0 !== this.shininess && (n.shininess = this.shininess), void 0 !== this.clearcoat && (n.clearcoat = this.clearcoat), void 0 !== this.clearcoatRoughness && (n.clearcoatRoughness = this.clearcoatRoughness), this.clearcoatMap && this.clearcoatMap.isTexture && (n.clearcoatMap = this.clearcoatMap.toJSON(t).uuid), this.clearcoatRoughnessMap && this.clearcoatRoughnessMap.isTexture && (n.clearcoatRoughnessMap = this.clearcoatRoughnessMap.toJSON(t).uuid), this.clearcoatNormalMap && this.clearcoatNormalMap.isTexture && (n.clearcoatNormalMap = this.clearcoatNormalMap.toJSON(t).uuid, n.clearcoatNormalScale = this.clearcoatNormalScale.toArray()), void 0 !== this.dispersion && (n.dispersion = this.dispersion), void 0 !== this.iridescence && (n.iridescence = this.iridescence), void 0 !== this.iridescenceIOR && (n.iridescenceIOR = this.iridescenceIOR), void 0 !== this.iridescenceThicknessRange && (n.iridescenceThicknessRange = this.iridescenceThicknessRange), this.iridescenceMap && this.iridescenceMap.isTexture && (n.iridescenceMap = this.iridescenceMap.toJSON(t).uuid), this.iridescenceThicknessMap && this.iridescenceThicknessMap.isTexture && (n.iridescenceThicknessMap = this.iridescenceThicknessMap.toJSON(t).uuid), void 0 !== this.anisotropy && (n.anisotropy = this.anisotropy), void 0 !== this.anisotropyRotation && (n.anisotropyRotation = this.anisotropyRotation), this.anisotropyMap && this.anisotropyMap.isTexture && (n.anisotropyMap = this.anisotropyMap.toJSON(t).uuid), this.map && this.map.isTexture && (n.map = this.map.toJSON(t).uuid), this.matcap && this.matcap.isTexture && (n.matcap = this.matcap.toJSON(t).uuid), this.alphaMap && this.alphaMap.isTexture && (n.alphaMap = this.alphaMap.toJSON(t).uuid), this.lightMap && this.lightMap.isTexture && (n.lightMap = this.lightMap.toJSON(t).uuid, n.lightMapIntensity = this.lightMapIntensity), this.aoMap && this.aoMap.isTexture && (n.aoMap = this.aoMap.toJSON(t).uuid, n.aoMapIntensity = this.aoMapIntensity), this.bumpMap && this.bumpMap.isTexture && (n.bumpMap = this.bumpMap.toJSON(t).uuid, n.bumpScale = this.bumpScale), this.normalMap && this.normalMap.isTexture && (n.normalMap = this.normalMap.toJSON(t).uuid, n.normalMapType = this.normalMapType, n.normalScale = this.normalScale.toArray()), this.displacementMap && this.displacementMap.isTexture && (n.displacementMap = this.displacementMap.toJSON(t).uuid, n.displacementScale = this.displacementScale, n.displacementBias = this.displacementBias), this.roughnessMap && this.roughnessMap.isTexture && (n.roughnessMap = this.roughnessMap.toJSON(t).uuid), this.metalnessMap && this.metalnessMap.isTexture && (n.metalnessMap = this.metalnessMap.toJSON(t).uuid), this.emissiveMap && this.emissiveMap.isTexture && (n.emissiveMap = this.emissiveMap.toJSON(t).uuid), this.specularMap && this.specularMap.isTexture && (n.specularMap = this.specularMap.toJSON(t).uuid), this.specularIntensityMap && this.specularIntensityMap.isTexture && (n.specularIntensityMap = this.specularIntensityMap.toJSON(t).uuid), this.specularColorMap && this.specularColorMap.isTexture && (n.specularColorMap = this.specularColorMap.toJSON(t).uuid), this.envMap && this.envMap.isTexture && (n.envMap = this.envMap.toJSON(t).uuid, void 0 !== this.combine && (n.combine = this.combine)), void 0 !== this.envMapRotation && (n.envMapRotation = this.envMapRotation.toArray()), void 0 !== this.envMapIntensity && (n.envMapIntensity = this.envMapIntensity), void 0 !== this.reflectivity && (n.reflectivity = this.reflectivity), void 0 !== this.refractionRatio && (n.refractionRatio = this.refractionRatio), this.gradientMap && this.gradientMap.isTexture && (n.gradientMap = this.gradientMap.toJSON(t).uuid), void 0 !== this.transmission && (n.transmission = this.transmission), this.transmissionMap && this.transmissionMap.isTexture && (n.transmissionMap = this.transmissionMap.toJSON(t).uuid), void 0 !== this.thickness && (n.thickness = this.thickness), this.thicknessMap && this.thicknessMap.isTexture && (n.thicknessMap = this.thicknessMap.toJSON(t).uuid), void 0 !== this.attenuationDistance && this.attenuationDistance !== Infinity && (n.attenuationDistance = this.attenuationDistance), void 0 !== this.attenuationColor && (n.attenuationColor = this.attenuationColor.getHex()), void 0 !== this.size && (n.size = this.size), null !== this.shadowSide && (n.shadowSide = this.shadowSide), void 0 !== this.sizeAttenuation && (n.sizeAttenuation = this.sizeAttenuation), 1 !== this.blending && (n.blending = this.blending), this.side !== 0 && (n.side = this.side), !0 === this.vertexColors && (n.vertexColors = !0), this.opacity < 1 && (n.opacity = this.opacity), !0 === this.transparent && (n.transparent = !0), this.blendSrc !== 204 && (n.blendSrc = this.blendSrc), this.blendDst !== 205 && (n.blendDst = this.blendDst), this.blendEquation !== 100 && (n.blendEquation = this.blendEquation), null !== this.blendSrcAlpha && (n.blendSrcAlpha = this.blendSrcAlpha), null !== this.blendDstAlpha && (n.blendDstAlpha = this.blendDstAlpha), null !== this.blendEquationAlpha && (n.blendEquationAlpha = this.blendEquationAlpha), this.blendColor && this.blendColor.isColor && (n.blendColor = this.blendColor.getHex()), 0 !== this.blendAlpha && (n.blendAlpha = this.blendAlpha), 3 !== this.depthFunc && (n.depthFunc = this.depthFunc), !1 === this.depthTest && (n.depthTest = this.depthTest), !1 === this.depthWrite && (n.depthWrite = this.depthWrite), !1 === this.colorWrite && (n.colorWrite = this.colorWrite), 255 !== this.stencilWriteMask && (n.stencilWriteMask = this.stencilWriteMask), 519 !== this.stencilFunc && (n.stencilFunc = this.stencilFunc), 0 !== this.stencilRef && (n.stencilRef = this.stencilRef), 255 !== this.stencilFuncMask && (n.stencilFuncMask = this.stencilFuncMask), this.stencilFail !== 7680 && (n.stencilFail = this.stencilFail), this.stencilZFail !== 7680 && (n.stencilZFail = this.stencilZFail), this.stencilZPass !== 7680 && (n.stencilZPass = this.stencilZPass), !0 === this.stencilWrite && (n.stencilWrite = this.stencilWrite), void 0 !== this.rotation && 0 !== this.rotation && (n.rotation = this.rotation), !0 === this.polygonOffset && (n.polygonOffset = !0), 0 !== this.polygonOffsetFactor && (n.polygonOffsetFactor = this.polygonOffsetFactor), 0 !== this.polygonOffsetUnits && (n.polygonOffsetUnits = this.polygonOffsetUnits), void 0 !== this.linewidth && 1 !== this.linewidth && (n.linewidth = this.linewidth), void 0 !== this.dashSize && (n.dashSize = this.dashSize), void 0 !== this.gapSize && (n.gapSize = this.gapSize), void 0 !== this.scale && (n.scale = this.scale), !0 === this.dithering && (n.dithering = !0), this.alphaTest > 0 && (n.alphaTest = this.alphaTest), !0 === this.alphaHash && (n.alphaHash = !0), !0 === this.alphaToCoverage && (n.alphaToCoverage = !0), !0 === this.premultipliedAlpha && (n.premultipliedAlpha = !0), !0 === this.forceSinglePass && (n.forceSinglePass = !0), !0 === this.wireframe && (n.wireframe = !0), this.wireframeLinewidth > 1 && (n.wireframeLinewidth = this.wireframeLinewidth), "round" !== this.wireframeLinecap && (n.wireframeLinecap = this.wireframeLinecap), "round" !== this.wireframeLinejoin && (n.wireframeLinejoin = this.wireframeLinejoin), !0 === this.flatShading && (n.flatShading = !0), !1 === this.visible && (n.visible = !1), !1 === this.toneMapped && (n.toneMapped = !1), !1 === this.fog && (n.fog = !1), Object.keys(this.userData).length > 0 && (n.userData = this.userData), e) {
				const e = i(t.textures), r = i(t.images);
				e.length > 0 && (n.textures = e), r.length > 0 && (n.images = r);
			}
			return n;
		}
		clone() {
			return new this.constructor().copy(this);
		}
		copy(t) {
			this.name = t.name, this.blending = t.blending, this.side = t.side, this.vertexColors = t.vertexColors, this.opacity = t.opacity, this.transparent = t.transparent, this.blendSrc = t.blendSrc, this.blendDst = t.blendDst, this.blendEquation = t.blendEquation, this.blendSrcAlpha = t.blendSrcAlpha, this.blendDstAlpha = t.blendDstAlpha, this.blendEquationAlpha = t.blendEquationAlpha, this.blendColor.copy(t.blendColor), this.blendAlpha = t.blendAlpha, this.depthFunc = t.depthFunc, this.depthTest = t.depthTest, this.depthWrite = t.depthWrite, this.stencilWriteMask = t.stencilWriteMask, this.stencilFunc = t.stencilFunc, this.stencilRef = t.stencilRef, this.stencilFuncMask = t.stencilFuncMask, this.stencilFail = t.stencilFail, this.stencilZFail = t.stencilZFail, this.stencilZPass = t.stencilZPass, this.stencilWrite = t.stencilWrite;
			const e = t.clippingPlanes;
			let n = null;
			if (null !== e) {
				const t = e.length;
				n = new Array(t);
				for (let i = 0; i !== t; ++i) n[i] = e[i].clone();
			}
			return this.clippingPlanes = n, this.clipIntersection = t.clipIntersection, this.clipShadows = t.clipShadows, this.shadowSide = t.shadowSide, this.colorWrite = t.colorWrite, this.precision = t.precision, this.polygonOffset = t.polygonOffset, this.polygonOffsetFactor = t.polygonOffsetFactor, this.polygonOffsetUnits = t.polygonOffsetUnits, this.dithering = t.dithering, this.alphaTest = t.alphaTest, this.alphaHash = t.alphaHash, this.alphaToCoverage = t.alphaToCoverage, this.premultipliedAlpha = t.premultipliedAlpha, this.forceSinglePass = t.forceSinglePass, this.visible = t.visible, this.toneMapped = t.toneMapped, this.userData = JSON.parse(JSON.stringify(t.userData)), this;
		}
		dispose() {
			this.dispatchEvent({ type: "dispose" });
		}
		set needsUpdate(t) {
			!0 === t && this.version++;
		}
		onBuild() {
			console.warn("Material: onBuild() has been removed.");
		}
	};
	var rs = class extends is {
		constructor(t) {
			super(), this.isMeshBasicMaterial = !0, this.type = "MeshBasicMaterial", this.color = new ts(16777215), this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.specularMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new _r(), this.combine = 0, this.reflectivity = 1, this.refractionRatio = .98, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.color.copy(t.color), this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.specularMap = t.specularMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.combine = t.combine, this.reflectivity = t.reflectivity, this.refractionRatio = t.refractionRatio, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.fog = t.fog, this;
		}
	};
	const ss = as();
	function as() {
		const t = /* @__PURE__ */ new ArrayBuffer(4), e = new Float32Array(t), n = new Uint32Array(t), i = new Uint32Array(512), r = new Uint32Array(512);
		for (let t = 0; t < 256; ++t) {
			const e = t - 127;
			e < -27 ? (i[t] = 0, i[256 | t] = 32768, r[t] = 24, r[256 | t] = 24) : e < -14 ? (i[t] = 1024 >> -e - 14, i[256 | t] = 1024 >> -e - 14 | 32768, r[t] = -e - 1, r[256 | t] = -e - 1) : e <= 15 ? (i[t] = e + 15 << 10, i[256 | t] = e + 15 << 10 | 32768, r[t] = 13, r[256 | t] = 13) : e < 128 ? (i[t] = 31744, i[256 | t] = 64512, r[t] = 24, r[256 | t] = 24) : (i[t] = 31744, i[256 | t] = 64512, r[t] = 13, r[256 | t] = 13);
		}
		const s = new Uint32Array(2048), a = new Uint32Array(64), o = new Uint32Array(64);
		for (let t = 1; t < 1024; ++t) {
			let e = t << 13, n = 0;
			for (; 0 == (8388608 & e);) e <<= 1, n -= 8388608;
			e &= -8388609, n += 947912704, s[t] = e | n;
		}
		for (let t = 1024; t < 2048; ++t) s[t] = 939524096 + (t - 1024 << 13);
		for (let t = 1; t < 31; ++t) a[t] = t << 23;
		a[31] = 1199570944, a[32] = 2147483648;
		for (let t = 33; t < 63; ++t) a[t] = 2147483648 + (t - 32 << 23);
		a[63] = 3347054592;
		for (let t = 1; t < 64; ++t) 32 !== t && (o[t] = 1024);
		return {
			floatView: e,
			uint32View: n,
			baseTable: i,
			shiftTable: r,
			mantissaTable: s,
			exponentTable: a,
			offsetTable: o
		};
	}
	function os(t) {
		Math.abs(t) > 65504 && console.warn("THREE.DataUtils.toHalfFloat(): Value out of range."), t = Yn(t, -65504, 65504), ss.floatView[0] = t;
		const e = ss.uint32View[0], n = e >> 23 & 511;
		return ss.baseTable[n] + ((8388607 & e) >> ss.shiftTable[n]);
	}
	function ls(t) {
		const e = t >> 10;
		return ss.uint32View[0] = ss.mantissaTable[ss.offsetTable[e] + (1023 & t)] + ss.exponentTable[e], ss.floatView[0];
	}
	const cs = {
		toHalfFloat: os,
		fromHalfFloat: ls
	}, hs = new Li(), us = new ti();
	var ds = class {
		constructor(t, e, n = !1) {
			if (Array.isArray(t)) throw new TypeError("THREE.BufferAttribute: array should be a Typed Array.");
			this.isBufferAttribute = !0, this.name = "", this.array = t, this.itemSize = e, this.count = void 0 !== t ? t.length / e : 0, this.normalized = n, this.usage = Cn, this.updateRanges = [], this.gpuType = Lt, this.version = 0;
		}
		onUploadCallback() {}
		set needsUpdate(t) {
			!0 === t && this.version++;
		}
		setUsage(t) {
			return this.usage = t, this;
		}
		addUpdateRange(t, e) {
			this.updateRanges.push({
				start: t,
				count: e
			});
		}
		clearUpdateRanges() {
			this.updateRanges.length = 0;
		}
		copy(t) {
			return this.name = t.name, this.array = new t.array.constructor(t.array), this.itemSize = t.itemSize, this.count = t.count, this.normalized = t.normalized, this.usage = t.usage, this.gpuType = t.gpuType, this;
		}
		copyAt(t, e, n) {
			t *= this.itemSize, n *= e.itemSize;
			for (let i = 0, r = this.itemSize; i < r; i++) this.array[t + i] = e.array[n + i];
			return this;
		}
		copyArray(t) {
			return this.array.set(t), this;
		}
		applyMatrix3(t) {
			if (2 === this.itemSize) for (let e = 0, n = this.count; e < n; e++) us.fromBufferAttribute(this, e), us.applyMatrix3(t), this.setXY(e, us.x, us.y);
			else if (3 === this.itemSize) for (let e = 0, n = this.count; e < n; e++) hs.fromBufferAttribute(this, e), hs.applyMatrix3(t), this.setXYZ(e, hs.x, hs.y, hs.z);
			return this;
		}
		applyMatrix4(t) {
			for (let e = 0, n = this.count; e < n; e++) hs.fromBufferAttribute(this, e), hs.applyMatrix4(t), this.setXYZ(e, hs.x, hs.y, hs.z);
			return this;
		}
		applyNormalMatrix(t) {
			for (let e = 0, n = this.count; e < n; e++) hs.fromBufferAttribute(this, e), hs.applyNormalMatrix(t), this.setXYZ(e, hs.x, hs.y, hs.z);
			return this;
		}
		transformDirection(t) {
			for (let e = 0, n = this.count; e < n; e++) hs.fromBufferAttribute(this, e), hs.transformDirection(t), this.setXYZ(e, hs.x, hs.y, hs.z);
			return this;
		}
		set(t, e = 0) {
			return this.array.set(t, e), this;
		}
		getComponent(t, e) {
			let n = this.array[t * this.itemSize + e];
			return this.normalized && (n = Kn(n, this.array)), n;
		}
		setComponent(t, e, n) {
			return this.normalized && (n = $n(n, this.array)), this.array[t * this.itemSize + e] = n, this;
		}
		getX(t) {
			let e = this.array[t * this.itemSize];
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		setX(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.array[t * this.itemSize] = e, this;
		}
		getY(t) {
			let e = this.array[t * this.itemSize + 1];
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		setY(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.array[t * this.itemSize + 1] = e, this;
		}
		getZ(t) {
			let e = this.array[t * this.itemSize + 2];
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		setZ(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.array[t * this.itemSize + 2] = e, this;
		}
		getW(t) {
			let e = this.array[t * this.itemSize + 3];
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		setW(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.array[t * this.itemSize + 3] = e, this;
		}
		setXY(t, e, n) {
			return t *= this.itemSize, this.normalized && (e = $n(e, this.array), n = $n(n, this.array)), this.array[t + 0] = e, this.array[t + 1] = n, this;
		}
		setXYZ(t, e, n, i) {
			return t *= this.itemSize, this.normalized && (e = $n(e, this.array), n = $n(n, this.array), i = $n(i, this.array)), this.array[t + 0] = e, this.array[t + 1] = n, this.array[t + 2] = i, this;
		}
		setXYZW(t, e, n, i, r) {
			return t *= this.itemSize, this.normalized && (e = $n(e, this.array), n = $n(n, this.array), i = $n(i, this.array), r = $n(r, this.array)), this.array[t + 0] = e, this.array[t + 1] = n, this.array[t + 2] = i, this.array[t + 3] = r, this;
		}
		onUpload(t) {
			return this.onUploadCallback = t, this;
		}
		clone() {
			return new this.constructor(this.array, this.itemSize).copy(this);
		}
		toJSON() {
			const t = {
				itemSize: this.itemSize,
				type: this.array.constructor.name,
				array: Array.from(this.array),
				normalized: this.normalized
			};
			return "" !== this.name && (t.name = this.name), this.usage !== 35044 && (t.usage = this.usage), t;
		}
	};
	var ps = class extends ds {
		constructor(t, e, n) {
			super(new Int8Array(t), e, n);
		}
	};
	var ms = class extends ds {
		constructor(t, e, n) {
			super(new Uint8Array(t), e, n);
		}
	};
	var fs = class extends ds {
		constructor(t, e, n) {
			super(new Uint8ClampedArray(t), e, n);
		}
	};
	var gs = class extends ds {
		constructor(t, e, n) {
			super(new Int16Array(t), e, n);
		}
	};
	var vs = class extends ds {
		constructor(t, e, n) {
			super(new Uint16Array(t), e, n);
		}
	};
	var _s = class extends ds {
		constructor(t, e, n) {
			super(new Int32Array(t), e, n);
		}
	};
	var xs = class extends ds {
		constructor(t, e, n) {
			super(new Uint32Array(t), e, n);
		}
	};
	var ys = class extends ds {
		constructor(t, e, n) {
			super(new Uint16Array(t), e, n), this.isFloat16BufferAttribute = !0;
		}
		getX(t) {
			let e = ls(this.array[t * this.itemSize]);
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		setX(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.array[t * this.itemSize] = os(e), this;
		}
		getY(t) {
			let e = ls(this.array[t * this.itemSize + 1]);
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		setY(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.array[t * this.itemSize + 1] = os(e), this;
		}
		getZ(t) {
			let e = ls(this.array[t * this.itemSize + 2]);
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		setZ(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.array[t * this.itemSize + 2] = os(e), this;
		}
		getW(t) {
			let e = ls(this.array[t * this.itemSize + 3]);
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		setW(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.array[t * this.itemSize + 3] = os(e), this;
		}
		setXY(t, e, n) {
			return t *= this.itemSize, this.normalized && (e = $n(e, this.array), n = $n(n, this.array)), this.array[t + 0] = os(e), this.array[t + 1] = os(n), this;
		}
		setXYZ(t, e, n, i) {
			return t *= this.itemSize, this.normalized && (e = $n(e, this.array), n = $n(n, this.array), i = $n(i, this.array)), this.array[t + 0] = os(e), this.array[t + 1] = os(n), this.array[t + 2] = os(i), this;
		}
		setXYZW(t, e, n, i, r) {
			return t *= this.itemSize, this.normalized && (e = $n(e, this.array), n = $n(n, this.array), i = $n(i, this.array), r = $n(r, this.array)), this.array[t + 0] = os(e), this.array[t + 1] = os(n), this.array[t + 2] = os(i), this.array[t + 3] = os(r), this;
		}
	};
	var Ms = class extends ds {
		constructor(t, e, n) {
			super(new Float32Array(t), e, n);
		}
	};
	let Ss = 0;
	const bs = new lr(), ws = new Dr(), Ts = new Li(), Es = new Di(), As = new Di(), Rs = new Li();
	var Cs = class Cs extends Hn {
		constructor() {
			super(), this.isBufferGeometry = !0, Object.defineProperty(this, "id", { value: Ss++ }), this.uuid = qn(), this.name = "", this.type = "BufferGeometry", this.index = null, this.attributes = {}, this.morphAttributes = {}, this.morphTargetsRelative = !1, this.groups = [], this.boundingBox = null, this.boundingSphere = null, this.drawRange = {
				start: 0,
				count: Infinity
			}, this.userData = {};
		}
		getIndex() {
			return this.index;
		}
		setIndex(t) {
			return Array.isArray(t) ? this.index = new (ii(t) ? xs : vs)(t, 1) : this.index = t, this;
		}
		getAttribute(t) {
			return this.attributes[t];
		}
		setAttribute(t, e) {
			return this.attributes[t] = e, this;
		}
		deleteAttribute(t) {
			return delete this.attributes[t], this;
		}
		hasAttribute(t) {
			return void 0 !== this.attributes[t];
		}
		addGroup(t, e, n = 0) {
			this.groups.push({
				start: t,
				count: e,
				materialIndex: n
			});
		}
		clearGroups() {
			this.groups = [];
		}
		setDrawRange(t, e) {
			this.drawRange.start = t, this.drawRange.count = e;
		}
		applyMatrix4(t) {
			const e = this.attributes.position;
			void 0 !== e && (e.applyMatrix4(t), e.needsUpdate = !0);
			const n = this.attributes.normal;
			if (void 0 !== n) {
				const e = new ei().getNormalMatrix(t);
				n.applyNormalMatrix(e), n.needsUpdate = !0;
			}
			const i = this.attributes.tangent;
			return void 0 !== i && (i.transformDirection(t), i.needsUpdate = !0), null !== this.boundingBox && this.computeBoundingBox(), null !== this.boundingSphere && this.computeBoundingSphere(), this;
		}
		applyQuaternion(t) {
			return bs.makeRotationFromQuaternion(t), this.applyMatrix4(bs), this;
		}
		rotateX(t) {
			return bs.makeRotationX(t), this.applyMatrix4(bs), this;
		}
		rotateY(t) {
			return bs.makeRotationY(t), this.applyMatrix4(bs), this;
		}
		rotateZ(t) {
			return bs.makeRotationZ(t), this.applyMatrix4(bs), this;
		}
		translate(t, e, n) {
			return bs.makeTranslation(t, e, n), this.applyMatrix4(bs), this;
		}
		scale(t, e, n) {
			return bs.makeScale(t, e, n), this.applyMatrix4(bs), this;
		}
		lookAt(t) {
			return ws.lookAt(t), ws.updateMatrix(), this.applyMatrix4(ws.matrix), this;
		}
		center() {
			return this.computeBoundingBox(), this.boundingBox.getCenter(Ts).negate(), this.translate(Ts.x, Ts.y, Ts.z), this;
		}
		setFromPoints(t) {
			const e = [];
			for (let n = 0, i = t.length; n < i; n++) {
				const i = t[n];
				e.push(i.x, i.y, i.z || 0);
			}
			return this.setAttribute("position", new Ms(e, 3)), this;
		}
		computeBoundingBox() {
			null === this.boundingBox && (this.boundingBox = new Di());
			const t = this.attributes.position, e = this.morphAttributes.position;
			if (t && t.isGLBufferAttribute) return console.error("THREE.BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.", this), void this.boundingBox.set(new Li(-Infinity, -Infinity, -Infinity), new Li(Infinity, Infinity, Infinity));
			if (void 0 !== t) {
				if (this.boundingBox.setFromBufferAttribute(t), e) for (let t = 0, n = e.length; t < n; t++) {
					const n = e[t];
					Es.setFromBufferAttribute(n), this.morphTargetsRelative ? (Rs.addVectors(this.boundingBox.min, Es.min), this.boundingBox.expandByPoint(Rs), Rs.addVectors(this.boundingBox.max, Es.max), this.boundingBox.expandByPoint(Rs)) : (this.boundingBox.expandByPoint(Es.min), this.boundingBox.expandByPoint(Es.max));
				}
			} else this.boundingBox.makeEmpty();
			(isNaN(this.boundingBox.min.x) || isNaN(this.boundingBox.min.y) || isNaN(this.boundingBox.min.z)) && console.error("THREE.BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The \"position\" attribute is likely to have NaN values.", this);
		}
		computeBoundingSphere() {
			null === this.boundingSphere && (this.boundingSphere = new Qi());
			const t = this.attributes.position, e = this.morphAttributes.position;
			if (t && t.isGLBufferAttribute) return console.error("THREE.BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.", this), void this.boundingSphere.set(new Li(), Infinity);
			if (t) {
				const n = this.boundingSphere.center;
				if (Es.setFromBufferAttribute(t), e) for (let t = 0, n = e.length; t < n; t++) {
					const n = e[t];
					As.setFromBufferAttribute(n), this.morphTargetsRelative ? (Rs.addVectors(Es.min, As.min), Es.expandByPoint(Rs), Rs.addVectors(Es.max, As.max), Es.expandByPoint(Rs)) : (Es.expandByPoint(As.min), Es.expandByPoint(As.max));
				}
				Es.getCenter(n);
				let i = 0;
				for (let e = 0, r = t.count; e < r; e++) Rs.fromBufferAttribute(t, e), i = Math.max(i, n.distanceToSquared(Rs));
				if (e) for (let r = 0, s = e.length; r < s; r++) {
					const s = e[r], a = this.morphTargetsRelative;
					for (let e = 0, r = s.count; e < r; e++) Rs.fromBufferAttribute(s, e), a && (Ts.fromBufferAttribute(t, e), Rs.add(Ts)), i = Math.max(i, n.distanceToSquared(Rs));
				}
				this.boundingSphere.radius = Math.sqrt(i), isNaN(this.boundingSphere.radius) && console.error("THREE.BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The \"position\" attribute is likely to have NaN values.", this);
			}
		}
		computeTangents() {
			const t = this.index, e = this.attributes;
			if (null === t || void 0 === e.position || void 0 === e.normal || void 0 === e.uv) return void console.error("THREE.BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");
			const n = e.position, i = e.normal, r = e.uv;
			!1 === this.hasAttribute("tangent") && this.setAttribute("tangent", new ds(new Float32Array(4 * n.count), 4));
			const s = this.getAttribute("tangent"), a = [], o = [];
			for (let t = 0; t < n.count; t++) a[t] = new Li(), o[t] = new Li();
			const l = new Li(), c = new Li(), h = new Li(), u = new ti(), d = new ti(), p = new ti(), m = new Li(), f = new Li();
			function g(t, e, i) {
				l.fromBufferAttribute(n, t), c.fromBufferAttribute(n, e), h.fromBufferAttribute(n, i), u.fromBufferAttribute(r, t), d.fromBufferAttribute(r, e), p.fromBufferAttribute(r, i), c.sub(l), h.sub(l), d.sub(u), p.sub(u);
				const s = 1 / (d.x * p.y - p.x * d.y);
				isFinite(s) && (m.copy(c).multiplyScalar(p.y).addScaledVector(h, -d.y).multiplyScalar(s), f.copy(h).multiplyScalar(d.x).addScaledVector(c, -p.x).multiplyScalar(s), a[t].add(m), a[e].add(m), a[i].add(m), o[t].add(f), o[e].add(f), o[i].add(f));
			}
			let v = this.groups;
			0 === v.length && (v = [{
				start: 0,
				count: t.count
			}]);
			for (let e = 0, n = v.length; e < n; ++e) {
				const n = v[e], i = n.start;
				for (let e = i, r = i + n.count; e < r; e += 3) g(t.getX(e + 0), t.getX(e + 1), t.getX(e + 2));
			}
			const _ = new Li(), x = new Li(), y = new Li(), M = new Li();
			function S(t) {
				y.fromBufferAttribute(i, t), M.copy(y);
				const e = a[t];
				_.copy(e), _.sub(y.multiplyScalar(y.dot(e))).normalize(), x.crossVectors(M, e);
				const n = x.dot(o[t]) < 0 ? -1 : 1;
				s.setXYZW(t, _.x, _.y, _.z, n);
			}
			for (let e = 0, n = v.length; e < n; ++e) {
				const n = v[e], i = n.start;
				for (let e = i, r = i + n.count; e < r; e += 3) S(t.getX(e + 0)), S(t.getX(e + 1)), S(t.getX(e + 2));
			}
		}
		computeVertexNormals() {
			const t = this.index, e = this.getAttribute("position");
			if (void 0 !== e) {
				let n = this.getAttribute("normal");
				if (void 0 === n) n = new ds(new Float32Array(3 * e.count), 3), this.setAttribute("normal", n);
				else for (let t = 0, e = n.count; t < e; t++) n.setXYZ(t, 0, 0, 0);
				const i = new Li(), r = new Li(), s = new Li(), a = new Li(), o = new Li(), l = new Li(), c = new Li(), h = new Li();
				if (t) for (let u = 0, d = t.count; u < d; u += 3) {
					const d = t.getX(u + 0), p = t.getX(u + 1), m = t.getX(u + 2);
					i.fromBufferAttribute(e, d), r.fromBufferAttribute(e, p), s.fromBufferAttribute(e, m), c.subVectors(s, r), h.subVectors(i, r), c.cross(h), a.fromBufferAttribute(n, d), o.fromBufferAttribute(n, p), l.fromBufferAttribute(n, m), a.add(c), o.add(c), l.add(c), n.setXYZ(d, a.x, a.y, a.z), n.setXYZ(p, o.x, o.y, o.z), n.setXYZ(m, l.x, l.y, l.z);
				}
				else for (let t = 0, a = e.count; t < a; t += 3) i.fromBufferAttribute(e, t + 0), r.fromBufferAttribute(e, t + 1), s.fromBufferAttribute(e, t + 2), c.subVectors(s, r), h.subVectors(i, r), c.cross(h), n.setXYZ(t + 0, c.x, c.y, c.z), n.setXYZ(t + 1, c.x, c.y, c.z), n.setXYZ(t + 2, c.x, c.y, c.z);
				this.normalizeNormals(), n.needsUpdate = !0;
			}
		}
		normalizeNormals() {
			const t = this.attributes.normal;
			for (let e = 0, n = t.count; e < n; e++) Rs.fromBufferAttribute(t, e), Rs.normalize(), t.setXYZ(e, Rs.x, Rs.y, Rs.z);
		}
		toNonIndexed() {
			function t(t, e) {
				const n = t.array, i = t.itemSize, r = t.normalized, s = new n.constructor(e.length * i);
				let a = 0, o = 0;
				for (let r = 0, l = e.length; r < l; r++) {
					a = t.isInterleavedBufferAttribute ? e[r] * t.data.stride + t.offset : e[r] * i;
					for (let t = 0; t < i; t++) s[o++] = n[a++];
				}
				return new ds(s, i, r);
			}
			if (null === this.index) return console.warn("THREE.BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."), this;
			const e = new Cs(), n = this.index.array, i = this.attributes;
			for (const r in i) {
				const s = t(i[r], n);
				e.setAttribute(r, s);
			}
			const r = this.morphAttributes;
			for (const i in r) {
				const s = [], a = r[i];
				for (let e = 0, i = a.length; e < i; e++) {
					const i = t(a[e], n);
					s.push(i);
				}
				e.morphAttributes[i] = s;
			}
			e.morphTargetsRelative = this.morphTargetsRelative;
			const s = this.groups;
			for (let t = 0, n = s.length; t < n; t++) {
				const n = s[t];
				e.addGroup(n.start, n.count, n.materialIndex);
			}
			return e;
		}
		toJSON() {
			const t = { metadata: {
				version: 4.6,
				type: "BufferGeometry",
				generator: "BufferGeometry.toJSON"
			} };
			if (t.uuid = this.uuid, t.type = this.type, "" !== this.name && (t.name = this.name), Object.keys(this.userData).length > 0 && (t.userData = this.userData), void 0 !== this.parameters) {
				const e = this.parameters;
				for (const n in e) void 0 !== e[n] && (t[n] = e[n]);
				return t;
			}
			t.data = { attributes: {} };
			const e = this.index;
			null !== e && (t.data.index = {
				type: e.array.constructor.name,
				array: Array.prototype.slice.call(e.array)
			});
			const n = this.attributes;
			for (const e in n) {
				const i = n[e];
				t.data.attributes[e] = i.toJSON(t.data);
			}
			const i = {};
			let r = !1;
			for (const e in this.morphAttributes) {
				const n = this.morphAttributes[e], s = [];
				for (let e = 0, i = n.length; e < i; e++) {
					const i = n[e];
					s.push(i.toJSON(t.data));
				}
				s.length > 0 && (i[e] = s, r = !0);
			}
			r && (t.data.morphAttributes = i, t.data.morphTargetsRelative = this.morphTargetsRelative);
			const s = this.groups;
			s.length > 0 && (t.data.groups = JSON.parse(JSON.stringify(s)));
			const a = this.boundingSphere;
			return null !== a && (t.data.boundingSphere = {
				center: a.center.toArray(),
				radius: a.radius
			}), t;
		}
		clone() {
			return new this.constructor().copy(this);
		}
		copy(t) {
			this.index = null, this.attributes = {}, this.morphAttributes = {}, this.groups = [], this.boundingBox = null, this.boundingSphere = null;
			const e = {};
			this.name = t.name;
			const n = t.index;
			null !== n && this.setIndex(n.clone(e));
			const i = t.attributes;
			for (const t in i) {
				const n = i[t];
				this.setAttribute(t, n.clone(e));
			}
			const r = t.morphAttributes;
			for (const t in r) {
				const n = [], i = r[t];
				for (let t = 0, r = i.length; t < r; t++) n.push(i[t].clone(e));
				this.morphAttributes[t] = n;
			}
			this.morphTargetsRelative = t.morphTargetsRelative;
			const s = t.groups;
			for (let t = 0, e = s.length; t < e; t++) {
				const e = s[t];
				this.addGroup(e.start, e.count, e.materialIndex);
			}
			const a = t.boundingBox;
			null !== a && (this.boundingBox = a.clone());
			const o = t.boundingSphere;
			return null !== o && (this.boundingSphere = o.clone()), this.drawRange.start = t.drawRange.start, this.drawRange.count = t.drawRange.count, this.userData = t.userData, this;
		}
		dispose() {
			this.dispatchEvent({ type: "dispose" });
		}
	};
	const Ps = new lr(), Is = new or(), Ls = new Qi(), Us = new Li(), Ns = new Li(), Ds = new Li(), Os = new Li(), Fs = new Li(), Bs = new Li(), zs = new Li(), ks = new Li();
	var Vs = class extends Dr {
		constructor(t = new Cs(), e = new rs()) {
			super(), this.isMesh = !0, this.type = "Mesh", this.geometry = t, this.material = e, this.updateMorphTargets();
		}
		copy(t, e) {
			return super.copy(t, e), void 0 !== t.morphTargetInfluences && (this.morphTargetInfluences = t.morphTargetInfluences.slice()), void 0 !== t.morphTargetDictionary && (this.morphTargetDictionary = Object.assign({}, t.morphTargetDictionary)), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this;
		}
		updateMorphTargets() {
			const t = this.geometry.morphAttributes, e = Object.keys(t);
			if (e.length > 0) {
				const n = t[e[0]];
				if (void 0 !== n) {
					this.morphTargetInfluences = [], this.morphTargetDictionary = {};
					for (let t = 0, e = n.length; t < e; t++) {
						const e = n[t].name || String(t);
						this.morphTargetInfluences.push(0), this.morphTargetDictionary[e] = t;
					}
				}
			}
		}
		getVertexPosition(t, e) {
			const n = this.geometry, i = n.attributes.position, r = n.morphAttributes.position, s = n.morphTargetsRelative;
			e.fromBufferAttribute(i, t);
			const a = this.morphTargetInfluences;
			if (r && a) {
				Bs.set(0, 0, 0);
				for (let n = 0, i = r.length; n < i; n++) {
					const i = a[n], o = r[n];
					0 !== i && (Fs.fromBufferAttribute(o, t), s ? Bs.addScaledVector(Fs, i) : Bs.addScaledVector(Fs.sub(e), i));
				}
				e.add(Bs);
			}
			return e;
		}
		raycast(t, e) {
			const n = this.geometry, i = this.material, r = this.matrixWorld;
			if (void 0 !== i) {
				if (null === n.boundingSphere && n.computeBoundingSphere(), Ls.copy(n.boundingSphere), Ls.applyMatrix4(r), Is.copy(t.ray).recast(t.near), !1 === Ls.containsPoint(Is.origin)) {
					if (null === Is.intersectSphere(Ls, Us)) return;
					if (Is.origin.distanceToSquared(Us) > (t.far - t.near) ** 2) return;
				}
				Ps.copy(r).invert(), Is.copy(t.ray).applyMatrix4(Ps), null !== n.boundingBox && !1 === Is.intersectsBox(n.boundingBox) || this._computeIntersections(t, e, Is);
			}
		}
		_computeIntersections(t, e, n) {
			let i;
			const r = this.geometry, s = this.material, a = r.index, o = r.attributes.position, l = r.attributes.uv, c = r.attributes.uv1, h = r.attributes.normal, u = r.groups, d = r.drawRange;
			if (null !== a) if (Array.isArray(s)) for (let r = 0, o = u.length; r < o; r++) {
				const o = u[r], p = s[o.materialIndex];
				for (let r = Math.max(o.start, d.start), s = Math.min(a.count, Math.min(o.start + o.count, d.start + d.count)); r < s; r += 3) i = Hs(this, p, t, n, l, c, h, a.getX(r), a.getX(r + 1), a.getX(r + 2)), i && (i.faceIndex = Math.floor(r / 3), i.face.materialIndex = o.materialIndex, e.push(i));
			}
			else for (let r = Math.max(0, d.start), o = Math.min(a.count, d.start + d.count); r < o; r += 3) i = Hs(this, s, t, n, l, c, h, a.getX(r), a.getX(r + 1), a.getX(r + 2)), i && (i.faceIndex = Math.floor(r / 3), e.push(i));
			else if (void 0 !== o) if (Array.isArray(s)) for (let r = 0, a = u.length; r < a; r++) {
				const a = u[r], p = s[a.materialIndex];
				for (let r = Math.max(a.start, d.start), s = Math.min(o.count, Math.min(a.start + a.count, d.start + d.count)); r < s; r += 3) i = Hs(this, p, t, n, l, c, h, r, r + 1, r + 2), i && (i.faceIndex = Math.floor(r / 3), i.face.materialIndex = a.materialIndex, e.push(i));
			}
			else for (let r = Math.max(0, d.start), a = Math.min(o.count, d.start + d.count); r < a; r += 3) i = Hs(this, s, t, n, l, c, h, r, r + 1, r + 2), i && (i.faceIndex = Math.floor(r / 3), e.push(i));
		}
	};
	function Hs(t, e, n, i, r, s, a, o, l, c) {
		t.getVertexPosition(o, Ns), t.getVertexPosition(l, Ds), t.getVertexPosition(c, Os);
		const h = function(t, e, n, i, r, s, a, o) {
			let l;
			if (l = e.side === 1 ? i.intersectTriangle(a, s, r, !0, o) : i.intersectTriangle(r, s, a, e.side === 0, o), null === l) return null;
			ks.copy(o), ks.applyMatrix4(t.matrixWorld);
			const c = n.ray.origin.distanceTo(ks);
			return c < n.near || c > n.far ? null : {
				distance: c,
				point: ks.clone(),
				object: t
			};
		}(t, e, n, i, Ns, Ds, Os, zs);
		if (h) {
			const t = new Li();
			Zr.getBarycoord(zs, Ns, Ds, Os, t), r && (h.uv = Zr.getInterpolatedAttribute(r, o, l, c, t, new ti())), s && (h.uv1 = Zr.getInterpolatedAttribute(s, o, l, c, t, new ti())), a && (h.normal = Zr.getInterpolatedAttribute(a, o, l, c, t, new Li()), h.normal.dot(i.direction) > 0 && h.normal.multiplyScalar(-1));
			const e = {
				a: o,
				b: l,
				c,
				normal: new Li(),
				materialIndex: 0
			};
			Zr.getNormal(Ns, Ds, Os, e.normal), h.face = e, h.barycoord = t;
		}
		return h;
	}
	var Gs = class Gs extends Cs {
		constructor(t = 1, e = 1, n = 1, i = 1, r = 1, s = 1) {
			super(), this.type = "BoxGeometry", this.parameters = {
				width: t,
				height: e,
				depth: n,
				widthSegments: i,
				heightSegments: r,
				depthSegments: s
			};
			const a = this;
			i = Math.floor(i), r = Math.floor(r), s = Math.floor(s);
			const o = [], l = [], c = [], h = [];
			let u = 0, d = 0;
			function p(t, e, n, i, r, s, p, m, f, g, v) {
				const _ = s / f, x = p / g, y = s / 2, M = p / 2, S = m / 2, b = f + 1, w = g + 1;
				let T = 0, E = 0;
				const A = new Li();
				for (let s = 0; s < w; s++) {
					const a = s * x - M;
					for (let o = 0; o < b; o++) A[t] = (o * _ - y) * i, A[e] = a * r, A[n] = S, l.push(A.x, A.y, A.z), A[t] = 0, A[e] = 0, A[n] = m > 0 ? 1 : -1, c.push(A.x, A.y, A.z), h.push(o / f), h.push(1 - s / g), T += 1;
				}
				for (let t = 0; t < g; t++) for (let e = 0; e < f; e++) {
					const n = u + e + b * t, i = u + e + b * (t + 1), r = u + (e + 1) + b * (t + 1), s = u + (e + 1) + b * t;
					o.push(n, i, s), o.push(i, r, s), E += 6;
				}
				a.addGroup(d, E, v), d += E, u += T;
			}
			p("z", "y", "x", -1, -1, n, e, t, s, r, 0), p("z", "y", "x", 1, -1, n, e, -t, s, r, 1), p("x", "z", "y", 1, 1, t, n, e, i, s, 2), p("x", "z", "y", 1, -1, t, n, -e, i, s, 3), p("x", "y", "z", 1, -1, t, e, n, i, r, 4), p("x", "y", "z", -1, -1, t, e, -n, i, r, 5), this.setIndex(o), this.setAttribute("position", new Ms(l, 3)), this.setAttribute("normal", new Ms(c, 3)), this.setAttribute("uv", new Ms(h, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new Gs(t.width, t.height, t.depth, t.widthSegments, t.heightSegments, t.depthSegments);
		}
	};
	function Ws(t) {
		const e = {};
		for (const n in t) {
			e[n] = {};
			for (const i in t[n]) {
				const r = t[n][i];
				r && (r.isColor || r.isMatrix3 || r.isMatrix4 || r.isVector2 || r.isVector3 || r.isVector4 || r.isTexture || r.isQuaternion) ? r.isRenderTargetTexture ? (console.warn("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."), e[n][i] = null) : e[n][i] = r.clone() : Array.isArray(r) ? e[n][i] = r.slice() : e[n][i] = r;
			}
		}
		return e;
	}
	function Xs(t) {
		const e = {};
		for (let n = 0; n < t.length; n++) {
			const i = Ws(t[n]);
			for (const t in i) e[t] = i[t];
		}
		return e;
	}
	function js(t) {
		const e = t.getRenderTarget();
		return null === e ? t.outputColorSpace : !0 === e.isXRRenderTarget ? e.texture.colorSpace : mi.workingColorSpace;
	}
	const qs = {
		clone: Ws,
		merge: Xs
	};
	var Ys = class extends is {
		constructor(t) {
			super(), this.isShaderMaterial = !0, this.type = "ShaderMaterial", this.defines = {}, this.uniforms = {}, this.uniformsGroups = [], this.vertexShader = "void main() {\n	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}", this.fragmentShader = "void main() {\n	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );\n}", this.linewidth = 1, this.wireframe = !1, this.wireframeLinewidth = 1, this.fog = !1, this.lights = !1, this.clipping = !1, this.forceSinglePass = !0, this.extensions = {
				clipCullDistance: !1,
				multiDraw: !1
			}, this.defaultAttributeValues = {
				color: [
					1,
					1,
					1
				],
				uv: [0, 0],
				uv1: [0, 0]
			}, this.index0AttributeName = void 0, this.uniformsNeedUpdate = !1, this.glslVersion = null, void 0 !== t && this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.fragmentShader = t.fragmentShader, this.vertexShader = t.vertexShader, this.uniforms = Ws(t.uniforms), this.uniformsGroups = function(t) {
				const e = [];
				for (let n = 0; n < t.length; n++) e.push(t[n].clone());
				return e;
			}(t.uniformsGroups), this.defines = Object.assign({}, t.defines), this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.fog = t.fog, this.lights = t.lights, this.clipping = t.clipping, this.extensions = Object.assign({}, t.extensions), this.glslVersion = t.glslVersion, this;
		}
		toJSON(t) {
			const e = super.toJSON(t);
			e.glslVersion = this.glslVersion, e.uniforms = {};
			for (const n in this.uniforms) {
				const i = this.uniforms[n].value;
				i && i.isTexture ? e.uniforms[n] = {
					type: "t",
					value: i.toJSON(t).uuid
				} : i && i.isColor ? e.uniforms[n] = {
					type: "c",
					value: i.getHex()
				} : i && i.isVector2 ? e.uniforms[n] = {
					type: "v2",
					value: i.toArray()
				} : i && i.isVector3 ? e.uniforms[n] = {
					type: "v3",
					value: i.toArray()
				} : i && i.isVector4 ? e.uniforms[n] = {
					type: "v4",
					value: i.toArray()
				} : i && i.isMatrix3 ? e.uniforms[n] = {
					type: "m3",
					value: i.toArray()
				} : i && i.isMatrix4 ? e.uniforms[n] = {
					type: "m4",
					value: i.toArray()
				} : e.uniforms[n] = { value: i };
			}
			Object.keys(this.defines).length > 0 && (e.defines = this.defines), e.vertexShader = this.vertexShader, e.fragmentShader = this.fragmentShader, e.lights = this.lights, e.clipping = this.clipping;
			const n = {};
			for (const t in this.extensions) !0 === this.extensions[t] && (n[t] = !0);
			return Object.keys(n).length > 0 && (e.extensions = n), e;
		}
	};
	var Zs = class extends Dr {
		constructor() {
			super(), this.isCamera = !0, this.type = "Camera", this.matrixWorldInverse = new lr(), this.projectionMatrix = new lr(), this.projectionMatrixInverse = new lr(), this.coordinateSystem = kn;
		}
		copy(t, e) {
			return super.copy(t, e), this.matrixWorldInverse.copy(t.matrixWorldInverse), this.projectionMatrix.copy(t.projectionMatrix), this.projectionMatrixInverse.copy(t.projectionMatrixInverse), this.coordinateSystem = t.coordinateSystem, this;
		}
		getWorldDirection(t) {
			return super.getWorldDirection(t).negate();
		}
		updateMatrixWorld(t) {
			super.updateMatrixWorld(t), this.matrixWorldInverse.copy(this.matrixWorld).invert();
		}
		updateWorldMatrix(t, e) {
			super.updateWorldMatrix(t, e), this.matrixWorldInverse.copy(this.matrixWorld).invert();
		}
		clone() {
			return new this.constructor().copy(this);
		}
	};
	const Js = new Li(), Ks = new ti(), $s = new ti();
	var Qs = class extends Zs {
		constructor(t = 50, e = 1, n = .1, i = 2e3) {
			super(), this.isPerspectiveCamera = !0, this.type = "PerspectiveCamera", this.fov = t, this.zoom = 1, this.near = n, this.far = i, this.focus = 10, this.aspect = e, this.view = null, this.filmGauge = 35, this.filmOffset = 0, this.updateProjectionMatrix();
		}
		copy(t, e) {
			return super.copy(t, e), this.fov = t.fov, this.zoom = t.zoom, this.near = t.near, this.far = t.far, this.focus = t.focus, this.aspect = t.aspect, this.view = null === t.view ? null : Object.assign({}, t.view), this.filmGauge = t.filmGauge, this.filmOffset = t.filmOffset, this;
		}
		setFocalLength(t) {
			const e = .5 * this.getFilmHeight() / t;
			this.fov = 2 * jn * Math.atan(e), this.updateProjectionMatrix();
		}
		getFocalLength() {
			const t = Math.tan(.5 * Xn * this.fov);
			return .5 * this.getFilmHeight() / t;
		}
		getEffectiveFOV() {
			return 2 * jn * Math.atan(Math.tan(.5 * Xn * this.fov) / this.zoom);
		}
		getFilmWidth() {
			return this.filmGauge * Math.min(this.aspect, 1);
		}
		getFilmHeight() {
			return this.filmGauge / Math.max(this.aspect, 1);
		}
		getViewBounds(t, e, n) {
			Js.set(-1, -1, .5).applyMatrix4(this.projectionMatrixInverse), e.set(Js.x, Js.y).multiplyScalar(-t / Js.z), Js.set(1, 1, .5).applyMatrix4(this.projectionMatrixInverse), n.set(Js.x, Js.y).multiplyScalar(-t / Js.z);
		}
		getViewSize(t, e) {
			return this.getViewBounds(t, Ks, $s), e.subVectors($s, Ks);
		}
		setViewOffset(t, e, n, i, r, s) {
			this.aspect = t / e, null === this.view && (this.view = {
				enabled: !0,
				fullWidth: 1,
				fullHeight: 1,
				offsetX: 0,
				offsetY: 0,
				width: 1,
				height: 1
			}), this.view.enabled = !0, this.view.fullWidth = t, this.view.fullHeight = e, this.view.offsetX = n, this.view.offsetY = i, this.view.width = r, this.view.height = s, this.updateProjectionMatrix();
		}
		clearViewOffset() {
			null !== this.view && (this.view.enabled = !1), this.updateProjectionMatrix();
		}
		updateProjectionMatrix() {
			const t = this.near;
			let e = t * Math.tan(.5 * Xn * this.fov) / this.zoom, n = 2 * e, i = this.aspect * n, r = -.5 * i;
			const s = this.view;
			if (null !== this.view && this.view.enabled) {
				const t = s.fullWidth, a = s.fullHeight;
				r += s.offsetX * i / t, e -= s.offsetY * n / a, i *= s.width / t, n *= s.height / a;
			}
			const a = this.filmOffset;
			0 !== a && (r += t * a / this.getFilmWidth()), this.projectionMatrix.makePerspective(r, r + i, e, e - n, t, this.far, this.coordinateSystem), this.projectionMatrixInverse.copy(this.projectionMatrix).invert();
		}
		toJSON(t) {
			const e = super.toJSON(t);
			return e.object.fov = this.fov, e.object.zoom = this.zoom, e.object.near = this.near, e.object.far = this.far, e.object.focus = this.focus, e.object.aspect = this.aspect, null !== this.view && (e.object.view = Object.assign({}, this.view)), e.object.filmGauge = this.filmGauge, e.object.filmOffset = this.filmOffset, e;
		}
	};
	const ta = -90;
	var ea = class extends Dr {
		constructor(t, e, n) {
			super(), this.type = "CubeCamera", this.renderTarget = n, this.coordinateSystem = null, this.activeMipmapLevel = 0;
			const i = new Qs(ta, 1, t, e);
			i.layers = this.layers, this.add(i);
			const r = new Qs(ta, 1, t, e);
			r.layers = this.layers, this.add(r);
			const s = new Qs(ta, 1, t, e);
			s.layers = this.layers, this.add(s);
			const a = new Qs(ta, 1, t, e);
			a.layers = this.layers, this.add(a);
			const o = new Qs(ta, 1, t, e);
			o.layers = this.layers, this.add(o);
			const l = new Qs(ta, 1, t, e);
			l.layers = this.layers, this.add(l);
		}
		updateCoordinateSystem() {
			const t = this.coordinateSystem, e = this.children.concat(), [n, i, r, s, a, o] = e;
			for (const t of e) this.remove(t);
			if (t === 2e3) n.up.set(0, 1, 0), n.lookAt(1, 0, 0), i.up.set(0, 1, 0), i.lookAt(-1, 0, 0), r.up.set(0, 0, -1), r.lookAt(0, 1, 0), s.up.set(0, 0, 1), s.lookAt(0, -1, 0), a.up.set(0, 1, 0), a.lookAt(0, 0, 1), o.up.set(0, 1, 0), o.lookAt(0, 0, -1);
			else {
				if (t !== 2001) throw new Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: " + t);
				n.up.set(0, -1, 0), n.lookAt(-1, 0, 0), i.up.set(0, -1, 0), i.lookAt(1, 0, 0), r.up.set(0, 0, 1), r.lookAt(0, 1, 0), s.up.set(0, 0, -1), s.lookAt(0, -1, 0), a.up.set(0, -1, 0), a.lookAt(0, 0, 1), o.up.set(0, -1, 0), o.lookAt(0, 0, -1);
			}
			for (const t of e) this.add(t), t.updateMatrixWorld();
		}
		update(t, e) {
			null === this.parent && this.updateMatrixWorld();
			const { renderTarget: n, activeMipmapLevel: i } = this;
			this.coordinateSystem !== t.coordinateSystem && (this.coordinateSystem = t.coordinateSystem, this.updateCoordinateSystem());
			const [r, s, a, o, l, c] = this.children, h = t.getRenderTarget(), u = t.getActiveCubeFace(), d = t.getActiveMipmapLevel(), p = t.xr.enabled;
			t.xr.enabled = !1;
			const m = n.texture.generateMipmaps;
			n.texture.generateMipmaps = !1, t.setRenderTarget(n, 0, i), t.render(e, r), t.setRenderTarget(n, 1, i), t.render(e, s), t.setRenderTarget(n, 2, i), t.render(e, a), t.setRenderTarget(n, 3, i), t.render(e, o), t.setRenderTarget(n, 4, i), t.render(e, l), n.texture.generateMipmaps = m, t.setRenderTarget(n, 5, i), t.render(e, c), t.setRenderTarget(h, u, d), t.xr.enabled = p, n.texture.needsPMREMUpdate = !0;
		}
	};
	var na = class extends bi {
		constructor(t, e, n, i, r, s, a, o, l, c) {
			super(t = void 0 !== t ? t : [], e = void 0 !== e ? e : 301, n, i, r, s, a, o, l, c), this.isCubeTexture = !0, this.flipY = !1;
		}
		get images() {
			return this.image;
		}
		set images(t) {
			this.image = t;
		}
	};
	var ia = class extends Ei {
		constructor(t = 1, e = {}) {
			super(t, t, e), this.isWebGLCubeRenderTarget = !0;
			const n = {
				width: t,
				height: t,
				depth: 1
			}, i = [
				n,
				n,
				n,
				n,
				n,
				n
			];
			this.texture = new na(i, e.mapping, e.wrapS, e.wrapT, e.magFilter, e.minFilter, e.format, e.type, e.anisotropy, e.colorSpace), this.texture.isRenderTargetTexture = !0, this.texture.generateMipmaps = void 0 !== e.generateMipmaps && e.generateMipmaps, this.texture.minFilter = void 0 !== e.minFilter ? e.minFilter : Mt;
		}
		fromEquirectangularTexture(t, e) {
			this.texture.type = e.type, this.texture.colorSpace = e.colorSpace, this.texture.generateMipmaps = e.generateMipmaps, this.texture.minFilter = e.minFilter, this.texture.magFilter = e.magFilter;
			const n = {
				uniforms: { tEquirect: { value: null } },
				vertexShader: "\n\n				varying vec3 vWorldDirection;\n\n				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {\n\n					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );\n\n				}\n\n				void main() {\n\n					vWorldDirection = transformDirection( position, modelMatrix );\n\n					#include <begin_vertex>\n					#include <project_vertex>\n\n				}\n			",
				fragmentShader: "\n\n				uniform sampler2D tEquirect;\n\n				varying vec3 vWorldDirection;\n\n				#include <common>\n\n				void main() {\n\n					vec3 direction = normalize( vWorldDirection );\n\n					vec2 sampleUV = equirectUv( direction );\n\n					gl_FragColor = texture2D( tEquirect, sampleUV );\n\n				}\n			"
			}, i = new Gs(5, 5, 5), r = new Ys({
				name: "CubemapFromEquirect",
				uniforms: Ws(n.uniforms),
				vertexShader: n.vertexShader,
				fragmentShader: n.fragmentShader,
				side: 1,
				blending: 0
			});
			r.uniforms.tEquirect.value = e;
			const s = new Vs(i, r), a = e.minFilter;
			e.minFilter === 1008 && (e.minFilter = 1006);
			return new ea(1, 10, this).update(t, s), e.minFilter = a, s.geometry.dispose(), s.material.dispose(), this;
		}
		clear(t, e, n, i) {
			const r = t.getRenderTarget();
			for (let r = 0; r < 6; r++) t.setRenderTarget(this, r), t.clear(e, n, i);
			t.setRenderTarget(r);
		}
	};
	const ra = new Li(), sa = new Li(), aa = new ei();
	var oa = class {
		constructor(t = new Li(1, 0, 0), e = 0) {
			this.isPlane = !0, this.normal = t, this.constant = e;
		}
		set(t, e) {
			return this.normal.copy(t), this.constant = e, this;
		}
		setComponents(t, e, n, i) {
			return this.normal.set(t, e, n), this.constant = i, this;
		}
		setFromNormalAndCoplanarPoint(t, e) {
			return this.normal.copy(t), this.constant = -e.dot(this.normal), this;
		}
		setFromCoplanarPoints(t, e, n) {
			const i = ra.subVectors(n, e).cross(sa.subVectors(t, e)).normalize();
			return this.setFromNormalAndCoplanarPoint(i, t), this;
		}
		copy(t) {
			return this.normal.copy(t.normal), this.constant = t.constant, this;
		}
		normalize() {
			const t = 1 / this.normal.length();
			return this.normal.multiplyScalar(t), this.constant *= t, this;
		}
		negate() {
			return this.constant *= -1, this.normal.negate(), this;
		}
		distanceToPoint(t) {
			return this.normal.dot(t) + this.constant;
		}
		distanceToSphere(t) {
			return this.distanceToPoint(t.center) - t.radius;
		}
		projectPoint(t, e) {
			return e.copy(t).addScaledVector(this.normal, -this.distanceToPoint(t));
		}
		intersectLine(t, e) {
			const n = t.delta(ra), i = this.normal.dot(n);
			if (0 === i) return 0 === this.distanceToPoint(t.start) ? e.copy(t.start) : null;
			const r = -(t.start.dot(this.normal) + this.constant) / i;
			return r < 0 || r > 1 ? null : e.copy(t.start).addScaledVector(n, r);
		}
		intersectsLine(t) {
			const e = this.distanceToPoint(t.start), n = this.distanceToPoint(t.end);
			return e < 0 && n > 0 || n < 0 && e > 0;
		}
		intersectsBox(t) {
			return t.intersectsPlane(this);
		}
		intersectsSphere(t) {
			return t.intersectsPlane(this);
		}
		coplanarPoint(t) {
			return t.copy(this.normal).multiplyScalar(-this.constant);
		}
		applyMatrix4(t, e) {
			const n = e || aa.getNormalMatrix(t), i = this.coplanarPoint(ra).applyMatrix4(t), r = this.normal.applyMatrix3(n).normalize();
			return this.constant = -i.dot(r), this;
		}
		translate(t) {
			return this.constant -= t.dot(this.normal), this;
		}
		equals(t) {
			return t.normal.equals(this.normal) && t.constant === this.constant;
		}
		clone() {
			return new this.constructor().copy(this);
		}
	};
	const la = new Qi(), ca = new Li();
	var ha = class {
		constructor(t = new oa(), e = new oa(), n = new oa(), i = new oa(), r = new oa(), s = new oa()) {
			this.planes = [
				t,
				e,
				n,
				i,
				r,
				s
			];
		}
		set(t, e, n, i, r, s) {
			const a = this.planes;
			return a[0].copy(t), a[1].copy(e), a[2].copy(n), a[3].copy(i), a[4].copy(r), a[5].copy(s), this;
		}
		copy(t) {
			const e = this.planes;
			for (let n = 0; n < 6; n++) e[n].copy(t.planes[n]);
			return this;
		}
		setFromProjectionMatrix(t, e = 2e3) {
			const n = this.planes, i = t.elements, r = i[0], s = i[1], a = i[2], o = i[3], l = i[4], c = i[5], h = i[6], u = i[7], d = i[8], p = i[9], m = i[10], f = i[11], g = i[12], v = i[13], _ = i[14], x = i[15];
			if (n[0].setComponents(o - r, u - l, f - d, x - g).normalize(), n[1].setComponents(o + r, u + l, f + d, x + g).normalize(), n[2].setComponents(o + s, u + c, f + p, x + v).normalize(), n[3].setComponents(o - s, u - c, f - p, x - v).normalize(), n[4].setComponents(o - a, u - h, f - m, x - _).normalize(), e === 2e3) n[5].setComponents(o + a, u + h, f + m, x + _).normalize();
			else {
				if (e !== 2001) throw new Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: " + e);
				n[5].setComponents(a, h, m, _).normalize();
			}
			return this;
		}
		intersectsObject(t) {
			if (void 0 !== t.boundingSphere) null === t.boundingSphere && t.computeBoundingSphere(), la.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);
			else {
				const e = t.geometry;
				null === e.boundingSphere && e.computeBoundingSphere(), la.copy(e.boundingSphere).applyMatrix4(t.matrixWorld);
			}
			return this.intersectsSphere(la);
		}
		intersectsSprite(t) {
			return la.center.set(0, 0, 0), la.radius = .7071067811865476, la.applyMatrix4(t.matrixWorld), this.intersectsSphere(la);
		}
		intersectsSphere(t) {
			const e = this.planes, n = t.center, i = -t.radius;
			for (let t = 0; t < 6; t++) if (e[t].distanceToPoint(n) < i) return !1;
			return !0;
		}
		intersectsBox(t) {
			const e = this.planes;
			for (let n = 0; n < 6; n++) {
				const i = e[n];
				if (ca.x = i.normal.x > 0 ? t.max.x : t.min.x, ca.y = i.normal.y > 0 ? t.max.y : t.min.y, ca.z = i.normal.z > 0 ? t.max.z : t.min.z, i.distanceToPoint(ca) < 0) return !1;
			}
			return !0;
		}
		containsPoint(t) {
			const e = this.planes;
			for (let n = 0; n < 6; n++) if (e[n].distanceToPoint(t) < 0) return !1;
			return !0;
		}
		clone() {
			return new this.constructor().copy(this);
		}
	};
	function ua() {
		let t = null, e = !1, n = null, i = null;
		function r(e, s) {
			n(e, s), i = t.requestAnimationFrame(r);
		}
		return {
			start: function() {
				!0 !== e && null !== n && (i = t.requestAnimationFrame(r), e = !0);
			},
			stop: function() {
				t.cancelAnimationFrame(i), e = !1;
			},
			setAnimationLoop: function(t) {
				n = t;
			},
			setContext: function(e) {
				t = e;
			}
		};
	}
	function da(t) {
		const e = /* @__PURE__ */ new WeakMap();
		return {
			get: function(t) {
				return t.isInterleavedBufferAttribute && (t = t.data), e.get(t);
			},
			remove: function(n) {
				n.isInterleavedBufferAttribute && (n = n.data);
				const i = e.get(n);
				i && (t.deleteBuffer(i.buffer), e.delete(n));
			},
			update: function(n, i) {
				if (n.isInterleavedBufferAttribute && (n = n.data), n.isGLBufferAttribute) {
					const t = e.get(n);
					(!t || t.version < n.version) && e.set(n, {
						buffer: n.buffer,
						type: n.type,
						bytesPerElement: n.elementSize,
						version: n.version
					});
					return;
				}
				const r = e.get(n);
				if (void 0 === r) e.set(n, function(e, n) {
					const i = e.array, r = e.usage, s = i.byteLength, a = t.createBuffer();
					let o;
					if (t.bindBuffer(n, a), t.bufferData(n, i, r), e.onUploadCallback(), i instanceof Float32Array) o = t.FLOAT;
					else if (i instanceof Uint16Array) o = e.isFloat16BufferAttribute ? t.HALF_FLOAT : t.UNSIGNED_SHORT;
					else if (i instanceof Int16Array) o = t.SHORT;
					else if (i instanceof Uint32Array) o = t.UNSIGNED_INT;
					else if (i instanceof Int32Array) o = t.INT;
					else if (i instanceof Int8Array) o = t.BYTE;
					else if (i instanceof Uint8Array) o = t.UNSIGNED_BYTE;
					else {
						if (!(i instanceof Uint8ClampedArray)) throw new Error("THREE.WebGLAttributes: Unsupported buffer data format: " + i);
						o = t.UNSIGNED_BYTE;
					}
					return {
						buffer: a,
						type: o,
						bytesPerElement: i.BYTES_PER_ELEMENT,
						version: e.version,
						size: s
					};
				}(n, i));
				else if (r.version < n.version) {
					if (r.size !== n.array.byteLength) throw new Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");
					(function(e, n, i) {
						const r = n.array, s = n.updateRanges;
						if (t.bindBuffer(i, e), 0 === s.length) t.bufferSubData(i, 0, r);
						else {
							s.sort(((t, e) => t.start - e.start));
							let e = 0;
							for (let t = 1; t < s.length; t++) {
								const n = s[e], i = s[t];
								i.start <= n.start + n.count + 1 ? n.count = Math.max(n.count, i.start + i.count - n.start) : (++e, s[e] = i);
							}
							s.length = e + 1;
							for (let e = 0, n = s.length; e < n; e++) {
								const n = s[e];
								t.bufferSubData(i, n.start * r.BYTES_PER_ELEMENT, r, n.start, n.count);
							}
							n.clearUpdateRanges();
						}
						n.onUploadCallback();
					})(r.buffer, n, i), r.version = n.version;
				}
			}
		};
	}
	var pa = class pa extends Cs {
		constructor(t = 1, e = 1, n = 1, i = 1) {
			super(), this.type = "PlaneGeometry", this.parameters = {
				width: t,
				height: e,
				widthSegments: n,
				heightSegments: i
			};
			const r = t / 2, s = e / 2, a = Math.floor(n), o = Math.floor(i), l = a + 1, c = o + 1, h = t / a, u = e / o, d = [], p = [], m = [], f = [];
			for (let t = 0; t < c; t++) {
				const e = t * u - s;
				for (let n = 0; n < l; n++) {
					const i = n * h - r;
					p.push(i, -e, 0), m.push(0, 0, 1), f.push(n / a), f.push(1 - t / o);
				}
			}
			for (let t = 0; t < o; t++) for (let e = 0; e < a; e++) {
				const n = e + l * t, i = e + l * (t + 1), r = e + 1 + l * (t + 1), s = e + 1 + l * t;
				d.push(n, i, s), d.push(i, r, s);
			}
			this.setIndex(d), this.setAttribute("position", new Ms(p, 3)), this.setAttribute("normal", new Ms(m, 3)), this.setAttribute("uv", new Ms(f, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new pa(t.width, t.height, t.widthSegments, t.heightSegments);
		}
	};
	const ma = {
		alphahash_fragment: "#ifdef USE_ALPHAHASH\n	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;\n#endif",
		alphahash_pars_fragment: "#ifdef USE_ALPHAHASH\n	const float ALPHA_HASH_SCALE = 0.05;\n	float hash2D( vec2 value ) {\n		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );\n	}\n	float hash3D( vec3 value ) {\n		return hash2D( vec2( hash2D( value.xy ), value.z ) );\n	}\n	float getAlphaHashThreshold( vec3 position ) {\n		float maxDeriv = max(\n			length( dFdx( position.xyz ) ),\n			length( dFdy( position.xyz ) )\n		);\n		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );\n		vec2 pixScales = vec2(\n			exp2( floor( log2( pixScale ) ) ),\n			exp2( ceil( log2( pixScale ) ) )\n		);\n		vec2 alpha = vec2(\n			hash3D( floor( pixScales.x * position.xyz ) ),\n			hash3D( floor( pixScales.y * position.xyz ) )\n		);\n		float lerpFactor = fract( log2( pixScale ) );\n		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;\n		float a = min( lerpFactor, 1.0 - lerpFactor );\n		vec3 cases = vec3(\n			x * x / ( 2.0 * a * ( 1.0 - a ) ),\n			( x - 0.5 * a ) / ( 1.0 - a ),\n			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )\n		);\n		float threshold = ( x < ( 1.0 - a ) )\n			? ( ( x < a ) ? cases.x : cases.y )\n			: cases.z;\n		return clamp( threshold , 1.0e-6, 1.0 );\n	}\n#endif",
		alphamap_fragment: "#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;\n#endif",
		alphamap_pars_fragment: "#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif",
		alphatest_fragment: "#ifdef USE_ALPHATEST\n	#ifdef ALPHA_TO_COVERAGE\n	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );\n	if ( diffuseColor.a == 0.0 ) discard;\n	#else\n	if ( diffuseColor.a < alphaTest ) discard;\n	#endif\n#endif",
		alphatest_pars_fragment: "#ifdef USE_ALPHATEST\n	uniform float alphaTest;\n#endif",
		aomap_fragment: "#ifdef USE_AOMAP\n	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;\n	reflectedLight.indirectDiffuse *= ambientOcclusion;\n	#if defined( USE_CLEARCOAT ) \n		clearcoatSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_SHEEN ) \n		sheenSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( STANDARD )\n		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );\n		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );\n	#endif\n#endif",
		aomap_pars_fragment: "#ifdef USE_AOMAP\n	uniform sampler2D aoMap;\n	uniform float aoMapIntensity;\n#endif",
		batching_pars_vertex: "#ifdef USE_BATCHING\n	#if ! defined( GL_ANGLE_multi_draw )\n	#define gl_DrawID _gl_DrawID\n	uniform int _gl_DrawID;\n	#endif\n	uniform highp sampler2D batchingTexture;\n	uniform highp usampler2D batchingIdTexture;\n	mat4 getBatchingMatrix( const in float i ) {\n		int size = textureSize( batchingTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n	float getIndirectIndex( const in int i ) {\n		int size = textureSize( batchingIdTexture, 0 ).x;\n		int x = i % size;\n		int y = i / size;\n		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );\n	}\n#endif\n#ifdef USE_BATCHING_COLOR\n	uniform sampler2D batchingColorTexture;\n	vec3 getBatchingColor( const in float i ) {\n		int size = textureSize( batchingColorTexture, 0 ).x;\n		int j = int( i );\n		int x = j % size;\n		int y = j / size;\n		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 ).rgb;\n	}\n#endif",
		batching_vertex: "#ifdef USE_BATCHING\n	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );\n#endif",
		begin_vertex: "vec3 transformed = vec3( position );\n#ifdef USE_ALPHAHASH\n	vPosition = vec3( position );\n#endif",
		beginnormal_vertex: "vec3 objectNormal = vec3( normal );\n#ifdef USE_TANGENT\n	vec3 objectTangent = vec3( tangent.xyz );\n#endif",
		bsdfs: "float G_BlinnPhong_Implicit( ) {\n	return 0.25;\n}\nfloat D_BlinnPhong( const in float shininess, const in float dotNH ) {\n	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );\n}\nvec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( specularColor, 1.0, dotVH );\n	float G = G_BlinnPhong_Implicit( );\n	float D = D_BlinnPhong( shininess, dotNH );\n	return F * ( G * D );\n} // validated",
		iridescence_fragment: "#ifdef USE_IRIDESCENCE\n	const mat3 XYZ_TO_REC709 = mat3(\n		 3.2404542, -0.9692660,  0.0556434,\n		-1.5371385,  1.8760108, -0.2040259,\n		-0.4985314,  0.0415560,  1.0572252\n	);\n	vec3 Fresnel0ToIor( vec3 fresnel0 ) {\n		vec3 sqrtF0 = sqrt( fresnel0 );\n		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );\n	}\n	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );\n	}\n	float IorToFresnel0( float transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));\n	}\n	vec3 evalSensitivity( float OPD, vec3 shift ) {\n		float phase = 2.0 * PI * OPD * 1.0e-9;\n		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );\n		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );\n		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );\n		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );\n		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );\n		xyz /= 1.0685e-7;\n		vec3 rgb = XYZ_TO_REC709 * xyz;\n		return rgb;\n	}\n	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {\n		vec3 I;\n		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );\n		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );\n		float cosTheta2Sq = 1.0 - sinTheta2Sq;\n		if ( cosTheta2Sq < 0.0 ) {\n			return vec3( 1.0 );\n		}\n		float cosTheta2 = sqrt( cosTheta2Sq );\n		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );\n		float R12 = F_Schlick( R0, 1.0, cosTheta1 );\n		float T121 = 1.0 - R12;\n		float phi12 = 0.0;\n		if ( iridescenceIOR < outsideIOR ) phi12 = PI;\n		float phi21 = PI - phi12;\n		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );\n		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );\n		vec3 phi23 = vec3( 0.0 );\n		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;\n		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;\n		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;\n		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;\n		vec3 phi = vec3( phi21 ) + phi23;\n		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );\n		vec3 r123 = sqrt( R123 );\n		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );\n		vec3 C0 = R12 + Rs;\n		I = C0;\n		vec3 Cm = Rs - T121;\n		for ( int m = 1; m <= 2; ++ m ) {\n			Cm *= r123;\n			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );\n			I += Cm * Sm;\n		}\n		return max( I, vec3( 0.0 ) );\n	}\n#endif",
		bumpmap_pars_fragment: "#ifdef USE_BUMPMAP\n	uniform sampler2D bumpMap;\n	uniform float bumpScale;\n	vec2 dHdxy_fwd() {\n		vec2 dSTdx = dFdx( vBumpMapUv );\n		vec2 dSTdy = dFdy( vBumpMapUv );\n		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;\n		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;\n		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;\n		return vec2( dBx, dBy );\n	}\n	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {\n		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );\n		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );\n		vec3 vN = surf_norm;\n		vec3 R1 = cross( vSigmaY, vN );\n		vec3 R2 = cross( vN, vSigmaX );\n		float fDet = dot( vSigmaX, R1 ) * faceDirection;\n		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );\n		return normalize( abs( fDet ) * surf_norm - vGrad );\n	}\n#endif",
		clipping_planes_fragment: "#if NUM_CLIPPING_PLANES > 0\n	vec4 plane;\n	#ifdef ALPHA_TO_COVERAGE\n		float distanceToPlane, distanceGradient;\n		float clipOpacity = 1.0;\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n			distanceGradient = fwidth( distanceToPlane ) / 2.0;\n			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			if ( clipOpacity == 0.0 ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			float unionClipOpacity = 1.0;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n				distanceGradient = fwidth( distanceToPlane ) / 2.0;\n				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			}\n			#pragma unroll_loop_end\n			clipOpacity *= 1.0 - unionClipOpacity;\n		#endif\n		diffuseColor.a *= clipOpacity;\n		if ( diffuseColor.a == 0.0 ) discard;\n	#else\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			bool clipped = true;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;\n			}\n			#pragma unroll_loop_end\n			if ( clipped ) discard;\n		#endif\n	#endif\n#endif",
		clipping_planes_pars_fragment: "#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];\n#endif",
		clipping_planes_pars_vertex: "#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n#endif",
		clipping_planes_vertex: "#if NUM_CLIPPING_PLANES > 0\n	vClipPosition = - mvPosition.xyz;\n#endif",
		color_fragment: "#if defined( USE_COLOR_ALPHA )\n	diffuseColor *= vColor;\n#elif defined( USE_COLOR )\n	diffuseColor.rgb *= vColor;\n#endif",
		color_pars_fragment: "#if defined( USE_COLOR_ALPHA )\n	varying vec4 vColor;\n#elif defined( USE_COLOR )\n	varying vec3 vColor;\n#endif",
		color_pars_vertex: "#if defined( USE_COLOR_ALPHA )\n	varying vec4 vColor;\n#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	varying vec3 vColor;\n#endif",
		color_vertex: "#if defined( USE_COLOR_ALPHA )\n	vColor = vec4( 1.0 );\n#elif defined( USE_COLOR ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	vColor = vec3( 1.0 );\n#endif\n#ifdef USE_COLOR\n	vColor *= color;\n#endif\n#ifdef USE_INSTANCING_COLOR\n	vColor.xyz *= instanceColor.xyz;\n#endif\n#ifdef USE_BATCHING_COLOR\n	vec3 batchingColor = getBatchingColor( getIndirectIndex( gl_DrawID ) );\n	vColor.xyz *= batchingColor.xyz;\n#endif",
		common: "#define PI 3.141592653589793\n#define PI2 6.283185307179586\n#define PI_HALF 1.5707963267948966\n#define RECIPROCAL_PI 0.3183098861837907\n#define RECIPROCAL_PI2 0.15915494309189535\n#define EPSILON 1e-6\n#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\n#define whiteComplement( a ) ( 1.0 - saturate( a ) )\nfloat pow2( const in float x ) { return x*x; }\nvec3 pow2( const in vec3 x ) { return x*x; }\nfloat pow3( const in float x ) { return x*x*x; }\nfloat pow4( const in float x ) { float x2 = x*x; return x2*x2; }\nfloat max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }\nfloat average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }\nhighp float rand( const in vec2 uv ) {\n	const highp float a = 12.9898, b = 78.233, c = 43758.5453;\n	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );\n	return fract( sin( sn ) * c );\n}\n#ifdef HIGH_PRECISION\n	float precisionSafeLength( vec3 v ) { return length( v ); }\n#else\n	float precisionSafeLength( vec3 v ) {\n		float maxComponent = max3( abs( v ) );\n		return length( v / maxComponent ) * maxComponent;\n	}\n#endif\nstruct IncidentLight {\n	vec3 color;\n	vec3 direction;\n	bool visible;\n};\nstruct ReflectedLight {\n	vec3 directDiffuse;\n	vec3 directSpecular;\n	vec3 indirectDiffuse;\n	vec3 indirectSpecular;\n};\n#ifdef USE_ALPHAHASH\n	varying vec3 vPosition;\n#endif\nvec3 transformDirection( in vec3 dir, in mat4 matrix ) {\n	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );\n}\nvec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {\n	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );\n}\nmat3 transposeMat3( const in mat3 m ) {\n	mat3 tmp;\n	tmp[ 0 ] = vec3( m[ 0 ].x, m[ 1 ].x, m[ 2 ].x );\n	tmp[ 1 ] = vec3( m[ 0 ].y, m[ 1 ].y, m[ 2 ].y );\n	tmp[ 2 ] = vec3( m[ 0 ].z, m[ 1 ].z, m[ 2 ].z );\n	return tmp;\n}\nbool isPerspectiveMatrix( mat4 m ) {\n	return m[ 2 ][ 3 ] == - 1.0;\n}\nvec2 equirectUv( in vec3 dir ) {\n	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;\n	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;\n	return vec2( u, v );\n}\nvec3 BRDF_Lambert( const in vec3 diffuseColor ) {\n	return RECIPROCAL_PI * diffuseColor;\n}\nvec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n}\nfloat F_Schlick( const in float f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n} // validated",
		cube_uv_reflection_fragment: "#ifdef ENVMAP_TYPE_CUBE_UV\n	#define cubeUV_minMipLevel 4.0\n	#define cubeUV_minTileSize 16.0\n	float getFace( vec3 direction ) {\n		vec3 absDirection = abs( direction );\n		float face = - 1.0;\n		if ( absDirection.x > absDirection.z ) {\n			if ( absDirection.x > absDirection.y )\n				face = direction.x > 0.0 ? 0.0 : 3.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		} else {\n			if ( absDirection.z > absDirection.y )\n				face = direction.z > 0.0 ? 2.0 : 5.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		}\n		return face;\n	}\n	vec2 getUV( vec3 direction, float face ) {\n		vec2 uv;\n		if ( face == 0.0 ) {\n			uv = vec2( direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 1.0 ) {\n			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );\n		} else if ( face == 2.0 ) {\n			uv = vec2( - direction.x, direction.y ) / abs( direction.z );\n		} else if ( face == 3.0 ) {\n			uv = vec2( - direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 4.0 ) {\n			uv = vec2( - direction.x, direction.z ) / abs( direction.y );\n		} else {\n			uv = vec2( direction.x, direction.y ) / abs( direction.z );\n		}\n		return 0.5 * ( uv + 1.0 );\n	}\n	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {\n		float face = getFace( direction );\n		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );\n		mipInt = max( mipInt, cubeUV_minMipLevel );\n		float faceSize = exp2( mipInt );\n		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;\n		if ( face > 2.0 ) {\n			uv.y += faceSize;\n			face -= 3.0;\n		}\n		uv.x += face * faceSize;\n		uv.x += filterInt * 3.0 * cubeUV_minTileSize;\n		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );\n		uv.x *= CUBEUV_TEXEL_WIDTH;\n		uv.y *= CUBEUV_TEXEL_HEIGHT;\n		#ifdef texture2DGradEXT\n			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;\n		#else\n			return texture2D( envMap, uv ).rgb;\n		#endif\n	}\n	#define cubeUV_r0 1.0\n	#define cubeUV_m0 - 2.0\n	#define cubeUV_r1 0.8\n	#define cubeUV_m1 - 1.0\n	#define cubeUV_r4 0.4\n	#define cubeUV_m4 2.0\n	#define cubeUV_r5 0.305\n	#define cubeUV_m5 3.0\n	#define cubeUV_r6 0.21\n	#define cubeUV_m6 4.0\n	float roughnessToMip( float roughness ) {\n		float mip = 0.0;\n		if ( roughness >= cubeUV_r1 ) {\n			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;\n		} else if ( roughness >= cubeUV_r4 ) {\n			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;\n		} else if ( roughness >= cubeUV_r5 ) {\n			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;\n		} else if ( roughness >= cubeUV_r6 ) {\n			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;\n		} else {\n			mip = - 2.0 * log2( 1.16 * roughness );		}\n		return mip;\n	}\n	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {\n		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );\n		float mipF = fract( mip );\n		float mipInt = floor( mip );\n		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );\n		if ( mipF == 0.0 ) {\n			return vec4( color0, 1.0 );\n		} else {\n			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );\n			return vec4( mix( color0, color1, mipF ), 1.0 );\n		}\n	}\n#endif",
		defaultnormal_vertex: "vec3 transformedNormal = objectNormal;\n#ifdef USE_TANGENT\n	vec3 transformedTangent = objectTangent;\n#endif\n#ifdef USE_BATCHING\n	mat3 bm = mat3( batchingMatrix );\n	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );\n	transformedNormal = bm * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = bm * transformedTangent;\n	#endif\n#endif\n#ifdef USE_INSTANCING\n	mat3 im = mat3( instanceMatrix );\n	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );\n	transformedNormal = im * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = im * transformedTangent;\n	#endif\n#endif\ntransformedNormal = normalMatrix * transformedNormal;\n#ifdef FLIP_SIDED\n	transformedNormal = - transformedNormal;\n#endif\n#ifdef USE_TANGENT\n	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;\n	#ifdef FLIP_SIDED\n		transformedTangent = - transformedTangent;\n	#endif\n#endif",
		displacementmap_pars_vertex: "#ifdef USE_DISPLACEMENTMAP\n	uniform sampler2D displacementMap;\n	uniform float displacementScale;\n	uniform float displacementBias;\n#endif",
		displacementmap_vertex: "#ifdef USE_DISPLACEMENTMAP\n	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );\n#endif",
		emissivemap_fragment: "#ifdef USE_EMISSIVEMAP\n	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );\n	totalEmissiveRadiance *= emissiveColor.rgb;\n#endif",
		emissivemap_pars_fragment: "#ifdef USE_EMISSIVEMAP\n	uniform sampler2D emissiveMap;\n#endif",
		colorspace_fragment: "gl_FragColor = linearToOutputTexel( gl_FragColor );",
		colorspace_pars_fragment: "\nconst mat3 LINEAR_SRGB_TO_LINEAR_DISPLAY_P3 = mat3(\n	vec3( 0.8224621, 0.177538, 0.0 ),\n	vec3( 0.0331941, 0.9668058, 0.0 ),\n	vec3( 0.0170827, 0.0723974, 0.9105199 )\n);\nconst mat3 LINEAR_DISPLAY_P3_TO_LINEAR_SRGB = mat3(\n	vec3( 1.2249401, - 0.2249404, 0.0 ),\n	vec3( - 0.0420569, 1.0420571, 0.0 ),\n	vec3( - 0.0196376, - 0.0786361, 1.0982735 )\n);\nvec4 LinearSRGBToLinearDisplayP3( in vec4 value ) {\n	return vec4( value.rgb * LINEAR_SRGB_TO_LINEAR_DISPLAY_P3, value.a );\n}\nvec4 LinearDisplayP3ToLinearSRGB( in vec4 value ) {\n	return vec4( value.rgb * LINEAR_DISPLAY_P3_TO_LINEAR_SRGB, value.a );\n}\nvec4 LinearTransferOETF( in vec4 value ) {\n	return value;\n}\nvec4 sRGBTransferOETF( in vec4 value ) {\n	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );\n}",
		envmap_fragment: "#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vec3 cameraToFrag;\n		if ( isOrthographic ) {\n			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToFrag = normalize( vWorldPosition - cameraPosition );\n		}\n		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vec3 reflectVec = reflect( cameraToFrag, worldNormal );\n		#else\n			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );\n		#endif\n	#else\n		vec3 reflectVec = vReflect;\n	#endif\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 envColor = textureCube( envMap, envMapRotation * vec3( flipEnvMap * reflectVec.x, reflectVec.yz ) );\n	#else\n		vec4 envColor = vec4( 0.0 );\n	#endif\n	#ifdef ENVMAP_BLENDING_MULTIPLY\n		outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );\n	#elif defined( ENVMAP_BLENDING_MIX )\n		outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );\n	#elif defined( ENVMAP_BLENDING_ADD )\n		outgoingLight += envColor.xyz * specularStrength * reflectivity;\n	#endif\n#endif",
		envmap_common_pars_fragment: "#ifdef USE_ENVMAP\n	uniform float envMapIntensity;\n	uniform float flipEnvMap;\n	uniform mat3 envMapRotation;\n	#ifdef ENVMAP_TYPE_CUBE\n		uniform samplerCube envMap;\n	#else\n		uniform sampler2D envMap;\n	#endif\n	\n#endif",
		envmap_pars_fragment: "#ifdef USE_ENVMAP\n	uniform float reflectivity;\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		varying vec3 vWorldPosition;\n		uniform float refractionRatio;\n	#else\n		varying vec3 vReflect;\n	#endif\n#endif",
		envmap_pars_vertex: "#ifdef USE_ENVMAP\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		\n		varying vec3 vWorldPosition;\n	#else\n		varying vec3 vReflect;\n		uniform float refractionRatio;\n	#endif\n#endif",
		envmap_physical_pars_fragment: "#ifdef USE_ENVMAP\n	vec3 getIBLIrradiance( const in vec3 normal ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );\n			return PI * envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 reflectVec = reflect( - viewDir, normal );\n			reflectVec = normalize( mix( reflectVec, normal, roughness * roughness) );\n			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );\n			return envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	#ifdef USE_ANISOTROPY\n		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {\n			#ifdef ENVMAP_TYPE_CUBE_UV\n				vec3 bentNormal = cross( bitangent, viewDir );\n				bentNormal = normalize( cross( bentNormal, bitangent ) );\n				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );\n				return getIBLRadiance( viewDir, bentNormal, roughness );\n			#else\n				return vec3( 0.0 );\n			#endif\n		}\n	#endif\n#endif",
		envmap_vertex: "#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vWorldPosition = worldPosition.xyz;\n	#else\n		vec3 cameraToVertex;\n		if ( isOrthographic ) {\n			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );\n		}\n		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vReflect = reflect( cameraToVertex, worldNormal );\n		#else\n			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );\n		#endif\n	#endif\n#endif",
		fog_vertex: "#ifdef USE_FOG\n	vFogDepth = - mvPosition.z;\n#endif",
		fog_pars_vertex: "#ifdef USE_FOG\n	varying float vFogDepth;\n#endif",
		fog_fragment: "#ifdef USE_FOG\n	#ifdef FOG_EXP2\n		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );\n	#else\n		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );\n	#endif\n	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );\n#endif",
		fog_pars_fragment: "#ifdef USE_FOG\n	uniform vec3 fogColor;\n	varying float vFogDepth;\n	#ifdef FOG_EXP2\n		uniform float fogDensity;\n	#else\n		uniform float fogNear;\n		uniform float fogFar;\n	#endif\n#endif",
		gradientmap_pars_fragment: "#ifdef USE_GRADIENTMAP\n	uniform sampler2D gradientMap;\n#endif\nvec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {\n	float dotNL = dot( normal, lightDirection );\n	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );\n	#ifdef USE_GRADIENTMAP\n		return vec3( texture2D( gradientMap, coord ).r );\n	#else\n		vec2 fw = fwidth( coord ) * 0.5;\n		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );\n	#endif\n}",
		lightmap_pars_fragment: "#ifdef USE_LIGHTMAP\n	uniform sampler2D lightMap;\n	uniform float lightMapIntensity;\n#endif",
		lights_lambert_fragment: "LambertMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularStrength = specularStrength;",
		lights_lambert_pars_fragment: "varying vec3 vViewPosition;\nstruct LambertMaterial {\n	vec3 diffuseColor;\n	float specularStrength;\n};\nvoid RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Lambert\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert",
		lights_pars_begin: "uniform bool receiveShadow;\nuniform vec3 ambientLightColor;\n#if defined( USE_LIGHT_PROBES )\n	uniform vec3 lightProbe[ 9 ];\n#endif\nvec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {\n	float x = normal.x, y = normal.y, z = normal.z;\n	vec3 result = shCoefficients[ 0 ] * 0.886227;\n	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;\n	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;\n	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;\n	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;\n	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;\n	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );\n	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;\n	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );\n	return result;\n}\nvec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {\n	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );\n	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );\n	return irradiance;\n}\nvec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {\n	vec3 irradiance = ambientLightColor;\n	return irradiance;\n}\nfloat getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {\n	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );\n	if ( cutoffDistance > 0.0 ) {\n		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );\n	}\n	return distanceFalloff;\n}\nfloat getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {\n	return smoothstep( coneCosine, penumbraCosine, angleCosine );\n}\n#if NUM_DIR_LIGHTS > 0\n	struct DirectionalLight {\n		vec3 direction;\n		vec3 color;\n	};\n	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];\n	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {\n		light.color = directionalLight.color;\n		light.direction = directionalLight.direction;\n		light.visible = true;\n	}\n#endif\n#if NUM_POINT_LIGHTS > 0\n	struct PointLight {\n		vec3 position;\n		vec3 color;\n		float distance;\n		float decay;\n	};\n	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];\n	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = pointLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float lightDistance = length( lVector );\n		light.color = pointLight.color;\n		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );\n		light.visible = ( light.color != vec3( 0.0 ) );\n	}\n#endif\n#if NUM_SPOT_LIGHTS > 0\n	struct SpotLight {\n		vec3 position;\n		vec3 direction;\n		vec3 color;\n		float distance;\n		float decay;\n		float coneCos;\n		float penumbraCos;\n	};\n	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];\n	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = spotLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float angleCos = dot( light.direction, spotLight.direction );\n		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );\n		if ( spotAttenuation > 0.0 ) {\n			float lightDistance = length( lVector );\n			light.color = spotLight.color * spotAttenuation;\n			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );\n			light.visible = ( light.color != vec3( 0.0 ) );\n		} else {\n			light.color = vec3( 0.0 );\n			light.visible = false;\n		}\n	}\n#endif\n#if NUM_RECT_AREA_LIGHTS > 0\n	struct RectAreaLight {\n		vec3 color;\n		vec3 position;\n		vec3 halfWidth;\n		vec3 halfHeight;\n	};\n	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;\n	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];\n#endif\n#if NUM_HEMI_LIGHTS > 0\n	struct HemisphereLight {\n		vec3 direction;\n		vec3 skyColor;\n		vec3 groundColor;\n	};\n	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];\n	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {\n		float dotNL = dot( normal, hemiLight.direction );\n		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;\n		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );\n		return irradiance;\n	}\n#endif",
		lights_toon_fragment: "ToonMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;",
		lights_toon_pars_fragment: "varying vec3 vViewPosition;\nstruct ToonMaterial {\n	vec3 diffuseColor;\n};\nvoid RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Toon\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon",
		lights_phong_fragment: "BlinnPhongMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularColor = specular;\nmaterial.specularShininess = shininess;\nmaterial.specularStrength = specularStrength;",
		lights_phong_pars_fragment: "varying vec3 vViewPosition;\nstruct BlinnPhongMaterial {\n	vec3 diffuseColor;\n	vec3 specularColor;\n	float specularShininess;\n	float specularStrength;\n};\nvoid RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;\n}\nvoid RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_BlinnPhong\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong",
		lights_physical_fragment: "PhysicalMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb * ( 1.0 - metalnessFactor );\nvec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );\nfloat geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );\nmaterial.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;\nmaterial.roughness = min( material.roughness, 1.0 );\n#ifdef IOR\n	material.ior = ior;\n	#ifdef USE_SPECULAR\n		float specularIntensityFactor = specularIntensity;\n		vec3 specularColorFactor = specularColor;\n		#ifdef USE_SPECULAR_COLORMAP\n			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;\n		#endif\n		#ifdef USE_SPECULAR_INTENSITYMAP\n			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;\n		#endif\n		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );\n	#else\n		float specularIntensityFactor = 1.0;\n		vec3 specularColorFactor = vec3( 1.0 );\n		material.specularF90 = 1.0;\n	#endif\n	material.specularColor = mix( min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor, diffuseColor.rgb, metalnessFactor );\n#else\n	material.specularColor = mix( vec3( 0.04 ), diffuseColor.rgb, metalnessFactor );\n	material.specularF90 = 1.0;\n#endif\n#ifdef USE_CLEARCOAT\n	material.clearcoat = clearcoat;\n	material.clearcoatRoughness = clearcoatRoughness;\n	material.clearcoatF0 = vec3( 0.04 );\n	material.clearcoatF90 = 1.0;\n	#ifdef USE_CLEARCOATMAP\n		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;\n	#endif\n	#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;\n	#endif\n	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );\n	material.clearcoatRoughness += geometryRoughness;\n	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );\n#endif\n#ifdef USE_DISPERSION\n	material.dispersion = dispersion;\n#endif\n#ifdef USE_IRIDESCENCE\n	material.iridescence = iridescence;\n	material.iridescenceIOR = iridescenceIOR;\n	#ifdef USE_IRIDESCENCEMAP\n		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;\n	#endif\n	#ifdef USE_IRIDESCENCE_THICKNESSMAP\n		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;\n	#else\n		material.iridescenceThickness = iridescenceThicknessMaximum;\n	#endif\n#endif\n#ifdef USE_SHEEN\n	material.sheenColor = sheenColor;\n	#ifdef USE_SHEEN_COLORMAP\n		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;\n	#endif\n	material.sheenRoughness = clamp( sheenRoughness, 0.07, 1.0 );\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	#ifdef USE_ANISOTROPYMAP\n		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );\n		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;\n		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;\n	#else\n		vec2 anisotropyV = anisotropyVector;\n	#endif\n	material.anisotropy = length( anisotropyV );\n	if( material.anisotropy == 0.0 ) {\n		anisotropyV = vec2( 1.0, 0.0 );\n	} else {\n		anisotropyV /= material.anisotropy;\n		material.anisotropy = saturate( material.anisotropy );\n	}\n	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );\n	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;\n	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;\n#endif",
		lights_physical_pars_fragment: "struct PhysicalMaterial {\n	vec3 diffuseColor;\n	float roughness;\n	vec3 specularColor;\n	float specularF90;\n	float dispersion;\n	#ifdef USE_CLEARCOAT\n		float clearcoat;\n		float clearcoatRoughness;\n		vec3 clearcoatF0;\n		float clearcoatF90;\n	#endif\n	#ifdef USE_IRIDESCENCE\n		float iridescence;\n		float iridescenceIOR;\n		float iridescenceThickness;\n		vec3 iridescenceFresnel;\n		vec3 iridescenceF0;\n	#endif\n	#ifdef USE_SHEEN\n		vec3 sheenColor;\n		float sheenRoughness;\n	#endif\n	#ifdef IOR\n		float ior;\n	#endif\n	#ifdef USE_TRANSMISSION\n		float transmission;\n		float transmissionAlpha;\n		float thickness;\n		float attenuationDistance;\n		vec3 attenuationColor;\n	#endif\n	#ifdef USE_ANISOTROPY\n		float anisotropy;\n		float alphaT;\n		vec3 anisotropyT;\n		vec3 anisotropyB;\n	#endif\n};\nvec3 clearcoatSpecularDirect = vec3( 0.0 );\nvec3 clearcoatSpecularIndirect = vec3( 0.0 );\nvec3 sheenSpecularDirect = vec3( 0.0 );\nvec3 sheenSpecularIndirect = vec3(0.0 );\nvec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {\n    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );\n    float x2 = x * x;\n    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );\n    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );\n}\nfloat V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {\n	float a2 = pow2( alpha );\n	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );\n	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );\n	return 0.5 / max( gv + gl, EPSILON );\n}\nfloat D_GGX( const in float alpha, const in float dotNH ) {\n	float a2 = pow2( alpha );\n	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;\n	return RECIPROCAL_PI * a2 / pow2( denom );\n}\n#ifdef USE_ANISOTROPY\n	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {\n		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );\n		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );\n		float v = 0.5 / ( gv + gl );\n		return saturate(v);\n	}\n	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {\n		float a2 = alphaT * alphaB;\n		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );\n		highp float v2 = dot( v, v );\n		float w2 = a2 / v2;\n		return RECIPROCAL_PI * a2 * pow2 ( w2 );\n	}\n#endif\n#ifdef USE_CLEARCOAT\n	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {\n		vec3 f0 = material.clearcoatF0;\n		float f90 = material.clearcoatF90;\n		float roughness = material.clearcoatRoughness;\n		float alpha = pow2( roughness );\n		vec3 halfDir = normalize( lightDir + viewDir );\n		float dotNL = saturate( dot( normal, lightDir ) );\n		float dotNV = saturate( dot( normal, viewDir ) );\n		float dotNH = saturate( dot( normal, halfDir ) );\n		float dotVH = saturate( dot( viewDir, halfDir ) );\n		vec3 F = F_Schlick( f0, f90, dotVH );\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n		return F * ( V * D );\n	}\n#endif\nvec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {\n	vec3 f0 = material.specularColor;\n	float f90 = material.specularF90;\n	float roughness = material.roughness;\n	float alpha = pow2( roughness );\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( f0, f90, dotVH );\n	#ifdef USE_IRIDESCENCE\n		F = mix( F, material.iridescenceFresnel, material.iridescence );\n	#endif\n	#ifdef USE_ANISOTROPY\n		float dotTL = dot( material.anisotropyT, lightDir );\n		float dotTV = dot( material.anisotropyT, viewDir );\n		float dotTH = dot( material.anisotropyT, halfDir );\n		float dotBL = dot( material.anisotropyB, lightDir );\n		float dotBV = dot( material.anisotropyB, viewDir );\n		float dotBH = dot( material.anisotropyB, halfDir );\n		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );\n		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );\n	#else\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n	#endif\n	return F * ( V * D );\n}\nvec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {\n	const float LUT_SIZE = 64.0;\n	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;\n	const float LUT_BIAS = 0.5 / LUT_SIZE;\n	float dotNV = saturate( dot( N, V ) );\n	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );\n	uv = uv * LUT_SCALE + LUT_BIAS;\n	return uv;\n}\nfloat LTC_ClippedSphereFormFactor( const in vec3 f ) {\n	float l = length( f );\n	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );\n}\nvec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {\n	float x = dot( v1, v2 );\n	float y = abs( x );\n	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;\n	float b = 3.4175940 + ( 4.1616724 + y ) * y;\n	float v = a / b;\n	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;\n	return cross( v1, v2 ) * theta_sintheta;\n}\nvec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {\n	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];\n	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];\n	vec3 lightNormal = cross( v1, v2 );\n	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );\n	vec3 T1, T2;\n	T1 = normalize( V - N * dot( V, N ) );\n	T2 = - cross( N, T1 );\n	mat3 mat = mInv * transposeMat3( mat3( T1, T2, N ) );\n	vec3 coords[ 4 ];\n	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );\n	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );\n	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );\n	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );\n	coords[ 0 ] = normalize( coords[ 0 ] );\n	coords[ 1 ] = normalize( coords[ 1 ] );\n	coords[ 2 ] = normalize( coords[ 2 ] );\n	coords[ 3 ] = normalize( coords[ 3 ] );\n	vec3 vectorFormFactor = vec3( 0.0 );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );\n	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );\n	return vec3( result );\n}\n#if defined( USE_SHEEN )\nfloat D_Charlie( float roughness, float dotNH ) {\n	float alpha = pow2( roughness );\n	float invAlpha = 1.0 / alpha;\n	float cos2h = dotNH * dotNH;\n	float sin2h = max( 1.0 - cos2h, 0.0078125 );\n	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );\n}\nfloat V_Neubelt( float dotNV, float dotNL ) {\n	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );\n}\nvec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float D = D_Charlie( sheenRoughness, dotNH );\n	float V = V_Neubelt( dotNV, dotNL );\n	return sheenColor * ( D * V );\n}\n#endif\nfloat IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float r2 = roughness * roughness;\n	float a = roughness < 0.25 ? -339.2 * r2 + 161.4 * roughness - 25.9 : -8.48 * r2 + 14.3 * roughness - 9.95;\n	float b = roughness < 0.25 ? 44.0 * r2 - 23.7 * roughness + 3.26 : 1.97 * r2 - 3.27 * roughness + 0.72;\n	float DG = exp( a * dotNV + b ) + ( roughness < 0.25 ? 0.0 : 0.1 * ( roughness - 0.25 ) );\n	return saturate( DG * RECIPROCAL_PI );\n}\nvec2 DFGApprox( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	const vec4 c0 = vec4( - 1, - 0.0275, - 0.572, 0.022 );\n	const vec4 c1 = vec4( 1, 0.0425, 1.04, - 0.04 );\n	vec4 r = roughness * c0 + c1;\n	float a004 = min( r.x * r.x, exp2( - 9.28 * dotNV ) ) * r.x + r.y;\n	vec2 fab = vec2( - 1.04, 1.04 ) * a004 + r.zw;\n	return fab;\n}\nvec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {\n	vec2 fab = DFGApprox( normal, viewDir, roughness );\n	return specularColor * fab.x + specularF90 * fab.y;\n}\n#ifdef USE_IRIDESCENCE\nvoid computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#else\nvoid computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#endif\n	vec2 fab = DFGApprox( normal, viewDir, roughness );\n	#ifdef USE_IRIDESCENCE\n		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );\n	#else\n		vec3 Fr = specularColor;\n	#endif\n	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;\n	float Ess = fab.x + fab.y;\n	float Ems = 1.0 - Ess;\n	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );\n	singleScatter += FssEss;\n	multiScatter += Fms * Ems;\n}\n#if NUM_RECT_AREA_LIGHTS > 0\n	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n		vec3 normal = geometryNormal;\n		vec3 viewDir = geometryViewDir;\n		vec3 position = geometryPosition;\n		vec3 lightPos = rectAreaLight.position;\n		vec3 halfWidth = rectAreaLight.halfWidth;\n		vec3 halfHeight = rectAreaLight.halfHeight;\n		vec3 lightColor = rectAreaLight.color;\n		float roughness = material.roughness;\n		vec3 rectCoords[ 4 ];\n		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;\n		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;\n		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;\n		vec2 uv = LTC_Uv( normal, viewDir, roughness );\n		vec4 t1 = texture2D( ltc_1, uv );\n		vec4 t2 = texture2D( ltc_2, uv );\n		mat3 mInv = mat3(\n			vec3( t1.x, 0, t1.y ),\n			vec3(    0, 1,    0 ),\n			vec3( t1.z, 0, t1.w )\n		);\n		vec3 fresnel = ( material.specularColor * t2.x + ( vec3( 1.0 ) - material.specularColor ) * t2.y );\n		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );\n		reflectedLight.directDiffuse += lightColor * material.diffuseColor * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );\n	}\n#endif\nvoid RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	#ifdef USE_CLEARCOAT\n		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );\n		vec3 ccIrradiance = dotNLcc * directLight.color;\n		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );\n	#endif\n	#ifdef USE_SHEEN\n		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );\n	#endif\n	reflectedLight.directSpecular += irradiance * BRDF_GGX( directLight.direction, geometryViewDir, geometryNormal, material );\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {\n	#ifdef USE_CLEARCOAT\n		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );\n	#endif\n	#ifdef USE_SHEEN\n		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n	#endif\n	vec3 singleScattering = vec3( 0.0 );\n	vec3 multiScattering = vec3( 0.0 );\n	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;\n	#ifdef USE_IRIDESCENCE\n		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnel, material.roughness, singleScattering, multiScattering );\n	#else\n		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScattering, multiScattering );\n	#endif\n	vec3 totalScattering = singleScattering + multiScattering;\n	vec3 diffuse = material.diffuseColor * ( 1.0 - max( max( totalScattering.r, totalScattering.g ), totalScattering.b ) );\n	reflectedLight.indirectSpecular += radiance * singleScattering;\n	reflectedLight.indirectSpecular += multiScattering * cosineWeightedIrradiance;\n	reflectedLight.indirectDiffuse += diffuse * cosineWeightedIrradiance;\n}\n#define RE_Direct				RE_Direct_Physical\n#define RE_Direct_RectArea		RE_Direct_RectArea_Physical\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical\n#define RE_IndirectSpecular		RE_IndirectSpecular_Physical\nfloat computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {\n	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );\n}",
		lights_fragment_begin: "\nvec3 geometryPosition = - vViewPosition;\nvec3 geometryNormal = normal;\nvec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );\nvec3 geometryClearcoatNormal = vec3( 0.0 );\n#ifdef USE_CLEARCOAT\n	geometryClearcoatNormal = clearcoatNormal;\n#endif\n#ifdef USE_IRIDESCENCE\n	float dotNVi = saturate( dot( normal, geometryViewDir ) );\n	if ( material.iridescenceThickness == 0.0 ) {\n		material.iridescence = 0.0;\n	} else {\n		material.iridescence = saturate( material.iridescence );\n	}\n	if ( material.iridescence > 0.0 ) {\n		material.iridescenceFresnel = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );\n		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );\n	}\n#endif\nIncidentLight directLight;\n#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )\n	PointLight pointLight;\n	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0\n	PointLightShadow pointLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {\n		pointLight = pointLights[ i ];\n		getPointLightInfo( pointLight, geometryPosition, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS )\n		pointLightShadow = pointLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )\n	SpotLight spotLight;\n	vec4 spotColor;\n	vec3 spotLightCoord;\n	bool inSpotLightMap;\n	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {\n		spotLight = spotLights[ i ];\n		getSpotLightInfo( spotLight, geometryPosition, directLight );\n		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX\n		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS\n		#else\n		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#endif\n		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )\n			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;\n			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );\n			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );\n			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;\n		#endif\n		#undef SPOT_LIGHT_MAP_INDEX\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		spotLightShadow = spotLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )\n	DirectionalLight directionalLight;\n	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {\n		directionalLight = directionalLights[ i ];\n		getDirectionalLightInfo( directionalLight, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )\n		directionalLightShadow = directionalLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )\n	RectAreaLight rectAreaLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {\n		rectAreaLight = rectAreaLights[ i ];\n		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if defined( RE_IndirectDiffuse )\n	vec3 iblIrradiance = vec3( 0.0 );\n	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );\n	#if defined( USE_LIGHT_PROBES )\n		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );\n	#endif\n	#if ( NUM_HEMI_LIGHTS > 0 )\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {\n			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );\n		}\n		#pragma unroll_loop_end\n	#endif\n#endif\n#if defined( RE_IndirectSpecular )\n	vec3 radiance = vec3( 0.0 );\n	vec3 clearcoatRadiance = vec3( 0.0 );\n#endif",
		lights_fragment_maps: "#if defined( RE_IndirectDiffuse )\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;\n		irradiance += lightMapIrradiance;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( STANDARD ) && defined( ENVMAP_TYPE_CUBE_UV )\n		iblIrradiance += getIBLIrradiance( geometryNormal );\n	#endif\n#endif\n#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )\n	#ifdef USE_ANISOTROPY\n		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );\n	#else\n		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );\n	#endif\n	#ifdef USE_CLEARCOAT\n		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );\n	#endif\n#endif",
		lights_fragment_end: "#if defined( RE_IndirectDiffuse )\n	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif\n#if defined( RE_IndirectSpecular )\n	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif",
		logdepthbuf_fragment: "#if defined( USE_LOGDEPTHBUF )\n	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;\n#endif",
		logdepthbuf_pars_fragment: "#if defined( USE_LOGDEPTHBUF )\n	uniform float logDepthBufFC;\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif",
		logdepthbuf_pars_vertex: "#ifdef USE_LOGDEPTHBUF\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif",
		logdepthbuf_vertex: "#ifdef USE_LOGDEPTHBUF\n	vFragDepth = 1.0 + gl_Position.w;\n	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );\n#endif",
		map_fragment: "#ifdef USE_MAP\n	vec4 sampledDiffuseColor = texture2D( map, vMapUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		sampledDiffuseColor = vec4( mix( pow( sampledDiffuseColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), sampledDiffuseColor.rgb * 0.0773993808, vec3( lessThanEqual( sampledDiffuseColor.rgb, vec3( 0.04045 ) ) ) ), sampledDiffuseColor.w );\n	\n	#endif\n	diffuseColor *= sampledDiffuseColor;\n#endif",
		map_pars_fragment: "#ifdef USE_MAP\n	uniform sampler2D map;\n#endif",
		map_particle_fragment: "#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n	#if defined( USE_POINTS_UV )\n		vec2 uv = vUv;\n	#else\n		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;\n	#endif\n#endif\n#ifdef USE_MAP\n	diffuseColor *= texture2D( map, uv );\n#endif\n#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, uv ).g;\n#endif",
		map_particle_pars_fragment: "#if defined( USE_POINTS_UV )\n	varying vec2 vUv;\n#else\n	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n		uniform mat3 uvTransform;\n	#endif\n#endif\n#ifdef USE_MAP\n	uniform sampler2D map;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif",
		metalnessmap_fragment: "float metalnessFactor = metalness;\n#ifdef USE_METALNESSMAP\n	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );\n	metalnessFactor *= texelMetalness.b;\n#endif",
		metalnessmap_pars_fragment: "#ifdef USE_METALNESSMAP\n	uniform sampler2D metalnessMap;\n#endif",
		morphinstance_vertex: "#ifdef USE_INSTANCING_MORPH\n	float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;\n	}\n#endif",
		morphcolor_vertex: "#if defined( USE_MORPHCOLORS )\n	vColor *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		#if defined( USE_COLOR_ALPHA )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];\n		#elif defined( USE_COLOR )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];\n		#endif\n	}\n#endif",
		morphnormal_vertex: "#ifdef USE_MORPHNORMALS\n	objectNormal *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif",
		morphtarget_pars_vertex: "#ifdef USE_MORPHTARGETS\n	#ifndef USE_INSTANCING_MORPH\n		uniform float morphTargetBaseInfluence;\n		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	#endif\n	uniform sampler2DArray morphTargetsTexture;\n	uniform ivec2 morphTargetsTextureSize;\n	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {\n		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;\n		int y = texelIndex / morphTargetsTextureSize.x;\n		int x = texelIndex - y * morphTargetsTextureSize.x;\n		ivec3 morphUV = ivec3( x, y, morphTargetIndex );\n		return texelFetch( morphTargetsTexture, morphUV, 0 );\n	}\n#endif",
		morphtarget_vertex: "#ifdef USE_MORPHTARGETS\n	transformed *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif",
		normal_fragment_begin: "float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;\n#ifdef FLAT_SHADED\n	vec3 fdx = dFdx( vViewPosition );\n	vec3 fdy = dFdy( vViewPosition );\n	vec3 normal = normalize( cross( fdx, fdy ) );\n#else\n	vec3 normal = normalize( vNormal );\n	#ifdef DOUBLE_SIDED\n		normal *= faceDirection;\n	#endif\n#endif\n#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )\n	#ifdef USE_TANGENT\n		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn = getTangentFrame( - vViewPosition, normal,\n		#if defined( USE_NORMALMAP )\n			vNormalMapUv\n		#elif defined( USE_CLEARCOAT_NORMALMAP )\n			vClearcoatNormalMapUv\n		#else\n			vUv\n		#endif\n		);\n	#endif\n	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )\n		tbn[0] *= faceDirection;\n		tbn[1] *= faceDirection;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	#ifdef USE_TANGENT\n		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );\n	#endif\n	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )\n		tbn2[0] *= faceDirection;\n		tbn2[1] *= faceDirection;\n	#endif\n#endif\nvec3 nonPerturbedNormal = normal;",
		normal_fragment_maps: "#ifdef USE_NORMALMAP_OBJECTSPACE\n	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	#ifdef FLIP_SIDED\n		normal = - normal;\n	#endif\n	#ifdef DOUBLE_SIDED\n		normal = normal * faceDirection;\n	#endif\n	normal = normalize( normalMatrix * normal );\n#elif defined( USE_NORMALMAP_TANGENTSPACE )\n	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	mapN.xy *= normalScale;\n	normal = normalize( tbn * mapN );\n#elif defined( USE_BUMPMAP )\n	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );\n#endif",
		normal_pars_fragment: "#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif",
		normal_pars_vertex: "#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif",
		normal_vertex: "#ifndef FLAT_SHADED\n	vNormal = normalize( transformedNormal );\n	#ifdef USE_TANGENT\n		vTangent = normalize( transformedTangent );\n		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );\n	#endif\n#endif",
		normalmap_pars_fragment: "#ifdef USE_NORMALMAP\n	uniform sampler2D normalMap;\n	uniform vec2 normalScale;\n#endif\n#ifdef USE_NORMALMAP_OBJECTSPACE\n	uniform mat3 normalMatrix;\n#endif\n#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )\n	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {\n		vec3 q0 = dFdx( eye_pos.xyz );\n		vec3 q1 = dFdy( eye_pos.xyz );\n		vec2 st0 = dFdx( uv.st );\n		vec2 st1 = dFdy( uv.st );\n		vec3 N = surf_norm;\n		vec3 q1perp = cross( q1, N );\n		vec3 q0perp = cross( N, q0 );\n		vec3 T = q1perp * st0.x + q0perp * st1.x;\n		vec3 B = q1perp * st0.y + q0perp * st1.y;\n		float det = max( dot( T, T ), dot( B, B ) );\n		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );\n		return mat3( T * scale, B * scale, N );\n	}\n#endif",
		clearcoat_normal_fragment_begin: "#ifdef USE_CLEARCOAT\n	vec3 clearcoatNormal = nonPerturbedNormal;\n#endif",
		clearcoat_normal_fragment_maps: "#ifdef USE_CLEARCOAT_NORMALMAP\n	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;\n	clearcoatMapN.xy *= clearcoatNormalScale;\n	clearcoatNormal = normalize( tbn2 * clearcoatMapN );\n#endif",
		clearcoat_pars_fragment: "#ifdef USE_CLEARCOATMAP\n	uniform sampler2D clearcoatMap;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform sampler2D clearcoatNormalMap;\n	uniform vec2 clearcoatNormalScale;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform sampler2D clearcoatRoughnessMap;\n#endif",
		iridescence_pars_fragment: "#ifdef USE_IRIDESCENCEMAP\n	uniform sampler2D iridescenceMap;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform sampler2D iridescenceThicknessMap;\n#endif",
		opaque_fragment: "#ifdef OPAQUE\ndiffuseColor.a = 1.0;\n#endif\n#ifdef USE_TRANSMISSION\ndiffuseColor.a *= material.transmissionAlpha;\n#endif\ngl_FragColor = vec4( outgoingLight, diffuseColor.a );",
		packing: "vec3 packNormalToRGB( const in vec3 normal ) {\n	return normalize( normal ) * 0.5 + 0.5;\n}\nvec3 unpackRGBToNormal( const in vec3 rgb ) {\n	return 2.0 * rgb.xyz - 1.0;\n}\nconst float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;\nconst float Inv255 = 1. / 255.;\nconst vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );\nconst vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );\nconst vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );\nconst vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );\nvec4 packDepthToRGBA( const in float v ) {\n	if( v <= 0.0 )\n		return vec4( 0., 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec4( 1., 1., 1., 1. );\n	float vuf;\n	float af = modf( v * PackFactors.a, vuf );\n	float bf = modf( vuf * ShiftRight8, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );\n}\nvec3 packDepthToRGB( const in float v ) {\n	if( v <= 0.0 )\n		return vec3( 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec3( 1., 1., 1. );\n	float vuf;\n	float bf = modf( v * PackFactors.b, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec3( vuf * Inv255, gf * PackUpscale, bf );\n}\nvec2 packDepthToRG( const in float v ) {\n	if( v <= 0.0 )\n		return vec2( 0., 0. );\n	if( v >= 1.0 )\n		return vec2( 1., 1. );\n	float vuf;\n	float gf = modf( v * 256., vuf );\n	return vec2( vuf * Inv255, gf );\n}\nfloat unpackRGBAToDepth( const in vec4 v ) {\n	return dot( v, UnpackFactors4 );\n}\nfloat unpackRGBToDepth( const in vec3 v ) {\n	return dot( v, UnpackFactors3 );\n}\nfloat unpackRGToDepth( const in vec2 v ) {\n	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;\n}\nvec4 pack2HalfToRGBA( const in vec2 v ) {\n	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );\n	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );\n}\nvec2 unpackRGBATo2Half( const in vec4 v ) {\n	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );\n}\nfloat viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( viewZ + near ) / ( near - far );\n}\nfloat orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	return depth * ( near - far ) - near;\n}\nfloat viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );\n}\nfloat perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	return ( near * far ) / ( ( far - near ) * depth - far );\n}",
		premultiplied_alpha_fragment: "#ifdef PREMULTIPLIED_ALPHA\n	gl_FragColor.rgb *= gl_FragColor.a;\n#endif",
		project_vertex: "vec4 mvPosition = vec4( transformed, 1.0 );\n#ifdef USE_BATCHING\n	mvPosition = batchingMatrix * mvPosition;\n#endif\n#ifdef USE_INSTANCING\n	mvPosition = instanceMatrix * mvPosition;\n#endif\nmvPosition = modelViewMatrix * mvPosition;\ngl_Position = projectionMatrix * mvPosition;",
		dithering_fragment: "#ifdef DITHERING\n	gl_FragColor.rgb = dithering( gl_FragColor.rgb );\n#endif",
		dithering_pars_fragment: "#ifdef DITHERING\n	vec3 dithering( vec3 color ) {\n		float grid_position = rand( gl_FragCoord.xy );\n		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );\n		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );\n		return color + dither_shift_RGB;\n	}\n#endif",
		roughnessmap_fragment: "float roughnessFactor = roughness;\n#ifdef USE_ROUGHNESSMAP\n	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );\n	roughnessFactor *= texelRoughness.g;\n#endif",
		roughnessmap_pars_fragment: "#ifdef USE_ROUGHNESSMAP\n	uniform sampler2D roughnessMap;\n#endif",
		shadowmap_pars_fragment: "#if NUM_SPOT_LIGHT_COORDS > 0\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#if NUM_SPOT_LIGHT_MAPS > 0\n	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		uniform sampler2D pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n	float texture2DCompare( sampler2D depths, vec2 uv, float compare ) {\n		return step( compare, unpackRGBAToDepth( texture2D( depths, uv ) ) );\n	}\n	vec2 texture2DDistribution( sampler2D shadow, vec2 uv ) {\n		return unpackRGBATo2Half( texture2D( shadow, uv ) );\n	}\n	float VSMShadow (sampler2D shadow, vec2 uv, float compare ){\n		float occlusion = 1.0;\n		vec2 distribution = texture2DDistribution( shadow, uv );\n		float hard_shadow = step( compare , distribution.x );\n		if (hard_shadow != 1.0 ) {\n			float distance = compare - distribution.x ;\n			float variance = max( 0.00000, distribution.y * distribution.y );\n			float softness_probability = variance / (variance + distance * distance );			softness_probability = clamp( ( softness_probability - 0.3 ) / ( 0.95 - 0.3 ), 0.0, 1.0 );			occlusion = clamp( max( hard_shadow, softness_probability ), 0.0, 1.0 );\n		}\n		return occlusion;\n	}\n	float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n		float shadow = 1.0;\n		shadowCoord.xyz /= shadowCoord.w;\n		shadowCoord.z += shadowBias;\n		bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n		bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n		if ( frustumTest ) {\n		#if defined( SHADOWMAP_TYPE_PCF )\n			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;\n			float dx0 = - texelSize.x * shadowRadius;\n			float dy0 = - texelSize.y * shadowRadius;\n			float dx1 = + texelSize.x * shadowRadius;\n			float dy1 = + texelSize.y * shadowRadius;\n			float dx2 = dx0 / 2.0;\n			float dy2 = dy0 / 2.0;\n			float dx3 = dx1 / 2.0;\n			float dy3 = dy1 / 2.0;\n			shadow = (\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy2 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy2 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy2 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx2, dy3 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy3 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx3, dy3 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx0, dy1 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( 0.0, dy1 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, shadowCoord.xy + vec2( dx1, dy1 ), shadowCoord.z )\n			) * ( 1.0 / 17.0 );\n		#elif defined( SHADOWMAP_TYPE_PCF_SOFT )\n			vec2 texelSize = vec2( 1.0 ) / shadowMapSize;\n			float dx = texelSize.x;\n			float dy = texelSize.y;\n			vec2 uv = shadowCoord.xy;\n			vec2 f = fract( uv * shadowMapSize + 0.5 );\n			uv -= f * texelSize;\n			shadow = (\n				texture2DCompare( shadowMap, uv, shadowCoord.z ) +\n				texture2DCompare( shadowMap, uv + vec2( dx, 0.0 ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, uv + vec2( 0.0, dy ), shadowCoord.z ) +\n				texture2DCompare( shadowMap, uv + texelSize, shadowCoord.z ) +\n				mix( texture2DCompare( shadowMap, uv + vec2( -dx, 0.0 ), shadowCoord.z ),\n					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 0.0 ), shadowCoord.z ),\n					 f.x ) +\n				mix( texture2DCompare( shadowMap, uv + vec2( -dx, dy ), shadowCoord.z ),\n					 texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, dy ), shadowCoord.z ),\n					 f.x ) +\n				mix( texture2DCompare( shadowMap, uv + vec2( 0.0, -dy ), shadowCoord.z ),\n					 texture2DCompare( shadowMap, uv + vec2( 0.0, 2.0 * dy ), shadowCoord.z ),\n					 f.y ) +\n				mix( texture2DCompare( shadowMap, uv + vec2( dx, -dy ), shadowCoord.z ),\n					 texture2DCompare( shadowMap, uv + vec2( dx, 2.0 * dy ), shadowCoord.z ),\n					 f.y ) +\n				mix( mix( texture2DCompare( shadowMap, uv + vec2( -dx, -dy ), shadowCoord.z ),\n						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, -dy ), shadowCoord.z ),\n						  f.x ),\n					 mix( texture2DCompare( shadowMap, uv + vec2( -dx, 2.0 * dy ), shadowCoord.z ),\n						  texture2DCompare( shadowMap, uv + vec2( 2.0 * dx, 2.0 * dy ), shadowCoord.z ),\n						  f.x ),\n					 f.y )\n			) * ( 1.0 / 9.0 );\n		#elif defined( SHADOWMAP_TYPE_VSM )\n			shadow = VSMShadow( shadowMap, shadowCoord.xy, shadowCoord.z );\n		#else\n			shadow = texture2DCompare( shadowMap, shadowCoord.xy, shadowCoord.z );\n		#endif\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n	vec2 cubeToUV( vec3 v, float texelSizeY ) {\n		vec3 absV = abs( v );\n		float scaleToCube = 1.0 / max( absV.x, max( absV.y, absV.z ) );\n		absV *= scaleToCube;\n		v *= scaleToCube * ( 1.0 - 2.0 * texelSizeY );\n		vec2 planar = v.xy;\n		float almostATexel = 1.5 * texelSizeY;\n		float almostOne = 1.0 - almostATexel;\n		if ( absV.z >= almostOne ) {\n			if ( v.z > 0.0 )\n				planar.x = 4.0 - v.x;\n		} else if ( absV.x >= almostOne ) {\n			float signX = sign( v.x );\n			planar.x = v.z * signX + 2.0 * signX;\n		} else if ( absV.y >= almostOne ) {\n			float signY = sign( v.y );\n			planar.x = v.x + 2.0 * signY + 2.0;\n			planar.y = v.z * signY - 2.0;\n		}\n		return vec2( 0.125, 0.25 ) * planar + vec2( 0.375, 0.75 );\n	}\n	float getPointShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {\n		float shadow = 1.0;\n		vec3 lightToPosition = shadowCoord.xyz;\n		\n		float lightToPositionLength = length( lightToPosition );\n		if ( lightToPositionLength - shadowCameraFar <= 0.0 && lightToPositionLength - shadowCameraNear >= 0.0 ) {\n			float dp = ( lightToPositionLength - shadowCameraNear ) / ( shadowCameraFar - shadowCameraNear );			dp += shadowBias;\n			vec3 bd3D = normalize( lightToPosition );\n			vec2 texelSize = vec2( 1.0 ) / ( shadowMapSize * vec2( 4.0, 2.0 ) );\n			#if defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_PCF_SOFT ) || defined( SHADOWMAP_TYPE_VSM )\n				vec2 offset = vec2( - 1, 1 ) * shadowRadius * texelSize.y;\n				shadow = (\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyy, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyy, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xyx, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yyx, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxy, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxy, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.xxx, texelSize.y ), dp ) +\n					texture2DCompare( shadowMap, cubeToUV( bd3D + offset.yxx, texelSize.y ), dp )\n				) * ( 1.0 / 9.0 );\n			#else\n				shadow = texture2DCompare( shadowMap, cubeToUV( bd3D, texelSize.y ), dp );\n			#endif\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n#endif",
		shadowmap_pars_vertex: "#if NUM_SPOT_LIGHT_COORDS > 0\n	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n#endif",
		shadowmap_vertex: "#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )\n	vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );\n	vec4 shadowWorldPosition;\n#endif\n#if defined( USE_SHADOWMAP )\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );\n			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );\n			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n#endif\n#if NUM_SPOT_LIGHT_COORDS > 0\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {\n		shadowWorldPosition = worldPosition;\n		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;\n		#endif\n		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;\n	}\n	#pragma unroll_loop_end\n#endif",
		shadowmask_pars_fragment: "float getShadowMask() {\n	float shadow = 1.0;\n	#ifdef USE_SHADOWMAP\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n		directionalLight = directionalLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {\n		spotLight = spotLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n	PointLightShadow pointLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n		pointLight = pointLightShadows[ i ];\n		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#endif\n	return shadow;\n}",
		skinbase_vertex: "#ifdef USE_SKINNING\n	mat4 boneMatX = getBoneMatrix( skinIndex.x );\n	mat4 boneMatY = getBoneMatrix( skinIndex.y );\n	mat4 boneMatZ = getBoneMatrix( skinIndex.z );\n	mat4 boneMatW = getBoneMatrix( skinIndex.w );\n#endif",
		skinning_pars_vertex: "#ifdef USE_SKINNING\n	uniform mat4 bindMatrix;\n	uniform mat4 bindMatrixInverse;\n	uniform highp sampler2D boneTexture;\n	mat4 getBoneMatrix( const in float i ) {\n		int size = textureSize( boneTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n#endif",
		skinning_vertex: "#ifdef USE_SKINNING\n	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );\n	vec4 skinned = vec4( 0.0 );\n	skinned += boneMatX * skinVertex * skinWeight.x;\n	skinned += boneMatY * skinVertex * skinWeight.y;\n	skinned += boneMatZ * skinVertex * skinWeight.z;\n	skinned += boneMatW * skinVertex * skinWeight.w;\n	transformed = ( bindMatrixInverse * skinned ).xyz;\n#endif",
		skinnormal_vertex: "#ifdef USE_SKINNING\n	mat4 skinMatrix = mat4( 0.0 );\n	skinMatrix += skinWeight.x * boneMatX;\n	skinMatrix += skinWeight.y * boneMatY;\n	skinMatrix += skinWeight.z * boneMatZ;\n	skinMatrix += skinWeight.w * boneMatW;\n	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;\n	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;\n	#ifdef USE_TANGENT\n		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;\n	#endif\n#endif",
		specularmap_fragment: "float specularStrength;\n#ifdef USE_SPECULARMAP\n	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );\n	specularStrength = texelSpecular.r;\n#else\n	specularStrength = 1.0;\n#endif",
		specularmap_pars_fragment: "#ifdef USE_SPECULARMAP\n	uniform sampler2D specularMap;\n#endif",
		tonemapping_fragment: "#if defined( TONE_MAPPING )\n	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );\n#endif",
		tonemapping_pars_fragment: "#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\nuniform float toneMappingExposure;\nvec3 LinearToneMapping( vec3 color ) {\n	return saturate( toneMappingExposure * color );\n}\nvec3 ReinhardToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	return saturate( color / ( vec3( 1.0 ) + color ) );\n}\nvec3 CineonToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	color = max( vec3( 0.0 ), color - 0.004 );\n	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );\n}\nvec3 RRTAndODTFit( vec3 v ) {\n	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;\n	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;\n	return a / b;\n}\nvec3 ACESFilmicToneMapping( vec3 color ) {\n	const mat3 ACESInputMat = mat3(\n		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),\n		vec3( 0.04823, 0.01566, 0.83777 )\n	);\n	const mat3 ACESOutputMat = mat3(\n		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),\n		vec3( -0.07367, -0.00605,  1.07602 )\n	);\n	color *= toneMappingExposure / 0.6;\n	color = ACESInputMat * color;\n	color = RRTAndODTFit( color );\n	color = ACESOutputMat * color;\n	return saturate( color );\n}\nconst mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(\n	vec3( 1.6605, - 0.1246, - 0.0182 ),\n	vec3( - 0.5876, 1.1329, - 0.1006 ),\n	vec3( - 0.0728, - 0.0083, 1.1187 )\n);\nconst mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(\n	vec3( 0.6274, 0.0691, 0.0164 ),\n	vec3( 0.3293, 0.9195, 0.0880 ),\n	vec3( 0.0433, 0.0113, 0.8956 )\n);\nvec3 agxDefaultContrastApprox( vec3 x ) {\n	vec3 x2 = x * x;\n	vec3 x4 = x2 * x2;\n	return + 15.5 * x4 * x2\n		- 40.14 * x4 * x\n		+ 31.96 * x4\n		- 6.868 * x2 * x\n		+ 0.4298 * x2\n		+ 0.1191 * x\n		- 0.00232;\n}\nvec3 AgXToneMapping( vec3 color ) {\n	const mat3 AgXInsetMatrix = mat3(\n		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),\n		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),\n		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )\n	);\n	const mat3 AgXOutsetMatrix = mat3(\n		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),\n		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),\n		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )\n	);\n	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;\n	color *= toneMappingExposure;\n	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;\n	color = AgXInsetMatrix * color;\n	color = max( color, 1e-10 );	color = log2( color );\n	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );\n	color = clamp( color, 0.0, 1.0 );\n	color = agxDefaultContrastApprox( color );\n	color = AgXOutsetMatrix * color;\n	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );\n	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;\n	color = clamp( color, 0.0, 1.0 );\n	return color;\n}\nvec3 NeutralToneMapping( vec3 color ) {\n	const float StartCompression = 0.8 - 0.04;\n	const float Desaturation = 0.15;\n	color *= toneMappingExposure;\n	float x = min( color.r, min( color.g, color.b ) );\n	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;\n	color -= offset;\n	float peak = max( color.r, max( color.g, color.b ) );\n	if ( peak < StartCompression ) return color;\n	float d = 1. - StartCompression;\n	float newPeak = 1. - d * d / ( peak + d - StartCompression );\n	color *= newPeak / peak;\n	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );\n	return mix( color, vec3( newPeak ), g );\n}\nvec3 CustomToneMapping( vec3 color ) { return color; }",
		transmission_fragment: "#ifdef USE_TRANSMISSION\n	material.transmission = transmission;\n	material.transmissionAlpha = 1.0;\n	material.thickness = thickness;\n	material.attenuationDistance = attenuationDistance;\n	material.attenuationColor = attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;\n	#endif\n	vec3 pos = vWorldPosition;\n	vec3 v = normalize( cameraPosition - pos );\n	vec3 n = inverseTransformDirection( normal, viewMatrix );\n	vec4 transmitted = getIBLVolumeRefraction(\n		n, v, material.roughness, material.diffuseColor, material.specularColor, material.specularF90,\n		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,\n		material.attenuationColor, material.attenuationDistance );\n	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );\n	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );\n#endif",
		transmission_pars_fragment: "#ifdef USE_TRANSMISSION\n	uniform float transmission;\n	uniform float thickness;\n	uniform float attenuationDistance;\n	uniform vec3 attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		uniform sampler2D transmissionMap;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		uniform sampler2D thicknessMap;\n	#endif\n	uniform vec2 transmissionSamplerSize;\n	uniform sampler2D transmissionSamplerMap;\n	uniform mat4 modelMatrix;\n	uniform mat4 projectionMatrix;\n	varying vec3 vWorldPosition;\n	float w0( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );\n	}\n	float w1( float a ) {\n		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );\n	}\n	float w2( float a ){\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );\n	}\n	float w3( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * a * a );\n	}\n	float g0( float a ) {\n		return w0( a ) + w1( a );\n	}\n	float g1( float a ) {\n		return w2( a ) + w3( a );\n	}\n	float h0( float a ) {\n		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );\n	}\n	float h1( float a ) {\n		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );\n	}\n	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {\n		uv = uv * texelSize.zw + 0.5;\n		vec2 iuv = floor( uv );\n		vec2 fuv = fract( uv );\n		float g0x = g0( fuv.x );\n		float g1x = g1( fuv.x );\n		float h0x = h0( fuv.x );\n		float h1x = h1( fuv.x );\n		float h0y = h0( fuv.y );\n		float h1y = h1( fuv.y );\n		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +\n			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );\n	}\n	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {\n		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );\n		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );\n		vec2 fLodSizeInv = 1.0 / fLodSize;\n		vec2 cLodSizeInv = 1.0 / cLodSize;\n		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );\n		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );\n		return mix( fSample, cSample, fract( lod ) );\n	}\n	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {\n		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );\n		vec3 modelScale;\n		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );\n		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );\n		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );\n		return normalize( refractionVector ) * thickness * modelScale;\n	}\n	float applyIorToRoughness( const in float roughness, const in float ior ) {\n		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );\n	}\n	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {\n		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );\n		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );\n	}\n	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {\n		if ( isinf( attenuationDistance ) ) {\n			return vec3( 1.0 );\n		} else {\n			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;\n			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;\n		}\n	}\n	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,\n		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,\n		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,\n		const in vec3 attenuationColor, const in float attenuationDistance ) {\n		vec4 transmittedLight;\n		vec3 transmittance;\n		#ifdef USE_DISPERSION\n			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;\n			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );\n			for ( int i = 0; i < 3; i ++ ) {\n				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );\n				vec3 refractedRayExit = position + transmissionRay;\n		\n				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n				vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n				refractionCoords += 1.0;\n				refractionCoords /= 2.0;\n		\n				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );\n				transmittedLight[ i ] = transmissionSample[ i ];\n				transmittedLight.a += transmissionSample.a;\n				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];\n			}\n			transmittedLight.a /= 3.0;\n		\n		#else\n		\n			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );\n			vec3 refractedRayExit = position + transmissionRay;\n			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n			vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n			refractionCoords += 1.0;\n			refractionCoords /= 2.0;\n			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );\n			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );\n		\n		#endif\n		vec3 attenuatedColor = transmittance * transmittedLight.rgb;\n		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );\n		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;\n		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );\n	}\n#endif",
		uv_pars_fragment: "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif",
		uv_pars_vertex: "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	uniform mat3 mapTransform;\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform mat3 alphaMapTransform;\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	uniform mat3 lightMapTransform;\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	uniform mat3 aoMapTransform;\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	uniform mat3 bumpMapTransform;\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	uniform mat3 normalMapTransform;\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	uniform mat3 displacementMapTransform;\n	varying vec2 vDisplacementMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	uniform mat3 emissiveMapTransform;\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	uniform mat3 metalnessMapTransform;\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	uniform mat3 roughnessMapTransform;\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	uniform mat3 anisotropyMapTransform;\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	uniform mat3 clearcoatMapTransform;\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform mat3 clearcoatNormalMapTransform;\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform mat3 clearcoatRoughnessMapTransform;\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	uniform mat3 sheenColorMapTransform;\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	uniform mat3 sheenRoughnessMapTransform;\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	uniform mat3 iridescenceMapTransform;\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform mat3 iridescenceThicknessMapTransform;\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	uniform mat3 specularMapTransform;\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	uniform mat3 specularColorMapTransform;\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	uniform mat3 specularIntensityMapTransform;\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif",
		uv_vertex: "#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	vUv = vec3( uv, 1 ).xy;\n#endif\n#ifdef USE_MAP\n	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ALPHAMAP\n	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_LIGHTMAP\n	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_AOMAP\n	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_BUMPMAP\n	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_NORMALMAP\n	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_EMISSIVEMAP\n	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_METALNESSMAP\n	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOATMAP\n	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULARMAP\n	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_THICKNESSMAP\n	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;\n#endif",
		worldpos_vertex: "#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0\n	vec4 worldPosition = vec4( transformed, 1.0 );\n	#ifdef USE_BATCHING\n		worldPosition = batchingMatrix * worldPosition;\n	#endif\n	#ifdef USE_INSTANCING\n		worldPosition = instanceMatrix * worldPosition;\n	#endif\n	worldPosition = modelMatrix * worldPosition;\n#endif",
		background_vert: "varying vec2 vUv;\nuniform mat3 uvTransform;\nvoid main() {\n	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	gl_Position = vec4( position.xy, 1.0, 1.0 );\n}",
		background_frag: "uniform sampler2D t2D;\nuniform float backgroundIntensity;\nvarying vec2 vUv;\nvoid main() {\n	vec4 texColor = texture2D( t2D, vUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
		backgroundCube_vert: "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}",
		backgroundCube_frag: "#ifdef ENVMAP_TYPE_CUBE\n	uniform samplerCube envMap;\n#elif defined( ENVMAP_TYPE_CUBE_UV )\n	uniform sampler2D envMap;\n#endif\nuniform float flipEnvMap;\nuniform float backgroundBlurriness;\nuniform float backgroundIntensity;\nuniform mat3 backgroundRotation;\nvarying vec3 vWorldDirection;\n#include <cube_uv_reflection_fragment>\nvoid main() {\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 texColor = textureCube( envMap, backgroundRotation * vec3( flipEnvMap * vWorldDirection.x, vWorldDirection.yz ) );\n	#elif defined( ENVMAP_TYPE_CUBE_UV )\n		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );\n	#else\n		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
		cube_vert: "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}",
		cube_frag: "uniform samplerCube tCube;\nuniform float tFlip;\nuniform float opacity;\nvarying vec3 vWorldDirection;\nvoid main() {\n	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );\n	gl_FragColor = texColor;\n	gl_FragColor.a *= opacity;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
		depth_vert: "#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vHighPrecisionZW = gl_Position.zw;\n}",
		depth_frag: "#if DEPTH_PACKING == 3200\n	uniform float opacity;\n#endif\n#include <common>\n#include <packing>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#if DEPTH_PACKING == 3200\n		diffuseColor.a = opacity;\n	#endif\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <logdepthbuf_fragment>\n	float fragCoordZ = 0.5 * vHighPrecisionZW[0] / vHighPrecisionZW[1] + 0.5;\n	#if DEPTH_PACKING == 3200\n		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );\n	#elif DEPTH_PACKING == 3201\n		gl_FragColor = packDepthToRGBA( fragCoordZ );\n	#elif DEPTH_PACKING == 3202\n		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );\n	#elif DEPTH_PACKING == 3203\n		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );\n	#endif\n}",
		distanceRGBA_vert: "#define DISTANCE\nvarying vec3 vWorldPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <worldpos_vertex>\n	#include <clipping_planes_vertex>\n	vWorldPosition = worldPosition.xyz;\n}",
		distanceRGBA_frag: "#define DISTANCE\nuniform vec3 referencePosition;\nuniform float nearDistance;\nuniform float farDistance;\nvarying vec3 vWorldPosition;\n#include <common>\n#include <packing>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main () {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	float dist = length( vWorldPosition - referencePosition );\n	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );\n	dist = saturate( dist );\n	gl_FragColor = packDepthToRGBA( dist );\n}",
		equirect_vert: "varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n}",
		equirect_frag: "uniform sampler2D tEquirect;\nvarying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vec3 direction = normalize( vWorldDirection );\n	vec2 sampleUV = equirectUv( direction );\n	gl_FragColor = texture2D( tEquirect, sampleUV );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",
		linedashed_vert: "uniform float scale;\nattribute float lineDistance;\nvarying float vLineDistance;\n#include <common>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	vLineDistance = scale * lineDistance;\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}",
		linedashed_frag: "uniform vec3 diffuse;\nuniform float opacity;\nuniform float dashSize;\nuniform float totalSize;\nvarying float vLineDistance;\n#include <common>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	if ( mod( vLineDistance, totalSize ) > dashSize ) {\n		discard;\n	}\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",
		meshbasic_vert: "#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinbase_vertex>\n		#include <skinnormal_vertex>\n		#include <defaultnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <fog_vertex>\n}",
		meshbasic_frag: "uniform vec3 diffuse;\nuniform float opacity;\n#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n#endif\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;\n	#else\n		reflectedLight.indirectDiffuse += vec3( 1.0 );\n	#endif\n	#include <aomap_fragment>\n	reflectedLight.indirectDiffuse *= diffuseColor.rgb;\n	vec3 outgoingLight = reflectedLight.indirectDiffuse;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
		meshlambert_vert: "#define LAMBERT\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
		meshlambert_frag: "#define LAMBERT\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <packing>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_lambert_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_lambert_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
		meshmatcap_vert: "#define MATCAP\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n	vViewPosition = - mvPosition.xyz;\n}",
		meshmatcap_frag: "#define MATCAP\nuniform vec3 diffuse;\nuniform float opacity;\nuniform sampler2D matcap;\nvarying vec3 vViewPosition;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	vec3 viewDir = normalize( vViewPosition );\n	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );\n	vec3 y = cross( viewDir, x );\n	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;\n	#ifdef USE_MATCAP\n		vec4 matcapColor = texture2D( matcap, uv );\n	#else\n		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );\n	#endif\n	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
		meshnormal_vert: "#define NORMAL\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	vViewPosition = - mvPosition.xyz;\n#endif\n}",
		meshnormal_frag: "#define NORMAL\nuniform float opacity;\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <packing>\n#include <uv_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	gl_FragColor = vec4( packNormalToRGB( normal ), diffuseColor.a );\n	#ifdef OPAQUE\n		gl_FragColor.a = 1.0;\n	#endif\n}",
		meshphong_vert: "#define PHONG\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
		meshphong_frag: "#define PHONG\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform vec3 specular;\nuniform float shininess;\nuniform float opacity;\n#include <common>\n#include <packing>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_phong_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_phong_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
		meshphysical_vert: "#define STANDARD\nvarying vec3 vViewPosition;\n#ifdef USE_TRANSMISSION\n	varying vec3 vWorldPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n#ifdef USE_TRANSMISSION\n	vWorldPosition = worldPosition.xyz;\n#endif\n}",
		meshphysical_frag: "#define STANDARD\n#ifdef PHYSICAL\n	#define IOR\n	#define USE_SPECULAR\n#endif\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float roughness;\nuniform float metalness;\nuniform float opacity;\n#ifdef IOR\n	uniform float ior;\n#endif\n#ifdef USE_SPECULAR\n	uniform float specularIntensity;\n	uniform vec3 specularColor;\n	#ifdef USE_SPECULAR_COLORMAP\n		uniform sampler2D specularColorMap;\n	#endif\n	#ifdef USE_SPECULAR_INTENSITYMAP\n		uniform sampler2D specularIntensityMap;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT\n	uniform float clearcoat;\n	uniform float clearcoatRoughness;\n#endif\n#ifdef USE_DISPERSION\n	uniform float dispersion;\n#endif\n#ifdef USE_IRIDESCENCE\n	uniform float iridescence;\n	uniform float iridescenceIOR;\n	uniform float iridescenceThicknessMinimum;\n	uniform float iridescenceThicknessMaximum;\n#endif\n#ifdef USE_SHEEN\n	uniform vec3 sheenColor;\n	uniform float sheenRoughness;\n	#ifdef USE_SHEEN_COLORMAP\n		uniform sampler2D sheenColorMap;\n	#endif\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		uniform sampler2D sheenRoughnessMap;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	uniform vec2 anisotropyVector;\n	#ifdef USE_ANISOTROPYMAP\n		uniform sampler2D anisotropyMap;\n	#endif\n#endif\nvarying vec3 vViewPosition;\n#include <common>\n#include <packing>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <iridescence_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_physical_pars_fragment>\n#include <transmission_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <clearcoat_pars_fragment>\n#include <iridescence_pars_fragment>\n#include <roughnessmap_pars_fragment>\n#include <metalnessmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <roughnessmap_fragment>\n	#include <metalnessmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <clearcoat_normal_fragment_begin>\n	#include <clearcoat_normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_physical_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;\n	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;\n	#include <transmission_fragment>\n	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;\n	#ifdef USE_SHEEN\n		float sheenEnergyComp = 1.0 - 0.157 * max3( material.sheenColor );\n		outgoingLight = outgoingLight * sheenEnergyComp + sheenSpecularDirect + sheenSpecularIndirect;\n	#endif\n	#ifdef USE_CLEARCOAT\n		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );\n		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );\n		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;\n	#endif\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
		meshtoon_vert: "#define TOON\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
		meshtoon_frag: "#define TOON\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <packing>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <gradientmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_toon_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_toon_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",
		points_vert: "uniform float size;\nuniform float scale;\n#include <common>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\n#ifdef USE_POINTS_UV\n	varying vec2 vUv;\n	uniform mat3 uvTransform;\n#endif\nvoid main() {\n	#ifdef USE_POINTS_UV\n		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	#endif\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	gl_PointSize = size;\n	#ifdef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );\n	#endif\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <fog_vertex>\n}",
		points_frag: "uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <color_pars_fragment>\n#include <map_particle_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_particle_fragment>\n	#include <color_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",
		shadow_vert: "#include <common>\n#include <batching_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <shadowmap_pars_vertex>\nvoid main() {\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",
		shadow_frag: "uniform vec3 color;\nuniform float opacity;\n#include <common>\n#include <packing>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <logdepthbuf_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <shadowmask_pars_fragment>\nvoid main() {\n	#include <logdepthbuf_fragment>\n	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n}",
		sprite_vert: "uniform float rotation;\nuniform vec2 center;\n#include <common>\n#include <uv_pars_vertex>\n#include <fog_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	vec4 mvPosition = modelViewMatrix[ 3 ];\n	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );\n	#ifndef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) scale *= - mvPosition.z;\n	#endif\n	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;\n	vec2 rotatedPosition;\n	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;\n	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;\n	mvPosition.xy += rotatedPosition;\n	gl_Position = projectionMatrix * mvPosition;\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}",
		sprite_frag: "uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n}"
	}, fa = {
		common: {
			diffuse: { value: new ts(16777215) },
			opacity: { value: 1 },
			map: { value: null },
			mapTransform: { value: new ei() },
			alphaMap: { value: null },
			alphaMapTransform: { value: new ei() },
			alphaTest: { value: 0 }
		},
		specularmap: {
			specularMap: { value: null },
			specularMapTransform: { value: new ei() }
		},
		envmap: {
			envMap: { value: null },
			envMapRotation: { value: new ei() },
			flipEnvMap: { value: -1 },
			reflectivity: { value: 1 },
			ior: { value: 1.5 },
			refractionRatio: { value: .98 }
		},
		aomap: {
			aoMap: { value: null },
			aoMapIntensity: { value: 1 },
			aoMapTransform: { value: new ei() }
		},
		lightmap: {
			lightMap: { value: null },
			lightMapIntensity: { value: 1 },
			lightMapTransform: { value: new ei() }
		},
		bumpmap: {
			bumpMap: { value: null },
			bumpMapTransform: { value: new ei() },
			bumpScale: { value: 1 }
		},
		normalmap: {
			normalMap: { value: null },
			normalMapTransform: { value: new ei() },
			normalScale: { value: new ti(1, 1) }
		},
		displacementmap: {
			displacementMap: { value: null },
			displacementMapTransform: { value: new ei() },
			displacementScale: { value: 1 },
			displacementBias: { value: 0 }
		},
		emissivemap: {
			emissiveMap: { value: null },
			emissiveMapTransform: { value: new ei() }
		},
		metalnessmap: {
			metalnessMap: { value: null },
			metalnessMapTransform: { value: new ei() }
		},
		roughnessmap: {
			roughnessMap: { value: null },
			roughnessMapTransform: { value: new ei() }
		},
		gradientmap: { gradientMap: { value: null } },
		fog: {
			fogDensity: { value: 25e-5 },
			fogNear: { value: 1 },
			fogFar: { value: 2e3 },
			fogColor: { value: new ts(16777215) }
		},
		lights: {
			ambientLightColor: { value: [] },
			lightProbe: { value: [] },
			directionalLights: {
				value: [],
				properties: {
					direction: {},
					color: {}
				}
			},
			directionalLightShadows: {
				value: [],
				properties: {
					shadowIntensity: 1,
					shadowBias: {},
					shadowNormalBias: {},
					shadowRadius: {},
					shadowMapSize: {}
				}
			},
			directionalShadowMap: { value: [] },
			directionalShadowMatrix: { value: [] },
			spotLights: {
				value: [],
				properties: {
					color: {},
					position: {},
					direction: {},
					distance: {},
					coneCos: {},
					penumbraCos: {},
					decay: {}
				}
			},
			spotLightShadows: {
				value: [],
				properties: {
					shadowIntensity: 1,
					shadowBias: {},
					shadowNormalBias: {},
					shadowRadius: {},
					shadowMapSize: {}
				}
			},
			spotLightMap: { value: [] },
			spotShadowMap: { value: [] },
			spotLightMatrix: { value: [] },
			pointLights: {
				value: [],
				properties: {
					color: {},
					position: {},
					decay: {},
					distance: {}
				}
			},
			pointLightShadows: {
				value: [],
				properties: {
					shadowIntensity: 1,
					shadowBias: {},
					shadowNormalBias: {},
					shadowRadius: {},
					shadowMapSize: {},
					shadowCameraNear: {},
					shadowCameraFar: {}
				}
			},
			pointShadowMap: { value: [] },
			pointShadowMatrix: { value: [] },
			hemisphereLights: {
				value: [],
				properties: {
					direction: {},
					skyColor: {},
					groundColor: {}
				}
			},
			rectAreaLights: {
				value: [],
				properties: {
					color: {},
					position: {},
					width: {},
					height: {}
				}
			},
			ltc_1: { value: null },
			ltc_2: { value: null }
		},
		points: {
			diffuse: { value: new ts(16777215) },
			opacity: { value: 1 },
			size: { value: 1 },
			scale: { value: 1 },
			map: { value: null },
			alphaMap: { value: null },
			alphaMapTransform: { value: new ei() },
			alphaTest: { value: 0 },
			uvTransform: { value: new ei() }
		},
		sprite: {
			diffuse: { value: new ts(16777215) },
			opacity: { value: 1 },
			center: { value: new ti(.5, .5) },
			rotation: { value: 0 },
			map: { value: null },
			mapTransform: { value: new ei() },
			alphaMap: { value: null },
			alphaMapTransform: { value: new ei() },
			alphaTest: { value: 0 }
		}
	}, ga = {
		basic: {
			uniforms: Xs([
				fa.common,
				fa.specularmap,
				fa.envmap,
				fa.aomap,
				fa.lightmap,
				fa.fog
			]),
			vertexShader: ma.meshbasic_vert,
			fragmentShader: ma.meshbasic_frag
		},
		lambert: {
			uniforms: Xs([
				fa.common,
				fa.specularmap,
				fa.envmap,
				fa.aomap,
				fa.lightmap,
				fa.emissivemap,
				fa.bumpmap,
				fa.normalmap,
				fa.displacementmap,
				fa.fog,
				fa.lights,
				{ emissive: { value: new ts(0) } }
			]),
			vertexShader: ma.meshlambert_vert,
			fragmentShader: ma.meshlambert_frag
		},
		phong: {
			uniforms: Xs([
				fa.common,
				fa.specularmap,
				fa.envmap,
				fa.aomap,
				fa.lightmap,
				fa.emissivemap,
				fa.bumpmap,
				fa.normalmap,
				fa.displacementmap,
				fa.fog,
				fa.lights,
				{
					emissive: { value: new ts(0) },
					specular: { value: new ts(1118481) },
					shininess: { value: 30 }
				}
			]),
			vertexShader: ma.meshphong_vert,
			fragmentShader: ma.meshphong_frag
		},
		standard: {
			uniforms: Xs([
				fa.common,
				fa.envmap,
				fa.aomap,
				fa.lightmap,
				fa.emissivemap,
				fa.bumpmap,
				fa.normalmap,
				fa.displacementmap,
				fa.roughnessmap,
				fa.metalnessmap,
				fa.fog,
				fa.lights,
				{
					emissive: { value: new ts(0) },
					roughness: { value: 1 },
					metalness: { value: 0 },
					envMapIntensity: { value: 1 }
				}
			]),
			vertexShader: ma.meshphysical_vert,
			fragmentShader: ma.meshphysical_frag
		},
		toon: {
			uniforms: Xs([
				fa.common,
				fa.aomap,
				fa.lightmap,
				fa.emissivemap,
				fa.bumpmap,
				fa.normalmap,
				fa.displacementmap,
				fa.gradientmap,
				fa.fog,
				fa.lights,
				{ emissive: { value: new ts(0) } }
			]),
			vertexShader: ma.meshtoon_vert,
			fragmentShader: ma.meshtoon_frag
		},
		matcap: {
			uniforms: Xs([
				fa.common,
				fa.bumpmap,
				fa.normalmap,
				fa.displacementmap,
				fa.fog,
				{ matcap: { value: null } }
			]),
			vertexShader: ma.meshmatcap_vert,
			fragmentShader: ma.meshmatcap_frag
		},
		points: {
			uniforms: Xs([fa.points, fa.fog]),
			vertexShader: ma.points_vert,
			fragmentShader: ma.points_frag
		},
		dashed: {
			uniforms: Xs([
				fa.common,
				fa.fog,
				{
					scale: { value: 1 },
					dashSize: { value: 1 },
					totalSize: { value: 2 }
				}
			]),
			vertexShader: ma.linedashed_vert,
			fragmentShader: ma.linedashed_frag
		},
		depth: {
			uniforms: Xs([fa.common, fa.displacementmap]),
			vertexShader: ma.depth_vert,
			fragmentShader: ma.depth_frag
		},
		normal: {
			uniforms: Xs([
				fa.common,
				fa.bumpmap,
				fa.normalmap,
				fa.displacementmap,
				{ opacity: { value: 1 } }
			]),
			vertexShader: ma.meshnormal_vert,
			fragmentShader: ma.meshnormal_frag
		},
		sprite: {
			uniforms: Xs([fa.sprite, fa.fog]),
			vertexShader: ma.sprite_vert,
			fragmentShader: ma.sprite_frag
		},
		background: {
			uniforms: {
				uvTransform: { value: new ei() },
				t2D: { value: null },
				backgroundIntensity: { value: 1 }
			},
			vertexShader: ma.background_vert,
			fragmentShader: ma.background_frag
		},
		backgroundCube: {
			uniforms: {
				envMap: { value: null },
				flipEnvMap: { value: -1 },
				backgroundBlurriness: { value: 0 },
				backgroundIntensity: { value: 1 },
				backgroundRotation: { value: new ei() }
			},
			vertexShader: ma.backgroundCube_vert,
			fragmentShader: ma.backgroundCube_frag
		},
		cube: {
			uniforms: {
				tCube: { value: null },
				tFlip: { value: -1 },
				opacity: { value: 1 }
			},
			vertexShader: ma.cube_vert,
			fragmentShader: ma.cube_frag
		},
		equirect: {
			uniforms: { tEquirect: { value: null } },
			vertexShader: ma.equirect_vert,
			fragmentShader: ma.equirect_frag
		},
		distanceRGBA: {
			uniforms: Xs([
				fa.common,
				fa.displacementmap,
				{
					referencePosition: { value: new Li() },
					nearDistance: { value: 1 },
					farDistance: { value: 1e3 }
				}
			]),
			vertexShader: ma.distanceRGBA_vert,
			fragmentShader: ma.distanceRGBA_frag
		},
		shadow: {
			uniforms: Xs([
				fa.lights,
				fa.fog,
				{
					color: { value: new ts(0) },
					opacity: { value: 1 }
				}
			]),
			vertexShader: ma.shadow_vert,
			fragmentShader: ma.shadow_frag
		}
	};
	ga.physical = {
		uniforms: Xs([ga.standard.uniforms, {
			clearcoat: { value: 0 },
			clearcoatMap: { value: null },
			clearcoatMapTransform: { value: new ei() },
			clearcoatNormalMap: { value: null },
			clearcoatNormalMapTransform: { value: new ei() },
			clearcoatNormalScale: { value: new ti(1, 1) },
			clearcoatRoughness: { value: 0 },
			clearcoatRoughnessMap: { value: null },
			clearcoatRoughnessMapTransform: { value: new ei() },
			dispersion: { value: 0 },
			iridescence: { value: 0 },
			iridescenceMap: { value: null },
			iridescenceMapTransform: { value: new ei() },
			iridescenceIOR: { value: 1.3 },
			iridescenceThicknessMinimum: { value: 100 },
			iridescenceThicknessMaximum: { value: 400 },
			iridescenceThicknessMap: { value: null },
			iridescenceThicknessMapTransform: { value: new ei() },
			sheen: { value: 0 },
			sheenColor: { value: new ts(0) },
			sheenColorMap: { value: null },
			sheenColorMapTransform: { value: new ei() },
			sheenRoughness: { value: 1 },
			sheenRoughnessMap: { value: null },
			sheenRoughnessMapTransform: { value: new ei() },
			transmission: { value: 0 },
			transmissionMap: { value: null },
			transmissionMapTransform: { value: new ei() },
			transmissionSamplerSize: { value: new ti() },
			transmissionSamplerMap: { value: null },
			thickness: { value: 0 },
			thicknessMap: { value: null },
			thicknessMapTransform: { value: new ei() },
			attenuationDistance: { value: 0 },
			attenuationColor: { value: new ts(0) },
			specularColor: { value: new ts(1, 1, 1) },
			specularColorMap: { value: null },
			specularColorMapTransform: { value: new ei() },
			specularIntensity: { value: 1 },
			specularIntensityMap: { value: null },
			specularIntensityMapTransform: { value: new ei() },
			anisotropyVector: { value: new ti() },
			anisotropyMap: { value: null },
			anisotropyMapTransform: { value: new ei() }
		}]),
		vertexShader: ma.meshphysical_vert,
		fragmentShader: ma.meshphysical_frag
	};
	const va = {
		r: 0,
		b: 0,
		g: 0
	}, _a = new _r(), xa = new lr();
	function ya(t, e, n, i, r, s, a) {
		const o = new ts(0);
		let l, c, h = !0 === s ? 0 : 1, p = null, m = 0, f = null;
		function g(t) {
			let i = !0 === t.isScene ? t.background : null;
			if (i && i.isTexture) i = (t.backgroundBlurriness > 0 ? n : e).get(i);
			return i;
		}
		function v(e, n) {
			e.getRGB(va, js(t)), i.buffers.color.setClear(va.r, va.g, va.b, n, a);
		}
		return {
			getClearColor: function() {
				return o;
			},
			setClearColor: function(t, e = 1) {
				o.set(t), h = e, v(o, h);
			},
			getClearAlpha: function() {
				return h;
			},
			setClearAlpha: function(t) {
				h = t, v(o, h);
			},
			render: function(e) {
				let n = !1;
				const r = g(e);
				null === r ? v(o, h) : r && r.isColor && (v(r, 1), n = !0);
				const s = t.xr.getEnvironmentBlendMode();
				"additive" === s ? i.buffers.color.setClear(0, 0, 0, 1, a) : "alpha-blend" === s && i.buffers.color.setClear(0, 0, 0, 0, a), (t.autoClear || n) && (i.buffers.depth.setTest(!0), i.buffers.depth.setMask(!0), i.buffers.color.setMask(!0), t.clear(t.autoClearColor, t.autoClearDepth, t.autoClearStencil));
			},
			addToRenderList: function(e, n) {
				const i = g(n);
				i && (i.isCubeTexture || i.mapping === 306) ? (void 0 === c && (c = new Vs(new Gs(1, 1, 1), new Ys({
					name: "BackgroundCubeMaterial",
					uniforms: Ws(ga.backgroundCube.uniforms),
					vertexShader: ga.backgroundCube.vertexShader,
					fragmentShader: ga.backgroundCube.fragmentShader,
					side: 1,
					depthTest: !1,
					depthWrite: !1,
					fog: !1
				})), c.geometry.deleteAttribute("normal"), c.geometry.deleteAttribute("uv"), c.onBeforeRender = function(t, e, n) {
					this.matrixWorld.copyPosition(n.matrixWorld);
				}, Object.defineProperty(c.material, "envMap", { get: function() {
					return this.uniforms.envMap.value;
				} }), r.update(c)), _a.copy(n.backgroundRotation), _a.x *= -1, _a.y *= -1, _a.z *= -1, i.isCubeTexture && !1 === i.isRenderTargetTexture && (_a.y *= -1, _a.z *= -1), c.material.uniforms.envMap.value = i, c.material.uniforms.flipEnvMap.value = i.isCubeTexture && !1 === i.isRenderTargetTexture ? -1 : 1, c.material.uniforms.backgroundBlurriness.value = n.backgroundBlurriness, c.material.uniforms.backgroundIntensity.value = n.backgroundIntensity, c.material.uniforms.backgroundRotation.value.setFromMatrix4(xa.makeRotationFromEuler(_a)), c.material.toneMapped = mi.getTransfer(i.colorSpace) !== en, p === i && m === i.version && f === t.toneMapping || (c.material.needsUpdate = !0, p = i, m = i.version, f = t.toneMapping), c.layers.enableAll(), e.unshift(c, c.geometry, c.material, 0, 0, null)) : i && i.isTexture && (void 0 === l && (l = new Vs(new pa(2, 2), new Ys({
					name: "BackgroundMaterial",
					uniforms: Ws(ga.background.uniforms),
					vertexShader: ga.background.vertexShader,
					fragmentShader: ga.background.fragmentShader,
					side: 0,
					depthTest: !1,
					depthWrite: !1,
					fog: !1
				})), l.geometry.deleteAttribute("normal"), Object.defineProperty(l.material, "map", { get: function() {
					return this.uniforms.t2D.value;
				} }), r.update(l)), l.material.uniforms.t2D.value = i, l.material.uniforms.backgroundIntensity.value = n.backgroundIntensity, l.material.toneMapped = mi.getTransfer(i.colorSpace) !== "srgb", !0 === i.matrixAutoUpdate && i.updateMatrix(), l.material.uniforms.uvTransform.value.copy(i.matrix), p === i && m === i.version && f === t.toneMapping || (l.material.needsUpdate = !0, p = i, m = i.version, f = t.toneMapping), l.layers.enableAll(), e.unshift(l, l.geometry, l.material, 0, 0, null));
			}
		};
	}
	function Ma(t, e) {
		const n = t.getParameter(t.MAX_VERTEX_ATTRIBS), i = {}, r = c(null);
		let s = r, a = !1;
		function o(e) {
			return t.bindVertexArray(e);
		}
		function l(e) {
			return t.deleteVertexArray(e);
		}
		function c(t) {
			const e = [], i = [], r = [];
			for (let t = 0; t < n; t++) e[t] = 0, i[t] = 0, r[t] = 0;
			return {
				geometry: null,
				program: null,
				wireframe: !1,
				newAttributes: e,
				enabledAttributes: i,
				attributeDivisors: r,
				object: t,
				attributes: {},
				index: null
			};
		}
		function h() {
			const t = s.newAttributes;
			for (let e = 0, n = t.length; e < n; e++) t[e] = 0;
		}
		function u(t) {
			d(t, 0);
		}
		function d(e, n) {
			const i = s.newAttributes, r = s.enabledAttributes, a = s.attributeDivisors;
			i[e] = 1, 0 === r[e] && (t.enableVertexAttribArray(e), r[e] = 1), a[e] !== n && (t.vertexAttribDivisor(e, n), a[e] = n);
		}
		function p() {
			const e = s.newAttributes, n = s.enabledAttributes;
			for (let i = 0, r = n.length; i < r; i++) n[i] !== e[i] && (t.disableVertexAttribArray(i), n[i] = 0);
		}
		function m(e, n, i, r, s, a, o) {
			!0 === o ? t.vertexAttribIPointer(e, n, i, s, a) : t.vertexAttribPointer(e, n, i, r, s, a);
		}
		function f() {
			g(), a = !0, s !== r && (s = r, o(s.object));
		}
		function g() {
			r.geometry = null, r.program = null, r.wireframe = !1;
		}
		return {
			setup: function(n, r, l, f, g) {
				let v = !1;
				const _ = function(e, n, r) {
					const s = !0 === r.wireframe;
					let a = i[e.id];
					void 0 === a && (a = {}, i[e.id] = a);
					let o = a[n.id];
					void 0 === o && (o = {}, a[n.id] = o);
					let l = o[s];
					void 0 === l && (l = c(t.createVertexArray()), o[s] = l);
					return l;
				}(f, l, r);
				s !== _ && (s = _, o(s.object)), v = function(t, e, n, i) {
					const r = s.attributes, a = e.attributes;
					let o = 0;
					const l = n.getAttributes();
					for (const e in l) if (l[e].location >= 0) {
						const n = r[e];
						let i = a[e];
						if (void 0 === i && ("instanceMatrix" === e && t.instanceMatrix && (i = t.instanceMatrix), "instanceColor" === e && t.instanceColor && (i = t.instanceColor)), void 0 === n) return !0;
						if (n.attribute !== i) return !0;
						if (i && n.data !== i.data) return !0;
						o++;
					}
					return s.attributesNum !== o || s.index !== i;
				}(n, f, l, g), v && function(t, e, n, i) {
					const r = {}, a = e.attributes;
					let o = 0;
					const l = n.getAttributes();
					for (const e in l) if (l[e].location >= 0) {
						let n = a[e];
						void 0 === n && ("instanceMatrix" === e && t.instanceMatrix && (n = t.instanceMatrix), "instanceColor" === e && t.instanceColor && (n = t.instanceColor));
						const i = {};
						i.attribute = n, n && n.data && (i.data = n.data), r[e] = i, o++;
					}
					s.attributes = r, s.attributesNum = o, s.index = i;
				}(n, f, l, g), null !== g && e.update(g, t.ELEMENT_ARRAY_BUFFER), (v || a) && (a = !1, function(n, i, r, s) {
					h();
					const a = s.attributes, o = r.getAttributes(), l = i.defaultAttributeValues;
					for (const i in o) {
						const r = o[i];
						if (r.location >= 0) {
							let o = a[i];
							if (void 0 === o && ("instanceMatrix" === i && n.instanceMatrix && (o = n.instanceMatrix), "instanceColor" === i && n.instanceColor && (o = n.instanceColor)), void 0 !== o) {
								const i = o.normalized, a = o.itemSize, l = e.get(o);
								if (void 0 === l) continue;
								const c = l.buffer, h = l.type, p = l.bytesPerElement, f = h === t.INT || h === t.UNSIGNED_INT || o.gpuType === 1013;
								if (o.isInterleavedBufferAttribute) {
									const e = o.data, l = e.stride, g = o.offset;
									if (e.isInstancedInterleavedBuffer) {
										for (let t = 0; t < r.locationSize; t++) d(r.location + t, e.meshPerAttribute);
										!0 !== n.isInstancedMesh && void 0 === s._maxInstanceCount && (s._maxInstanceCount = e.meshPerAttribute * e.count);
									} else for (let t = 0; t < r.locationSize; t++) u(r.location + t);
									t.bindBuffer(t.ARRAY_BUFFER, c);
									for (let t = 0; t < r.locationSize; t++) m(r.location + t, a / r.locationSize, h, i, l * p, (g + a / r.locationSize * t) * p, f);
								} else {
									if (o.isInstancedBufferAttribute) {
										for (let t = 0; t < r.locationSize; t++) d(r.location + t, o.meshPerAttribute);
										!0 !== n.isInstancedMesh && void 0 === s._maxInstanceCount && (s._maxInstanceCount = o.meshPerAttribute * o.count);
									} else for (let t = 0; t < r.locationSize; t++) u(r.location + t);
									t.bindBuffer(t.ARRAY_BUFFER, c);
									for (let t = 0; t < r.locationSize; t++) m(r.location + t, a / r.locationSize, h, i, a * p, a / r.locationSize * t * p, f);
								}
							} else if (void 0 !== l) {
								const e = l[i];
								if (void 0 !== e) switch (e.length) {
									case 2:
										t.vertexAttrib2fv(r.location, e);
										break;
									case 3:
										t.vertexAttrib3fv(r.location, e);
										break;
									case 4:
										t.vertexAttrib4fv(r.location, e);
										break;
									default: t.vertexAttrib1fv(r.location, e);
								}
							}
						}
					}
					p();
				}(n, r, l, f), null !== g && t.bindBuffer(t.ELEMENT_ARRAY_BUFFER, e.get(g).buffer));
			},
			reset: f,
			resetDefaultState: g,
			dispose: function() {
				f();
				for (const t in i) {
					const e = i[t];
					for (const t in e) {
						const n = e[t];
						for (const t in n) l(n[t].object), delete n[t];
						delete e[t];
					}
					delete i[t];
				}
			},
			releaseStatesOfGeometry: function(t) {
				if (void 0 === i[t.id]) return;
				const e = i[t.id];
				for (const t in e) {
					const n = e[t];
					for (const t in n) l(n[t].object), delete n[t];
					delete e[t];
				}
				delete i[t.id];
			},
			releaseStatesOfProgram: function(t) {
				for (const e in i) {
					const n = i[e];
					if (void 0 === n[t.id]) continue;
					const r = n[t.id];
					for (const t in r) l(r[t].object), delete r[t];
					delete n[t.id];
				}
			},
			initAttributes: h,
			enableAttribute: u,
			disableUnusedAttributes: p
		};
	}
	function Sa(t, e, n) {
		let i;
		function r(e, r, s) {
			0 !== s && (t.drawArraysInstanced(i, e, r, s), n.update(r, i, s));
		}
		this.setMode = function(t) {
			i = t;
		}, this.render = function(e, r) {
			t.drawArrays(i, e, r), n.update(r, i, 1);
		}, this.renderInstances = r, this.renderMultiDraw = function(t, r, s) {
			if (0 === s) return;
			e.get("WEBGL_multi_draw").multiDrawArraysWEBGL(i, t, 0, r, 0, s);
			let a = 0;
			for (let t = 0; t < s; t++) a += r[t];
			n.update(a, i, 1);
		}, this.renderMultiDrawInstances = function(t, s, a, o) {
			if (0 === a) return;
			const l = e.get("WEBGL_multi_draw");
			if (null === l) for (let e = 0; e < t.length; e++) r(t[e], s[e], o[e]);
			else {
				l.multiDrawArraysInstancedWEBGL(i, t, 0, s, 0, o, 0, a);
				let e = 0;
				for (let t = 0; t < a; t++) e += s[t];
				for (let t = 0; t < o.length; t++) n.update(e, i, o[t]);
			}
		};
	}
	function ba(t, e, n, i) {
		let r;
		function s(e) {
			if ("highp" === e) {
				if (t.getShaderPrecisionFormat(t.VERTEX_SHADER, t.HIGH_FLOAT).precision > 0 && t.getShaderPrecisionFormat(t.FRAGMENT_SHADER, t.HIGH_FLOAT).precision > 0) return "highp";
				e = "mediump";
			}
			return "mediump" === e && t.getShaderPrecisionFormat(t.VERTEX_SHADER, t.MEDIUM_FLOAT).precision > 0 && t.getShaderPrecisionFormat(t.FRAGMENT_SHADER, t.MEDIUM_FLOAT).precision > 0 ? "mediump" : "lowp";
		}
		let a = void 0 !== n.precision ? n.precision : "highp";
		const o = s(a);
		o !== a && (console.warn("THREE.WebGLRenderer:", a, "not supported, using", o, "instead."), a = o);
		const l = !0 === n.logarithmicDepthBuffer, c = !0 === n.reverseDepthBuffer && e.has("EXT_clip_control");
		if (!0 === c) {
			const t = e.get("EXT_clip_control");
			t.clipControlEXT(t.LOWER_LEFT_EXT, t.ZERO_TO_ONE_EXT);
		}
		const h = t.getParameter(t.MAX_TEXTURE_IMAGE_UNITS), u = t.getParameter(t.MAX_VERTEX_TEXTURE_IMAGE_UNITS);
		return {
			isWebGL2: !0,
			getMaxAnisotropy: function() {
				if (void 0 !== r) return r;
				if (!0 === e.has("EXT_texture_filter_anisotropic")) {
					const n = e.get("EXT_texture_filter_anisotropic");
					r = t.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT);
				} else r = 0;
				return r;
			},
			getMaxPrecision: s,
			textureFormatReadable: function(e) {
				return e === 1023 || i.convert(e) === t.getParameter(t.IMPLEMENTATION_COLOR_READ_FORMAT);
			},
			textureTypeReadable: function(n) {
				const r = n === 1016 && (e.has("EXT_color_buffer_half_float") || e.has("EXT_color_buffer_float"));
				return !(n !== 1009 && i.convert(n) !== t.getParameter(t.IMPLEMENTATION_COLOR_READ_TYPE) && n !== 1015 && !r);
			},
			precision: a,
			logarithmicDepthBuffer: l,
			reverseDepthBuffer: c,
			maxTextures: h,
			maxVertexTextures: u,
			maxTextureSize: t.getParameter(t.MAX_TEXTURE_SIZE),
			maxCubemapSize: t.getParameter(t.MAX_CUBE_MAP_TEXTURE_SIZE),
			maxAttributes: t.getParameter(t.MAX_VERTEX_ATTRIBS),
			maxVertexUniforms: t.getParameter(t.MAX_VERTEX_UNIFORM_VECTORS),
			maxVaryings: t.getParameter(t.MAX_VARYING_VECTORS),
			maxFragmentUniforms: t.getParameter(t.MAX_FRAGMENT_UNIFORM_VECTORS),
			vertexTextures: u > 0,
			maxSamples: t.getParameter(t.MAX_SAMPLES)
		};
	}
	function wa(t) {
		const e = this;
		let n = null, i = 0, r = !1, s = !1;
		const a = new oa(), o = new ei(), l = {
			value: null,
			needsUpdate: !1
		};
		function c(t, n, i, r) {
			const s = null !== t ? t.length : 0;
			let c = null;
			if (0 !== s) {
				if (c = l.value, !0 !== r || null === c) {
					const e = i + 4 * s, r = n.matrixWorldInverse;
					o.getNormalMatrix(r), (null === c || c.length < e) && (c = new Float32Array(e));
					for (let e = 0, n = i; e !== s; ++e, n += 4) a.copy(t[e]).applyMatrix4(r, o), a.normal.toArray(c, n), c[n + 3] = a.constant;
				}
				l.value = c, l.needsUpdate = !0;
			}
			return e.numPlanes = s, e.numIntersection = 0, c;
		}
		this.uniform = l, this.numPlanes = 0, this.numIntersection = 0, this.init = function(t, e) {
			const n = 0 !== t.length || e || 0 !== i || r;
			return r = e, i = t.length, n;
		}, this.beginShadows = function() {
			s = !0, c(null);
		}, this.endShadows = function() {
			s = !1;
		}, this.setGlobalState = function(t, e) {
			n = c(t, e, 0);
		}, this.setState = function(a, o, h) {
			const u = a.clippingPlanes, d = a.clipIntersection, p = a.clipShadows, m = t.get(a);
			if (!r || null === u || 0 === u.length || s && !p) s ? c(null) : function() {
				l.value !== n && (l.value = n, l.needsUpdate = i > 0);
				e.numPlanes = i, e.numIntersection = 0;
			}();
			else {
				const t = s ? 0 : i, e = 4 * t;
				let r = m.clippingState || null;
				l.value = r, r = c(u, o, e, h);
				for (let t = 0; t !== e; ++t) r[t] = n[t];
				m.clippingState = r, this.numIntersection = d ? this.numPlanes : 0, this.numPlanes += t;
			}
		};
	}
	function Ta(t) {
		let e = /* @__PURE__ */ new WeakMap();
		function n(t, e) {
			return e === 303 ? t.mapping = 301 : e === 304 && (t.mapping = 302), t;
		}
		function i(t) {
			const n = t.target;
			n.removeEventListener("dispose", i);
			const r = e.get(n);
			void 0 !== r && (e.delete(n), r.dispose());
		}
		return {
			get: function(r) {
				if (r && r.isTexture) {
					const s = r.mapping;
					if (s === 303 || s === 304) {
						if (e.has(r)) return n(e.get(r).texture, r.mapping);
						{
							const s = r.image;
							if (s && s.height > 0) {
								const a = new ia(s.height);
								return a.fromEquirectangularTexture(t, r), e.set(r, a), r.addEventListener("dispose", i), n(a.texture, r.mapping);
							}
							return null;
						}
					}
				}
				return r;
			},
			dispose: function() {
				e = /* @__PURE__ */ new WeakMap();
			}
		};
	}
	var Ea = class extends Zs {
		constructor(t = -1, e = 1, n = 1, i = -1, r = .1, s = 2e3) {
			super(), this.isOrthographicCamera = !0, this.type = "OrthographicCamera", this.zoom = 1, this.view = null, this.left = t, this.right = e, this.top = n, this.bottom = i, this.near = r, this.far = s, this.updateProjectionMatrix();
		}
		copy(t, e) {
			return super.copy(t, e), this.left = t.left, this.right = t.right, this.top = t.top, this.bottom = t.bottom, this.near = t.near, this.far = t.far, this.zoom = t.zoom, this.view = null === t.view ? null : Object.assign({}, t.view), this;
		}
		setViewOffset(t, e, n, i, r, s) {
			null === this.view && (this.view = {
				enabled: !0,
				fullWidth: 1,
				fullHeight: 1,
				offsetX: 0,
				offsetY: 0,
				width: 1,
				height: 1
			}), this.view.enabled = !0, this.view.fullWidth = t, this.view.fullHeight = e, this.view.offsetX = n, this.view.offsetY = i, this.view.width = r, this.view.height = s, this.updateProjectionMatrix();
		}
		clearViewOffset() {
			null !== this.view && (this.view.enabled = !1), this.updateProjectionMatrix();
		}
		updateProjectionMatrix() {
			const t = (this.right - this.left) / (2 * this.zoom), e = (this.top - this.bottom) / (2 * this.zoom), n = (this.right + this.left) / 2, i = (this.top + this.bottom) / 2;
			let r = n - t, s = n + t, a = i + e, o = i - e;
			if (null !== this.view && this.view.enabled) {
				const t = (this.right - this.left) / this.view.fullWidth / this.zoom, e = (this.top - this.bottom) / this.view.fullHeight / this.zoom;
				r += t * this.view.offsetX, s = r + t * this.view.width, a -= e * this.view.offsetY, o = a - e * this.view.height;
			}
			this.projectionMatrix.makeOrthographic(r, s, a, o, this.near, this.far, this.coordinateSystem), this.projectionMatrixInverse.copy(this.projectionMatrix).invert();
		}
		toJSON(t) {
			const e = super.toJSON(t);
			return e.object.zoom = this.zoom, e.object.left = this.left, e.object.right = this.right, e.object.top = this.top, e.object.bottom = this.bottom, e.object.near = this.near, e.object.far = this.far, null !== this.view && (e.object.view = Object.assign({}, this.view)), e;
		}
	};
	const Aa = [
		.125,
		.215,
		.35,
		.446,
		.526,
		.582
	], Ra = 20, Ca = new Ea(), Pa = new ts();
	let Ia = null, La = 0, Ua = 0, Na = !1;
	const Da = (1 + Math.sqrt(5)) / 2, Oa = 1 / Da, Fa = [
		new Li(-Da, Oa, 0),
		new Li(Da, Oa, 0),
		new Li(-Oa, 0, Da),
		new Li(Oa, 0, Da),
		new Li(0, Da, -Oa),
		new Li(0, Da, Oa),
		new Li(-1, 1, -1),
		new Li(1, 1, -1),
		new Li(-1, 1, 1),
		new Li(1, 1, 1)
	];
	var Ba = class {
		constructor(t) {
			this._renderer = t, this._pingPongRenderTarget = null, this._lodMax = 0, this._cubeSize = 0, this._lodPlanes = [], this._sizeLods = [], this._sigmas = [], this._blurMaterial = null, this._cubemapMaterial = null, this._equirectMaterial = null, this._compileMaterial(this._blurMaterial);
		}
		fromScene(t, e = 0, n = .1, i = 100) {
			Ia = this._renderer.getRenderTarget(), La = this._renderer.getActiveCubeFace(), Ua = this._renderer.getActiveMipmapLevel(), Na = this._renderer.xr.enabled, this._renderer.xr.enabled = !1, this._setSize(256);
			const r = this._allocateTargets();
			return r.depthBuffer = !0, this._sceneToCubeUV(t, n, i, r), e > 0 && this._blur(r, 0, 0, e), this._applyPMREM(r), this._cleanup(r), r;
		}
		fromEquirectangular(t, e = null) {
			return this._fromTexture(t, e);
		}
		fromCubemap(t, e = null) {
			return this._fromTexture(t, e);
		}
		compileCubemapShader() {
			null === this._cubemapMaterial && (this._cubemapMaterial = Ha(), this._compileMaterial(this._cubemapMaterial));
		}
		compileEquirectangularShader() {
			null === this._equirectMaterial && (this._equirectMaterial = Va(), this._compileMaterial(this._equirectMaterial));
		}
		dispose() {
			this._dispose(), null !== this._cubemapMaterial && this._cubemapMaterial.dispose(), null !== this._equirectMaterial && this._equirectMaterial.dispose();
		}
		_setSize(t) {
			this._lodMax = Math.floor(Math.log2(t)), this._cubeSize = Math.pow(2, this._lodMax);
		}
		_dispose() {
			null !== this._blurMaterial && this._blurMaterial.dispose(), null !== this._pingPongRenderTarget && this._pingPongRenderTarget.dispose();
			for (let t = 0; t < this._lodPlanes.length; t++) this._lodPlanes[t].dispose();
		}
		_cleanup(t) {
			this._renderer.setRenderTarget(Ia, La, Ua), this._renderer.xr.enabled = Na, t.scissorTest = !1, ka(t, 0, 0, t.width, t.height);
		}
		_fromTexture(t, e) {
			t.mapping === 301 || t.mapping === 302 ? this._setSize(0 === t.image.length ? 16 : t.image[0].width || t.image[0].image.width) : this._setSize(t.image.width / 4), Ia = this._renderer.getRenderTarget(), La = this._renderer.getActiveCubeFace(), Ua = this._renderer.getActiveMipmapLevel(), Na = this._renderer.xr.enabled, this._renderer.xr.enabled = !1;
			const n = e || this._allocateTargets();
			return this._textureToCubeUV(t, n), this._applyPMREM(n), this._cleanup(n), n;
		}
		_allocateTargets() {
			const t = 3 * Math.max(this._cubeSize, 112), e = 4 * this._cubeSize, n = {
				magFilter: Mt,
				minFilter: Mt,
				generateMipmaps: !1,
				type: Ut,
				format: kt,
				colorSpace: Ke,
				depthBuffer: !1
			}, i = za(t, e, n);
			if (null === this._pingPongRenderTarget || this._pingPongRenderTarget.width !== t || this._pingPongRenderTarget.height !== e) {
				null !== this._pingPongRenderTarget && this._dispose(), this._pingPongRenderTarget = za(t, e, n);
				const { _lodMax: i } = this;
				({sizeLods: this._sizeLods, lodPlanes: this._lodPlanes, sigmas: this._sigmas} = function(t) {
					const e = [], n = [], i = [];
					let r = t;
					const s = t - 4 + 1 + Aa.length;
					for (let a = 0; a < s; a++) {
						const s = Math.pow(2, r);
						n.push(s);
						let o = 1 / s;
						a > t - 4 ? o = Aa[a - t + 4 - 1] : 0 === a && (o = 0), i.push(o);
						const l = 1 / (s - 2), c = -l, h = 1 + l, u = [
							c,
							c,
							h,
							c,
							h,
							h,
							c,
							c,
							h,
							h,
							c,
							h
						], d = 6, p = 6, m = 3, f = 2, g = 1, v = new Float32Array(m * p * d), _ = new Float32Array(f * p * d), x = new Float32Array(g * p * d);
						for (let t = 0; t < d; t++) {
							const e = t % 3 * 2 / 3 - 1, n = t > 2 ? 0 : -1, i = [
								e,
								n,
								0,
								e + 2 / 3,
								n,
								0,
								e + 2 / 3,
								n + 1,
								0,
								e,
								n,
								0,
								e + 2 / 3,
								n + 1,
								0,
								e,
								n + 1,
								0
							];
							v.set(i, m * p * t), _.set(u, f * p * t);
							const r = [
								t,
								t,
								t,
								t,
								t,
								t
							];
							x.set(r, g * p * t);
						}
						const y = new Cs();
						y.setAttribute("position", new ds(v, m)), y.setAttribute("uv", new ds(_, f)), y.setAttribute("faceIndex", new ds(x, g)), e.push(y), r > 4 && r--;
					}
					return {
						lodPlanes: e,
						sizeLods: n,
						sigmas: i
					};
				}(i)), this._blurMaterial = function(t, e, n) {
					const i = new Float32Array(Ra), r = new Li(0, 1, 0);
					return new Ys({
						name: "SphericalGaussianBlur",
						defines: {
							n: Ra,
							CUBEUV_TEXEL_WIDTH: 1 / e,
							CUBEUV_TEXEL_HEIGHT: 1 / n,
							CUBEUV_MAX_MIP: `${t}.0`
						},
						uniforms: {
							envMap: { value: null },
							samples: { value: 1 },
							weights: { value: i },
							latitudinal: { value: !1 },
							dTheta: { value: 0 },
							mipInt: { value: 0 },
							poleAxis: { value: r }
						},
						vertexShader: Ga(),
						fragmentShader: "\n\n			precision mediump float;\n			precision mediump int;\n\n			varying vec3 vOutputDirection;\n\n			uniform sampler2D envMap;\n			uniform int samples;\n			uniform float weights[ n ];\n			uniform bool latitudinal;\n			uniform float dTheta;\n			uniform float mipInt;\n			uniform vec3 poleAxis;\n\n			#define ENVMAP_TYPE_CUBE_UV\n			#include <cube_uv_reflection_fragment>\n\n			vec3 getSample( float theta, vec3 axis ) {\n\n				float cosTheta = cos( theta );\n				// Rodrigues' axis-angle rotation\n				vec3 sampleDirection = vOutputDirection * cosTheta\n					+ cross( axis, vOutputDirection ) * sin( theta )\n					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );\n\n				return bilinearCubeUV( envMap, sampleDirection, mipInt );\n\n			}\n\n			void main() {\n\n				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );\n\n				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {\n\n					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );\n\n				}\n\n				axis = normalize( axis );\n\n				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );\n				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );\n\n				for ( int i = 1; i < n; i++ ) {\n\n					if ( i >= samples ) {\n\n						break;\n\n					}\n\n					float theta = dTheta * float( i );\n					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );\n					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );\n\n				}\n\n			}\n		",
						blending: 0,
						depthTest: !1,
						depthWrite: !1
					});
				}(i, t, e);
			}
			return i;
		}
		_compileMaterial(t) {
			const e = new Vs(this._lodPlanes[0], t);
			this._renderer.compile(e, Ca);
		}
		_sceneToCubeUV(t, e, n, i) {
			const r = new Qs(90, 1, e, n), s = [
				1,
				-1,
				1,
				1,
				1,
				1
			], a = [
				1,
				1,
				1,
				-1,
				-1,
				-1
			], o = this._renderer, l = o.autoClear, c = o.toneMapping;
			o.getClearColor(Pa), o.toneMapping = 0, o.autoClear = !1;
			const h = new rs({
				name: "PMREM.Background",
				side: 1,
				depthWrite: !1,
				depthTest: !1
			}), u = new Vs(new Gs(), h);
			let p = !1;
			const m = t.background;
			m ? m.isColor && (h.color.copy(m), t.background = null, p = !0) : (h.color.copy(Pa), p = !0);
			for (let e = 0; e < 6; e++) {
				const n = e % 3;
				0 === n ? (r.up.set(0, s[e], 0), r.lookAt(a[e], 0, 0)) : 1 === n ? (r.up.set(0, 0, s[e]), r.lookAt(0, a[e], 0)) : (r.up.set(0, s[e], 0), r.lookAt(0, 0, a[e]));
				const l = this._cubeSize;
				ka(i, n * l, e > 2 ? l : 0, l, l), o.setRenderTarget(i), p && o.render(u, r), o.render(t, r);
			}
			u.geometry.dispose(), u.material.dispose(), o.toneMapping = c, o.autoClear = l, t.background = m;
		}
		_textureToCubeUV(t, e) {
			const n = this._renderer, i = t.mapping === 301 || t.mapping === 302;
			i ? (null === this._cubemapMaterial && (this._cubemapMaterial = Ha()), this._cubemapMaterial.uniforms.flipEnvMap.value = !1 === t.isRenderTargetTexture ? -1 : 1) : null === this._equirectMaterial && (this._equirectMaterial = Va());
			const r = i ? this._cubemapMaterial : this._equirectMaterial, s = new Vs(this._lodPlanes[0], r);
			r.uniforms.envMap.value = t;
			const a = this._cubeSize;
			ka(e, 0, 0, 3 * a, 2 * a), n.setRenderTarget(e), n.render(s, Ca);
		}
		_applyPMREM(t) {
			const e = this._renderer, n = e.autoClear;
			e.autoClear = !1;
			const i = this._lodPlanes.length;
			for (let e = 1; e < i; e++) {
				const n = Math.sqrt(this._sigmas[e] * this._sigmas[e] - this._sigmas[e - 1] * this._sigmas[e - 1]), r = Fa[(i - e - 1) % Fa.length];
				this._blur(t, e - 1, e, n, r);
			}
			e.autoClear = n;
		}
		_blur(t, e, n, i, r) {
			const s = this._pingPongRenderTarget;
			this._halfBlur(t, s, e, n, i, "latitudinal", r), this._halfBlur(s, t, n, n, i, "longitudinal", r);
		}
		_halfBlur(t, e, n, i, r, s, a) {
			const o = this._renderer, l = this._blurMaterial;
			"latitudinal" !== s && "longitudinal" !== s && console.error("blur direction must be either latitudinal or longitudinal!");
			const c = new Vs(this._lodPlanes[i], l), h = l.uniforms, u = this._sizeLods[n] - 1, d = isFinite(r) ? Math.PI / (2 * u) : 2 * Math.PI / 39, p = r / d, m = isFinite(r) ? 1 + Math.floor(3 * p) : Ra;
			m > Ra && console.warn(`sigmaRadians, ${r}, is too large and will clip, as it requested ${m} samples when the maximum is set to 20`);
			const f = [];
			let g = 0;
			for (let t = 0; t < Ra; ++t) {
				const e = t / p, n = Math.exp(-e * e / 2);
				f.push(n), 0 === t ? g += n : t < m && (g += 2 * n);
			}
			for (let t = 0; t < f.length; t++) f[t] = f[t] / g;
			h.envMap.value = t.texture, h.samples.value = m, h.weights.value = f, h.latitudinal.value = "latitudinal" === s, a && (h.poleAxis.value = a);
			const { _lodMax: v } = this;
			h.dTheta.value = d, h.mipInt.value = v - n;
			const _ = this._sizeLods[i];
			ka(e, 3 * _ * (i > v - 4 ? i - v + 4 : 0), 4 * (this._cubeSize - _), 3 * _, 2 * _), o.setRenderTarget(e), o.render(c, Ca);
		}
	};
	function za(t, e, n) {
		const i = new Ei(t, e, n);
		return i.texture.mapping = 306, i.texture.name = "PMREM.cubeUv", i.scissorTest = !0, i;
	}
	function ka(t, e, n, i, r) {
		t.viewport.set(e, n, i, r), t.scissor.set(e, n, i, r);
	}
	function Va() {
		return new Ys({
			name: "EquirectangularToCubeUV",
			uniforms: { envMap: { value: null } },
			vertexShader: Ga(),
			fragmentShader: "\n\n			precision mediump float;\n			precision mediump int;\n\n			varying vec3 vOutputDirection;\n\n			uniform sampler2D envMap;\n\n			#include <common>\n\n			void main() {\n\n				vec3 outputDirection = normalize( vOutputDirection );\n				vec2 uv = equirectUv( outputDirection );\n\n				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );\n\n			}\n		",
			blending: 0,
			depthTest: !1,
			depthWrite: !1
		});
	}
	function Ha() {
		return new Ys({
			name: "CubemapToCubeUV",
			uniforms: {
				envMap: { value: null },
				flipEnvMap: { value: -1 }
			},
			vertexShader: Ga(),
			fragmentShader: "\n\n			precision mediump float;\n			precision mediump int;\n\n			uniform float flipEnvMap;\n\n			varying vec3 vOutputDirection;\n\n			uniform samplerCube envMap;\n\n			void main() {\n\n				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );\n\n			}\n		",
			blending: 0,
			depthTest: !1,
			depthWrite: !1
		});
	}
	function Ga() {
		return "\n\n		precision mediump float;\n		precision mediump int;\n\n		attribute float faceIndex;\n\n		varying vec3 vOutputDirection;\n\n		// RH coordinate system; PMREM face-indexing convention\n		vec3 getDirection( vec2 uv, float face ) {\n\n			uv = 2.0 * uv - 1.0;\n\n			vec3 direction = vec3( uv, 1.0 );\n\n			if ( face == 0.0 ) {\n\n				direction = direction.zyx; // ( 1, v, u ) pos x\n\n			} else if ( face == 1.0 ) {\n\n				direction = direction.xzy;\n				direction.xz *= -1.0; // ( -u, 1, -v ) pos y\n\n			} else if ( face == 2.0 ) {\n\n				direction.x *= -1.0; // ( -u, v, 1 ) pos z\n\n			} else if ( face == 3.0 ) {\n\n				direction = direction.zyx;\n				direction.xz *= -1.0; // ( -1, v, -u ) neg x\n\n			} else if ( face == 4.0 ) {\n\n				direction = direction.xzy;\n				direction.xy *= -1.0; // ( -u, -1, v ) neg y\n\n			} else if ( face == 5.0 ) {\n\n				direction.z *= -1.0; // ( u, v, -1 ) neg z\n\n			}\n\n			return direction;\n\n		}\n\n		void main() {\n\n			vOutputDirection = getDirection( uv, faceIndex );\n			gl_Position = vec4( position, 1.0 );\n\n		}\n	";
	}
	function Wa(t) {
		let e = /* @__PURE__ */ new WeakMap(), n = null;
		function i(t) {
			const n = t.target;
			n.removeEventListener("dispose", i);
			const r = e.get(n);
			void 0 !== r && (e.delete(n), r.dispose());
		}
		return {
			get: function(r) {
				if (r && r.isTexture) {
					const s = r.mapping, a = s === 303 || s === 304, o = s === 301 || s === 302;
					if (a || o) {
						let s = e.get(r);
						const l = void 0 !== s ? s.texture.pmremVersion : 0;
						if (r.isRenderTargetTexture && r.pmremVersion !== l) return null === n && (n = new Ba(t)), s = a ? n.fromEquirectangular(r, s) : n.fromCubemap(r, s), s.texture.pmremVersion = r.pmremVersion, e.set(r, s), s.texture;
						if (void 0 !== s) return s.texture;
						{
							const l = r.image;
							return a && l && l.height > 0 || o && l && function(t) {
								let e = 0;
								const n = 6;
								for (let i = 0; i < n; i++) void 0 !== t[i] && e++;
								return e === n;
							}(l) ? (null === n && (n = new Ba(t)), s = a ? n.fromEquirectangular(r) : n.fromCubemap(r), s.texture.pmremVersion = r.pmremVersion, e.set(r, s), r.addEventListener("dispose", i), s.texture) : null;
						}
					}
				}
				return r;
			},
			dispose: function() {
				e = /* @__PURE__ */ new WeakMap(), null !== n && (n.dispose(), n = null);
			}
		};
	}
	function Xa(t) {
		const e = {};
		function n(n) {
			if (void 0 !== e[n]) return e[n];
			let i;
			switch (n) {
				case "WEBGL_depth_texture":
					i = t.getExtension("WEBGL_depth_texture") || t.getExtension("MOZ_WEBGL_depth_texture") || t.getExtension("WEBKIT_WEBGL_depth_texture");
					break;
				case "EXT_texture_filter_anisotropic":
					i = t.getExtension("EXT_texture_filter_anisotropic") || t.getExtension("MOZ_EXT_texture_filter_anisotropic") || t.getExtension("WEBKIT_EXT_texture_filter_anisotropic");
					break;
				case "WEBGL_compressed_texture_s3tc":
					i = t.getExtension("WEBGL_compressed_texture_s3tc") || t.getExtension("MOZ_WEBGL_compressed_texture_s3tc") || t.getExtension("WEBKIT_WEBGL_compressed_texture_s3tc");
					break;
				case "WEBGL_compressed_texture_pvrtc":
					i = t.getExtension("WEBGL_compressed_texture_pvrtc") || t.getExtension("WEBKIT_WEBGL_compressed_texture_pvrtc");
					break;
				default: i = t.getExtension(n);
			}
			return e[n] = i, i;
		}
		return {
			has: function(t) {
				return null !== n(t);
			},
			init: function() {
				n("EXT_color_buffer_float"), n("WEBGL_clip_cull_distance"), n("OES_texture_float_linear"), n("EXT_color_buffer_half_float"), n("WEBGL_multisampled_render_to_texture"), n("WEBGL_render_shared_exponent");
			},
			get: function(t) {
				const e = n(t);
				return null === e && ci("THREE.WebGLRenderer: " + t + " extension not supported."), e;
			}
		};
	}
	function ja(t, e, n, i) {
		const r = {}, s = /* @__PURE__ */ new WeakMap();
		function a(t) {
			const o = t.target;
			null !== o.index && e.remove(o.index);
			for (const t in o.attributes) e.remove(o.attributes[t]);
			for (const t in o.morphAttributes) {
				const n = o.morphAttributes[t];
				for (let t = 0, i = n.length; t < i; t++) e.remove(n[t]);
			}
			o.removeEventListener("dispose", a), delete r[o.id];
			const l = s.get(o);
			l && (e.remove(l), s.delete(o)), i.releaseStatesOfGeometry(o), !0 === o.isInstancedBufferGeometry && delete o._maxInstanceCount, n.memory.geometries--;
		}
		function o(t) {
			const n = [], i = t.index, r = t.attributes.position;
			let a = 0;
			if (null !== i) {
				const t = i.array;
				a = i.version;
				for (let e = 0, i = t.length; e < i; e += 3) {
					const i = t[e + 0], r = t[e + 1], s = t[e + 2];
					n.push(i, r, r, s, s, i);
				}
			} else {
				if (void 0 === r) return;
				{
					const t = r.array;
					a = r.version;
					for (let e = 0, i = t.length / 3 - 1; e < i; e += 3) {
						const t = e + 0, i = e + 1, r = e + 2;
						n.push(t, i, i, r, r, t);
					}
				}
			}
			const o = new (ii(n) ? xs : vs)(n, 1);
			o.version = a;
			const l = s.get(t);
			l && e.remove(l), s.set(t, o);
		}
		return {
			get: function(t, e) {
				return !0 === r[e.id] || (e.addEventListener("dispose", a), r[e.id] = !0, n.memory.geometries++), e;
			},
			update: function(n) {
				const i = n.attributes;
				for (const n in i) e.update(i[n], t.ARRAY_BUFFER);
				const r = n.morphAttributes;
				for (const n in r) {
					const i = r[n];
					for (let n = 0, r = i.length; n < r; n++) e.update(i[n], t.ARRAY_BUFFER);
				}
			},
			getWireframeAttribute: function(t) {
				const e = s.get(t);
				if (e) {
					const n = t.index;
					null !== n && e.version < n.version && o(t);
				} else o(t);
				return s.get(t);
			}
		};
	}
	function qa(t, e, n) {
		let i, r, s;
		function a(e, a, o) {
			0 !== o && (t.drawElementsInstanced(i, a, r, e * s, o), n.update(a, i, o));
		}
		this.setMode = function(t) {
			i = t;
		}, this.setIndex = function(t) {
			r = t.type, s = t.bytesPerElement;
		}, this.render = function(e, a) {
			t.drawElements(i, a, r, e * s), n.update(a, i, 1);
		}, this.renderInstances = a, this.renderMultiDraw = function(t, s, a) {
			if (0 === a) return;
			e.get("WEBGL_multi_draw").multiDrawElementsWEBGL(i, s, 0, r, t, 0, a);
			let o = 0;
			for (let t = 0; t < a; t++) o += s[t];
			n.update(o, i, 1);
		}, this.renderMultiDrawInstances = function(t, o, l, c) {
			if (0 === l) return;
			const h = e.get("WEBGL_multi_draw");
			if (null === h) for (let e = 0; e < t.length; e++) a(t[e] / s, o[e], c[e]);
			else {
				h.multiDrawElementsInstancedWEBGL(i, o, 0, r, t, 0, c, 0, l);
				let e = 0;
				for (let t = 0; t < l; t++) e += o[t];
				for (let t = 0; t < c.length; t++) n.update(e, i, c[t]);
			}
		};
	}
	function Ya(t) {
		const e = {
			frame: 0,
			calls: 0,
			triangles: 0,
			points: 0,
			lines: 0
		};
		return {
			memory: {
				geometries: 0,
				textures: 0
			},
			render: e,
			programs: null,
			autoReset: !0,
			reset: function() {
				e.calls = 0, e.triangles = 0, e.points = 0, e.lines = 0;
			},
			update: function(n, i, r) {
				switch (e.calls++, i) {
					case t.TRIANGLES:
						e.triangles += r * (n / 3);
						break;
					case t.LINES:
						e.lines += r * (n / 2);
						break;
					case t.LINE_STRIP:
						e.lines += r * (n - 1);
						break;
					case t.LINE_LOOP:
						e.lines += r * n;
						break;
					case t.POINTS:
						e.points += r * n;
						break;
					default: console.error("THREE.WebGLInfo: Unknown draw mode:", i);
				}
			}
		};
	}
	function Za(t, e, n) {
		const i = /* @__PURE__ */ new WeakMap(), r = new wi();
		return { update: function(s, a, o) {
			const l = s.morphTargetInfluences, c = a.morphAttributes.position || a.morphAttributes.normal || a.morphAttributes.color, h = void 0 !== c ? c.length : 0;
			let u = i.get(a);
			if (void 0 === u || u.count !== h) {
				void 0 !== u && u.texture.dispose();
				const d = void 0 !== a.morphAttributes.position, p = void 0 !== a.morphAttributes.normal, m = void 0 !== a.morphAttributes.color, f = a.morphAttributes.position || [], g = a.morphAttributes.normal || [], v = a.morphAttributes.color || [];
				let _ = 0;
				!0 === d && (_ = 1), !0 === p && (_ = 2), !0 === m && (_ = 3);
				let x = a.attributes.position.count * _, y = 1;
				x > e.maxTextureSize && (y = Math.ceil(x / e.maxTextureSize), x = e.maxTextureSize);
				const M = new Float32Array(x * y * 4 * h), S = new Ai(M, x, y, h);
				S.type = Lt, S.needsUpdate = !0;
				const b = 4 * _;
				for (let T = 0; T < h; T++) {
					const E = f[T], A = g[T], R = v[T], C = x * y * 4 * T;
					for (let P = 0; P < E.count; P++) {
						const I = P * b;
						!0 === d && (r.fromBufferAttribute(E, P), M[C + I + 0] = r.x, M[C + I + 1] = r.y, M[C + I + 2] = r.z, M[C + I + 3] = 0), !0 === p && (r.fromBufferAttribute(A, P), M[C + I + 4] = r.x, M[C + I + 5] = r.y, M[C + I + 6] = r.z, M[C + I + 7] = 0), !0 === m && (r.fromBufferAttribute(R, P), M[C + I + 8] = r.x, M[C + I + 9] = r.y, M[C + I + 10] = r.z, M[C + I + 11] = 4 === R.itemSize ? r.w : 1);
					}
				}
				function w() {
					S.dispose(), i.delete(a), a.removeEventListener("dispose", w);
				}
				u = {
					count: h,
					texture: S,
					size: new ti(x, y)
				}, i.set(a, u), a.addEventListener("dispose", w);
			}
			if (!0 === s.isInstancedMesh && null !== s.morphTexture) o.getUniforms().setValue(t, "morphTexture", s.morphTexture, n);
			else {
				let L = 0;
				for (let N = 0; N < l.length; N++) L += l[N];
				const U = a.morphTargetsRelative ? 1 : 1 - L;
				o.getUniforms().setValue(t, "morphTargetBaseInfluence", U), o.getUniforms().setValue(t, "morphTargetInfluences", l);
			}
			o.getUniforms().setValue(t, "morphTargetsTexture", u.texture, n), o.getUniforms().setValue(t, "morphTargetsTextureSize", u.size);
		} };
	}
	function Ja(t, e, n, i) {
		let r = /* @__PURE__ */ new WeakMap();
		function s(t) {
			const e = t.target;
			e.removeEventListener("dispose", s), n.remove(e.instanceMatrix), null !== e.instanceColor && n.remove(e.instanceColor);
		}
		return {
			update: function(a) {
				const o = i.render.frame, l = a.geometry, c = e.get(a, l);
				if (r.get(c) !== o && (e.update(c), r.set(c, o)), a.isInstancedMesh && (!1 === a.hasEventListener("dispose", s) && a.addEventListener("dispose", s), r.get(a) !== o && (n.update(a.instanceMatrix, t.ARRAY_BUFFER), null !== a.instanceColor && n.update(a.instanceColor, t.ARRAY_BUFFER), r.set(a, o))), a.isSkinnedMesh) {
					const t = a.skeleton;
					r.get(t) !== o && (t.update(), r.set(t, o));
				}
				return c;
			},
			dispose: function() {
				r = /* @__PURE__ */ new WeakMap();
			}
		};
	}
	var Ka = class extends bi {
		constructor(t, e, n, i, r, s, a, o, l, c = 1026) {
			if (c !== 1026 && c !== 1027) throw new Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");
			void 0 === n && c === 1026 && (n = 1014), void 0 === n && c === 1027 && (n = 1020), super(null, i, r, s, a, o, c, n, l), this.isDepthTexture = !0, this.image = {
				width: t,
				height: e
			}, this.magFilter = void 0 !== a ? a : gt, this.minFilter = void 0 !== o ? o : gt, this.flipY = !1, this.generateMipmaps = !1, this.compareFunction = null;
		}
		copy(t) {
			return super.copy(t), this.compareFunction = t.compareFunction, this;
		}
		toJSON(t) {
			const e = super.toJSON(t);
			return null !== this.compareFunction && (e.compareFunction = this.compareFunction), e;
		}
	};
	const $a = new bi(), Qa = new Ka(1, 1), to = new Ai(), eo = new Ci(), no = new na(), io = [], ro = [], so = new Float32Array(16), ao = new Float32Array(9), oo = new Float32Array(4);
	function lo(t, e, n) {
		const i = t[0];
		if (i <= 0 || i > 0) return t;
		const r = e * n;
		let s = io[r];
		if (void 0 === s && (s = new Float32Array(r), io[r] = s), 0 !== e) {
			i.toArray(s, 0);
			for (let i = 1, r = 0; i !== e; ++i) r += n, t[i].toArray(s, r);
		}
		return s;
	}
	function co(t, e) {
		if (t.length !== e.length) return !1;
		for (let n = 0, i = t.length; n < i; n++) if (t[n] !== e[n]) return !1;
		return !0;
	}
	function ho(t, e) {
		for (let n = 0, i = e.length; n < i; n++) t[n] = e[n];
	}
	function uo(t, e) {
		let n = ro[e];
		void 0 === n && (n = new Int32Array(e), ro[e] = n);
		for (let i = 0; i !== e; ++i) n[i] = t.allocateTextureUnit();
		return n;
	}
	function po(t, e) {
		const n = this.cache;
		n[0] !== e && (t.uniform1f(this.addr, e), n[0] = e);
	}
	function mo(t, e) {
		const n = this.cache;
		if (void 0 !== e.x) n[0] === e.x && n[1] === e.y || (t.uniform2f(this.addr, e.x, e.y), n[0] = e.x, n[1] = e.y);
		else {
			if (co(n, e)) return;
			t.uniform2fv(this.addr, e), ho(n, e);
		}
	}
	function fo(t, e) {
		const n = this.cache;
		if (void 0 !== e.x) n[0] === e.x && n[1] === e.y && n[2] === e.z || (t.uniform3f(this.addr, e.x, e.y, e.z), n[0] = e.x, n[1] = e.y, n[2] = e.z);
		else if (void 0 !== e.r) n[0] === e.r && n[1] === e.g && n[2] === e.b || (t.uniform3f(this.addr, e.r, e.g, e.b), n[0] = e.r, n[1] = e.g, n[2] = e.b);
		else {
			if (co(n, e)) return;
			t.uniform3fv(this.addr, e), ho(n, e);
		}
	}
	function go(t, e) {
		const n = this.cache;
		if (void 0 !== e.x) n[0] === e.x && n[1] === e.y && n[2] === e.z && n[3] === e.w || (t.uniform4f(this.addr, e.x, e.y, e.z, e.w), n[0] = e.x, n[1] = e.y, n[2] = e.z, n[3] = e.w);
		else {
			if (co(n, e)) return;
			t.uniform4fv(this.addr, e), ho(n, e);
		}
	}
	function vo(t, e) {
		const n = this.cache, i = e.elements;
		if (void 0 === i) {
			if (co(n, e)) return;
			t.uniformMatrix2fv(this.addr, !1, e), ho(n, e);
		} else {
			if (co(n, i)) return;
			oo.set(i), t.uniformMatrix2fv(this.addr, !1, oo), ho(n, i);
		}
	}
	function _o(t, e) {
		const n = this.cache, i = e.elements;
		if (void 0 === i) {
			if (co(n, e)) return;
			t.uniformMatrix3fv(this.addr, !1, e), ho(n, e);
		} else {
			if (co(n, i)) return;
			ao.set(i), t.uniformMatrix3fv(this.addr, !1, ao), ho(n, i);
		}
	}
	function xo(t, e) {
		const n = this.cache, i = e.elements;
		if (void 0 === i) {
			if (co(n, e)) return;
			t.uniformMatrix4fv(this.addr, !1, e), ho(n, e);
		} else {
			if (co(n, i)) return;
			so.set(i), t.uniformMatrix4fv(this.addr, !1, so), ho(n, i);
		}
	}
	function yo(t, e) {
		const n = this.cache;
		n[0] !== e && (t.uniform1i(this.addr, e), n[0] = e);
	}
	function Mo(t, e) {
		const n = this.cache;
		if (void 0 !== e.x) n[0] === e.x && n[1] === e.y || (t.uniform2i(this.addr, e.x, e.y), n[0] = e.x, n[1] = e.y);
		else {
			if (co(n, e)) return;
			t.uniform2iv(this.addr, e), ho(n, e);
		}
	}
	function So(t, e) {
		const n = this.cache;
		if (void 0 !== e.x) n[0] === e.x && n[1] === e.y && n[2] === e.z || (t.uniform3i(this.addr, e.x, e.y, e.z), n[0] = e.x, n[1] = e.y, n[2] = e.z);
		else {
			if (co(n, e)) return;
			t.uniform3iv(this.addr, e), ho(n, e);
		}
	}
	function bo(t, e) {
		const n = this.cache;
		if (void 0 !== e.x) n[0] === e.x && n[1] === e.y && n[2] === e.z && n[3] === e.w || (t.uniform4i(this.addr, e.x, e.y, e.z, e.w), n[0] = e.x, n[1] = e.y, n[2] = e.z, n[3] = e.w);
		else {
			if (co(n, e)) return;
			t.uniform4iv(this.addr, e), ho(n, e);
		}
	}
	function wo(t, e) {
		const n = this.cache;
		n[0] !== e && (t.uniform1ui(this.addr, e), n[0] = e);
	}
	function To(t, e) {
		const n = this.cache;
		if (void 0 !== e.x) n[0] === e.x && n[1] === e.y || (t.uniform2ui(this.addr, e.x, e.y), n[0] = e.x, n[1] = e.y);
		else {
			if (co(n, e)) return;
			t.uniform2uiv(this.addr, e), ho(n, e);
		}
	}
	function Eo(t, e) {
		const n = this.cache;
		if (void 0 !== e.x) n[0] === e.x && n[1] === e.y && n[2] === e.z || (t.uniform3ui(this.addr, e.x, e.y, e.z), n[0] = e.x, n[1] = e.y, n[2] = e.z);
		else {
			if (co(n, e)) return;
			t.uniform3uiv(this.addr, e), ho(n, e);
		}
	}
	function Ao(t, e) {
		const n = this.cache;
		if (void 0 !== e.x) n[0] === e.x && n[1] === e.y && n[2] === e.z && n[3] === e.w || (t.uniform4ui(this.addr, e.x, e.y, e.z, e.w), n[0] = e.x, n[1] = e.y, n[2] = e.z, n[3] = e.w);
		else {
			if (co(n, e)) return;
			t.uniform4uiv(this.addr, e), ho(n, e);
		}
	}
	function Ro(t, e, n) {
		const i = this.cache, r = n.allocateTextureUnit();
		let s;
		i[0] !== r && (t.uniform1i(this.addr, r), i[0] = r), this.type === t.SAMPLER_2D_SHADOW ? (Qa.compareFunction = 515, s = Qa) : s = $a, n.setTexture2D(e || s, r);
	}
	function Co(t, e, n) {
		const i = this.cache, r = n.allocateTextureUnit();
		i[0] !== r && (t.uniform1i(this.addr, r), i[0] = r), n.setTexture3D(e || eo, r);
	}
	function Po(t, e, n) {
		const i = this.cache, r = n.allocateTextureUnit();
		i[0] !== r && (t.uniform1i(this.addr, r), i[0] = r), n.setTextureCube(e || no, r);
	}
	function Io(t, e, n) {
		const i = this.cache, r = n.allocateTextureUnit();
		i[0] !== r && (t.uniform1i(this.addr, r), i[0] = r), n.setTexture2DArray(e || to, r);
	}
	function Lo(t, e) {
		t.uniform1fv(this.addr, e);
	}
	function Uo(t, e) {
		const n = lo(e, this.size, 2);
		t.uniform2fv(this.addr, n);
	}
	function No(t, e) {
		const n = lo(e, this.size, 3);
		t.uniform3fv(this.addr, n);
	}
	function Do(t, e) {
		const n = lo(e, this.size, 4);
		t.uniform4fv(this.addr, n);
	}
	function Oo(t, e) {
		const n = lo(e, this.size, 4);
		t.uniformMatrix2fv(this.addr, !1, n);
	}
	function Fo(t, e) {
		const n = lo(e, this.size, 9);
		t.uniformMatrix3fv(this.addr, !1, n);
	}
	function Bo(t, e) {
		const n = lo(e, this.size, 16);
		t.uniformMatrix4fv(this.addr, !1, n);
	}
	function zo(t, e) {
		t.uniform1iv(this.addr, e);
	}
	function ko(t, e) {
		t.uniform2iv(this.addr, e);
	}
	function Vo(t, e) {
		t.uniform3iv(this.addr, e);
	}
	function Ho(t, e) {
		t.uniform4iv(this.addr, e);
	}
	function Go(t, e) {
		t.uniform1uiv(this.addr, e);
	}
	function Wo(t, e) {
		t.uniform2uiv(this.addr, e);
	}
	function Xo(t, e) {
		t.uniform3uiv(this.addr, e);
	}
	function jo(t, e) {
		t.uniform4uiv(this.addr, e);
	}
	function qo(t, e, n) {
		const i = this.cache, r = e.length, s = uo(n, r);
		co(i, s) || (t.uniform1iv(this.addr, s), ho(i, s));
		for (let t = 0; t !== r; ++t) n.setTexture2D(e[t] || $a, s[t]);
	}
	function Yo(t, e, n) {
		const i = this.cache, r = e.length, s = uo(n, r);
		co(i, s) || (t.uniform1iv(this.addr, s), ho(i, s));
		for (let t = 0; t !== r; ++t) n.setTexture3D(e[t] || eo, s[t]);
	}
	function Zo(t, e, n) {
		const i = this.cache, r = e.length, s = uo(n, r);
		co(i, s) || (t.uniform1iv(this.addr, s), ho(i, s));
		for (let t = 0; t !== r; ++t) n.setTextureCube(e[t] || no, s[t]);
	}
	function Jo(t, e, n) {
		const i = this.cache, r = e.length, s = uo(n, r);
		co(i, s) || (t.uniform1iv(this.addr, s), ho(i, s));
		for (let t = 0; t !== r; ++t) n.setTexture2DArray(e[t] || to, s[t]);
	}
	var Ko = class {
		constructor(t, e, n) {
			this.id = t, this.addr = n, this.cache = [], this.type = e.type, this.setValue = function(t) {
				switch (t) {
					case 5126: return po;
					case 35664: return mo;
					case 35665: return fo;
					case 35666: return go;
					case 35674: return vo;
					case 35675: return _o;
					case 35676: return xo;
					case 5124:
					case 35670: return yo;
					case 35667:
					case 35671: return Mo;
					case 35668:
					case 35672: return So;
					case 35669:
					case 35673: return bo;
					case 5125: return wo;
					case 36294: return To;
					case 36295: return Eo;
					case 36296: return Ao;
					case 35678:
					case 36198:
					case 36298:
					case 36306:
					case 35682: return Ro;
					case 35679:
					case 36299:
					case 36307: return Co;
					case 35680:
					case 36300:
					case 36308:
					case 36293: return Po;
					case 36289:
					case 36303:
					case 36311:
					case 36292: return Io;
				}
			}(e.type);
		}
	};
	var $o = class {
		constructor(t, e, n) {
			this.id = t, this.addr = n, this.cache = [], this.type = e.type, this.size = e.size, this.setValue = function(t) {
				switch (t) {
					case 5126: return Lo;
					case 35664: return Uo;
					case 35665: return No;
					case 35666: return Do;
					case 35674: return Oo;
					case 35675: return Fo;
					case 35676: return Bo;
					case 5124:
					case 35670: return zo;
					case 35667:
					case 35671: return ko;
					case 35668:
					case 35672: return Vo;
					case 35669:
					case 35673: return Ho;
					case 5125: return Go;
					case 36294: return Wo;
					case 36295: return Xo;
					case 36296: return jo;
					case 35678:
					case 36198:
					case 36298:
					case 36306:
					case 35682: return qo;
					case 35679:
					case 36299:
					case 36307: return Yo;
					case 35680:
					case 36300:
					case 36308:
					case 36293: return Zo;
					case 36289:
					case 36303:
					case 36311:
					case 36292: return Jo;
				}
			}(e.type);
		}
	};
	var Qo = class {
		constructor(t) {
			this.id = t, this.seq = [], this.map = {};
		}
		setValue(t, e, n) {
			const i = this.seq;
			for (let r = 0, s = i.length; r !== s; ++r) {
				const s = i[r];
				s.setValue(t, e[s.id], n);
			}
		}
	};
	const tl = /(\w+)(\])?(\[|\.)?/g;
	function el(t, e) {
		t.seq.push(e), t.map[e.id] = e;
	}
	function nl(t, e, n) {
		const i = t.name, r = i.length;
		for (tl.lastIndex = 0;;) {
			const s = tl.exec(i), a = tl.lastIndex;
			let o = s[1];
			const l = "]" === s[2], c = s[3];
			if (l && (o |= 0), void 0 === c || "[" === c && a + 2 === r) {
				el(n, void 0 === c ? new Ko(o, t, e) : new $o(o, t, e));
				break;
			}
			{
				let t = n.map[o];
				void 0 === t && (t = new Qo(o), el(n, t)), n = t;
			}
		}
	}
	var il = class {
		constructor(t, e) {
			this.seq = [], this.map = {};
			const n = t.getProgramParameter(e, t.ACTIVE_UNIFORMS);
			for (let i = 0; i < n; ++i) {
				const n = t.getActiveUniform(e, i);
				nl(n, t.getUniformLocation(e, n.name), this);
			}
		}
		setValue(t, e, n, i) {
			const r = this.map[e];
			void 0 !== r && r.setValue(t, n, i);
		}
		setOptional(t, e, n) {
			const i = e[n];
			void 0 !== i && this.setValue(t, n, i);
		}
		static upload(t, e, n, i) {
			for (let r = 0, s = e.length; r !== s; ++r) {
				const s = e[r], a = n[s.id];
				!1 !== a.needsUpdate && s.setValue(t, a.value, i);
			}
		}
		static seqWithValue(t, e) {
			const n = [];
			for (let i = 0, r = t.length; i !== r; ++i) {
				const r = t[i];
				r.id in e && n.push(r);
			}
			return n;
		}
	};
	function rl(t, e, n) {
		const i = t.createShader(e);
		return t.shaderSource(i, n), t.compileShader(i), i;
	}
	const sl = 37297;
	let al = 0;
	function ol(t, e, n) {
		const i = t.getShaderParameter(e, t.COMPILE_STATUS), r = t.getShaderInfoLog(e).trim();
		if (i && "" === r) return "";
		const s = /ERROR: 0:(\d+)/.exec(r);
		if (s) {
			const i = parseInt(s[1]);
			return n.toUpperCase() + "\n\n" + r + "\n\n" + function(t, e) {
				const n = t.split("\n"), i = [], r = Math.max(e - 6, 0), s = Math.min(e + 6, n.length);
				for (let t = r; t < s; t++) {
					const r = t + 1;
					i.push(`${r === e ? ">" : " "} ${r}: ${n[t]}`);
				}
				return i.join("\n");
			}(t.getShaderSource(e), i);
		}
		return r;
	}
	function ll(t, e) {
		const n = function(t) {
			const e = mi.getPrimaries(mi.workingColorSpace), n = mi.getPrimaries(t);
			let i;
			switch (e === n ? i = "" : e === "p3" && n === "rec709" ? i = "LinearDisplayP3ToLinearSRGB" : e === "rec709" && n === "p3" && (i = "LinearSRGBToLinearDisplayP3"), t) {
				case Ke:
				case Qe: return [i, "LinearTransferOETF"];
				case Je:
				case $e: return [i, "sRGBTransferOETF"];
				default: return console.warn("THREE.WebGLProgram: Unsupported color space:", t), [i, "LinearTransferOETF"];
			}
		}(e);
		return `vec4 ${t}( vec4 value ) { return ${n[0]}( ${n[1]}( value ) ); }`;
	}
	function cl(t, e) {
		let n;
		switch (e) {
			case 1:
				n = "Linear";
				break;
			case 2:
				n = "Reinhard";
				break;
			case 3:
				n = "Cineon";
				break;
			case 4:
				n = "ACESFilmic";
				break;
			case 6:
				n = "AgX";
				break;
			case 7:
				n = "Neutral";
				break;
			case 5:
				n = "Custom";
				break;
			default: console.warn("THREE.WebGLProgram: Unsupported toneMapping:", e), n = "Linear";
		}
		return "vec3 " + t + "( vec3 color ) { return " + n + "ToneMapping( color ); }";
	}
	const hl = new Li();
	function ul() {
		mi.getLuminanceCoefficients(hl);
		return [
			"float luminance( const in vec3 rgb ) {",
			`\tconst vec3 weights = vec3( ${hl.x.toFixed(4)}, ${hl.y.toFixed(4)}, ${hl.z.toFixed(4)} );`,
			"	return dot( weights, rgb );",
			"}"
		].join("\n");
	}
	function dl(t) {
		return "" !== t;
	}
	function pl(t, e) {
		const n = e.numSpotLightShadows + e.numSpotLightMaps - e.numSpotLightShadowsWithMaps;
		return t.replace(/NUM_DIR_LIGHTS/g, e.numDirLights).replace(/NUM_SPOT_LIGHTS/g, e.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g, e.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g, n).replace(/NUM_RECT_AREA_LIGHTS/g, e.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g, e.numPointLights).replace(/NUM_HEMI_LIGHTS/g, e.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g, e.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g, e.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g, e.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g, e.numPointLightShadows);
	}
	function ml(t, e) {
		return t.replace(/NUM_CLIPPING_PLANES/g, e.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g, e.numClippingPlanes - e.numClipIntersection);
	}
	const fl = /^[ \t]*#include +<([\w\d./]+)>/gm;
	function gl(t) {
		return t.replace(fl, _l);
	}
	const vl = /* @__PURE__ */ new Map();
	function _l(t, e) {
		let n = ma[e];
		if (void 0 === n) {
			const t = vl.get(e);
			if (void 0 === t) throw new Error("Can not resolve #include <" + e + ">");
			n = ma[t], console.warn("THREE.WebGLRenderer: Shader chunk \"%s\" has been deprecated. Use \"%s\" instead.", e, t);
		}
		return gl(n);
	}
	const xl = /#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;
	function yl(t) {
		return t.replace(xl, Ml);
	}
	function Ml(t, e, n, i) {
		let r = "";
		for (let t = parseInt(e); t < parseInt(n); t++) r += i.replace(/\[\s*i\s*\]/g, "[ " + t + " ]").replace(/UNROLLED_LOOP_INDEX/g, t);
		return r;
	}
	function Sl(t) {
		let e = `precision ${t.precision} float;\n\tprecision ${t.precision} int;\n\tprecision ${t.precision} sampler2D;\n\tprecision ${t.precision} samplerCube;\n\tprecision ${t.precision} sampler3D;\n\tprecision ${t.precision} sampler2DArray;\n\tprecision ${t.precision} sampler2DShadow;\n\tprecision ${t.precision} samplerCubeShadow;\n\tprecision ${t.precision} sampler2DArrayShadow;\n\tprecision ${t.precision} isampler2D;\n\tprecision ${t.precision} isampler3D;\n\tprecision ${t.precision} isamplerCube;\n\tprecision ${t.precision} isampler2DArray;\n\tprecision ${t.precision} usampler2D;\n\tprecision ${t.precision} usampler3D;\n\tprecision ${t.precision} usamplerCube;\n\tprecision ${t.precision} usampler2DArray;\n\t`;
		return "highp" === t.precision ? e += "\n#define HIGH_PRECISION" : "mediump" === t.precision ? e += "\n#define MEDIUM_PRECISION" : "lowp" === t.precision && (e += "\n#define LOW_PRECISION"), e;
	}
	function bl(t, e, n, i) {
		const r = t.getContext(), s = n.defines;
		let a = n.vertexShader, o = n.fragmentShader;
		const u = function(t) {
			let e = "SHADOWMAP_TYPE_BASIC";
			return t.shadowMapType === 1 ? e = "SHADOWMAP_TYPE_PCF" : t.shadowMapType === 2 ? e = "SHADOWMAP_TYPE_PCF_SOFT" : t.shadowMapType === 3 && (e = "SHADOWMAP_TYPE_VSM"), e;
		}(n), d = function(t) {
			let e = "ENVMAP_TYPE_CUBE";
			if (t.envMap) switch (t.envMapMode) {
				case 301:
				case 302:
					e = "ENVMAP_TYPE_CUBE";
					break;
				case 306: e = "ENVMAP_TYPE_CUBE_UV";
			}
			return e;
		}(n), p = function(t) {
			let e = "ENVMAP_MODE_REFLECTION";
			t.envMap && t.envMapMode === 302 && (e = "ENVMAP_MODE_REFRACTION");
			return e;
		}(n), m = function(t) {
			let e = "ENVMAP_BLENDING_NONE";
			if (t.envMap) switch (t.combine) {
				case 0:
					e = "ENVMAP_BLENDING_MULTIPLY";
					break;
				case 1:
					e = "ENVMAP_BLENDING_MIX";
					break;
				case 2: e = "ENVMAP_BLENDING_ADD";
			}
			return e;
		}(n), f = function(t) {
			const e = t.envMapCubeUVHeight;
			if (null === e) return null;
			const n = Math.log2(e) - 2, i = 1 / e;
			return {
				texelWidth: 1 / (3 * Math.max(Math.pow(2, n), 112)),
				texelHeight: i,
				maxMip: n
			};
		}(n), g = function(t) {
			return [t.extensionClipCullDistance ? "#extension GL_ANGLE_clip_cull_distance : require" : "", t.extensionMultiDraw ? "#extension GL_ANGLE_multi_draw : require" : ""].filter(dl).join("\n");
		}(n), v = function(t) {
			const e = [];
			for (const n in t) {
				const i = t[n];
				!1 !== i && e.push("#define " + n + " " + i);
			}
			return e.join("\n");
		}(s), _ = r.createProgram();
		let x, y, M = n.glslVersion ? "#version " + n.glslVersion + "\n" : "";
		n.isRawShaderMaterial ? (x = [
			"#define SHADER_TYPE " + n.shaderType,
			"#define SHADER_NAME " + n.shaderName,
			v
		].filter(dl).join("\n"), x.length > 0 && (x += "\n"), y = [
			"#define SHADER_TYPE " + n.shaderType,
			"#define SHADER_NAME " + n.shaderName,
			v
		].filter(dl).join("\n"), y.length > 0 && (y += "\n")) : (x = [
			Sl(n),
			"#define SHADER_TYPE " + n.shaderType,
			"#define SHADER_NAME " + n.shaderName,
			v,
			n.extensionClipCullDistance ? "#define USE_CLIP_DISTANCE" : "",
			n.batching ? "#define USE_BATCHING" : "",
			n.batchingColor ? "#define USE_BATCHING_COLOR" : "",
			n.instancing ? "#define USE_INSTANCING" : "",
			n.instancingColor ? "#define USE_INSTANCING_COLOR" : "",
			n.instancingMorph ? "#define USE_INSTANCING_MORPH" : "",
			n.useFog && n.fog ? "#define USE_FOG" : "",
			n.useFog && n.fogExp2 ? "#define FOG_EXP2" : "",
			n.map ? "#define USE_MAP" : "",
			n.envMap ? "#define USE_ENVMAP" : "",
			n.envMap ? "#define " + p : "",
			n.lightMap ? "#define USE_LIGHTMAP" : "",
			n.aoMap ? "#define USE_AOMAP" : "",
			n.bumpMap ? "#define USE_BUMPMAP" : "",
			n.normalMap ? "#define USE_NORMALMAP" : "",
			n.normalMapObjectSpace ? "#define USE_NORMALMAP_OBJECTSPACE" : "",
			n.normalMapTangentSpace ? "#define USE_NORMALMAP_TANGENTSPACE" : "",
			n.displacementMap ? "#define USE_DISPLACEMENTMAP" : "",
			n.emissiveMap ? "#define USE_EMISSIVEMAP" : "",
			n.anisotropy ? "#define USE_ANISOTROPY" : "",
			n.anisotropyMap ? "#define USE_ANISOTROPYMAP" : "",
			n.clearcoatMap ? "#define USE_CLEARCOATMAP" : "",
			n.clearcoatRoughnessMap ? "#define USE_CLEARCOAT_ROUGHNESSMAP" : "",
			n.clearcoatNormalMap ? "#define USE_CLEARCOAT_NORMALMAP" : "",
			n.iridescenceMap ? "#define USE_IRIDESCENCEMAP" : "",
			n.iridescenceThicknessMap ? "#define USE_IRIDESCENCE_THICKNESSMAP" : "",
			n.specularMap ? "#define USE_SPECULARMAP" : "",
			n.specularColorMap ? "#define USE_SPECULAR_COLORMAP" : "",
			n.specularIntensityMap ? "#define USE_SPECULAR_INTENSITYMAP" : "",
			n.roughnessMap ? "#define USE_ROUGHNESSMAP" : "",
			n.metalnessMap ? "#define USE_METALNESSMAP" : "",
			n.alphaMap ? "#define USE_ALPHAMAP" : "",
			n.alphaHash ? "#define USE_ALPHAHASH" : "",
			n.transmission ? "#define USE_TRANSMISSION" : "",
			n.transmissionMap ? "#define USE_TRANSMISSIONMAP" : "",
			n.thicknessMap ? "#define USE_THICKNESSMAP" : "",
			n.sheenColorMap ? "#define USE_SHEEN_COLORMAP" : "",
			n.sheenRoughnessMap ? "#define USE_SHEEN_ROUGHNESSMAP" : "",
			n.mapUv ? "#define MAP_UV " + n.mapUv : "",
			n.alphaMapUv ? "#define ALPHAMAP_UV " + n.alphaMapUv : "",
			n.lightMapUv ? "#define LIGHTMAP_UV " + n.lightMapUv : "",
			n.aoMapUv ? "#define AOMAP_UV " + n.aoMapUv : "",
			n.emissiveMapUv ? "#define EMISSIVEMAP_UV " + n.emissiveMapUv : "",
			n.bumpMapUv ? "#define BUMPMAP_UV " + n.bumpMapUv : "",
			n.normalMapUv ? "#define NORMALMAP_UV " + n.normalMapUv : "",
			n.displacementMapUv ? "#define DISPLACEMENTMAP_UV " + n.displacementMapUv : "",
			n.metalnessMapUv ? "#define METALNESSMAP_UV " + n.metalnessMapUv : "",
			n.roughnessMapUv ? "#define ROUGHNESSMAP_UV " + n.roughnessMapUv : "",
			n.anisotropyMapUv ? "#define ANISOTROPYMAP_UV " + n.anisotropyMapUv : "",
			n.clearcoatMapUv ? "#define CLEARCOATMAP_UV " + n.clearcoatMapUv : "",
			n.clearcoatNormalMapUv ? "#define CLEARCOAT_NORMALMAP_UV " + n.clearcoatNormalMapUv : "",
			n.clearcoatRoughnessMapUv ? "#define CLEARCOAT_ROUGHNESSMAP_UV " + n.clearcoatRoughnessMapUv : "",
			n.iridescenceMapUv ? "#define IRIDESCENCEMAP_UV " + n.iridescenceMapUv : "",
			n.iridescenceThicknessMapUv ? "#define IRIDESCENCE_THICKNESSMAP_UV " + n.iridescenceThicknessMapUv : "",
			n.sheenColorMapUv ? "#define SHEEN_COLORMAP_UV " + n.sheenColorMapUv : "",
			n.sheenRoughnessMapUv ? "#define SHEEN_ROUGHNESSMAP_UV " + n.sheenRoughnessMapUv : "",
			n.specularMapUv ? "#define SPECULARMAP_UV " + n.specularMapUv : "",
			n.specularColorMapUv ? "#define SPECULAR_COLORMAP_UV " + n.specularColorMapUv : "",
			n.specularIntensityMapUv ? "#define SPECULAR_INTENSITYMAP_UV " + n.specularIntensityMapUv : "",
			n.transmissionMapUv ? "#define TRANSMISSIONMAP_UV " + n.transmissionMapUv : "",
			n.thicknessMapUv ? "#define THICKNESSMAP_UV " + n.thicknessMapUv : "",
			n.vertexTangents && !1 === n.flatShading ? "#define USE_TANGENT" : "",
			n.vertexColors ? "#define USE_COLOR" : "",
			n.vertexAlphas ? "#define USE_COLOR_ALPHA" : "",
			n.vertexUv1s ? "#define USE_UV1" : "",
			n.vertexUv2s ? "#define USE_UV2" : "",
			n.vertexUv3s ? "#define USE_UV3" : "",
			n.pointsUvs ? "#define USE_POINTS_UV" : "",
			n.flatShading ? "#define FLAT_SHADED" : "",
			n.skinning ? "#define USE_SKINNING" : "",
			n.morphTargets ? "#define USE_MORPHTARGETS" : "",
			n.morphNormals && !1 === n.flatShading ? "#define USE_MORPHNORMALS" : "",
			n.morphColors ? "#define USE_MORPHCOLORS" : "",
			n.morphTargetsCount > 0 ? "#define MORPHTARGETS_TEXTURE_STRIDE " + n.morphTextureStride : "",
			n.morphTargetsCount > 0 ? "#define MORPHTARGETS_COUNT " + n.morphTargetsCount : "",
			n.doubleSided ? "#define DOUBLE_SIDED" : "",
			n.flipSided ? "#define FLIP_SIDED" : "",
			n.shadowMapEnabled ? "#define USE_SHADOWMAP" : "",
			n.shadowMapEnabled ? "#define " + u : "",
			n.sizeAttenuation ? "#define USE_SIZEATTENUATION" : "",
			n.numLightProbes > 0 ? "#define USE_LIGHT_PROBES" : "",
			n.logarithmicDepthBuffer ? "#define USE_LOGDEPTHBUF" : "",
			n.reverseDepthBuffer ? "#define USE_REVERSEDEPTHBUF" : "",
			"uniform mat4 modelMatrix;",
			"uniform mat4 modelViewMatrix;",
			"uniform mat4 projectionMatrix;",
			"uniform mat4 viewMatrix;",
			"uniform mat3 normalMatrix;",
			"uniform vec3 cameraPosition;",
			"uniform bool isOrthographic;",
			"#ifdef USE_INSTANCING",
			"	attribute mat4 instanceMatrix;",
			"#endif",
			"#ifdef USE_INSTANCING_COLOR",
			"	attribute vec3 instanceColor;",
			"#endif",
			"#ifdef USE_INSTANCING_MORPH",
			"	uniform sampler2D morphTexture;",
			"#endif",
			"attribute vec3 position;",
			"attribute vec3 normal;",
			"attribute vec2 uv;",
			"#ifdef USE_UV1",
			"	attribute vec2 uv1;",
			"#endif",
			"#ifdef USE_UV2",
			"	attribute vec2 uv2;",
			"#endif",
			"#ifdef USE_UV3",
			"	attribute vec2 uv3;",
			"#endif",
			"#ifdef USE_TANGENT",
			"	attribute vec4 tangent;",
			"#endif",
			"#if defined( USE_COLOR_ALPHA )",
			"	attribute vec4 color;",
			"#elif defined( USE_COLOR )",
			"	attribute vec3 color;",
			"#endif",
			"#ifdef USE_SKINNING",
			"	attribute vec4 skinIndex;",
			"	attribute vec4 skinWeight;",
			"#endif",
			"\n"
		].filter(dl).join("\n"), y = [
			Sl(n),
			"#define SHADER_TYPE " + n.shaderType,
			"#define SHADER_NAME " + n.shaderName,
			v,
			n.useFog && n.fog ? "#define USE_FOG" : "",
			n.useFog && n.fogExp2 ? "#define FOG_EXP2" : "",
			n.alphaToCoverage ? "#define ALPHA_TO_COVERAGE" : "",
			n.map ? "#define USE_MAP" : "",
			n.matcap ? "#define USE_MATCAP" : "",
			n.envMap ? "#define USE_ENVMAP" : "",
			n.envMap ? "#define " + d : "",
			n.envMap ? "#define " + p : "",
			n.envMap ? "#define " + m : "",
			f ? "#define CUBEUV_TEXEL_WIDTH " + f.texelWidth : "",
			f ? "#define CUBEUV_TEXEL_HEIGHT " + f.texelHeight : "",
			f ? "#define CUBEUV_MAX_MIP " + f.maxMip + ".0" : "",
			n.lightMap ? "#define USE_LIGHTMAP" : "",
			n.aoMap ? "#define USE_AOMAP" : "",
			n.bumpMap ? "#define USE_BUMPMAP" : "",
			n.normalMap ? "#define USE_NORMALMAP" : "",
			n.normalMapObjectSpace ? "#define USE_NORMALMAP_OBJECTSPACE" : "",
			n.normalMapTangentSpace ? "#define USE_NORMALMAP_TANGENTSPACE" : "",
			n.emissiveMap ? "#define USE_EMISSIVEMAP" : "",
			n.anisotropy ? "#define USE_ANISOTROPY" : "",
			n.anisotropyMap ? "#define USE_ANISOTROPYMAP" : "",
			n.clearcoat ? "#define USE_CLEARCOAT" : "",
			n.clearcoatMap ? "#define USE_CLEARCOATMAP" : "",
			n.clearcoatRoughnessMap ? "#define USE_CLEARCOAT_ROUGHNESSMAP" : "",
			n.clearcoatNormalMap ? "#define USE_CLEARCOAT_NORMALMAP" : "",
			n.dispersion ? "#define USE_DISPERSION" : "",
			n.iridescence ? "#define USE_IRIDESCENCE" : "",
			n.iridescenceMap ? "#define USE_IRIDESCENCEMAP" : "",
			n.iridescenceThicknessMap ? "#define USE_IRIDESCENCE_THICKNESSMAP" : "",
			n.specularMap ? "#define USE_SPECULARMAP" : "",
			n.specularColorMap ? "#define USE_SPECULAR_COLORMAP" : "",
			n.specularIntensityMap ? "#define USE_SPECULAR_INTENSITYMAP" : "",
			n.roughnessMap ? "#define USE_ROUGHNESSMAP" : "",
			n.metalnessMap ? "#define USE_METALNESSMAP" : "",
			n.alphaMap ? "#define USE_ALPHAMAP" : "",
			n.alphaTest ? "#define USE_ALPHATEST" : "",
			n.alphaHash ? "#define USE_ALPHAHASH" : "",
			n.sheen ? "#define USE_SHEEN" : "",
			n.sheenColorMap ? "#define USE_SHEEN_COLORMAP" : "",
			n.sheenRoughnessMap ? "#define USE_SHEEN_ROUGHNESSMAP" : "",
			n.transmission ? "#define USE_TRANSMISSION" : "",
			n.transmissionMap ? "#define USE_TRANSMISSIONMAP" : "",
			n.thicknessMap ? "#define USE_THICKNESSMAP" : "",
			n.vertexTangents && !1 === n.flatShading ? "#define USE_TANGENT" : "",
			n.vertexColors || n.instancingColor || n.batchingColor ? "#define USE_COLOR" : "",
			n.vertexAlphas ? "#define USE_COLOR_ALPHA" : "",
			n.vertexUv1s ? "#define USE_UV1" : "",
			n.vertexUv2s ? "#define USE_UV2" : "",
			n.vertexUv3s ? "#define USE_UV3" : "",
			n.pointsUvs ? "#define USE_POINTS_UV" : "",
			n.gradientMap ? "#define USE_GRADIENTMAP" : "",
			n.flatShading ? "#define FLAT_SHADED" : "",
			n.doubleSided ? "#define DOUBLE_SIDED" : "",
			n.flipSided ? "#define FLIP_SIDED" : "",
			n.shadowMapEnabled ? "#define USE_SHADOWMAP" : "",
			n.shadowMapEnabled ? "#define " + u : "",
			n.premultipliedAlpha ? "#define PREMULTIPLIED_ALPHA" : "",
			n.numLightProbes > 0 ? "#define USE_LIGHT_PROBES" : "",
			n.decodeVideoTexture ? "#define DECODE_VIDEO_TEXTURE" : "",
			n.logarithmicDepthBuffer ? "#define USE_LOGDEPTHBUF" : "",
			n.reverseDepthBuffer ? "#define USE_REVERSEDEPTHBUF" : "",
			"uniform mat4 viewMatrix;",
			"uniform vec3 cameraPosition;",
			"uniform bool isOrthographic;",
			n.toneMapping !== 0 ? "#define TONE_MAPPING" : "",
			n.toneMapping !== 0 ? ma.tonemapping_pars_fragment : "",
			n.toneMapping !== 0 ? cl("toneMapping", n.toneMapping) : "",
			n.dithering ? "#define DITHERING" : "",
			n.opaque ? "#define OPAQUE" : "",
			ma.colorspace_pars_fragment,
			ll("linearToOutputTexel", n.outputColorSpace),
			ul(),
			n.useDepthPacking ? "#define DEPTH_PACKING " + n.depthPacking : "",
			"\n"
		].filter(dl).join("\n")), a = gl(a), a = pl(a, n), a = ml(a, n), o = gl(o), o = pl(o, n), o = ml(o, n), a = yl(a), o = yl(o), !0 !== n.isRawShaderMaterial && (M = "#version 300 es\n", x = [
			g,
			"#define attribute in",
			"#define varying out",
			"#define texture2D texture"
		].join("\n") + "\n" + x, y = [
			"#define varying in",
			n.glslVersion === "300 es" ? "" : "layout(location = 0) out highp vec4 pc_fragColor;",
			n.glslVersion === "300 es" ? "" : "#define gl_FragColor pc_fragColor",
			"#define gl_FragDepthEXT gl_FragDepth",
			"#define texture2D texture",
			"#define textureCube texture",
			"#define texture2DProj textureProj",
			"#define texture2DLodEXT textureLod",
			"#define texture2DProjLodEXT textureProjLod",
			"#define textureCubeLodEXT textureLod",
			"#define texture2DGradEXT textureGrad",
			"#define texture2DProjGradEXT textureProjGrad",
			"#define textureCubeGradEXT textureGrad"
		].join("\n") + "\n" + y);
		const S = M + x + a, b = M + y + o, w = rl(r, r.VERTEX_SHADER, S), T = rl(r, r.FRAGMENT_SHADER, b);
		function E(e) {
			if (t.debug.checkShaderErrors) {
				const n = r.getProgramInfoLog(_).trim(), i = r.getShaderInfoLog(w).trim(), s = r.getShaderInfoLog(T).trim();
				let a = !0, o = !0;
				if (!1 === r.getProgramParameter(_, r.LINK_STATUS)) if (a = !1, "function" == typeof t.debug.onShaderError) t.debug.onShaderError(r, _, w, T);
				else {
					const t = ol(r, w, "vertex"), i = ol(r, T, "fragment");
					console.error("THREE.WebGLProgram: Shader Error " + r.getError() + " - VALIDATE_STATUS " + r.getProgramParameter(_, r.VALIDATE_STATUS) + "\n\nMaterial Name: " + e.name + "\nMaterial Type: " + e.type + "\n\nProgram Info Log: " + n + "\n" + t + "\n" + i);
				}
				else "" !== n ? console.warn("THREE.WebGLProgram: Program Info Log:", n) : "" !== i && "" !== s || (o = !1);
				o && (e.diagnostics = {
					runnable: a,
					programLog: n,
					vertexShader: {
						log: i,
						prefix: x
					},
					fragmentShader: {
						log: s,
						prefix: y
					}
				});
			}
			r.deleteShader(w), r.deleteShader(T), A = new il(r, _), R = function(t, e) {
				const n = {}, i = t.getProgramParameter(e, t.ACTIVE_ATTRIBUTES);
				for (let r = 0; r < i; r++) {
					const i = t.getActiveAttrib(e, r), s = i.name;
					let a = 1;
					i.type === t.FLOAT_MAT2 && (a = 2), i.type === t.FLOAT_MAT3 && (a = 3), i.type === t.FLOAT_MAT4 && (a = 4), n[s] = {
						type: i.type,
						location: t.getAttribLocation(e, s),
						locationSize: a
					};
				}
				return n;
			}(r, _);
		}
		let A, R;
		r.attachShader(_, w), r.attachShader(_, T), void 0 !== n.index0AttributeName ? r.bindAttribLocation(_, 0, n.index0AttributeName) : !0 === n.morphTargets && r.bindAttribLocation(_, 0, "position"), r.linkProgram(_), this.getUniforms = function() {
			return void 0 === A && E(this), A;
		}, this.getAttributes = function() {
			return void 0 === R && E(this), R;
		};
		let C = !1 === n.rendererExtensionParallelShaderCompile;
		return this.isReady = function() {
			return !1 === C && (C = r.getProgramParameter(_, sl)), C;
		}, this.destroy = function() {
			i.releaseStatesOfProgram(this), r.deleteProgram(_), this.program = void 0;
		}, this.type = n.shaderType, this.name = n.shaderName, this.id = al++, this.cacheKey = e, this.usedTimes = 1, this.program = _, this.vertexShader = w, this.fragmentShader = T, this;
	}
	let wl = 0;
	var Tl = class {
		constructor() {
			this.shaderCache = /* @__PURE__ */ new Map(), this.materialCache = /* @__PURE__ */ new Map();
		}
		update(t) {
			const e = t.vertexShader, n = t.fragmentShader, i = this._getShaderStage(e), r = this._getShaderStage(n), s = this._getShaderCacheForMaterial(t);
			return !1 === s.has(i) && (s.add(i), i.usedTimes++), !1 === s.has(r) && (s.add(r), r.usedTimes++), this;
		}
		remove(t) {
			const e = this.materialCache.get(t);
			for (const t of e) t.usedTimes--, 0 === t.usedTimes && this.shaderCache.delete(t.code);
			return this.materialCache.delete(t), this;
		}
		getVertexShaderID(t) {
			return this._getShaderStage(t.vertexShader).id;
		}
		getFragmentShaderID(t) {
			return this._getShaderStage(t.fragmentShader).id;
		}
		dispose() {
			this.shaderCache.clear(), this.materialCache.clear();
		}
		_getShaderCacheForMaterial(t) {
			const e = this.materialCache;
			let n = e.get(t);
			return void 0 === n && (n = /* @__PURE__ */ new Set(), e.set(t, n)), n;
		}
		_getShaderStage(t) {
			const e = this.shaderCache;
			let n = e.get(t);
			return void 0 === n && (n = new El(t), e.set(t, n)), n;
		}
	};
	var El = class {
		constructor(t) {
			this.id = wl++, this.code = t, this.usedTimes = 0;
		}
	};
	function Al(t, e, n, i, r, s, a) {
		const o = new xr(), l = new Tl(), c = /* @__PURE__ */ new Set(), h = [], u = r.logarithmicDepthBuffer, p = r.reverseDepthBuffer, m = r.vertexTextures;
		let f = r.precision;
		const g = {
			MeshDepthMaterial: "depth",
			MeshDistanceMaterial: "distanceRGBA",
			MeshNormalMaterial: "normal",
			MeshBasicMaterial: "basic",
			MeshLambertMaterial: "lambert",
			MeshPhongMaterial: "phong",
			MeshToonMaterial: "toon",
			MeshStandardMaterial: "physical",
			MeshPhysicalMaterial: "physical",
			MeshMatcapMaterial: "matcap",
			LineBasicMaterial: "basic",
			LineDashedMaterial: "dashed",
			PointsMaterial: "points",
			ShadowMaterial: "shadow",
			SpriteMaterial: "sprite"
		};
		function v(t) {
			return c.add(t), 0 === t ? "uv" : `uv${t}`;
		}
		return {
			getParameters: function(s, o, h, _, x) {
				const y = _.fog, M = x.geometry, S = s.isMeshStandardMaterial ? _.environment : null, b = (s.isMeshStandardMaterial ? n : e).get(s.envMap || S), w = b && b.mapping === 306 ? b.image.height : null, T = g[s.type];
				null !== s.precision && (f = r.getMaxPrecision(s.precision), f !== s.precision && console.warn("THREE.WebGLProgram.getParameters:", s.precision, "not supported, using", f, "instead."));
				const E = M.morphAttributes.position || M.morphAttributes.normal || M.morphAttributes.color, A = void 0 !== E ? E.length : 0;
				let R, C, P, I, L = 0;
				if (void 0 !== M.morphAttributes.position && (L = 1), void 0 !== M.morphAttributes.normal && (L = 2), void 0 !== M.morphAttributes.color && (L = 3), T) {
					const t = ga[T];
					R = t.vertexShader, C = t.fragmentShader;
				} else R = s.vertexShader, C = s.fragmentShader, l.update(s), P = l.getVertexShaderID(s), I = l.getFragmentShaderID(s);
				const U = t.getRenderTarget(), N = !0 === x.isInstancedMesh, D = !0 === x.isBatchedMesh, O = !!s.map, F = !!s.matcap, B = !!b, z = !!s.aoMap, k = !!s.lightMap, V = !!s.bumpMap, H = !!s.normalMap, G = !!s.displacementMap, W = !!s.emissiveMap, X = !!s.metalnessMap, j = !!s.roughnessMap, q = s.anisotropy > 0, Y = s.clearcoat > 0, Z = s.dispersion > 0, J = s.iridescence > 0, $ = s.sheen > 0, Q = s.transmission > 0, tt = q && !!s.anisotropyMap, et = Y && !!s.clearcoatMap, nt = Y && !!s.clearcoatNormalMap, it = Y && !!s.clearcoatRoughnessMap, rt = J && !!s.iridescenceMap, st = J && !!s.iridescenceThicknessMap, at = $ && !!s.sheenColorMap, ot = $ && !!s.sheenRoughnessMap, lt = !!s.specularMap, ct = !!s.specularColorMap, ht = !!s.specularIntensityMap, ut = Q && !!s.transmissionMap, pt = Q && !!s.thicknessMap, mt = !!s.gradientMap, ft = !!s.alphaMap, gt = s.alphaTest > 0, vt = !!s.alphaHash, _t = !!s.extensions;
				let xt = 0;
				s.toneMapped && (null !== U && !0 !== U.isXRRenderTarget || (xt = t.toneMapping));
				const yt = {
					shaderID: T,
					shaderType: s.type,
					shaderName: s.name,
					vertexShader: R,
					fragmentShader: C,
					defines: s.defines,
					customVertexShaderID: P,
					customFragmentShaderID: I,
					isRawShaderMaterial: !0 === s.isRawShaderMaterial,
					glslVersion: s.glslVersion,
					precision: f,
					batching: D,
					batchingColor: D && null !== x._colorsTexture,
					instancing: N,
					instancingColor: N && null !== x.instanceColor,
					instancingMorph: N && null !== x.morphTexture,
					supportsVertexTextures: m,
					outputColorSpace: null === U ? t.outputColorSpace : !0 === U.isXRRenderTarget ? U.texture.colorSpace : Ke,
					alphaToCoverage: !!s.alphaToCoverage,
					map: O,
					matcap: F,
					envMap: B,
					envMapMode: B && b.mapping,
					envMapCubeUVHeight: w,
					aoMap: z,
					lightMap: k,
					bumpMap: V,
					normalMap: H,
					displacementMap: m && G,
					emissiveMap: W,
					normalMapObjectSpace: H && 1 === s.normalMapType,
					normalMapTangentSpace: H && 0 === s.normalMapType,
					metalnessMap: X,
					roughnessMap: j,
					anisotropy: q,
					anisotropyMap: tt,
					clearcoat: Y,
					clearcoatMap: et,
					clearcoatNormalMap: nt,
					clearcoatRoughnessMap: it,
					dispersion: Z,
					iridescence: J,
					iridescenceMap: rt,
					iridescenceThicknessMap: st,
					sheen: $,
					sheenColorMap: at,
					sheenRoughnessMap: ot,
					specularMap: lt,
					specularColorMap: ct,
					specularIntensityMap: ht,
					transmission: Q,
					transmissionMap: ut,
					thicknessMap: pt,
					gradientMap: mt,
					opaque: !1 === s.transparent && 1 === s.blending && !1 === s.alphaToCoverage,
					alphaMap: ft,
					alphaTest: gt,
					alphaHash: vt,
					combine: s.combine,
					mapUv: O && v(s.map.channel),
					aoMapUv: z && v(s.aoMap.channel),
					lightMapUv: k && v(s.lightMap.channel),
					bumpMapUv: V && v(s.bumpMap.channel),
					normalMapUv: H && v(s.normalMap.channel),
					displacementMapUv: G && v(s.displacementMap.channel),
					emissiveMapUv: W && v(s.emissiveMap.channel),
					metalnessMapUv: X && v(s.metalnessMap.channel),
					roughnessMapUv: j && v(s.roughnessMap.channel),
					anisotropyMapUv: tt && v(s.anisotropyMap.channel),
					clearcoatMapUv: et && v(s.clearcoatMap.channel),
					clearcoatNormalMapUv: nt && v(s.clearcoatNormalMap.channel),
					clearcoatRoughnessMapUv: it && v(s.clearcoatRoughnessMap.channel),
					iridescenceMapUv: rt && v(s.iridescenceMap.channel),
					iridescenceThicknessMapUv: st && v(s.iridescenceThicknessMap.channel),
					sheenColorMapUv: at && v(s.sheenColorMap.channel),
					sheenRoughnessMapUv: ot && v(s.sheenRoughnessMap.channel),
					specularMapUv: lt && v(s.specularMap.channel),
					specularColorMapUv: ct && v(s.specularColorMap.channel),
					specularIntensityMapUv: ht && v(s.specularIntensityMap.channel),
					transmissionMapUv: ut && v(s.transmissionMap.channel),
					thicknessMapUv: pt && v(s.thicknessMap.channel),
					alphaMapUv: ft && v(s.alphaMap.channel),
					vertexTangents: !!M.attributes.tangent && (H || q),
					vertexColors: s.vertexColors,
					vertexAlphas: !0 === s.vertexColors && !!M.attributes.color && 4 === M.attributes.color.itemSize,
					pointsUvs: !0 === x.isPoints && !!M.attributes.uv && (O || ft),
					fog: !!y,
					useFog: !0 === s.fog,
					fogExp2: !!y && y.isFogExp2,
					flatShading: !0 === s.flatShading,
					sizeAttenuation: !0 === s.sizeAttenuation,
					logarithmicDepthBuffer: u,
					reverseDepthBuffer: p,
					skinning: !0 === x.isSkinnedMesh,
					morphTargets: void 0 !== M.morphAttributes.position,
					morphNormals: void 0 !== M.morphAttributes.normal,
					morphColors: void 0 !== M.morphAttributes.color,
					morphTargetsCount: A,
					morphTextureStride: L,
					numDirLights: o.directional.length,
					numPointLights: o.point.length,
					numSpotLights: o.spot.length,
					numSpotLightMaps: o.spotLightMap.length,
					numRectAreaLights: o.rectArea.length,
					numHemiLights: o.hemi.length,
					numDirLightShadows: o.directionalShadowMap.length,
					numPointLightShadows: o.pointShadowMap.length,
					numSpotLightShadows: o.spotShadowMap.length,
					numSpotLightShadowsWithMaps: o.numSpotLightShadowsWithMaps,
					numLightProbes: o.numLightProbes,
					numClippingPlanes: a.numPlanes,
					numClipIntersection: a.numIntersection,
					dithering: s.dithering,
					shadowMapEnabled: t.shadowMap.enabled && h.length > 0,
					shadowMapType: t.shadowMap.type,
					toneMapping: xt,
					decodeVideoTexture: O && !0 === s.map.isVideoTexture && mi.getTransfer(s.map.colorSpace) === "srgb",
					premultipliedAlpha: s.premultipliedAlpha,
					doubleSided: 2 === s.side,
					flipSided: s.side === 1,
					useDepthPacking: s.depthPacking >= 0,
					depthPacking: s.depthPacking || 0,
					index0AttributeName: s.index0AttributeName,
					extensionClipCullDistance: _t && !0 === s.extensions.clipCullDistance && i.has("WEBGL_clip_cull_distance"),
					extensionMultiDraw: (_t && !0 === s.extensions.multiDraw || D) && i.has("WEBGL_multi_draw"),
					rendererExtensionParallelShaderCompile: i.has("KHR_parallel_shader_compile"),
					customProgramCacheKey: s.customProgramCacheKey()
				};
				return yt.vertexUv1s = c.has(1), yt.vertexUv2s = c.has(2), yt.vertexUv3s = c.has(3), c.clear(), yt;
			},
			getProgramCacheKey: function(e) {
				const n = [];
				if (e.shaderID ? n.push(e.shaderID) : (n.push(e.customVertexShaderID), n.push(e.customFragmentShaderID)), void 0 !== e.defines) for (const t in e.defines) n.push(t), n.push(e.defines[t]);
				return !1 === e.isRawShaderMaterial && (function(t, e) {
					t.push(e.precision), t.push(e.outputColorSpace), t.push(e.envMapMode), t.push(e.envMapCubeUVHeight), t.push(e.mapUv), t.push(e.alphaMapUv), t.push(e.lightMapUv), t.push(e.aoMapUv), t.push(e.bumpMapUv), t.push(e.normalMapUv), t.push(e.displacementMapUv), t.push(e.emissiveMapUv), t.push(e.metalnessMapUv), t.push(e.roughnessMapUv), t.push(e.anisotropyMapUv), t.push(e.clearcoatMapUv), t.push(e.clearcoatNormalMapUv), t.push(e.clearcoatRoughnessMapUv), t.push(e.iridescenceMapUv), t.push(e.iridescenceThicknessMapUv), t.push(e.sheenColorMapUv), t.push(e.sheenRoughnessMapUv), t.push(e.specularMapUv), t.push(e.specularColorMapUv), t.push(e.specularIntensityMapUv), t.push(e.transmissionMapUv), t.push(e.thicknessMapUv), t.push(e.combine), t.push(e.fogExp2), t.push(e.sizeAttenuation), t.push(e.morphTargetsCount), t.push(e.morphAttributeCount), t.push(e.numDirLights), t.push(e.numPointLights), t.push(e.numSpotLights), t.push(e.numSpotLightMaps), t.push(e.numHemiLights), t.push(e.numRectAreaLights), t.push(e.numDirLightShadows), t.push(e.numPointLightShadows), t.push(e.numSpotLightShadows), t.push(e.numSpotLightShadowsWithMaps), t.push(e.numLightProbes), t.push(e.shadowMapType), t.push(e.toneMapping), t.push(e.numClippingPlanes), t.push(e.numClipIntersection), t.push(e.depthPacking);
				}(n, e), function(t, e) {
					o.disableAll(), e.supportsVertexTextures && o.enable(0);
					e.instancing && o.enable(1);
					e.instancingColor && o.enable(2);
					e.instancingMorph && o.enable(3);
					e.matcap && o.enable(4);
					e.envMap && o.enable(5);
					e.normalMapObjectSpace && o.enable(6);
					e.normalMapTangentSpace && o.enable(7);
					e.clearcoat && o.enable(8);
					e.iridescence && o.enable(9);
					e.alphaTest && o.enable(10);
					e.vertexColors && o.enable(11);
					e.vertexAlphas && o.enable(12);
					e.vertexUv1s && o.enable(13);
					e.vertexUv2s && o.enable(14);
					e.vertexUv3s && o.enable(15);
					e.vertexTangents && o.enable(16);
					e.anisotropy && o.enable(17);
					e.alphaHash && o.enable(18);
					e.batching && o.enable(19);
					e.dispersion && o.enable(20);
					e.batchingColor && o.enable(21);
					t.push(o.mask), o.disableAll(), e.fog && o.enable(0);
					e.useFog && o.enable(1);
					e.flatShading && o.enable(2);
					e.logarithmicDepthBuffer && o.enable(3);
					e.reverseDepthBuffer && o.enable(4);
					e.skinning && o.enable(5);
					e.morphTargets && o.enable(6);
					e.morphNormals && o.enable(7);
					e.morphColors && o.enable(8);
					e.premultipliedAlpha && o.enable(9);
					e.shadowMapEnabled && o.enable(10);
					e.doubleSided && o.enable(11);
					e.flipSided && o.enable(12);
					e.useDepthPacking && o.enable(13);
					e.dithering && o.enable(14);
					e.transmission && o.enable(15);
					e.sheen && o.enable(16);
					e.opaque && o.enable(17);
					e.pointsUvs && o.enable(18);
					e.decodeVideoTexture && o.enable(19);
					e.alphaToCoverage && o.enable(20);
					t.push(o.mask);
				}(n, e), n.push(t.outputColorSpace)), n.push(e.customProgramCacheKey), n.join();
			},
			getUniforms: function(t) {
				const e = g[t.type];
				let n;
				if (e) {
					const t = ga[e];
					n = qs.clone(t.uniforms);
				} else n = t.uniforms;
				return n;
			},
			acquireProgram: function(e, n) {
				let i;
				for (let t = 0, e = h.length; t < e; t++) {
					const e = h[t];
					if (e.cacheKey === n) {
						i = e, ++i.usedTimes;
						break;
					}
				}
				return void 0 === i && (i = new bl(t, n, e, s), h.push(i)), i;
			},
			releaseProgram: function(t) {
				if (0 == --t.usedTimes) {
					const e = h.indexOf(t);
					h[e] = h[h.length - 1], h.pop(), t.destroy();
				}
			},
			releaseShaderCache: function(t) {
				l.remove(t);
			},
			programs: h,
			dispose: function() {
				l.dispose();
			}
		};
	}
	function Rl() {
		let t = /* @__PURE__ */ new WeakMap();
		return {
			has: function(e) {
				return t.has(e);
			},
			get: function(e) {
				let n = t.get(e);
				return void 0 === n && (n = {}, t.set(e, n)), n;
			},
			remove: function(e) {
				t.delete(e);
			},
			update: function(e, n, i) {
				t.get(e)[n] = i;
			},
			dispose: function() {
				t = /* @__PURE__ */ new WeakMap();
			}
		};
	}
	function Cl(t, e) {
		return t.groupOrder !== e.groupOrder ? t.groupOrder - e.groupOrder : t.renderOrder !== e.renderOrder ? t.renderOrder - e.renderOrder : t.material.id !== e.material.id ? t.material.id - e.material.id : t.z !== e.z ? t.z - e.z : t.id - e.id;
	}
	function Pl(t, e) {
		return t.groupOrder !== e.groupOrder ? t.groupOrder - e.groupOrder : t.renderOrder !== e.renderOrder ? t.renderOrder - e.renderOrder : t.z !== e.z ? e.z - t.z : t.id - e.id;
	}
	function Il() {
		const t = [];
		let e = 0;
		const n = [], i = [], r = [];
		function s(n, i, r, s, a, o) {
			let l = t[e];
			return void 0 === l ? (l = {
				id: n.id,
				object: n,
				geometry: i,
				material: r,
				groupOrder: s,
				renderOrder: n.renderOrder,
				z: a,
				group: o
			}, t[e] = l) : (l.id = n.id, l.object = n, l.geometry = i, l.material = r, l.groupOrder = s, l.renderOrder = n.renderOrder, l.z = a, l.group = o), e++, l;
		}
		return {
			opaque: n,
			transmissive: i,
			transparent: r,
			init: function() {
				e = 0, n.length = 0, i.length = 0, r.length = 0;
			},
			push: function(t, e, a, o, l, c) {
				const h = s(t, e, a, o, l, c);
				a.transmission > 0 ? i.push(h) : !0 === a.transparent ? r.push(h) : n.push(h);
			},
			unshift: function(t, e, a, o, l, c) {
				const h = s(t, e, a, o, l, c);
				a.transmission > 0 ? i.unshift(h) : !0 === a.transparent ? r.unshift(h) : n.unshift(h);
			},
			finish: function() {
				for (let n = e, i = t.length; n < i; n++) {
					const e = t[n];
					if (null === e.id) break;
					e.id = null, e.object = null, e.geometry = null, e.material = null, e.group = null;
				}
			},
			sort: function(t, e) {
				n.length > 1 && n.sort(t || Cl), i.length > 1 && i.sort(e || Pl), r.length > 1 && r.sort(e || Pl);
			}
		};
	}
	function Ll() {
		let t = /* @__PURE__ */ new WeakMap();
		return {
			get: function(e, n) {
				const i = t.get(e);
				let r;
				return void 0 === i ? (r = new Il(), t.set(e, [r])) : n >= i.length ? (r = new Il(), i.push(r)) : r = i[n], r;
			},
			dispose: function() {
				t = /* @__PURE__ */ new WeakMap();
			}
		};
	}
	function Ul() {
		const t = {};
		return { get: function(e) {
			if (void 0 !== t[e.id]) return t[e.id];
			let n;
			switch (e.type) {
				case "DirectionalLight":
					n = {
						direction: new Li(),
						color: new ts()
					};
					break;
				case "SpotLight":
					n = {
						position: new Li(),
						direction: new Li(),
						color: new ts(),
						distance: 0,
						coneCos: 0,
						penumbraCos: 0,
						decay: 0
					};
					break;
				case "PointLight":
					n = {
						position: new Li(),
						color: new ts(),
						distance: 0,
						decay: 0
					};
					break;
				case "HemisphereLight":
					n = {
						direction: new Li(),
						skyColor: new ts(),
						groundColor: new ts()
					};
					break;
				case "RectAreaLight": n = {
					color: new ts(),
					position: new Li(),
					halfWidth: new Li(),
					halfHeight: new Li()
				};
			}
			return t[e.id] = n, n;
		} };
	}
	let Nl = 0;
	function Dl(t, e) {
		return (e.castShadow ? 2 : 0) - (t.castShadow ? 2 : 0) + (e.map ? 1 : 0) - (t.map ? 1 : 0);
	}
	function Ol(t) {
		const e = new Ul(), n = function() {
			const t = {};
			return { get: function(e) {
				if (void 0 !== t[e.id]) return t[e.id];
				let n;
				switch (e.type) {
					case "DirectionalLight":
					case "SpotLight":
						n = {
							shadowIntensity: 1,
							shadowBias: 0,
							shadowNormalBias: 0,
							shadowRadius: 1,
							shadowMapSize: new ti()
						};
						break;
					case "PointLight": n = {
						shadowIntensity: 1,
						shadowBias: 0,
						shadowNormalBias: 0,
						shadowRadius: 1,
						shadowMapSize: new ti(),
						shadowCameraNear: 1,
						shadowCameraFar: 1e3
					};
				}
				return t[e.id] = n, n;
			} };
		}(), i = {
			version: 0,
			hash: {
				directionalLength: -1,
				pointLength: -1,
				spotLength: -1,
				rectAreaLength: -1,
				hemiLength: -1,
				numDirectionalShadows: -1,
				numPointShadows: -1,
				numSpotShadows: -1,
				numSpotMaps: -1,
				numLightProbes: -1
			},
			ambient: [
				0,
				0,
				0
			],
			probe: [],
			directional: [],
			directionalShadow: [],
			directionalShadowMap: [],
			directionalShadowMatrix: [],
			spot: [],
			spotLightMap: [],
			spotShadow: [],
			spotShadowMap: [],
			spotLightMatrix: [],
			rectArea: [],
			rectAreaLTC1: null,
			rectAreaLTC2: null,
			point: [],
			pointShadow: [],
			pointShadowMap: [],
			pointShadowMatrix: [],
			hemi: [],
			numSpotLightShadowsWithMaps: 0,
			numLightProbes: 0
		};
		for (let t = 0; t < 9; t++) i.probe.push(new Li());
		const r = new Li(), s = new lr(), a = new lr();
		return {
			setup: function(r) {
				let s = 0, a = 0, o = 0;
				for (let t = 0; t < 9; t++) i.probe[t].set(0, 0, 0);
				let l = 0, c = 0, h = 0, u = 0, d = 0, p = 0, m = 0, f = 0, g = 0, v = 0, _ = 0;
				r.sort(Dl);
				for (let t = 0, x = r.length; t < x; t++) {
					const x = r[t], y = x.color, M = x.intensity, S = x.distance, b = x.shadow && x.shadow.map ? x.shadow.map.texture : null;
					if (x.isAmbientLight) s += y.r * M, a += y.g * M, o += y.b * M;
					else if (x.isLightProbe) {
						for (let t = 0; t < 9; t++) i.probe[t].addScaledVector(x.sh.coefficients[t], M);
						_++;
					} else if (x.isDirectionalLight) {
						const t = e.get(x);
						if (t.color.copy(x.color).multiplyScalar(x.intensity), x.castShadow) {
							const t = x.shadow, e = n.get(x);
							e.shadowIntensity = t.intensity, e.shadowBias = t.bias, e.shadowNormalBias = t.normalBias, e.shadowRadius = t.radius, e.shadowMapSize = t.mapSize, i.directionalShadow[l] = e, i.directionalShadowMap[l] = b, i.directionalShadowMatrix[l] = x.shadow.matrix, p++;
						}
						i.directional[l] = t, l++;
					} else if (x.isSpotLight) {
						const t = e.get(x);
						t.position.setFromMatrixPosition(x.matrixWorld), t.color.copy(y).multiplyScalar(M), t.distance = S, t.coneCos = Math.cos(x.angle), t.penumbraCos = Math.cos(x.angle * (1 - x.penumbra)), t.decay = x.decay, i.spot[h] = t;
						const r = x.shadow;
						if (x.map && (i.spotLightMap[g] = x.map, g++, r.updateMatrices(x), x.castShadow && v++), i.spotLightMatrix[h] = r.matrix, x.castShadow) {
							const t = n.get(x);
							t.shadowIntensity = r.intensity, t.shadowBias = r.bias, t.shadowNormalBias = r.normalBias, t.shadowRadius = r.radius, t.shadowMapSize = r.mapSize, i.spotShadow[h] = t, i.spotShadowMap[h] = b, f++;
						}
						h++;
					} else if (x.isRectAreaLight) {
						const t = e.get(x);
						t.color.copy(y).multiplyScalar(M), t.halfWidth.set(.5 * x.width, 0, 0), t.halfHeight.set(0, .5 * x.height, 0), i.rectArea[u] = t, u++;
					} else if (x.isPointLight) {
						const t = e.get(x);
						if (t.color.copy(x.color).multiplyScalar(x.intensity), t.distance = x.distance, t.decay = x.decay, x.castShadow) {
							const t = x.shadow, e = n.get(x);
							e.shadowIntensity = t.intensity, e.shadowBias = t.bias, e.shadowNormalBias = t.normalBias, e.shadowRadius = t.radius, e.shadowMapSize = t.mapSize, e.shadowCameraNear = t.camera.near, e.shadowCameraFar = t.camera.far, i.pointShadow[c] = e, i.pointShadowMap[c] = b, i.pointShadowMatrix[c] = x.shadow.matrix, m++;
						}
						i.point[c] = t, c++;
					} else if (x.isHemisphereLight) {
						const t = e.get(x);
						t.skyColor.copy(x.color).multiplyScalar(M), t.groundColor.copy(x.groundColor).multiplyScalar(M), i.hemi[d] = t, d++;
					}
				}
				u > 0 && (!0 === t.has("OES_texture_float_linear") ? (i.rectAreaLTC1 = fa.LTC_FLOAT_1, i.rectAreaLTC2 = fa.LTC_FLOAT_2) : (i.rectAreaLTC1 = fa.LTC_HALF_1, i.rectAreaLTC2 = fa.LTC_HALF_2)), i.ambient[0] = s, i.ambient[1] = a, i.ambient[2] = o;
				const x = i.hash;
				x.directionalLength === l && x.pointLength === c && x.spotLength === h && x.rectAreaLength === u && x.hemiLength === d && x.numDirectionalShadows === p && x.numPointShadows === m && x.numSpotShadows === f && x.numSpotMaps === g && x.numLightProbes === _ || (i.directional.length = l, i.spot.length = h, i.rectArea.length = u, i.point.length = c, i.hemi.length = d, i.directionalShadow.length = p, i.directionalShadowMap.length = p, i.pointShadow.length = m, i.pointShadowMap.length = m, i.spotShadow.length = f, i.spotShadowMap.length = f, i.directionalShadowMatrix.length = p, i.pointShadowMatrix.length = m, i.spotLightMatrix.length = f + g - v, i.spotLightMap.length = g, i.numSpotLightShadowsWithMaps = v, i.numLightProbes = _, x.directionalLength = l, x.pointLength = c, x.spotLength = h, x.rectAreaLength = u, x.hemiLength = d, x.numDirectionalShadows = p, x.numPointShadows = m, x.numSpotShadows = f, x.numSpotMaps = g, x.numLightProbes = _, i.version = Nl++);
			},
			setupView: function(t, e) {
				let n = 0, o = 0, l = 0, c = 0, h = 0;
				const u = e.matrixWorldInverse;
				for (let e = 0, d = t.length; e < d; e++) {
					const d = t[e];
					if (d.isDirectionalLight) {
						const t = i.directional[n];
						t.direction.setFromMatrixPosition(d.matrixWorld), r.setFromMatrixPosition(d.target.matrixWorld), t.direction.sub(r), t.direction.transformDirection(u), n++;
					} else if (d.isSpotLight) {
						const t = i.spot[l];
						t.position.setFromMatrixPosition(d.matrixWorld), t.position.applyMatrix4(u), t.direction.setFromMatrixPosition(d.matrixWorld), r.setFromMatrixPosition(d.target.matrixWorld), t.direction.sub(r), t.direction.transformDirection(u), l++;
					} else if (d.isRectAreaLight) {
						const t = i.rectArea[c];
						t.position.setFromMatrixPosition(d.matrixWorld), t.position.applyMatrix4(u), a.identity(), s.copy(d.matrixWorld), s.premultiply(u), a.extractRotation(s), t.halfWidth.set(.5 * d.width, 0, 0), t.halfHeight.set(0, .5 * d.height, 0), t.halfWidth.applyMatrix4(a), t.halfHeight.applyMatrix4(a), c++;
					} else if (d.isPointLight) {
						const t = i.point[o];
						t.position.setFromMatrixPosition(d.matrixWorld), t.position.applyMatrix4(u), o++;
					} else if (d.isHemisphereLight) {
						const t = i.hemi[h];
						t.direction.setFromMatrixPosition(d.matrixWorld), t.direction.transformDirection(u), h++;
					}
				}
			},
			state: i
		};
	}
	function Fl(t) {
		const e = new Ol(t), n = [], i = [];
		const r = {
			lightsArray: n,
			shadowsArray: i,
			camera: null,
			lights: e,
			transmissionRenderTarget: {}
		};
		return {
			init: function(t) {
				r.camera = t, n.length = 0, i.length = 0;
			},
			state: r,
			setupLights: function() {
				e.setup(n);
			},
			setupLightsView: function(t) {
				e.setupView(n, t);
			},
			pushLight: function(t) {
				n.push(t);
			},
			pushShadow: function(t) {
				i.push(t);
			}
		};
	}
	function Bl(t) {
		let e = /* @__PURE__ */ new WeakMap();
		return {
			get: function(n, i = 0) {
				const r = e.get(n);
				let s;
				return void 0 === r ? (s = new Fl(t), e.set(n, [s])) : i >= r.length ? (s = new Fl(t), r.push(s)) : s = r[i], s;
			},
			dispose: function() {
				e = /* @__PURE__ */ new WeakMap();
			}
		};
	}
	var zl = class extends is {
		constructor(t) {
			super(), this.isMeshDepthMaterial = !0, this.type = "MeshDepthMaterial", this.depthPacking = 3200, this.map = null, this.alphaMap = null, this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.wireframe = !1, this.wireframeLinewidth = 1, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.depthPacking = t.depthPacking, this.map = t.map, this.alphaMap = t.alphaMap, this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this;
		}
	};
	var kl = class extends is {
		constructor(t) {
			super(), this.isMeshDistanceMaterial = !0, this.type = "MeshDistanceMaterial", this.map = null, this.alphaMap = null, this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.map = t.map, this.alphaMap = t.alphaMap, this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this;
		}
	};
	function Vl(t, e, n) {
		let i = new ha();
		const r = new ti(), s = new ti(), a = new wi(), o = new zl({ depthPacking: 3201 }), c = new kl(), p = {}, m = n.maxTextureSize, f = {
			[0]: 1,
			[1]: 0,
			2: 2
		}, g = new Ys({
			defines: { VSM_SAMPLES: 8 },
			uniforms: {
				shadow_pass: { value: null },
				resolution: { value: new ti() },
				radius: { value: 4 }
			},
			vertexShader: "void main() {\n	gl_Position = vec4( position, 1.0 );\n}",
			fragmentShader: "uniform sampler2D shadow_pass;\nuniform vec2 resolution;\nuniform float radius;\n#include <packing>\nvoid main() {\n	const float samples = float( VSM_SAMPLES );\n	float mean = 0.0;\n	float squared_mean = 0.0;\n	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );\n	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;\n	for ( float i = 0.0; i < samples; i ++ ) {\n		float uvOffset = uvStart + i * uvStride;\n		#ifdef HORIZONTAL_PASS\n			vec2 distribution = unpackRGBATo2Half( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ) );\n			mean += distribution.x;\n			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;\n		#else\n			float depth = unpackRGBAToDepth( texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ) );\n			mean += depth;\n			squared_mean += depth * depth;\n		#endif\n	}\n	mean = mean / samples;\n	squared_mean = squared_mean / samples;\n	float std_dev = sqrt( squared_mean - mean * mean );\n	gl_FragColor = pack2HalfToRGBA( vec2( mean, std_dev ) );\n}"
		}), v = g.clone();
		v.defines.HORIZONTAL_PASS = 1;
		const _ = new Cs();
		_.setAttribute("position", new ds(new Float32Array([
			-1,
			-1,
			.5,
			3,
			-1,
			.5,
			-1,
			3,
			.5
		]), 3));
		const x = new Vs(_, g), y = this;
		this.enabled = !1, this.autoUpdate = !0, this.needsUpdate = !1, this.type = 1;
		let M = this.type;
		function S(n, i) {
			const s = e.update(x);
			g.defines.VSM_SAMPLES !== n.blurSamples && (g.defines.VSM_SAMPLES = n.blurSamples, v.defines.VSM_SAMPLES = n.blurSamples, g.needsUpdate = !0, v.needsUpdate = !0), null === n.mapPass && (n.mapPass = new Ei(r.x, r.y)), g.uniforms.shadow_pass.value = n.map.texture, g.uniforms.resolution.value = n.mapSize, g.uniforms.radius.value = n.radius, t.setRenderTarget(n.mapPass), t.clear(), t.renderBufferDirect(i, null, s, g, x, null), v.uniforms.shadow_pass.value = n.mapPass.texture, v.uniforms.resolution.value = n.mapSize, v.uniforms.radius.value = n.radius, t.setRenderTarget(n.map), t.clear(), t.renderBufferDirect(i, null, s, v, x, null);
		}
		function b(e, n, i, r) {
			let s = null;
			const a = !0 === i.isPointLight ? e.customDistanceMaterial : e.customDepthMaterial;
			if (void 0 !== a) s = a;
			else if (s = !0 === i.isPointLight ? c : o, t.localClippingEnabled && !0 === n.clipShadows && Array.isArray(n.clippingPlanes) && 0 !== n.clippingPlanes.length || n.displacementMap && 0 !== n.displacementScale || n.alphaMap && n.alphaTest > 0 || n.map && n.alphaTest > 0) {
				const t = s.uuid, e = n.uuid;
				let i = p[t];
				void 0 === i && (i = {}, p[t] = i);
				let r = i[e];
				void 0 === r && (r = s.clone(), i[e] = r, n.addEventListener("dispose", T)), s = r;
			}
			if (s.visible = n.visible, s.wireframe = n.wireframe, s.side = r === 3 ? null !== n.shadowSide ? n.shadowSide : n.side : null !== n.shadowSide ? n.shadowSide : f[n.side], s.alphaMap = n.alphaMap, s.alphaTest = n.alphaTest, s.map = n.map, s.clipShadows = n.clipShadows, s.clippingPlanes = n.clippingPlanes, s.clipIntersection = n.clipIntersection, s.displacementMap = n.displacementMap, s.displacementScale = n.displacementScale, s.displacementBias = n.displacementBias, s.wireframeLinewidth = n.wireframeLinewidth, s.linewidth = n.linewidth, !0 === i.isPointLight && !0 === s.isMeshDistanceMaterial) t.properties.get(s).light = i;
			return s;
		}
		function w(n, r, s, a, o) {
			if (!1 === n.visible) return;
			if (n.layers.test(r.layers) && (n.isMesh || n.isLine || n.isPoints) && (n.castShadow || n.receiveShadow && o === 3) && (!n.frustumCulled || i.intersectsObject(n))) {
				n.modelViewMatrix.multiplyMatrices(s.matrixWorldInverse, n.matrixWorld);
				const i = e.update(n), l = n.material;
				if (Array.isArray(l)) {
					const e = i.groups;
					for (let c = 0, h = e.length; c < h; c++) {
						const h = e[c], u = l[h.materialIndex];
						if (u && u.visible) {
							const e = b(n, u, a, o);
							n.onBeforeShadow(t, n, r, s, i, e, h), t.renderBufferDirect(s, null, i, e, n, h), n.onAfterShadow(t, n, r, s, i, e, h);
						}
					}
				} else if (l.visible) {
					const e = b(n, l, a, o);
					n.onBeforeShadow(t, n, r, s, i, e, null), t.renderBufferDirect(s, null, i, e, n, null), n.onAfterShadow(t, n, r, s, i, e, null);
				}
			}
			const l = n.children;
			for (let t = 0, e = l.length; t < e; t++) w(l[t], r, s, a, o);
		}
		function T(t) {
			t.target.removeEventListener("dispose", T);
			for (const e in p) {
				const n = p[e], i = t.target.uuid;
				if (i in n) n[i].dispose(), delete n[i];
			}
		}
		this.render = function(e, n, o) {
			if (!1 === y.enabled) return;
			if (!1 === y.autoUpdate && !1 === y.needsUpdate) return;
			if (0 === e.length) return;
			const l = t.getRenderTarget(), c = t.getActiveCubeFace(), u = t.getActiveMipmapLevel(), d = t.state;
			d.setBlending(0), d.buffers.color.setClear(1, 1, 1, 1), d.buffers.depth.setTest(!0), d.setScissorTest(!1);
			const p = M !== 3 && this.type === 3, f = M === 3 && this.type !== 3;
			for (let l = 0, c = e.length; l < c; l++) {
				const c = e[l], u = c.shadow;
				if (void 0 === u) {
					console.warn("THREE.WebGLShadowMap:", c, "has no shadow.");
					continue;
				}
				if (!1 === u.autoUpdate && !1 === u.needsUpdate) continue;
				r.copy(u.mapSize);
				const g = u.getFrameExtents();
				if (r.multiply(g), s.copy(u.mapSize), (r.x > m || r.y > m) && (r.x > m && (s.x = Math.floor(m / g.x), r.x = s.x * g.x, u.mapSize.x = s.x), r.y > m && (s.y = Math.floor(m / g.y), r.y = s.y * g.y, u.mapSize.y = s.y)), null === u.map || !0 === p || !0 === f) {
					const t = this.type !== 3 ? {
						minFilter: gt,
						magFilter: gt
					} : {};
					null !== u.map && u.map.dispose(), u.map = new Ei(r.x, r.y, t), u.map.texture.name = c.name + ".shadowMap", u.camera.updateProjectionMatrix();
				}
				t.setRenderTarget(u.map), t.clear();
				const v = u.getViewportCount();
				for (let t = 0; t < v; t++) {
					const e = u.getViewport(t);
					a.set(s.x * e.x, s.y * e.y, s.x * e.z, s.y * e.w), d.viewport(a), u.updateMatrices(c, t), i = u.getFrustum(), w(n, o, u.camera, c, this.type);
				}
				!0 !== u.isPointLightShadow && this.type === 3 && S(u, o), u.needsUpdate = !1;
			}
			M = this.type, y.needsUpdate = !1, t.setRenderTarget(l, c, u);
		};
	}
	const Hl = {
		0: 1,
		2: 6,
		4: 7,
		3: 5,
		1: 0,
		6: 2,
		7: 4,
		5: 3
	};
	function Gl(t) {
		const e = new function() {
			let e = !1;
			const n = new wi();
			let i = null;
			const r = new wi(0, 0, 0, 0);
			return {
				setMask: function(n) {
					i === n || e || (t.colorMask(n, n, n, n), i = n);
				},
				setLocked: function(t) {
					e = t;
				},
				setClear: function(e, i, s, a, o) {
					!0 === o && (e *= a, i *= a, s *= a), n.set(e, i, s, a), !1 === r.equals(n) && (t.clearColor(e, i, s, a), r.copy(n));
				},
				reset: function() {
					e = !1, i = null, r.set(-1, 0, 0, 0);
				}
			};
		}(), n = new function() {
			let e = !1, n = !1, i = null, r = null, s = null;
			return {
				setReversed: function(t) {
					n = t;
				},
				setTest: function(e) {
					e ? G(t.DEPTH_TEST) : W(t.DEPTH_TEST);
				},
				setMask: function(n) {
					i === n || e || (t.depthMask(n), i = n);
				},
				setFunc: function(e) {
					if (n && (e = Hl[e]), r !== e) {
						switch (e) {
							case 0:
								t.depthFunc(t.NEVER);
								break;
							case 1:
								t.depthFunc(t.ALWAYS);
								break;
							case 2:
								t.depthFunc(t.LESS);
								break;
							case 3:
							default:
								t.depthFunc(t.LEQUAL);
								break;
							case 4:
								t.depthFunc(t.EQUAL);
								break;
							case 5:
								t.depthFunc(t.GEQUAL);
								break;
							case 6:
								t.depthFunc(t.GREATER);
								break;
							case 7: t.depthFunc(t.NOTEQUAL);
						}
						r = e;
					}
				},
				setLocked: function(t) {
					e = t;
				},
				setClear: function(e) {
					s !== e && (t.clearDepth(e), s = e);
				},
				reset: function() {
					e = !1, i = null, r = null, s = null;
				}
			};
		}(), i = new function() {
			let e = !1, n = null, i = null, r = null, s = null, a = null, o = null, l = null, c = null;
			return {
				setTest: function(n) {
					e || (n ? G(t.STENCIL_TEST) : W(t.STENCIL_TEST));
				},
				setMask: function(i) {
					n === i || e || (t.stencilMask(i), n = i);
				},
				setFunc: function(e, n, a) {
					i === e && r === n && s === a || (t.stencilFunc(e, n, a), i = e, r = n, s = a);
				},
				setOp: function(e, n, i) {
					a === e && o === n && l === i || (t.stencilOp(e, n, i), a = e, o = n, l = i);
				},
				setLocked: function(t) {
					e = t;
				},
				setClear: function(e) {
					c !== e && (t.clearStencil(e), c = e);
				},
				reset: function() {
					e = !1, n = null, i = null, r = null, s = null, a = null, o = null, l = null, c = null;
				}
			};
		}(), r = /* @__PURE__ */ new WeakMap(), s = /* @__PURE__ */ new WeakMap();
		let a = {}, o = {}, l = /* @__PURE__ */ new WeakMap(), c = [], h = null, u = !1, p = null, m = null, f = null, g = null, v = null, _ = null, x = null, M = new ts(0, 0, 0), S = 0, b = !1, w = null, T = null, E = null, A = null, R = null;
		const I = t.getParameter(t.MAX_COMBINED_TEXTURE_IMAGE_UNITS);
		let L = !1, U = 0;
		const N = t.getParameter(t.VERSION);
		-1 !== N.indexOf("WebGL") ? (U = parseFloat(/^WebGL (\d)/.exec(N)[1]), L = U >= 1) : -1 !== N.indexOf("OpenGL ES") && (U = parseFloat(/^OpenGL ES (\d)/.exec(N)[1]), L = U >= 2);
		let D = null, O = {};
		const F = t.getParameter(t.SCISSOR_BOX), B = t.getParameter(t.VIEWPORT), z = new wi().fromArray(F), k = new wi().fromArray(B);
		function V(e, n, i, r) {
			const s = new Uint8Array(4), a = t.createTexture();
			t.bindTexture(e, a), t.texParameteri(e, t.TEXTURE_MIN_FILTER, t.NEAREST), t.texParameteri(e, t.TEXTURE_MAG_FILTER, t.NEAREST);
			for (let a = 0; a < i; a++) e === t.TEXTURE_3D || e === t.TEXTURE_2D_ARRAY ? t.texImage3D(n, 0, t.RGBA, 1, 1, r, 0, t.RGBA, t.UNSIGNED_BYTE, s) : t.texImage2D(n + a, 0, t.RGBA, 1, 1, 0, t.RGBA, t.UNSIGNED_BYTE, s);
			return a;
		}
		const H = {};
		function G(e) {
			!0 !== a[e] && (t.enable(e), a[e] = !0);
		}
		function W(e) {
			!1 !== a[e] && (t.disable(e), a[e] = !1);
		}
		H[t.TEXTURE_2D] = V(t.TEXTURE_2D, t.TEXTURE_2D, 1), H[t.TEXTURE_CUBE_MAP] = V(t.TEXTURE_CUBE_MAP, t.TEXTURE_CUBE_MAP_POSITIVE_X, 6), H[t.TEXTURE_2D_ARRAY] = V(t.TEXTURE_2D_ARRAY, t.TEXTURE_2D_ARRAY, 1, 1), H[t.TEXTURE_3D] = V(t.TEXTURE_3D, t.TEXTURE_3D, 1, 1), e.setClear(0, 0, 0, 1), n.setClear(1), i.setClear(0), G(t.DEPTH_TEST), n.setFunc(3), Y(!1), Z(1), G(t.CULL_FACE), q(0);
		const X = {
			[100]: t.FUNC_ADD,
			101: t.FUNC_SUBTRACT,
			102: t.FUNC_REVERSE_SUBTRACT
		};
		X[103] = t.MIN, X[104] = t.MAX;
		const j = {
			200: t.ZERO,
			201: t.ONE,
			202: t.SRC_COLOR,
			[204]: t.SRC_ALPHA,
			210: t.SRC_ALPHA_SATURATE,
			208: t.DST_COLOR,
			206: t.DST_ALPHA,
			203: t.ONE_MINUS_SRC_COLOR,
			[205]: t.ONE_MINUS_SRC_ALPHA,
			209: t.ONE_MINUS_DST_COLOR,
			207: t.ONE_MINUS_DST_ALPHA,
			211: t.CONSTANT_COLOR,
			212: t.ONE_MINUS_CONSTANT_COLOR,
			213: t.CONSTANT_ALPHA,
			214: t.ONE_MINUS_CONSTANT_ALPHA
		};
		function q(e, n, i, r, s, a, o, l, c, h) {
			if (0 !== e) {
				if (!1 === u && (G(t.BLEND), u = !0), 5 === e) s = s || n, a = a || i, o = o || r, n === m && s === v || (t.blendEquationSeparate(X[n], X[s]), m = n, v = s), i === f && r === g && a === _ && o === x || (t.blendFuncSeparate(j[i], j[r], j[a], j[o]), f = i, g = r, _ = a, x = o), !1 !== l.equals(M) && c === S || (t.blendColor(l.r, l.g, l.b, c), M.copy(l), S = c), p = e, b = !1;
				else if (e !== p || h !== b) {
					if (m === 100 && v === 100 || (t.blendEquation(t.FUNC_ADD), m = 100, v = 100), h) switch (e) {
						case 1:
							t.blendFuncSeparate(t.ONE, t.ONE_MINUS_SRC_ALPHA, t.ONE, t.ONE_MINUS_SRC_ALPHA);
							break;
						case 2:
							t.blendFunc(t.ONE, t.ONE);
							break;
						case 3:
							t.blendFuncSeparate(t.ZERO, t.ONE_MINUS_SRC_COLOR, t.ZERO, t.ONE);
							break;
						case 4:
							t.blendFuncSeparate(t.ZERO, t.SRC_COLOR, t.ZERO, t.SRC_ALPHA);
							break;
						default: console.error("THREE.WebGLState: Invalid blending: ", e);
					}
					else switch (e) {
						case 1:
							t.blendFuncSeparate(t.SRC_ALPHA, t.ONE_MINUS_SRC_ALPHA, t.ONE, t.ONE_MINUS_SRC_ALPHA);
							break;
						case 2:
							t.blendFunc(t.SRC_ALPHA, t.ONE);
							break;
						case 3:
							t.blendFuncSeparate(t.ZERO, t.ONE_MINUS_SRC_COLOR, t.ZERO, t.ONE);
							break;
						case 4:
							t.blendFunc(t.ZERO, t.SRC_COLOR);
							break;
						default: console.error("THREE.WebGLState: Invalid blending: ", e);
					}
					f = null, g = null, _ = null, x = null, M.set(0, 0, 0), S = 0, p = e, b = h;
				}
			} else !0 === u && (W(t.BLEND), u = !1);
		}
		function Y(e) {
			w !== e && (e ? t.frontFace(t.CW) : t.frontFace(t.CCW), w = e);
		}
		function Z(e) {
			0 !== e ? (G(t.CULL_FACE), e !== T && (1 === e ? t.cullFace(t.BACK) : 2 === e ? t.cullFace(t.FRONT) : t.cullFace(t.FRONT_AND_BACK))) : W(t.CULL_FACE), T = e;
		}
		function J(e, n, i) {
			e ? (G(t.POLYGON_OFFSET_FILL), A === n && R === i || (t.polygonOffset(n, i), A = n, R = i)) : W(t.POLYGON_OFFSET_FILL);
		}
		return {
			buffers: {
				color: e,
				depth: n,
				stencil: i
			},
			enable: G,
			disable: W,
			bindFramebuffer: function(e, n) {
				return o[e] !== n && (t.bindFramebuffer(e, n), o[e] = n, e === t.DRAW_FRAMEBUFFER && (o[t.FRAMEBUFFER] = n), e === t.FRAMEBUFFER && (o[t.DRAW_FRAMEBUFFER] = n), !0);
			},
			drawBuffers: function(e, n) {
				let i = c, r = !1;
				if (e) {
					i = l.get(n), void 0 === i && (i = [], l.set(n, i));
					const s = e.textures;
					if (i.length !== s.length || i[0] !== t.COLOR_ATTACHMENT0) {
						for (let e = 0, n = s.length; e < n; e++) i[e] = t.COLOR_ATTACHMENT0 + e;
						i.length = s.length, r = !0;
					}
				} else i[0] !== t.BACK && (i[0] = t.BACK, r = !0);
				r && t.drawBuffers(i);
			},
			useProgram: function(e) {
				return h !== e && (t.useProgram(e), h = e, !0);
			},
			setBlending: q,
			setMaterial: function(r, s) {
				2 === r.side ? W(t.CULL_FACE) : G(t.CULL_FACE);
				let a = r.side === 1;
				s && (a = !a), Y(a), 1 === r.blending && !1 === r.transparent ? q(0) : q(r.blending, r.blendEquation, r.blendSrc, r.blendDst, r.blendEquationAlpha, r.blendSrcAlpha, r.blendDstAlpha, r.blendColor, r.blendAlpha, r.premultipliedAlpha), n.setFunc(r.depthFunc), n.setTest(r.depthTest), n.setMask(r.depthWrite), e.setMask(r.colorWrite);
				const o = r.stencilWrite;
				i.setTest(o), o && (i.setMask(r.stencilWriteMask), i.setFunc(r.stencilFunc, r.stencilRef, r.stencilFuncMask), i.setOp(r.stencilFail, r.stencilZFail, r.stencilZPass)), J(r.polygonOffset, r.polygonOffsetFactor, r.polygonOffsetUnits), !0 === r.alphaToCoverage ? G(t.SAMPLE_ALPHA_TO_COVERAGE) : W(t.SAMPLE_ALPHA_TO_COVERAGE);
			},
			setFlipSided: Y,
			setCullFace: Z,
			setLineWidth: function(e) {
				e !== E && (L && t.lineWidth(e), E = e);
			},
			setPolygonOffset: J,
			setScissorTest: function(e) {
				e ? G(t.SCISSOR_TEST) : W(t.SCISSOR_TEST);
			},
			activeTexture: function(e) {
				void 0 === e && (e = t.TEXTURE0 + I - 1), D !== e && (t.activeTexture(e), D = e);
			},
			bindTexture: function(e, n, i) {
				void 0 === i && (i = null === D ? t.TEXTURE0 + I - 1 : D);
				let r = O[i];
				void 0 === r && (r = {
					type: void 0,
					texture: void 0
				}, O[i] = r), r.type === e && r.texture === n || (D !== i && (t.activeTexture(i), D = i), t.bindTexture(e, n || H[e]), r.type = e, r.texture = n);
			},
			unbindTexture: function() {
				const e = O[D];
				void 0 !== e && void 0 !== e.type && (t.bindTexture(e.type, null), e.type = void 0, e.texture = void 0);
			},
			compressedTexImage2D: function() {
				try {
					t.compressedTexImage2D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			compressedTexImage3D: function() {
				try {
					t.compressedTexImage3D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			texImage2D: function() {
				try {
					t.texImage2D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			texImage3D: function() {
				try {
					t.texImage3D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			updateUBOMapping: function(e, n) {
				let i = s.get(n);
				void 0 === i && (i = /* @__PURE__ */ new WeakMap(), s.set(n, i));
				let r = i.get(e);
				void 0 === r && (r = t.getUniformBlockIndex(n, e.name), i.set(e, r));
			},
			uniformBlockBinding: function(e, n) {
				const i = s.get(n).get(e);
				r.get(n) !== i && (t.uniformBlockBinding(n, i, e.__bindingPointIndex), r.set(n, i));
			},
			texStorage2D: function() {
				try {
					t.texStorage2D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			texStorage3D: function() {
				try {
					t.texStorage3D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			texSubImage2D: function() {
				try {
					t.texSubImage2D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			texSubImage3D: function() {
				try {
					t.texSubImage3D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			compressedTexSubImage2D: function() {
				try {
					t.compressedTexSubImage2D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			compressedTexSubImage3D: function() {
				try {
					t.compressedTexSubImage3D.apply(t, arguments);
				} catch (t) {
					console.error("THREE.WebGLState:", t);
				}
			},
			scissor: function(e) {
				!1 === z.equals(e) && (t.scissor(e.x, e.y, e.z, e.w), z.copy(e));
			},
			viewport: function(e) {
				!1 === k.equals(e) && (t.viewport(e.x, e.y, e.z, e.w), k.copy(e));
			},
			reset: function() {
				t.disable(t.BLEND), t.disable(t.CULL_FACE), t.disable(t.DEPTH_TEST), t.disable(t.POLYGON_OFFSET_FILL), t.disable(t.SCISSOR_TEST), t.disable(t.STENCIL_TEST), t.disable(t.SAMPLE_ALPHA_TO_COVERAGE), t.blendEquation(t.FUNC_ADD), t.blendFunc(t.ONE, t.ZERO), t.blendFuncSeparate(t.ONE, t.ZERO, t.ONE, t.ZERO), t.blendColor(0, 0, 0, 0), t.colorMask(!0, !0, !0, !0), t.clearColor(0, 0, 0, 0), t.depthMask(!0), t.depthFunc(t.LESS), t.clearDepth(1), t.stencilMask(4294967295), t.stencilFunc(t.ALWAYS, 0, 4294967295), t.stencilOp(t.KEEP, t.KEEP, t.KEEP), t.clearStencil(0), t.cullFace(t.BACK), t.frontFace(t.CCW), t.polygonOffset(0, 0), t.activeTexture(t.TEXTURE0), t.bindFramebuffer(t.FRAMEBUFFER, null), t.bindFramebuffer(t.DRAW_FRAMEBUFFER, null), t.bindFramebuffer(t.READ_FRAMEBUFFER, null), t.useProgram(null), t.lineWidth(1), t.scissor(0, 0, t.canvas.width, t.canvas.height), t.viewport(0, 0, t.canvas.width, t.canvas.height), a = {}, D = null, O = {}, o = {}, l = /* @__PURE__ */ new WeakMap(), c = [], h = null, u = !1, p = null, m = null, f = null, g = null, v = null, _ = null, x = null, M = new ts(0, 0, 0), S = 0, b = !1, w = null, T = null, E = null, A = null, R = null, z.set(0, 0, t.canvas.width, t.canvas.height), k.set(0, 0, t.canvas.width, t.canvas.height), e.reset(), n.reset(), i.reset();
			}
		};
	}
	function Wl(t, e, n, i) {
		const r = function(t) {
			switch (t) {
				case Et:
				case At: return {
					byteLength: 1,
					components: 1
				};
				case Ct:
				case Rt:
				case Ut: return {
					byteLength: 2,
					components: 1
				};
				case Nt:
				case Dt: return {
					byteLength: 2,
					components: 4
				};
				case It:
				case Pt:
				case Lt: return {
					byteLength: 4,
					components: 1
				};
				case Ft: return {
					byteLength: 4,
					components: 3
				};
			}
			throw new Error(`Unknown texture type ${t}.`);
		}(i);
		switch (n) {
			case Bt:
			case Vt: return t * e;
			case Ht: return t * e * 2;
			case Xt:
			case jt: return t * e / r.components * r.byteLength;
			case qt:
			case Yt: return t * e * 2 / r.components * r.byteLength;
			case zt: return t * e * 3 / r.components * r.byteLength;
			case kt:
			case Jt: return t * e * 4 / r.components * r.byteLength;
			case Kt:
			case $t: return Math.floor((t + 3) / 4) * Math.floor((e + 3) / 4) * 8;
			case Qt:
			case te: return Math.floor((t + 3) / 4) * Math.floor((e + 3) / 4) * 16;
			case ne:
			case re: return Math.max(t, 16) * Math.max(e, 8) / 4;
			case ee:
			case ie: return Math.max(t, 8) * Math.max(e, 8) / 2;
			case se:
			case ae: return Math.floor((t + 3) / 4) * Math.floor((e + 3) / 4) * 8;
			case oe:
			case le: return Math.floor((t + 3) / 4) * Math.floor((e + 3) / 4) * 16;
			case ce: return Math.floor((t + 4) / 5) * Math.floor((e + 3) / 4) * 16;
			case he: return Math.floor((t + 4) / 5) * Math.floor((e + 4) / 5) * 16;
			case ue: return Math.floor((t + 5) / 6) * Math.floor((e + 4) / 5) * 16;
			case de: return Math.floor((t + 5) / 6) * Math.floor((e + 5) / 6) * 16;
			case pe: return Math.floor((t + 7) / 8) * Math.floor((e + 4) / 5) * 16;
			case me: return Math.floor((t + 7) / 8) * Math.floor((e + 5) / 6) * 16;
			case fe: return Math.floor((t + 7) / 8) * Math.floor((e + 7) / 8) * 16;
			case ge: return Math.floor((t + 9) / 10) * Math.floor((e + 4) / 5) * 16;
			case ve: return Math.floor((t + 9) / 10) * Math.floor((e + 5) / 6) * 16;
			case _e: return Math.floor((t + 9) / 10) * Math.floor((e + 7) / 8) * 16;
			case xe: return Math.floor((t + 9) / 10) * Math.floor((e + 9) / 10) * 16;
			case ye: return Math.floor((t + 11) / 12) * Math.floor((e + 9) / 10) * 16;
			case Me: return Math.floor((t + 11) / 12) * Math.floor((e + 11) / 12) * 16;
			case Se:
			case be:
			case we: return Math.ceil(t / 4) * Math.ceil(e / 4) * 16;
			case Te:
			case Ee: return Math.ceil(t / 4) * Math.ceil(e / 4) * 8;
			case Ae:
			case Re: return Math.ceil(t / 4) * Math.ceil(e / 4) * 16;
		}
		throw new Error(`Unable to determine texture byte length for ${n} format.`);
	}
	const Xl = {
		contain: function(t, e) {
			const n = t.image && t.image.width ? t.image.width / t.image.height : 1;
			return n > e ? (t.repeat.x = 1, t.repeat.y = n / e, t.offset.x = 0, t.offset.y = (1 - t.repeat.y) / 2) : (t.repeat.x = e / n, t.repeat.y = 1, t.offset.x = (1 - t.repeat.x) / 2, t.offset.y = 0), t;
		},
		cover: function(t, e) {
			const n = t.image && t.image.width ? t.image.width / t.image.height : 1;
			return n > e ? (t.repeat.x = e / n, t.repeat.y = 1, t.offset.x = (1 - t.repeat.x) / 2, t.offset.y = 0) : (t.repeat.x = 1, t.repeat.y = n / e, t.offset.x = 0, t.offset.y = (1 - t.repeat.y) / 2), t;
		},
		fill: function(t) {
			return t.repeat.x = 1, t.repeat.y = 1, t.offset.x = 0, t.offset.y = 0, t;
		},
		getByteLength: Wl
	};
	function jl(t, e, n, i, r, s, a) {
		const o = e.has("WEBGL_multisampled_render_to_texture") ? e.get("WEBGL_multisampled_render_to_texture") : null, l = "undefined" != typeof navigator && /OculusBrowser/g.test(navigator.userAgent), c = new ti(), h = /* @__PURE__ */ new WeakMap();
		let u;
		const d = /* @__PURE__ */ new WeakMap();
		let p = !1;
		try {
			p = "undefined" != typeof OffscreenCanvas && null !== new OffscreenCanvas(1, 1).getContext("2d");
		} catch (t) {}
		function m(t, e) {
			return p ? new OffscreenCanvas(t, e) : ai("canvas");
		}
		function f(t, e, n) {
			let i = 1;
			const r = k(t);
			if ((r.width > n || r.height > n) && (i = n / Math.max(r.width, r.height)), i < 1) {
				if ("undefined" != typeof HTMLImageElement && t instanceof HTMLImageElement || "undefined" != typeof HTMLCanvasElement && t instanceof HTMLCanvasElement || "undefined" != typeof ImageBitmap && t instanceof ImageBitmap || "undefined" != typeof VideoFrame && t instanceof VideoFrame) {
					const n = Math.floor(i * r.width), s = Math.floor(i * r.height);
					void 0 === u && (u = m(n, s));
					const a = e ? m(n, s) : u;
					a.width = n, a.height = s;
					return a.getContext("2d").drawImage(t, 0, 0, n, s), console.warn("THREE.WebGLRenderer: Texture has been resized from (" + r.width + "x" + r.height + ") to (" + n + "x" + s + ")."), a;
				}
				return "data" in t && console.warn("THREE.WebGLRenderer: Image in DataTexture is too big (" + r.width + "x" + r.height + ")."), t;
			}
			return t;
		}
		function g(t) {
			return t.generateMipmaps && t.minFilter !== 1003 && t.minFilter !== 1006;
		}
		function v(e) {
			t.generateMipmap(e);
		}
		function _(n, i, r, s, a = !1) {
			if (null !== n) {
				if (void 0 !== t[n]) return t[n];
				console.warn("THREE.WebGLRenderer: Attempt to use non-existing WebGL internal format '" + n + "'");
			}
			let o = i;
			if (i === t.RED && (r === t.FLOAT && (o = t.R32F), r === t.HALF_FLOAT && (o = t.R16F), r === t.UNSIGNED_BYTE && (o = t.R8)), i === t.RED_INTEGER && (r === t.UNSIGNED_BYTE && (o = t.R8UI), r === t.UNSIGNED_SHORT && (o = t.R16UI), r === t.UNSIGNED_INT && (o = t.R32UI), r === t.BYTE && (o = t.R8I), r === t.SHORT && (o = t.R16I), r === t.INT && (o = t.R32I)), i === t.RG && (r === t.FLOAT && (o = t.RG32F), r === t.HALF_FLOAT && (o = t.RG16F), r === t.UNSIGNED_BYTE && (o = t.RG8)), i === t.RG_INTEGER && (r === t.UNSIGNED_BYTE && (o = t.RG8UI), r === t.UNSIGNED_SHORT && (o = t.RG16UI), r === t.UNSIGNED_INT && (o = t.RG32UI), r === t.BYTE && (o = t.RG8I), r === t.SHORT && (o = t.RG16I), r === t.INT && (o = t.RG32I)), i === t.RGB_INTEGER && (r === t.UNSIGNED_BYTE && (o = t.RGB8UI), r === t.UNSIGNED_SHORT && (o = t.RGB16UI), r === t.UNSIGNED_INT && (o = t.RGB32UI), r === t.BYTE && (o = t.RGB8I), r === t.SHORT && (o = t.RGB16I), r === t.INT && (o = t.RGB32I)), i === t.RGBA_INTEGER && (r === t.UNSIGNED_BYTE && (o = t.RGBA8UI), r === t.UNSIGNED_SHORT && (o = t.RGBA16UI), r === t.UNSIGNED_INT && (o = t.RGBA32UI), r === t.BYTE && (o = t.RGBA8I), r === t.SHORT && (o = t.RGBA16I), r === t.INT && (o = t.RGBA32I)), i === t.RGB && r === t.UNSIGNED_INT_5_9_9_9_REV && (o = t.RGB9_E5), i === t.RGBA) {
				const e = a ? tn : mi.getTransfer(s);
				r === t.FLOAT && (o = t.RGBA32F), r === t.HALF_FLOAT && (o = t.RGBA16F), r === t.UNSIGNED_BYTE && (o = e === "srgb" ? t.SRGB8_ALPHA8 : t.RGBA8), r === t.UNSIGNED_SHORT_4_4_4_4 && (o = t.RGBA4), r === t.UNSIGNED_SHORT_5_5_5_1 && (o = t.RGB5_A1);
			}
			return o !== t.R16F && o !== t.R32F && o !== t.RG16F && o !== t.RG32F && o !== t.RGBA16F && o !== t.RGBA32F || e.get("EXT_color_buffer_float"), o;
		}
		function x(e, n) {
			let i;
			return e ? null === n || n === 1014 || n === 1020 ? i = t.DEPTH24_STENCIL8 : n === 1015 ? i = t.DEPTH32F_STENCIL8 : n === 1012 && (i = t.DEPTH24_STENCIL8, console.warn("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")) : null === n || n === 1014 || n === 1020 ? i = t.DEPTH_COMPONENT24 : n === 1015 ? i = t.DEPTH_COMPONENT32F : n === 1012 && (i = t.DEPTH_COMPONENT16), i;
		}
		function y(t, e) {
			return !0 === g(t) || t.isFramebufferTexture && t.minFilter !== 1003 && t.minFilter !== 1006 ? Math.log2(Math.max(e.width, e.height)) + 1 : void 0 !== t.mipmaps && t.mipmaps.length > 0 ? t.mipmaps.length : t.isCompressedTexture && Array.isArray(t.image) ? e.mipmaps.length : 1;
		}
		function M(t) {
			const e = t.target;
			e.removeEventListener("dispose", M), function(t) {
				const e = i.get(t);
				if (void 0 === e.__webglInit) return;
				const n = t.source, r = d.get(n);
				if (r) {
					const i = r[e.__cacheKey];
					i.usedTimes--, 0 === i.usedTimes && b(t), 0 === Object.keys(r).length && d.delete(n);
				}
				i.remove(t);
			}(e), e.isVideoTexture && h.delete(e);
		}
		function S(e) {
			const n = e.target;
			n.removeEventListener("dispose", S), function(e) {
				const n = i.get(e);
				e.depthTexture && e.depthTexture.dispose();
				if (e.isWebGLCubeRenderTarget) for (let e = 0; e < 6; e++) {
					if (Array.isArray(n.__webglFramebuffer[e])) for (let i = 0; i < n.__webglFramebuffer[e].length; i++) t.deleteFramebuffer(n.__webglFramebuffer[e][i]);
					else t.deleteFramebuffer(n.__webglFramebuffer[e]);
					n.__webglDepthbuffer && t.deleteRenderbuffer(n.__webglDepthbuffer[e]);
				}
				else {
					if (Array.isArray(n.__webglFramebuffer)) for (let e = 0; e < n.__webglFramebuffer.length; e++) t.deleteFramebuffer(n.__webglFramebuffer[e]);
					else t.deleteFramebuffer(n.__webglFramebuffer);
					if (n.__webglDepthbuffer && t.deleteRenderbuffer(n.__webglDepthbuffer), n.__webglMultisampledFramebuffer && t.deleteFramebuffer(n.__webglMultisampledFramebuffer), n.__webglColorRenderbuffer) for (let e = 0; e < n.__webglColorRenderbuffer.length; e++) n.__webglColorRenderbuffer[e] && t.deleteRenderbuffer(n.__webglColorRenderbuffer[e]);
					n.__webglDepthRenderbuffer && t.deleteRenderbuffer(n.__webglDepthRenderbuffer);
				}
				const r = e.textures;
				for (let e = 0, n = r.length; e < n; e++) {
					const n = i.get(r[e]);
					n.__webglTexture && (t.deleteTexture(n.__webglTexture), a.memory.textures--), i.remove(r[e]);
				}
				i.remove(e);
			}(n);
		}
		function b(e) {
			const n = i.get(e);
			t.deleteTexture(n.__webglTexture);
			const r = e.source;
			delete d.get(r)[n.__cacheKey], a.memory.textures--;
		}
		let w = 0;
		function T(e, r) {
			const s = i.get(e);
			if (e.isVideoTexture && function(t) {
				const e = a.render.frame;
				h.get(t) !== e && (h.set(t, e), t.update());
			}(e), !1 === e.isRenderTargetTexture && e.version > 0 && s.__version !== e.version) {
				const t = e.image;
				if (null === t) console.warn("THREE.WebGLRenderer: Texture marked for update but no image data found.");
				else {
					if (!1 !== t.complete) return void I(s, e, r);
					console.warn("THREE.WebGLRenderer: Texture marked for update but image is incomplete");
				}
			}
			n.bindTexture(t.TEXTURE_2D, s.__webglTexture, t.TEXTURE0 + r);
		}
		const E = {
			[pt]: t.REPEAT,
			[mt]: t.CLAMP_TO_EDGE,
			[ft]: t.MIRRORED_REPEAT
		}, A = {
			[gt]: t.NEAREST,
			[vt]: t.NEAREST_MIPMAP_NEAREST,
			[xt]: t.NEAREST_MIPMAP_LINEAR,
			[Mt]: t.LINEAR,
			[St]: t.LINEAR_MIPMAP_NEAREST,
			[wt]: t.LINEAR_MIPMAP_LINEAR
		}, R = {
			512: t.NEVER,
			519: t.ALWAYS,
			513: t.LESS,
			[515]: t.LEQUAL,
			514: t.EQUAL,
			518: t.GEQUAL,
			516: t.GREATER,
			517: t.NOTEQUAL
		};
		function C(n, s) {
			if (s.type !== 1015 || !1 !== e.has("OES_texture_float_linear") || s.magFilter !== 1006 && s.magFilter !== 1007 && s.magFilter !== 1005 && s.magFilter !== 1008 && s.minFilter !== 1006 && s.minFilter !== 1007 && s.minFilter !== 1005 && s.minFilter !== 1008 || console.warn("THREE.WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."), t.texParameteri(n, t.TEXTURE_WRAP_S, E[s.wrapS]), t.texParameteri(n, t.TEXTURE_WRAP_T, E[s.wrapT]), n !== t.TEXTURE_3D && n !== t.TEXTURE_2D_ARRAY || t.texParameteri(n, t.TEXTURE_WRAP_R, E[s.wrapR]), t.texParameteri(n, t.TEXTURE_MAG_FILTER, A[s.magFilter]), t.texParameteri(n, t.TEXTURE_MIN_FILTER, A[s.minFilter]), s.compareFunction && (t.texParameteri(n, t.TEXTURE_COMPARE_MODE, t.COMPARE_REF_TO_TEXTURE), t.texParameteri(n, t.TEXTURE_COMPARE_FUNC, R[s.compareFunction])), !0 === e.has("EXT_texture_filter_anisotropic")) {
				if (s.magFilter === 1003) return;
				if (s.minFilter !== 1005 && s.minFilter !== 1008) return;
				if (s.type === 1015 && !1 === e.has("OES_texture_float_linear")) return;
				if (s.anisotropy > 1 || i.get(s).__currentAnisotropy) {
					const a = e.get("EXT_texture_filter_anisotropic");
					t.texParameterf(n, a.TEXTURE_MAX_ANISOTROPY_EXT, Math.min(s.anisotropy, r.getMaxAnisotropy())), i.get(s).__currentAnisotropy = s.anisotropy;
				}
			}
		}
		function P(e, n) {
			let i = !1;
			void 0 === e.__webglInit && (e.__webglInit = !0, n.addEventListener("dispose", M));
			const r = n.source;
			let s = d.get(r);
			void 0 === s && (s = {}, d.set(r, s));
			const o = function(t) {
				const e = [];
				return e.push(t.wrapS), e.push(t.wrapT), e.push(t.wrapR || 0), e.push(t.magFilter), e.push(t.minFilter), e.push(t.anisotropy), e.push(t.internalFormat), e.push(t.format), e.push(t.type), e.push(t.generateMipmaps), e.push(t.premultiplyAlpha), e.push(t.flipY), e.push(t.unpackAlignment), e.push(t.colorSpace), e.join();
			}(n);
			if (o !== e.__cacheKey) {
				void 0 === s[o] && (s[o] = {
					texture: t.createTexture(),
					usedTimes: 0
				}, a.memory.textures++, i = !0), s[o].usedTimes++;
				const r = s[e.__cacheKey];
				void 0 !== r && (s[e.__cacheKey].usedTimes--, 0 === r.usedTimes && b(n)), e.__cacheKey = o, e.__webglTexture = s[o].texture;
			}
			return i;
		}
		function I(e, a, o) {
			let l = t.TEXTURE_2D;
			(a.isDataArrayTexture || a.isCompressedArrayTexture) && (l = t.TEXTURE_2D_ARRAY), a.isData3DTexture && (l = t.TEXTURE_3D);
			const c = P(e, a), h = a.source;
			n.bindTexture(l, e.__webglTexture, t.TEXTURE0 + o);
			const u = i.get(h);
			if (h.version !== u.__version || !0 === c) {
				n.activeTexture(t.TEXTURE0 + o);
				const e = mi.getPrimaries(mi.workingColorSpace), i = a.colorSpace === "" ? null : mi.getPrimaries(a.colorSpace), d = a.colorSpace === "" || e === i ? t.NONE : t.BROWSER_DEFAULT_WEBGL;
				t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, a.flipY), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, a.premultiplyAlpha), t.pixelStorei(t.UNPACK_ALIGNMENT, a.unpackAlignment), t.pixelStorei(t.UNPACK_COLORSPACE_CONVERSION_WEBGL, d);
				let p = f(a.image, !1, r.maxTextureSize);
				p = z(a, p);
				const m = s.convert(a.format, a.colorSpace), M = s.convert(a.type);
				let S, b = _(a.internalFormat, m, M, a.colorSpace, a.isVideoTexture);
				C(l, a);
				const w = a.mipmaps, T = !0 !== a.isVideoTexture, E = void 0 === u.__version || !0 === c, A = h.dataReady, R = y(a, p);
				if (a.isDepthTexture) b = x(a.format === Wt, a.type), E && (T ? n.texStorage2D(t.TEXTURE_2D, 1, b, p.width, p.height) : n.texImage2D(t.TEXTURE_2D, 0, b, p.width, p.height, 0, m, M, null));
				else if (a.isDataTexture) if (w.length > 0) {
					T && E && n.texStorage2D(t.TEXTURE_2D, R, b, w[0].width, w[0].height);
					for (let e = 0, i = w.length; e < i; e++) S = w[e], T ? A && n.texSubImage2D(t.TEXTURE_2D, e, 0, 0, S.width, S.height, m, M, S.data) : n.texImage2D(t.TEXTURE_2D, e, b, S.width, S.height, 0, m, M, S.data);
					a.generateMipmaps = !1;
				} else T ? (E && n.texStorage2D(t.TEXTURE_2D, R, b, p.width, p.height), A && n.texSubImage2D(t.TEXTURE_2D, 0, 0, 0, p.width, p.height, m, M, p.data)) : n.texImage2D(t.TEXTURE_2D, 0, b, p.width, p.height, 0, m, M, p.data);
				else if (a.isCompressedTexture) if (a.isCompressedArrayTexture) {
					T && E && n.texStorage3D(t.TEXTURE_2D_ARRAY, R, b, w[0].width, w[0].height, p.depth);
					for (let e = 0, i = w.length; e < i; e++) if (S = w[e], a.format !== 1023) if (null !== m) if (T) {
						if (A) if (a.layerUpdates.size > 0) {
							const i = Wl(S.width, S.height, a.format, a.type);
							for (const r of a.layerUpdates) {
								const s = S.data.subarray(r * i / S.data.BYTES_PER_ELEMENT, (r + 1) * i / S.data.BYTES_PER_ELEMENT);
								n.compressedTexSubImage3D(t.TEXTURE_2D_ARRAY, e, 0, 0, r, S.width, S.height, 1, m, s, 0, 0);
							}
							a.clearLayerUpdates();
						} else n.compressedTexSubImage3D(t.TEXTURE_2D_ARRAY, e, 0, 0, 0, S.width, S.height, p.depth, m, S.data, 0, 0);
					} else n.compressedTexImage3D(t.TEXTURE_2D_ARRAY, e, b, S.width, S.height, p.depth, 0, S.data, 0, 0);
					else console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");
					else T ? A && n.texSubImage3D(t.TEXTURE_2D_ARRAY, e, 0, 0, 0, S.width, S.height, p.depth, m, M, S.data) : n.texImage3D(t.TEXTURE_2D_ARRAY, e, b, S.width, S.height, p.depth, 0, m, M, S.data);
				} else {
					T && E && n.texStorage2D(t.TEXTURE_2D, R, b, w[0].width, w[0].height);
					for (let e = 0, i = w.length; e < i; e++) S = w[e], a.format !== 1023 ? null !== m ? T ? A && n.compressedTexSubImage2D(t.TEXTURE_2D, e, 0, 0, S.width, S.height, m, S.data) : n.compressedTexImage2D(t.TEXTURE_2D, e, b, S.width, S.height, 0, S.data) : console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()") : T ? A && n.texSubImage2D(t.TEXTURE_2D, e, 0, 0, S.width, S.height, m, M, S.data) : n.texImage2D(t.TEXTURE_2D, e, b, S.width, S.height, 0, m, M, S.data);
				}
				else if (a.isDataArrayTexture) if (T) {
					if (E && n.texStorage3D(t.TEXTURE_2D_ARRAY, R, b, p.width, p.height, p.depth), A) if (a.layerUpdates.size > 0) {
						const e = Wl(p.width, p.height, a.format, a.type);
						for (const i of a.layerUpdates) {
							const r = p.data.subarray(i * e / p.data.BYTES_PER_ELEMENT, (i + 1) * e / p.data.BYTES_PER_ELEMENT);
							n.texSubImage3D(t.TEXTURE_2D_ARRAY, 0, 0, 0, i, p.width, p.height, 1, m, M, r);
						}
						a.clearLayerUpdates();
					} else n.texSubImage3D(t.TEXTURE_2D_ARRAY, 0, 0, 0, 0, p.width, p.height, p.depth, m, M, p.data);
				} else n.texImage3D(t.TEXTURE_2D_ARRAY, 0, b, p.width, p.height, p.depth, 0, m, M, p.data);
				else if (a.isData3DTexture) T ? (E && n.texStorage3D(t.TEXTURE_3D, R, b, p.width, p.height, p.depth), A && n.texSubImage3D(t.TEXTURE_3D, 0, 0, 0, 0, p.width, p.height, p.depth, m, M, p.data)) : n.texImage3D(t.TEXTURE_3D, 0, b, p.width, p.height, p.depth, 0, m, M, p.data);
				else if (a.isFramebufferTexture) {
					if (E) if (T) n.texStorage2D(t.TEXTURE_2D, R, b, p.width, p.height);
					else {
						let e = p.width, i = p.height;
						for (let r = 0; r < R; r++) n.texImage2D(t.TEXTURE_2D, r, b, e, i, 0, m, M, null), e >>= 1, i >>= 1;
					}
				} else if (w.length > 0) {
					if (T && E) {
						const e = k(w[0]);
						n.texStorage2D(t.TEXTURE_2D, R, b, e.width, e.height);
					}
					for (let e = 0, i = w.length; e < i; e++) S = w[e], T ? A && n.texSubImage2D(t.TEXTURE_2D, e, 0, 0, m, M, S) : n.texImage2D(t.TEXTURE_2D, e, b, m, M, S);
					a.generateMipmaps = !1;
				} else if (T) {
					if (E) {
						const e = k(p);
						n.texStorage2D(t.TEXTURE_2D, R, b, e.width, e.height);
					}
					A && n.texSubImage2D(t.TEXTURE_2D, 0, 0, 0, m, M, p);
				} else n.texImage2D(t.TEXTURE_2D, 0, b, m, M, p);
				g(a) && v(l), u.__version = h.version, a.onUpdate && a.onUpdate(a);
			}
			e.__version = a.version;
		}
		function L(e, r, a, l, c, h) {
			const u = s.convert(a.format, a.colorSpace), d = s.convert(a.type), p = _(a.internalFormat, u, d, a.colorSpace);
			if (!i.get(r).__hasExternalTextures) {
				const e = Math.max(1, r.width >> h), i = Math.max(1, r.height >> h);
				c === t.TEXTURE_3D || c === t.TEXTURE_2D_ARRAY ? n.texImage3D(c, h, p, e, i, r.depth, 0, u, d, null) : n.texImage2D(c, h, p, e, i, 0, u, d, null);
			}
			n.bindFramebuffer(t.FRAMEBUFFER, e), B(r) ? o.framebufferTexture2DMultisampleEXT(t.FRAMEBUFFER, l, c, i.get(a).__webglTexture, 0, F(r)) : (c === t.TEXTURE_2D || c >= t.TEXTURE_CUBE_MAP_POSITIVE_X && c <= t.TEXTURE_CUBE_MAP_NEGATIVE_Z) && t.framebufferTexture2D(t.FRAMEBUFFER, l, c, i.get(a).__webglTexture, h), n.bindFramebuffer(t.FRAMEBUFFER, null);
		}
		function U(e, n, i) {
			if (t.bindRenderbuffer(t.RENDERBUFFER, e), n.depthBuffer) {
				const r = n.depthTexture, s = r && r.isDepthTexture ? r.type : null, a = x(n.stencilBuffer, s), l = n.stencilBuffer ? t.DEPTH_STENCIL_ATTACHMENT : t.DEPTH_ATTACHMENT, c = F(n);
				B(n) ? o.renderbufferStorageMultisampleEXT(t.RENDERBUFFER, c, a, n.width, n.height) : i ? t.renderbufferStorageMultisample(t.RENDERBUFFER, c, a, n.width, n.height) : t.renderbufferStorage(t.RENDERBUFFER, a, n.width, n.height), t.framebufferRenderbuffer(t.FRAMEBUFFER, l, t.RENDERBUFFER, e);
			} else {
				const e = n.textures;
				for (let r = 0; r < e.length; r++) {
					const a = e[r], l = s.convert(a.format, a.colorSpace), c = s.convert(a.type), h = _(a.internalFormat, l, c, a.colorSpace), u = F(n);
					i && !1 === B(n) ? t.renderbufferStorageMultisample(t.RENDERBUFFER, u, h, n.width, n.height) : B(n) ? o.renderbufferStorageMultisampleEXT(t.RENDERBUFFER, u, h, n.width, n.height) : t.renderbufferStorage(t.RENDERBUFFER, h, n.width, n.height);
				}
			}
			t.bindRenderbuffer(t.RENDERBUFFER, null);
		}
		function N(e) {
			const r = i.get(e), s = !0 === e.isWebGLCubeRenderTarget;
			if (r.__boundDepthTexture !== e.depthTexture) {
				const t = e.depthTexture;
				if (r.__depthDisposeCallback && r.__depthDisposeCallback(), t) {
					const e = () => {
						delete r.__boundDepthTexture, delete r.__depthDisposeCallback, t.removeEventListener("dispose", e);
					};
					t.addEventListener("dispose", e), r.__depthDisposeCallback = e;
				}
				r.__boundDepthTexture = t;
			}
			if (e.depthTexture && !r.__autoAllocateDepthBuffer) {
				if (s) throw new Error("target.depthTexture not supported in Cube render targets");
				(function(e, r) {
					if (r && r.isWebGLCubeRenderTarget) throw new Error("Depth Texture with cube render targets is not supported");
					if (n.bindFramebuffer(t.FRAMEBUFFER, e), !r.depthTexture || !r.depthTexture.isDepthTexture) throw new Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");
					i.get(r.depthTexture).__webglTexture && r.depthTexture.image.width === r.width && r.depthTexture.image.height === r.height || (r.depthTexture.image.width = r.width, r.depthTexture.image.height = r.height, r.depthTexture.needsUpdate = !0), T(r.depthTexture, 0);
					const s = i.get(r.depthTexture).__webglTexture, a = F(r);
					if (r.depthTexture.format === 1026) B(r) ? o.framebufferTexture2DMultisampleEXT(t.FRAMEBUFFER, t.DEPTH_ATTACHMENT, t.TEXTURE_2D, s, 0, a) : t.framebufferTexture2D(t.FRAMEBUFFER, t.DEPTH_ATTACHMENT, t.TEXTURE_2D, s, 0);
					else {
						if (r.depthTexture.format !== 1027) throw new Error("Unknown depthTexture format");
						B(r) ? o.framebufferTexture2DMultisampleEXT(t.FRAMEBUFFER, t.DEPTH_STENCIL_ATTACHMENT, t.TEXTURE_2D, s, 0, a) : t.framebufferTexture2D(t.FRAMEBUFFER, t.DEPTH_STENCIL_ATTACHMENT, t.TEXTURE_2D, s, 0);
					}
				})(r.__webglFramebuffer, e);
			} else if (s) {
				r.__webglDepthbuffer = [];
				for (let i = 0; i < 6; i++) if (n.bindFramebuffer(t.FRAMEBUFFER, r.__webglFramebuffer[i]), void 0 === r.__webglDepthbuffer[i]) r.__webglDepthbuffer[i] = t.createRenderbuffer(), U(r.__webglDepthbuffer[i], e, !1);
				else {
					const n = e.stencilBuffer ? t.DEPTH_STENCIL_ATTACHMENT : t.DEPTH_ATTACHMENT, s = r.__webglDepthbuffer[i];
					t.bindRenderbuffer(t.RENDERBUFFER, s), t.framebufferRenderbuffer(t.FRAMEBUFFER, n, t.RENDERBUFFER, s);
				}
			} else if (n.bindFramebuffer(t.FRAMEBUFFER, r.__webglFramebuffer), void 0 === r.__webglDepthbuffer) r.__webglDepthbuffer = t.createRenderbuffer(), U(r.__webglDepthbuffer, e, !1);
			else {
				const n = e.stencilBuffer ? t.DEPTH_STENCIL_ATTACHMENT : t.DEPTH_ATTACHMENT, i = r.__webglDepthbuffer;
				t.bindRenderbuffer(t.RENDERBUFFER, i), t.framebufferRenderbuffer(t.FRAMEBUFFER, n, t.RENDERBUFFER, i);
			}
			n.bindFramebuffer(t.FRAMEBUFFER, null);
		}
		const D = [], O = [];
		function F(t) {
			return Math.min(r.maxSamples, t.samples);
		}
		function B(t) {
			const n = i.get(t);
			return t.samples > 0 && !0 === e.has("WEBGL_multisampled_render_to_texture") && !1 !== n.__useRenderToTexture;
		}
		function z(t, e) {
			const n = t.colorSpace, i = t.format, r = t.type;
			return !0 === t.isCompressedTexture || !0 === t.isVideoTexture || n !== "srgb-linear" && n !== "" && (mi.getTransfer(n) === "srgb" ? i === 1023 && r === 1009 || console.warn("THREE.WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType.") : console.error("THREE.WebGLTextures: Unsupported texture color space:", n)), e;
		}
		function k(t) {
			return "undefined" != typeof HTMLImageElement && t instanceof HTMLImageElement ? (c.width = t.naturalWidth || t.width, c.height = t.naturalHeight || t.height) : "undefined" != typeof VideoFrame && t instanceof VideoFrame ? (c.width = t.displayWidth, c.height = t.displayHeight) : (c.width = t.width, c.height = t.height), c;
		}
		this.allocateTextureUnit = function() {
			const t = w;
			return t >= r.maxTextures && console.warn("THREE.WebGLTextures: Trying to use " + t + " texture units while this GPU supports only " + r.maxTextures), w += 1, t;
		}, this.resetTextureUnits = function() {
			w = 0;
		}, this.setTexture2D = T, this.setTexture2DArray = function(e, r) {
			const s = i.get(e);
			e.version > 0 && s.__version !== e.version ? I(s, e, r) : n.bindTexture(t.TEXTURE_2D_ARRAY, s.__webglTexture, t.TEXTURE0 + r);
		}, this.setTexture3D = function(e, r) {
			const s = i.get(e);
			e.version > 0 && s.__version !== e.version ? I(s, e, r) : n.bindTexture(t.TEXTURE_3D, s.__webglTexture, t.TEXTURE0 + r);
		}, this.setTextureCube = function(e, a) {
			const o = i.get(e);
			e.version > 0 && o.__version !== e.version ? function(e, a, o) {
				if (6 !== a.image.length) return;
				const l = P(e, a), c = a.source;
				n.bindTexture(t.TEXTURE_CUBE_MAP, e.__webglTexture, t.TEXTURE0 + o);
				const h = i.get(c);
				if (c.version !== h.__version || !0 === l) {
					n.activeTexture(t.TEXTURE0 + o);
					const e = mi.getPrimaries(mi.workingColorSpace), i = a.colorSpace === "" ? null : mi.getPrimaries(a.colorSpace), u = a.colorSpace === "" || e === i ? t.NONE : t.BROWSER_DEFAULT_WEBGL;
					t.pixelStorei(t.UNPACK_FLIP_Y_WEBGL, a.flipY), t.pixelStorei(t.UNPACK_PREMULTIPLY_ALPHA_WEBGL, a.premultiplyAlpha), t.pixelStorei(t.UNPACK_ALIGNMENT, a.unpackAlignment), t.pixelStorei(t.UNPACK_COLORSPACE_CONVERSION_WEBGL, u);
					const d = a.isCompressedTexture || a.image[0].isCompressedTexture, p = a.image[0] && a.image[0].isDataTexture, m = [];
					for (let t = 0; t < 6; t++) m[t] = d || p ? p ? a.image[t].image : a.image[t] : f(a.image[t], !0, r.maxCubemapSize), m[t] = z(a, m[t]);
					const x = m[0], M = s.convert(a.format, a.colorSpace), S = s.convert(a.type), b = _(a.internalFormat, M, S, a.colorSpace), w = !0 !== a.isVideoTexture, T = void 0 === h.__version || !0 === l, E = c.dataReady;
					let A, R = y(a, x);
					if (C(t.TEXTURE_CUBE_MAP, a), d) {
						w && T && n.texStorage2D(t.TEXTURE_CUBE_MAP, R, b, x.width, x.height);
						for (let e = 0; e < 6; e++) {
							A = m[e].mipmaps;
							for (let i = 0; i < A.length; i++) {
								const r = A[i];
								a.format !== 1023 ? null !== M ? w ? E && n.compressedTexSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, i, 0, 0, r.width, r.height, M, r.data) : n.compressedTexImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, i, b, r.width, r.height, 0, r.data) : console.warn("THREE.WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()") : w ? E && n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, i, 0, 0, r.width, r.height, M, S, r.data) : n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, i, b, r.width, r.height, 0, M, S, r.data);
							}
						}
					} else {
						if (A = a.mipmaps, w && T) {
							A.length > 0 && R++;
							const e = k(m[0]);
							n.texStorage2D(t.TEXTURE_CUBE_MAP, R, b, e.width, e.height);
						}
						for (let e = 0; e < 6; e++) if (p) {
							w ? E && n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, 0, 0, 0, m[e].width, m[e].height, M, S, m[e].data) : n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, 0, b, m[e].width, m[e].height, 0, M, S, m[e].data);
							for (let i = 0; i < A.length; i++) {
								const r = A[i].image[e].image;
								w ? E && n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, i + 1, 0, 0, r.width, r.height, M, S, r.data) : n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, i + 1, b, r.width, r.height, 0, M, S, r.data);
							}
						} else {
							w ? E && n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, 0, 0, 0, M, S, m[e]) : n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, 0, b, M, S, m[e]);
							for (let i = 0; i < A.length; i++) {
								const r = A[i];
								w ? E && n.texSubImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, i + 1, 0, 0, M, S, r.image[e]) : n.texImage2D(t.TEXTURE_CUBE_MAP_POSITIVE_X + e, i + 1, b, M, S, r.image[e]);
							}
						}
					}
					g(a) && v(t.TEXTURE_CUBE_MAP), h.__version = c.version, a.onUpdate && a.onUpdate(a);
				}
				e.__version = a.version;
			}(o, e, a) : n.bindTexture(t.TEXTURE_CUBE_MAP, o.__webglTexture, t.TEXTURE0 + a);
		}, this.rebindTextures = function(e, n, r) {
			const s = i.get(e);
			void 0 !== n && L(s.__webglFramebuffer, e, e.texture, t.COLOR_ATTACHMENT0, t.TEXTURE_2D, 0), void 0 !== r && N(e);
		}, this.setupRenderTarget = function(e) {
			const r = e.texture, o = i.get(e), l = i.get(r);
			e.addEventListener("dispose", S);
			const c = e.textures, h = !0 === e.isWebGLCubeRenderTarget, u = c.length > 1;
			if (u || (void 0 === l.__webglTexture && (l.__webglTexture = t.createTexture()), l.__version = r.version, a.memory.textures++), h) {
				o.__webglFramebuffer = [];
				for (let e = 0; e < 6; e++) if (r.mipmaps && r.mipmaps.length > 0) {
					o.__webglFramebuffer[e] = [];
					for (let n = 0; n < r.mipmaps.length; n++) o.__webglFramebuffer[e][n] = t.createFramebuffer();
				} else o.__webglFramebuffer[e] = t.createFramebuffer();
			} else {
				if (r.mipmaps && r.mipmaps.length > 0) {
					o.__webglFramebuffer = [];
					for (let e = 0; e < r.mipmaps.length; e++) o.__webglFramebuffer[e] = t.createFramebuffer();
				} else o.__webglFramebuffer = t.createFramebuffer();
				if (u) for (let e = 0, n = c.length; e < n; e++) {
					const n = i.get(c[e]);
					void 0 === n.__webglTexture && (n.__webglTexture = t.createTexture(), a.memory.textures++);
				}
				if (e.samples > 0 && !1 === B(e)) {
					o.__webglMultisampledFramebuffer = t.createFramebuffer(), o.__webglColorRenderbuffer = [], n.bindFramebuffer(t.FRAMEBUFFER, o.__webglMultisampledFramebuffer);
					for (let n = 0; n < c.length; n++) {
						const i = c[n];
						o.__webglColorRenderbuffer[n] = t.createRenderbuffer(), t.bindRenderbuffer(t.RENDERBUFFER, o.__webglColorRenderbuffer[n]);
						const r = s.convert(i.format, i.colorSpace), a = s.convert(i.type), l = _(i.internalFormat, r, a, i.colorSpace, !0 === e.isXRRenderTarget), h = F(e);
						t.renderbufferStorageMultisample(t.RENDERBUFFER, h, l, e.width, e.height), t.framebufferRenderbuffer(t.FRAMEBUFFER, t.COLOR_ATTACHMENT0 + n, t.RENDERBUFFER, o.__webglColorRenderbuffer[n]);
					}
					t.bindRenderbuffer(t.RENDERBUFFER, null), e.depthBuffer && (o.__webglDepthRenderbuffer = t.createRenderbuffer(), U(o.__webglDepthRenderbuffer, e, !0)), n.bindFramebuffer(t.FRAMEBUFFER, null);
				}
			}
			if (h) {
				n.bindTexture(t.TEXTURE_CUBE_MAP, l.__webglTexture), C(t.TEXTURE_CUBE_MAP, r);
				for (let n = 0; n < 6; n++) if (r.mipmaps && r.mipmaps.length > 0) for (let i = 0; i < r.mipmaps.length; i++) L(o.__webglFramebuffer[n][i], e, r, t.COLOR_ATTACHMENT0, t.TEXTURE_CUBE_MAP_POSITIVE_X + n, i);
				else L(o.__webglFramebuffer[n], e, r, t.COLOR_ATTACHMENT0, t.TEXTURE_CUBE_MAP_POSITIVE_X + n, 0);
				g(r) && v(t.TEXTURE_CUBE_MAP), n.unbindTexture();
			} else if (u) {
				for (let r = 0, s = c.length; r < s; r++) {
					const s = c[r], a = i.get(s);
					n.bindTexture(t.TEXTURE_2D, a.__webglTexture), C(t.TEXTURE_2D, s), L(o.__webglFramebuffer, e, s, t.COLOR_ATTACHMENT0 + r, t.TEXTURE_2D, 0), g(s) && v(t.TEXTURE_2D);
				}
				n.unbindTexture();
			} else {
				let i = t.TEXTURE_2D;
				if ((e.isWebGL3DRenderTarget || e.isWebGLArrayRenderTarget) && (i = e.isWebGL3DRenderTarget ? t.TEXTURE_3D : t.TEXTURE_2D_ARRAY), n.bindTexture(i, l.__webglTexture), C(i, r), r.mipmaps && r.mipmaps.length > 0) for (let n = 0; n < r.mipmaps.length; n++) L(o.__webglFramebuffer[n], e, r, t.COLOR_ATTACHMENT0, i, n);
				else L(o.__webglFramebuffer, e, r, t.COLOR_ATTACHMENT0, i, 0);
				g(r) && v(i), n.unbindTexture();
			}
			e.depthBuffer && N(e);
		}, this.updateRenderTargetMipmap = function(e) {
			const r = e.textures;
			for (let s = 0, a = r.length; s < a; s++) {
				const a = r[s];
				if (g(a)) {
					const r = e.isWebGLCubeRenderTarget ? t.TEXTURE_CUBE_MAP : t.TEXTURE_2D, s = i.get(a).__webglTexture;
					n.bindTexture(r, s), v(r), n.unbindTexture();
				}
			}
		}, this.updateMultisampleRenderTarget = function(e) {
			if (e.samples > 0) {
				if (!1 === B(e)) {
					const r = e.textures, s = e.width, a = e.height;
					let o = t.COLOR_BUFFER_BIT;
					const c = e.stencilBuffer ? t.DEPTH_STENCIL_ATTACHMENT : t.DEPTH_ATTACHMENT, h = i.get(e), u = r.length > 1;
					if (u) for (let e = 0; e < r.length; e++) n.bindFramebuffer(t.FRAMEBUFFER, h.__webglMultisampledFramebuffer), t.framebufferRenderbuffer(t.FRAMEBUFFER, t.COLOR_ATTACHMENT0 + e, t.RENDERBUFFER, null), n.bindFramebuffer(t.FRAMEBUFFER, h.__webglFramebuffer), t.framebufferTexture2D(t.DRAW_FRAMEBUFFER, t.COLOR_ATTACHMENT0 + e, t.TEXTURE_2D, null, 0);
					n.bindFramebuffer(t.READ_FRAMEBUFFER, h.__webglMultisampledFramebuffer), n.bindFramebuffer(t.DRAW_FRAMEBUFFER, h.__webglFramebuffer);
					for (let n = 0; n < r.length; n++) {
						if (e.resolveDepthBuffer && (e.depthBuffer && (o |= t.DEPTH_BUFFER_BIT), e.stencilBuffer && e.resolveStencilBuffer && (o |= t.STENCIL_BUFFER_BIT)), u) {
							t.framebufferRenderbuffer(t.READ_FRAMEBUFFER, t.COLOR_ATTACHMENT0, t.RENDERBUFFER, h.__webglColorRenderbuffer[n]);
							const e = i.get(r[n]).__webglTexture;
							t.framebufferTexture2D(t.DRAW_FRAMEBUFFER, t.COLOR_ATTACHMENT0, t.TEXTURE_2D, e, 0);
						}
						t.blitFramebuffer(0, 0, s, a, 0, 0, s, a, o, t.NEAREST), !0 === l && (D.length = 0, O.length = 0, D.push(t.COLOR_ATTACHMENT0 + n), e.depthBuffer && !1 === e.resolveDepthBuffer && (D.push(c), O.push(c), t.invalidateFramebuffer(t.DRAW_FRAMEBUFFER, O)), t.invalidateFramebuffer(t.READ_FRAMEBUFFER, D));
					}
					if (n.bindFramebuffer(t.READ_FRAMEBUFFER, null), n.bindFramebuffer(t.DRAW_FRAMEBUFFER, null), u) for (let e = 0; e < r.length; e++) {
						n.bindFramebuffer(t.FRAMEBUFFER, h.__webglMultisampledFramebuffer), t.framebufferRenderbuffer(t.FRAMEBUFFER, t.COLOR_ATTACHMENT0 + e, t.RENDERBUFFER, h.__webglColorRenderbuffer[e]);
						const s = i.get(r[e]).__webglTexture;
						n.bindFramebuffer(t.FRAMEBUFFER, h.__webglFramebuffer), t.framebufferTexture2D(t.DRAW_FRAMEBUFFER, t.COLOR_ATTACHMENT0 + e, t.TEXTURE_2D, s, 0);
					}
					n.bindFramebuffer(t.DRAW_FRAMEBUFFER, h.__webglMultisampledFramebuffer);
				} else if (e.depthBuffer && !1 === e.resolveDepthBuffer && l) {
					const n = e.stencilBuffer ? t.DEPTH_STENCIL_ATTACHMENT : t.DEPTH_ATTACHMENT;
					t.invalidateFramebuffer(t.DRAW_FRAMEBUFFER, [n]);
				}
			}
		}, this.setupDepthRenderbuffer = N, this.setupFrameBufferTexture = L, this.useMultisampledRTT = B;
	}
	function ql(t, e) {
		return { convert: function(n, i = "") {
			let r;
			const s = mi.getTransfer(i);
			if (n === 1009) return t.UNSIGNED_BYTE;
			if (n === 1017) return t.UNSIGNED_SHORT_4_4_4_4;
			if (n === 1018) return t.UNSIGNED_SHORT_5_5_5_1;
			if (n === 35902) return t.UNSIGNED_INT_5_9_9_9_REV;
			if (n === 1010) return t.BYTE;
			if (n === 1011) return t.SHORT;
			if (n === 1012) return t.UNSIGNED_SHORT;
			if (n === 1013) return t.INT;
			if (n === 1014) return t.UNSIGNED_INT;
			if (n === 1015) return t.FLOAT;
			if (n === 1016) return t.HALF_FLOAT;
			if (n === 1021) return t.ALPHA;
			if (n === 1022) return t.RGB;
			if (n === 1023) return t.RGBA;
			if (n === 1024) return t.LUMINANCE;
			if (n === 1025) return t.LUMINANCE_ALPHA;
			if (n === 1026) return t.DEPTH_COMPONENT;
			if (n === 1027) return t.DEPTH_STENCIL;
			if (n === 1028) return t.RED;
			if (n === 1029) return t.RED_INTEGER;
			if (n === 1030) return t.RG;
			if (n === 1031) return t.RG_INTEGER;
			if (n === 1033) return t.RGBA_INTEGER;
			if (n === 33776 || n === 33777 || n === 33778 || n === 33779) if (s === "srgb") {
				if (r = e.get("WEBGL_compressed_texture_s3tc_srgb"), null === r) return null;
				if (n === 33776) return r.COMPRESSED_SRGB_S3TC_DXT1_EXT;
				if (n === 33777) return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;
				if (n === 33778) return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;
				if (n === 33779) return r.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT;
			} else {
				if (r = e.get("WEBGL_compressed_texture_s3tc"), null === r) return null;
				if (n === 33776) return r.COMPRESSED_RGB_S3TC_DXT1_EXT;
				if (n === 33777) return r.COMPRESSED_RGBA_S3TC_DXT1_EXT;
				if (n === 33778) return r.COMPRESSED_RGBA_S3TC_DXT3_EXT;
				if (n === 33779) return r.COMPRESSED_RGBA_S3TC_DXT5_EXT;
			}
			if (n === 35840 || n === 35841 || n === 35842 || n === 35843) {
				if (r = e.get("WEBGL_compressed_texture_pvrtc"), null === r) return null;
				if (n === 35840) return r.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;
				if (n === 35841) return r.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;
				if (n === 35842) return r.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;
				if (n === 35843) return r.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG;
			}
			if (n === 36196 || n === 37492 || n === 37496) {
				if (r = e.get("WEBGL_compressed_texture_etc"), null === r) return null;
				if (n === 36196 || n === 37492) return s === "srgb" ? r.COMPRESSED_SRGB8_ETC2 : r.COMPRESSED_RGB8_ETC2;
				if (n === 37496) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC : r.COMPRESSED_RGBA8_ETC2_EAC;
			}
			if (n === 37808 || n === 37809 || n === 37810 || n === 37811 || n === 37812 || n === 37813 || n === 37814 || n === 37815 || n === 37816 || n === 37817 || n === 37818 || n === 37819 || n === 37820 || n === 37821) {
				if (r = e.get("WEBGL_compressed_texture_astc"), null === r) return null;
				if (n === 37808) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR : r.COMPRESSED_RGBA_ASTC_4x4_KHR;
				if (n === 37809) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR : r.COMPRESSED_RGBA_ASTC_5x4_KHR;
				if (n === 37810) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR : r.COMPRESSED_RGBA_ASTC_5x5_KHR;
				if (n === 37811) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR : r.COMPRESSED_RGBA_ASTC_6x5_KHR;
				if (n === 37812) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR : r.COMPRESSED_RGBA_ASTC_6x6_KHR;
				if (n === 37813) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR : r.COMPRESSED_RGBA_ASTC_8x5_KHR;
				if (n === 37814) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR : r.COMPRESSED_RGBA_ASTC_8x6_KHR;
				if (n === 37815) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR : r.COMPRESSED_RGBA_ASTC_8x8_KHR;
				if (n === 37816) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR : r.COMPRESSED_RGBA_ASTC_10x5_KHR;
				if (n === 37817) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR : r.COMPRESSED_RGBA_ASTC_10x6_KHR;
				if (n === 37818) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR : r.COMPRESSED_RGBA_ASTC_10x8_KHR;
				if (n === 37819) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR : r.COMPRESSED_RGBA_ASTC_10x10_KHR;
				if (n === 37820) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR : r.COMPRESSED_RGBA_ASTC_12x10_KHR;
				if (n === 37821) return s === "srgb" ? r.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR : r.COMPRESSED_RGBA_ASTC_12x12_KHR;
			}
			if (n === 36492 || n === 36494 || n === 36495) {
				if (r = e.get("EXT_texture_compression_bptc"), null === r) return null;
				if (n === 36492) return s === "srgb" ? r.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT : r.COMPRESSED_RGBA_BPTC_UNORM_EXT;
				if (n === 36494) return r.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;
				if (n === 36495) return r.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT;
			}
			if (n === 36283 || n === 36284 || n === 36285 || n === 36286) {
				if (r = e.get("EXT_texture_compression_rgtc"), null === r) return null;
				if (n === 36492) return r.COMPRESSED_RED_RGTC1_EXT;
				if (n === 36284) return r.COMPRESSED_SIGNED_RED_RGTC1_EXT;
				if (n === 36285) return r.COMPRESSED_RED_GREEN_RGTC2_EXT;
				if (n === 36286) return r.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT;
			}
			return n === 1020 ? t.UNSIGNED_INT_24_8 : void 0 !== t[n] ? t[n] : null;
		} };
	}
	var Yl = class extends Qs {
		constructor(t = []) {
			super(), this.isArrayCamera = !0, this.cameras = t;
		}
	};
	var Zl = class extends Dr {
		constructor() {
			super(), this.isGroup = !0, this.type = "Group";
		}
	};
	const Jl = { type: "move" };
	var Kl = class {
		constructor() {
			this._targetRay = null, this._grip = null, this._hand = null;
		}
		getHandSpace() {
			return null === this._hand && (this._hand = new Zl(), this._hand.matrixAutoUpdate = !1, this._hand.visible = !1, this._hand.joints = {}, this._hand.inputState = { pinching: !1 }), this._hand;
		}
		getTargetRaySpace() {
			return null === this._targetRay && (this._targetRay = new Zl(), this._targetRay.matrixAutoUpdate = !1, this._targetRay.visible = !1, this._targetRay.hasLinearVelocity = !1, this._targetRay.linearVelocity = new Li(), this._targetRay.hasAngularVelocity = !1, this._targetRay.angularVelocity = new Li()), this._targetRay;
		}
		getGripSpace() {
			return null === this._grip && (this._grip = new Zl(), this._grip.matrixAutoUpdate = !1, this._grip.visible = !1, this._grip.hasLinearVelocity = !1, this._grip.linearVelocity = new Li(), this._grip.hasAngularVelocity = !1, this._grip.angularVelocity = new Li()), this._grip;
		}
		dispatchEvent(t) {
			return null !== this._targetRay && this._targetRay.dispatchEvent(t), null !== this._grip && this._grip.dispatchEvent(t), null !== this._hand && this._hand.dispatchEvent(t), this;
		}
		connect(t) {
			if (t && t.hand) {
				const e = this._hand;
				if (e) for (const n of t.hand.values()) this._getHandJoint(e, n);
			}
			return this.dispatchEvent({
				type: "connected",
				data: t
			}), this;
		}
		disconnect(t) {
			return this.dispatchEvent({
				type: "disconnected",
				data: t
			}), null !== this._targetRay && (this._targetRay.visible = !1), null !== this._grip && (this._grip.visible = !1), null !== this._hand && (this._hand.visible = !1), this;
		}
		update(t, e, n) {
			let i = null, r = null, s = null;
			const a = this._targetRay, o = this._grip, l = this._hand;
			if (t && "visible-blurred" !== e.session.visibilityState) {
				if (l && t.hand) {
					s = !0;
					for (const i of t.hand.values()) {
						const t = e.getJointPose(i, n), r = this._getHandJoint(l, i);
						null !== t && (r.matrix.fromArray(t.transform.matrix), r.matrix.decompose(r.position, r.rotation, r.scale), r.matrixWorldNeedsUpdate = !0, r.jointRadius = t.radius), r.visible = null !== t;
					}
					const i = l.joints["index-finger-tip"], r = l.joints["thumb-tip"], a = i.position.distanceTo(r.position), o = .02, c = .005;
					l.inputState.pinching && a > o + c ? (l.inputState.pinching = !1, this.dispatchEvent({
						type: "pinchend",
						handedness: t.handedness,
						target: this
					})) : !l.inputState.pinching && a <= o - c && (l.inputState.pinching = !0, this.dispatchEvent({
						type: "pinchstart",
						handedness: t.handedness,
						target: this
					}));
				} else null !== o && t.gripSpace && (r = e.getPose(t.gripSpace, n), null !== r && (o.matrix.fromArray(r.transform.matrix), o.matrix.decompose(o.position, o.rotation, o.scale), o.matrixWorldNeedsUpdate = !0, r.linearVelocity ? (o.hasLinearVelocity = !0, o.linearVelocity.copy(r.linearVelocity)) : o.hasLinearVelocity = !1, r.angularVelocity ? (o.hasAngularVelocity = !0, o.angularVelocity.copy(r.angularVelocity)) : o.hasAngularVelocity = !1));
				null !== a && (i = e.getPose(t.targetRaySpace, n), null === i && null !== r && (i = r), null !== i && (a.matrix.fromArray(i.transform.matrix), a.matrix.decompose(a.position, a.rotation, a.scale), a.matrixWorldNeedsUpdate = !0, i.linearVelocity ? (a.hasLinearVelocity = !0, a.linearVelocity.copy(i.linearVelocity)) : a.hasLinearVelocity = !1, i.angularVelocity ? (a.hasAngularVelocity = !0, a.angularVelocity.copy(i.angularVelocity)) : a.hasAngularVelocity = !1, this.dispatchEvent(Jl)));
			}
			return null !== a && (a.visible = null !== i), null !== o && (o.visible = null !== r), null !== l && (l.visible = null !== s), this;
		}
		_getHandJoint(t, e) {
			if (void 0 === t.joints[e.jointName]) {
				const n = new Zl();
				n.matrixAutoUpdate = !1, n.visible = !1, t.joints[e.jointName] = n, t.add(n);
			}
			return t.joints[e.jointName];
		}
	};
	var $l = class {
		constructor() {
			this.texture = null, this.mesh = null, this.depthNear = 0, this.depthFar = 0;
		}
		init(t, e, n) {
			if (null === this.texture) {
				const i = new bi();
				t.properties.get(i).__webglTexture = e.texture, e.depthNear == n.depthNear && e.depthFar == n.depthFar || (this.depthNear = e.depthNear, this.depthFar = e.depthFar), this.texture = i;
			}
		}
		getMesh(t) {
			if (null !== this.texture && null === this.mesh) {
				const e = t.cameras[0].viewport, n = new Ys({
					vertexShader: "\nvoid main() {\n\n	gl_Position = vec4( position, 1.0 );\n\n}",
					fragmentShader: "\nuniform sampler2DArray depthColor;\nuniform float depthWidth;\nuniform float depthHeight;\n\nvoid main() {\n\n	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );\n\n	if ( coord.x >= 1.0 ) {\n\n		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;\n\n	} else {\n\n		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;\n\n	}\n\n}",
					uniforms: {
						depthColor: { value: this.texture },
						depthWidth: { value: e.z },
						depthHeight: { value: e.w }
					}
				});
				this.mesh = new Vs(new pa(20, 20), n);
			}
			return this.mesh;
		}
		reset() {
			this.texture = null, this.mesh = null;
		}
		getDepthTexture() {
			return this.texture;
		}
	};
	var Ql = class extends Hn {
		constructor(t, e) {
			super();
			const n = this;
			let i = null, r = 1, s = null, a = "local-floor", o = 1, l = null, c = null, h = null, u = null, d = null, p = null;
			const m = new $l(), f = e.getContextAttributes();
			let g = null, v = null;
			const _ = [], x = [], y = new ti();
			let M = null;
			const S = new Qs();
			S.layers.enable(1), S.viewport = new wi();
			const b = new Qs();
			b.layers.enable(2), b.viewport = new wi();
			const w = [S, b], T = new Yl();
			T.layers.enable(1), T.layers.enable(2);
			let E = null, A = null;
			function R(t) {
				const e = x.indexOf(t.inputSource);
				if (-1 === e) return;
				const n = _[e];
				void 0 !== n && (n.update(t.inputSource, t.frame, l || s), n.dispatchEvent({
					type: t.type,
					data: t.inputSource
				}));
			}
			function C() {
				i.removeEventListener("select", R), i.removeEventListener("selectstart", R), i.removeEventListener("selectend", R), i.removeEventListener("squeeze", R), i.removeEventListener("squeezestart", R), i.removeEventListener("squeezeend", R), i.removeEventListener("end", C), i.removeEventListener("inputsourceschange", P);
				for (let t = 0; t < _.length; t++) {
					const e = x[t];
					null !== e && (x[t] = null, _[t].disconnect(e));
				}
				E = null, A = null, m.reset(), t.setRenderTarget(g), d = null, u = null, h = null, i = null, v = null, D.stop(), n.isPresenting = !1, t.setPixelRatio(M), t.setSize(y.width, y.height, !1), n.dispatchEvent({ type: "sessionend" });
			}
			function P(t) {
				for (let e = 0; e < t.removed.length; e++) {
					const n = t.removed[e], i = x.indexOf(n);
					i >= 0 && (x[i] = null, _[i].disconnect(n));
				}
				for (let e = 0; e < t.added.length; e++) {
					const n = t.added[e];
					let i = x.indexOf(n);
					if (-1 === i) {
						for (let t = 0; t < _.length; t++) {
							if (t >= x.length) {
								x.push(n), i = t;
								break;
							}
							if (null === x[t]) {
								x[t] = n, i = t;
								break;
							}
						}
						if (-1 === i) break;
					}
					const r = _[i];
					r && r.connect(n);
				}
			}
			this.cameraAutoUpdate = !0, this.enabled = !1, this.isPresenting = !1, this.getController = function(t) {
				let e = _[t];
				return void 0 === e && (e = new Kl(), _[t] = e), e.getTargetRaySpace();
			}, this.getControllerGrip = function(t) {
				let e = _[t];
				return void 0 === e && (e = new Kl(), _[t] = e), e.getGripSpace();
			}, this.getHand = function(t) {
				let e = _[t];
				return void 0 === e && (e = new Kl(), _[t] = e), e.getHandSpace();
			}, this.setFramebufferScaleFactor = function(t) {
				r = t, !0 === n.isPresenting && console.warn("THREE.WebXRManager: Cannot change framebuffer scale while presenting.");
			}, this.setReferenceSpaceType = function(t) {
				a = t, !0 === n.isPresenting && console.warn("THREE.WebXRManager: Cannot change reference space type while presenting.");
			}, this.getReferenceSpace = function() {
				return l || s;
			}, this.setReferenceSpace = function(t) {
				l = t;
			}, this.getBaseLayer = function() {
				return null !== u ? u : d;
			}, this.getBinding = function() {
				return h;
			}, this.getFrame = function() {
				return p;
			}, this.getSession = function() {
				return i;
			}, this.setSession = async function(c) {
				if (i = c, null !== i) {
					if (g = t.getRenderTarget(), i.addEventListener("select", R), i.addEventListener("selectstart", R), i.addEventListener("selectend", R), i.addEventListener("squeeze", R), i.addEventListener("squeezestart", R), i.addEventListener("squeezeend", R), i.addEventListener("end", C), i.addEventListener("inputsourceschange", P), !0 !== f.xrCompatible && await e.makeXRCompatible(), M = t.getPixelRatio(), t.getSize(y), void 0 === i.renderState.layers) {
						const n = {
							antialias: f.antialias,
							alpha: !0,
							depth: f.depth,
							stencil: f.stencil,
							framebufferScaleFactor: r
						};
						d = new XRWebGLLayer(i, e, n), i.updateRenderState({ baseLayer: d }), t.setPixelRatio(1), t.setSize(d.framebufferWidth, d.framebufferHeight, !1), v = new Ei(d.framebufferWidth, d.framebufferHeight, {
							format: kt,
							type: Et,
							colorSpace: t.outputColorSpace,
							stencilBuffer: f.stencil
						});
					} else {
						let n = null, s = null, a = null;
						f.depth && (a = f.stencil ? e.DEPTH24_STENCIL8 : e.DEPTH_COMPONENT24, n = f.stencil ? 1027 : 1026, s = f.stencil ? 1020 : 1014);
						const o = {
							colorFormat: e.RGBA8,
							depthFormat: a,
							scaleFactor: r
						};
						h = new XRWebGLBinding(i, e), u = h.createProjectionLayer(o), i.updateRenderState({ layers: [u] }), t.setPixelRatio(1), t.setSize(u.textureWidth, u.textureHeight, !1), v = new Ei(u.textureWidth, u.textureHeight, {
							format: kt,
							type: Et,
							depthTexture: new Ka(u.textureWidth, u.textureHeight, s, void 0, void 0, void 0, void 0, void 0, void 0, n),
							stencilBuffer: f.stencil,
							colorSpace: t.outputColorSpace,
							samples: f.antialias ? 4 : 0,
							resolveDepthBuffer: !1 === u.ignoreDepthValues
						});
					}
					v.isXRRenderTarget = !0, this.setFoveation(o), l = null, s = await i.requestReferenceSpace(a), D.setContext(i), D.start(), n.isPresenting = !0, n.dispatchEvent({ type: "sessionstart" });
				}
			}, this.getEnvironmentBlendMode = function() {
				if (null !== i) return i.environmentBlendMode;
			}, this.getDepthTexture = function() {
				return m.getDepthTexture();
			};
			const I = new Li(), L = new Li();
			function U(t, e) {
				null === e ? t.matrixWorld.copy(t.matrix) : t.matrixWorld.multiplyMatrices(e.matrixWorld, t.matrix), t.matrixWorldInverse.copy(t.matrixWorld).invert();
			}
			this.updateCamera = function(t) {
				if (null === i) return;
				let e = t.near, n = t.far;
				null !== m.texture && (m.depthNear > 0 && (e = m.depthNear), m.depthFar > 0 && (n = m.depthFar)), T.near = b.near = S.near = e, T.far = b.far = S.far = n, E === T.near && A === T.far || (i.updateRenderState({
					depthNear: T.near,
					depthFar: T.far
				}), E = T.near, A = T.far);
				const r = t.parent, s = T.cameras;
				U(T, r);
				for (let t = 0; t < s.length; t++) U(s[t], r);
				2 === s.length ? function(t, e, n) {
					I.setFromMatrixPosition(e.matrixWorld), L.setFromMatrixPosition(n.matrixWorld);
					const i = I.distanceTo(L), r = e.projectionMatrix.elements, s = n.projectionMatrix.elements, a = r[14] / (r[10] - 1), o = r[14] / (r[10] + 1), l = (r[9] + 1) / r[5], c = (r[9] - 1) / r[5], h = (r[8] - 1) / r[0], u = (s[8] + 1) / s[0], d = a * h, p = a * u, m = i / (-h + u), f = m * -h;
					if (e.matrixWorld.decompose(t.position, t.quaternion, t.scale), t.translateX(f), t.translateZ(m), t.matrixWorld.compose(t.position, t.quaternion, t.scale), t.matrixWorldInverse.copy(t.matrixWorld).invert(), -1 === r[10]) t.projectionMatrix.copy(e.projectionMatrix), t.projectionMatrixInverse.copy(e.projectionMatrixInverse);
					else {
						const e = a + m, n = o + m, r = d - f, s = p + (i - f), h = l * o / n * e, u = c * o / n * e;
						t.projectionMatrix.makePerspective(r, s, h, u, e, n), t.projectionMatrixInverse.copy(t.projectionMatrix).invert();
					}
				}(T, S, b) : T.projectionMatrix.copy(S.projectionMatrix), function(t, e, n) {
					null === n ? t.matrix.copy(e.matrixWorld) : (t.matrix.copy(n.matrixWorld), t.matrix.invert(), t.matrix.multiply(e.matrixWorld));
					t.matrix.decompose(t.position, t.quaternion, t.scale), t.updateMatrixWorld(!0), t.projectionMatrix.copy(e.projectionMatrix), t.projectionMatrixInverse.copy(e.projectionMatrixInverse), t.isPerspectiveCamera && (t.fov = 2 * jn * Math.atan(1 / t.projectionMatrix.elements[5]), t.zoom = 1);
				}(t, T, r);
			}, this.getCamera = function() {
				return T;
			}, this.getFoveation = function() {
				if (null !== u || null !== d) return o;
			}, this.setFoveation = function(t) {
				o = t, null !== u && (u.fixedFoveation = t), null !== d && void 0 !== d.fixedFoveation && (d.fixedFoveation = t);
			}, this.hasDepthSensing = function() {
				return null !== m.texture;
			}, this.getDepthSensingMesh = function() {
				return m.getMesh(T);
			};
			let N = null;
			const D = new ua();
			D.setAnimationLoop((function(e, r) {
				if (c = r.getViewerPose(l || s), p = r, null !== c) {
					const e = c.views;
					null !== d && (t.setRenderTargetFramebuffer(v, d.framebuffer), t.setRenderTarget(v));
					let n = !1;
					e.length !== T.cameras.length && (T.cameras.length = 0, n = !0);
					for (let i = 0; i < e.length; i++) {
						const r = e[i];
						let s = null;
						if (null !== d) s = d.getViewport(r);
						else {
							const e = h.getViewSubImage(u, r);
							s = e.viewport, 0 === i && (t.setRenderTargetTextures(v, e.colorTexture, u.ignoreDepthValues ? void 0 : e.depthStencilTexture), t.setRenderTarget(v));
						}
						let a = w[i];
						void 0 === a && (a = new Qs(), a.layers.enable(i), a.viewport = new wi(), w[i] = a), a.matrix.fromArray(r.transform.matrix), a.matrix.decompose(a.position, a.quaternion, a.scale), a.projectionMatrix.fromArray(r.projectionMatrix), a.projectionMatrixInverse.copy(a.projectionMatrix).invert(), a.viewport.set(s.x, s.y, s.width, s.height), 0 === i && (T.matrix.copy(a.matrix), T.matrix.decompose(T.position, T.quaternion, T.scale)), !0 === n && T.cameras.push(a);
					}
					const r = i.enabledFeatures;
					if (r && r.includes("depth-sensing")) {
						const n = h.getDepthInformation(e[0]);
						n && n.isValid && n.texture && m.init(t, n, i.renderState);
					}
				}
				for (let t = 0; t < _.length; t++) {
					const e = x[t], n = _[t];
					null !== e && void 0 !== n && n.update(e, r, l || s);
				}
				N && N(e, r), r.detectedPlanes && n.dispatchEvent({
					type: "planesdetected",
					data: r
				}), p = null;
			})), this.setAnimationLoop = function(t) {
				N = t;
			}, this.dispose = function() {};
		}
	};
	const tc = new _r(), ec = new lr();
	function nc(t, e) {
		function n(t, e) {
			!0 === t.matrixAutoUpdate && t.updateMatrix(), e.value.copy(t.matrix);
		}
		function i(t, i) {
			t.opacity.value = i.opacity, i.color && t.diffuse.value.copy(i.color), i.emissive && t.emissive.value.copy(i.emissive).multiplyScalar(i.emissiveIntensity), i.map && (t.map.value = i.map, n(i.map, t.mapTransform)), i.alphaMap && (t.alphaMap.value = i.alphaMap, n(i.alphaMap, t.alphaMapTransform)), i.bumpMap && (t.bumpMap.value = i.bumpMap, n(i.bumpMap, t.bumpMapTransform), t.bumpScale.value = i.bumpScale, i.side === 1 && (t.bumpScale.value *= -1)), i.normalMap && (t.normalMap.value = i.normalMap, n(i.normalMap, t.normalMapTransform), t.normalScale.value.copy(i.normalScale), i.side === 1 && t.normalScale.value.negate()), i.displacementMap && (t.displacementMap.value = i.displacementMap, n(i.displacementMap, t.displacementMapTransform), t.displacementScale.value = i.displacementScale, t.displacementBias.value = i.displacementBias), i.emissiveMap && (t.emissiveMap.value = i.emissiveMap, n(i.emissiveMap, t.emissiveMapTransform)), i.specularMap && (t.specularMap.value = i.specularMap, n(i.specularMap, t.specularMapTransform)), i.alphaTest > 0 && (t.alphaTest.value = i.alphaTest);
			const r = e.get(i), s = r.envMap, a = r.envMapRotation;
			s && (t.envMap.value = s, tc.copy(a), tc.x *= -1, tc.y *= -1, tc.z *= -1, s.isCubeTexture && !1 === s.isRenderTargetTexture && (tc.y *= -1, tc.z *= -1), t.envMapRotation.value.setFromMatrix4(ec.makeRotationFromEuler(tc)), t.flipEnvMap.value = s.isCubeTexture && !1 === s.isRenderTargetTexture ? -1 : 1, t.reflectivity.value = i.reflectivity, t.ior.value = i.ior, t.refractionRatio.value = i.refractionRatio), i.lightMap && (t.lightMap.value = i.lightMap, t.lightMapIntensity.value = i.lightMapIntensity, n(i.lightMap, t.lightMapTransform)), i.aoMap && (t.aoMap.value = i.aoMap, t.aoMapIntensity.value = i.aoMapIntensity, n(i.aoMap, t.aoMapTransform));
		}
		return {
			refreshFogUniforms: function(e, n) {
				n.color.getRGB(e.fogColor.value, js(t)), n.isFog ? (e.fogNear.value = n.near, e.fogFar.value = n.far) : n.isFogExp2 && (e.fogDensity.value = n.density);
			},
			refreshMaterialUniforms: function(t, r, s, a, o) {
				r.isMeshBasicMaterial || r.isMeshLambertMaterial ? i(t, r) : r.isMeshToonMaterial ? (i(t, r), function(t, e) {
					e.gradientMap && (t.gradientMap.value = e.gradientMap);
				}(t, r)) : r.isMeshPhongMaterial ? (i(t, r), function(t, e) {
					t.specular.value.copy(e.specular), t.shininess.value = Math.max(e.shininess, 1e-4);
				}(t, r)) : r.isMeshStandardMaterial ? (i(t, r), function(t, e) {
					t.metalness.value = e.metalness, e.metalnessMap && (t.metalnessMap.value = e.metalnessMap, n(e.metalnessMap, t.metalnessMapTransform));
					t.roughness.value = e.roughness, e.roughnessMap && (t.roughnessMap.value = e.roughnessMap, n(e.roughnessMap, t.roughnessMapTransform));
					e.envMap && (t.envMapIntensity.value = e.envMapIntensity);
				}(t, r), r.isMeshPhysicalMaterial && function(t, e, i) {
					t.ior.value = e.ior, e.sheen > 0 && (t.sheenColor.value.copy(e.sheenColor).multiplyScalar(e.sheen), t.sheenRoughness.value = e.sheenRoughness, e.sheenColorMap && (t.sheenColorMap.value = e.sheenColorMap, n(e.sheenColorMap, t.sheenColorMapTransform)), e.sheenRoughnessMap && (t.sheenRoughnessMap.value = e.sheenRoughnessMap, n(e.sheenRoughnessMap, t.sheenRoughnessMapTransform)));
					e.clearcoat > 0 && (t.clearcoat.value = e.clearcoat, t.clearcoatRoughness.value = e.clearcoatRoughness, e.clearcoatMap && (t.clearcoatMap.value = e.clearcoatMap, n(e.clearcoatMap, t.clearcoatMapTransform)), e.clearcoatRoughnessMap && (t.clearcoatRoughnessMap.value = e.clearcoatRoughnessMap, n(e.clearcoatRoughnessMap, t.clearcoatRoughnessMapTransform)), e.clearcoatNormalMap && (t.clearcoatNormalMap.value = e.clearcoatNormalMap, n(e.clearcoatNormalMap, t.clearcoatNormalMapTransform), t.clearcoatNormalScale.value.copy(e.clearcoatNormalScale), e.side === 1 && t.clearcoatNormalScale.value.negate()));
					e.dispersion > 0 && (t.dispersion.value = e.dispersion);
					e.iridescence > 0 && (t.iridescence.value = e.iridescence, t.iridescenceIOR.value = e.iridescenceIOR, t.iridescenceThicknessMinimum.value = e.iridescenceThicknessRange[0], t.iridescenceThicknessMaximum.value = e.iridescenceThicknessRange[1], e.iridescenceMap && (t.iridescenceMap.value = e.iridescenceMap, n(e.iridescenceMap, t.iridescenceMapTransform)), e.iridescenceThicknessMap && (t.iridescenceThicknessMap.value = e.iridescenceThicknessMap, n(e.iridescenceThicknessMap, t.iridescenceThicknessMapTransform)));
					e.transmission > 0 && (t.transmission.value = e.transmission, t.transmissionSamplerMap.value = i.texture, t.transmissionSamplerSize.value.set(i.width, i.height), e.transmissionMap && (t.transmissionMap.value = e.transmissionMap, n(e.transmissionMap, t.transmissionMapTransform)), t.thickness.value = e.thickness, e.thicknessMap && (t.thicknessMap.value = e.thicknessMap, n(e.thicknessMap, t.thicknessMapTransform)), t.attenuationDistance.value = e.attenuationDistance, t.attenuationColor.value.copy(e.attenuationColor));
					e.anisotropy > 0 && (t.anisotropyVector.value.set(e.anisotropy * Math.cos(e.anisotropyRotation), e.anisotropy * Math.sin(e.anisotropyRotation)), e.anisotropyMap && (t.anisotropyMap.value = e.anisotropyMap, n(e.anisotropyMap, t.anisotropyMapTransform)));
					t.specularIntensity.value = e.specularIntensity, t.specularColor.value.copy(e.specularColor), e.specularColorMap && (t.specularColorMap.value = e.specularColorMap, n(e.specularColorMap, t.specularColorMapTransform));
					e.specularIntensityMap && (t.specularIntensityMap.value = e.specularIntensityMap, n(e.specularIntensityMap, t.specularIntensityMapTransform));
				}(t, r, o)) : r.isMeshMatcapMaterial ? (i(t, r), function(t, e) {
					e.matcap && (t.matcap.value = e.matcap);
				}(t, r)) : r.isMeshDepthMaterial ? i(t, r) : r.isMeshDistanceMaterial ? (i(t, r), function(t, n) {
					const i = e.get(n).light;
					t.referencePosition.value.setFromMatrixPosition(i.matrixWorld), t.nearDistance.value = i.shadow.camera.near, t.farDistance.value = i.shadow.camera.far;
				}(t, r)) : r.isMeshNormalMaterial ? i(t, r) : r.isLineBasicMaterial ? (function(t, e) {
					t.diffuse.value.copy(e.color), t.opacity.value = e.opacity, e.map && (t.map.value = e.map, n(e.map, t.mapTransform));
				}(t, r), r.isLineDashedMaterial && function(t, e) {
					t.dashSize.value = e.dashSize, t.totalSize.value = e.dashSize + e.gapSize, t.scale.value = e.scale;
				}(t, r)) : r.isPointsMaterial ? function(t, e, i, r) {
					t.diffuse.value.copy(e.color), t.opacity.value = e.opacity, t.size.value = e.size * i, t.scale.value = .5 * r, e.map && (t.map.value = e.map, n(e.map, t.uvTransform));
					e.alphaMap && (t.alphaMap.value = e.alphaMap, n(e.alphaMap, t.alphaMapTransform));
					e.alphaTest > 0 && (t.alphaTest.value = e.alphaTest);
				}(t, r, s, a) : r.isSpriteMaterial ? function(t, e) {
					t.diffuse.value.copy(e.color), t.opacity.value = e.opacity, t.rotation.value = e.rotation, e.map && (t.map.value = e.map, n(e.map, t.mapTransform));
					e.alphaMap && (t.alphaMap.value = e.alphaMap, n(e.alphaMap, t.alphaMapTransform));
					e.alphaTest > 0 && (t.alphaTest.value = e.alphaTest);
				}(t, r) : r.isShadowMaterial ? (t.color.value.copy(r.color), t.opacity.value = r.opacity) : r.isShaderMaterial && (r.uniformsNeedUpdate = !1);
			}
		};
	}
	function ic(t, e, n, i) {
		let r = {}, s = {}, a = [];
		const o = t.getParameter(t.MAX_UNIFORM_BUFFER_BINDINGS);
		function l(t, e, n, i) {
			const r = t.value, s = e + "_" + n;
			if (void 0 === i[s]) return i[s] = "number" == typeof r || "boolean" == typeof r ? r : r.clone(), !0;
			{
				const t = i[s];
				if ("number" == typeof r || "boolean" == typeof r) {
					if (t !== r) return i[s] = r, !0;
				} else if (!1 === t.equals(r)) return t.copy(r), !0;
			}
			return !1;
		}
		function c(t) {
			const e = {
				boundary: 0,
				storage: 0
			};
			return "number" == typeof t || "boolean" == typeof t ? (e.boundary = 4, e.storage = 4) : t.isVector2 ? (e.boundary = 8, e.storage = 8) : t.isVector3 || t.isColor ? (e.boundary = 16, e.storage = 12) : t.isVector4 ? (e.boundary = 16, e.storage = 16) : t.isMatrix3 ? (e.boundary = 48, e.storage = 48) : t.isMatrix4 ? (e.boundary = 64, e.storage = 64) : t.isTexture ? console.warn("THREE.WebGLRenderer: Texture samplers can not be part of an uniforms group.") : console.warn("THREE.WebGLRenderer: Unsupported uniform value type.", t), e;
		}
		function h(e) {
			const n = e.target;
			n.removeEventListener("dispose", h);
			const i = a.indexOf(n.__bindingPointIndex);
			a.splice(i, 1), t.deleteBuffer(r[n.id]), delete r[n.id], delete s[n.id];
		}
		return {
			bind: function(t, e) {
				const n = e.program;
				i.uniformBlockBinding(t, n);
			},
			update: function(n, u) {
				let d = r[n.id];
				void 0 === d && (function(t) {
					const e = t.uniforms;
					let n = 0;
					const i = 16;
					for (let t = 0, r = e.length; t < r; t++) {
						const r = Array.isArray(e[t]) ? e[t] : [e[t]];
						for (let t = 0, e = r.length; t < e; t++) {
							const e = r[t], s = Array.isArray(e.value) ? e.value : [e.value];
							for (let t = 0, r = s.length; t < r; t++) {
								const r = c(s[t]), a = n % i, o = a % r.boundary, l = a + o;
								n += o, 0 !== l && i - l < r.storage && (n += i - l), e.__data = new Float32Array(r.storage / Float32Array.BYTES_PER_ELEMENT), e.__offset = n, n += r.storage;
							}
						}
					}
					const r = n % i;
					r > 0 && (n += i - r);
					t.__size = n, t.__cache = {};
				}(n), d = function(e) {
					const n = function() {
						for (let t = 0; t < o; t++) if (-1 === a.indexOf(t)) return a.push(t), t;
						return console.error("THREE.WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."), 0;
					}();
					e.__bindingPointIndex = n;
					const i = t.createBuffer(), r = e.__size, s = e.usage;
					return t.bindBuffer(t.UNIFORM_BUFFER, i), t.bufferData(t.UNIFORM_BUFFER, r, s), t.bindBuffer(t.UNIFORM_BUFFER, null), t.bindBufferBase(t.UNIFORM_BUFFER, n, i), i;
				}(n), r[n.id] = d, n.addEventListener("dispose", h));
				const p = u.program;
				i.updateUBOMapping(n, p);
				const m = e.render.frame;
				s[n.id] !== m && (function(e) {
					const n = r[e.id], i = e.uniforms, s = e.__cache;
					t.bindBuffer(t.UNIFORM_BUFFER, n);
					for (let e = 0, n = i.length; e < n; e++) {
						const n = Array.isArray(i[e]) ? i[e] : [i[e]];
						for (let i = 0, r = n.length; i < r; i++) {
							const r = n[i];
							if (!0 === l(r, e, i, s)) {
								const e = r.__offset, n = Array.isArray(r.value) ? r.value : [r.value];
								let i = 0;
								for (let s = 0; s < n.length; s++) {
									const a = n[s], o = c(a);
									"number" == typeof a || "boolean" == typeof a ? (r.__data[0] = a, t.bufferSubData(t.UNIFORM_BUFFER, e + i, r.__data)) : a.isMatrix3 ? (r.__data[0] = a.elements[0], r.__data[1] = a.elements[1], r.__data[2] = a.elements[2], r.__data[3] = 0, r.__data[4] = a.elements[3], r.__data[5] = a.elements[4], r.__data[6] = a.elements[5], r.__data[7] = 0, r.__data[8] = a.elements[6], r.__data[9] = a.elements[7], r.__data[10] = a.elements[8], r.__data[11] = 0) : (a.toArray(r.__data, i), i += o.storage / Float32Array.BYTES_PER_ELEMENT);
								}
								t.bufferSubData(t.UNIFORM_BUFFER, e, r.__data);
							}
						}
					}
					t.bindBuffer(t.UNIFORM_BUFFER, null);
				}(n), s[n.id] = m);
			},
			dispose: function() {
				for (const e in r) t.deleteBuffer(r[e]);
				a = [], r = {}, s = {};
			}
		};
	}
	var rc = class {
		constructor(e = {}) {
			const { canvas: n = oi(), context: i = null, depth: r = !0, stencil: s = !1, alpha: a = !1, antialias: o = !1, premultipliedAlpha: l = !0, preserveDrawingBuffer: c = !1, powerPreference: h = "default", failIfMajorPerformanceCaveat: p = !1 } = e;
			let m;
			if (this.isWebGLRenderer = !0, null !== i) {
				if ("undefined" != typeof WebGLRenderingContext && i instanceof WebGLRenderingContext) throw new Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");
				m = i.getContextAttributes().alpha;
			} else m = a;
			const f = new Uint32Array(4), g = new Int32Array(4);
			let v = null, _ = null;
			const x = [], y = [];
			this.domElement = n, this.debug = {
				checkShaderErrors: !0,
				onShaderError: null
			}, this.autoClear = !0, this.autoClearColor = !0, this.autoClearDepth = !0, this.autoClearStencil = !0, this.sortObjects = !0, this.clippingPlanes = [], this.localClippingEnabled = !1, this._outputColorSpace = Je, this.toneMapping = 0, this.toneMappingExposure = 1;
			const M = this;
			let S = !1, b = 0, w = 0, T = null, E = -1, A = null;
			const R = new wi(), C = new wi();
			let P = null;
			const I = new ts(0);
			let L = 0, U = n.width, N = n.height, D = 1, O = null, F = null;
			const B = new wi(0, 0, U, N), z = new wi(0, 0, U, N);
			let k = !1;
			const V = new ha();
			let H = !1, G = !1;
			const W = new lr(), X = new lr(), j = new Li(), q = new wi(), Y = {
				background: null,
				fog: null,
				environment: null,
				overrideMaterial: null,
				isScene: !0
			};
			let Z = !1;
			function J() {
				return null === T ? D : 1;
			}
			let $, Q, tt, et, nt, it, rt, st, at, ot, lt, ct, ht, ut, dt, pt, mt, ft, gt, vt, _t, xt, yt, Mt, St = i;
			function bt(t, e) {
				return n.getContext(t, e);
			}
			try {
				const e = {
					alpha: !0,
					depth: r,
					stencil: s,
					antialias: o,
					premultipliedAlpha: l,
					preserveDrawingBuffer: c,
					powerPreference: h,
					failIfMajorPerformanceCaveat: p
				};
				if ("setAttribute" in n && n.setAttribute("data-engine", `three.js r169`), n.addEventListener("webglcontextlost", Rt, !1), n.addEventListener("webglcontextrestored", Pt, !1), n.addEventListener("webglcontextcreationerror", Lt, !1), null === St) {
					const t = "webgl2";
					if (St = bt(t, e), null === St) throw bt(t) ? /* @__PURE__ */ new Error("Error creating WebGL context with your selected attributes.") : /* @__PURE__ */ new Error("Error creating WebGL context.");
				}
			} catch (t) {
				throw console.error("THREE.WebGLRenderer: " + t.message), t;
			}
			function Tt() {
				$ = new Xa(St), $.init(), xt = new ql(St, $), Q = new ba(St, $, e, xt), tt = new Gl(St), Q.reverseDepthBuffer && tt.buffers.depth.setReversed(!0), et = new Ya(St), nt = new Rl(), it = new jl(St, $, tt, nt, Q, xt, et), rt = new Ta(M), st = new Wa(M), at = new da(St), yt = new Ma(St, at), ot = new ja(St, at, et, yt), lt = new Ja(St, ot, at, et), gt = new Za(St, Q, it), pt = new wa(nt), ct = new Al(M, rt, st, $, Q, yt, pt), ht = new nc(M, nt), ut = new Ll(), dt = new Bl($), ft = new ya(M, rt, st, tt, lt, m, l), mt = new Vl(M, lt, Q), Mt = new ic(St, et, Q, tt), vt = new Sa(St, $, et), _t = new qa(St, $, et), et.programs = ct.programs, M.capabilities = Q, M.extensions = $, M.properties = nt, M.renderLists = ut, M.shadowMap = mt, M.state = tt, M.info = et;
			}
			Tt();
			const At = new Ql(M, St);
			function Rt(t) {
				t.preventDefault(), console.log("THREE.WebGLRenderer: Context Lost."), S = !0;
			}
			function Pt() {
				console.log("THREE.WebGLRenderer: Context Restored."), S = !1;
				const t = et.autoReset, e = mt.enabled, n = mt.autoUpdate, i = mt.needsUpdate, r = mt.type;
				Tt(), et.autoReset = t, mt.enabled = e, mt.autoUpdate = n, mt.needsUpdate = i, mt.type = r;
			}
			function Lt(t) {
				console.error("THREE.WebGLRenderer: A WebGL context could not be created. Reason: ", t.statusMessage);
			}
			function Ft(t) {
				const e = t.target;
				e.removeEventListener("dispose", Ft), function(t) {
					(function(t) {
						const e = nt.get(t).programs;
						void 0 !== e && (e.forEach((function(t) {
							ct.releaseProgram(t);
						})), t.isShaderMaterial && ct.releaseShaderCache(t));
					})(t), nt.remove(t);
				}(e);
			}
			function Bt(t, e, n) {
				!0 === t.transparent && 2 === t.side && !1 === t.forceSinglePass ? (t.side = 1, t.needsUpdate = !0, Kt(t, e, n), t.side = 0, t.needsUpdate = !0, Kt(t, e, n), t.side = 2) : Kt(t, e, n);
			}
			this.xr = At, this.getContext = function() {
				return St;
			}, this.getContextAttributes = function() {
				return St.getContextAttributes();
			}, this.forceContextLoss = function() {
				const t = $.get("WEBGL_lose_context");
				t && t.loseContext();
			}, this.forceContextRestore = function() {
				const t = $.get("WEBGL_lose_context");
				t && t.restoreContext();
			}, this.getPixelRatio = function() {
				return D;
			}, this.setPixelRatio = function(t) {
				void 0 !== t && (D = t, this.setSize(U, N, !1));
			}, this.getSize = function(t) {
				return t.set(U, N);
			}, this.setSize = function(t, e, i = !0) {
				At.isPresenting ? console.warn("THREE.WebGLRenderer: Can't change size while VR device is presenting.") : (U = t, N = e, n.width = Math.floor(t * D), n.height = Math.floor(e * D), !0 === i && (n.style.width = t + "px", n.style.height = e + "px"), this.setViewport(0, 0, t, e));
			}, this.getDrawingBufferSize = function(t) {
				return t.set(U * D, N * D).floor();
			}, this.setDrawingBufferSize = function(t, e, i) {
				U = t, N = e, D = i, n.width = Math.floor(t * i), n.height = Math.floor(e * i), this.setViewport(0, 0, t, e);
			}, this.getCurrentViewport = function(t) {
				return t.copy(R);
			}, this.getViewport = function(t) {
				return t.copy(B);
			}, this.setViewport = function(t, e, n, i) {
				t.isVector4 ? B.set(t.x, t.y, t.z, t.w) : B.set(t, e, n, i), tt.viewport(R.copy(B).multiplyScalar(D).round());
			}, this.getScissor = function(t) {
				return t.copy(z);
			}, this.setScissor = function(t, e, n, i) {
				t.isVector4 ? z.set(t.x, t.y, t.z, t.w) : z.set(t, e, n, i), tt.scissor(C.copy(z).multiplyScalar(D).round());
			}, this.getScissorTest = function() {
				return k;
			}, this.setScissorTest = function(t) {
				tt.setScissorTest(k = t);
			}, this.setOpaqueSort = function(t) {
				O = t;
			}, this.setTransparentSort = function(t) {
				F = t;
			}, this.getClearColor = function(t) {
				return t.copy(ft.getClearColor());
			}, this.setClearColor = function() {
				ft.setClearColor.apply(ft, arguments);
			}, this.getClearAlpha = function() {
				return ft.getClearAlpha();
			}, this.setClearAlpha = function() {
				ft.setClearAlpha.apply(ft, arguments);
			}, this.clear = function(t = !0, e = !0, n = !0) {
				let i = 0;
				if (t) {
					let t = !1;
					if (null !== T) {
						const e = T.texture.format;
						t = e === 1033 || e === 1031 || e === 1029;
					}
					if (t) {
						const t = T.texture.type, e = t === 1009 || t === 1014 || t === 1012 || t === 1020 || t === 1017 || t === 1018, n = ft.getClearColor(), i = ft.getClearAlpha(), r = n.r, s = n.g, a = n.b;
						e ? (f[0] = r, f[1] = s, f[2] = a, f[3] = i, St.clearBufferuiv(St.COLOR, 0, f)) : (g[0] = r, g[1] = s, g[2] = a, g[3] = i, St.clearBufferiv(St.COLOR, 0, g));
					} else i |= St.COLOR_BUFFER_BIT;
				}
				e && (i |= St.DEPTH_BUFFER_BIT, St.clearDepth(this.capabilities.reverseDepthBuffer ? 0 : 1)), n && (i |= St.STENCIL_BUFFER_BIT, this.state.buffers.stencil.setMask(4294967295)), St.clear(i);
			}, this.clearColor = function() {
				this.clear(!0, !1, !1);
			}, this.clearDepth = function() {
				this.clear(!1, !0, !1);
			}, this.clearStencil = function() {
				this.clear(!1, !1, !0);
			}, this.dispose = function() {
				n.removeEventListener("webglcontextlost", Rt, !1), n.removeEventListener("webglcontextrestored", Pt, !1), n.removeEventListener("webglcontextcreationerror", Lt, !1), ut.dispose(), dt.dispose(), nt.dispose(), rt.dispose(), st.dispose(), lt.dispose(), yt.dispose(), Mt.dispose(), ct.dispose(), At.dispose(), At.removeEventListener("sessionstart", kt), At.removeEventListener("sessionend", Vt), Ht.stop();
			}, this.renderBufferDirect = function(t, e, n, i, r, s) {
				null === e && (e = Y);
				const a = r.isMesh && r.matrixWorld.determinant() < 0, o = function(t, e, n, i, r) {
					!0 !== e.isScene && (e = Y);
					it.resetTextureUnits();
					const s = e.fog, a = i.isMeshStandardMaterial ? e.environment : null, o = null === T ? M.outputColorSpace : !0 === T.isXRRenderTarget ? T.texture.colorSpace : Ke, l = (i.isMeshStandardMaterial ? st : rt).get(i.envMap || a), c = !0 === i.vertexColors && !!n.attributes.color && 4 === n.attributes.color.itemSize, h = !!n.attributes.tangent && (!!i.normalMap || i.anisotropy > 0), u = !!n.morphAttributes.position, d = !!n.morphAttributes.normal, p = !!n.morphAttributes.color;
					let m = 0;
					i.toneMapped && (null !== T && !0 !== T.isXRRenderTarget || (m = M.toneMapping));
					const f = n.morphAttributes.position || n.morphAttributes.normal || n.morphAttributes.color, g = void 0 !== f ? f.length : 0, v = nt.get(i), x = _.state.lights;
					if (!0 === H && (!0 === G || t !== A)) {
						const e = t === A && i.id === E;
						pt.setState(i, t, e);
					}
					let y = !1;
					i.version === v.__version ? v.needsLights && v.lightsStateVersion !== x.state.version || v.outputColorSpace !== o || r.isBatchedMesh && !1 === v.batching ? y = !0 : r.isBatchedMesh || !0 !== v.batching ? r.isBatchedMesh && !0 === v.batchingColor && null === r.colorTexture || r.isBatchedMesh && !1 === v.batchingColor && null !== r.colorTexture || r.isInstancedMesh && !1 === v.instancing ? y = !0 : r.isInstancedMesh || !0 !== v.instancing ? r.isSkinnedMesh && !1 === v.skinning ? y = !0 : r.isSkinnedMesh || !0 !== v.skinning ? r.isInstancedMesh && !0 === v.instancingColor && null === r.instanceColor || r.isInstancedMesh && !1 === v.instancingColor && null !== r.instanceColor || r.isInstancedMesh && !0 === v.instancingMorph && null === r.morphTexture || r.isInstancedMesh && !1 === v.instancingMorph && null !== r.morphTexture || v.envMap !== l || !0 === i.fog && v.fog !== s ? y = !0 : void 0 === v.numClippingPlanes || v.numClippingPlanes === pt.numPlanes && v.numIntersection === pt.numIntersection ? (v.vertexAlphas !== c || v.vertexTangents !== h || v.morphTargets !== u || v.morphNormals !== d || v.morphColors !== p || v.toneMapping !== m || v.morphTargetsCount !== g) && (y = !0) : y = !0 : y = !0 : y = !0 : y = !0 : (y = !0, v.__version = i.version);
					let S = v.currentProgram;
					!0 === y && (S = Kt(i, e, r));
					let b = !1, w = !1, R = !1;
					const C = S.getUniforms(), P = v.uniforms;
					tt.useProgram(S.program) && (b = !0, w = !0, R = !0);
					i.id !== E && (E = i.id, w = !0);
					if (b || A !== t) {
						Q.reverseDepthBuffer ? (W.copy(t.projectionMatrix), function(t) {
							const e = t.elements;
							e[2] = .5 * e[2] + .5 * e[3], e[6] = .5 * e[6] + .5 * e[7], e[10] = .5 * e[10] + .5 * e[11], e[14] = .5 * e[14] + .5 * e[15];
						}(W), function(t) {
							const e = t.elements;
							-1 === e[11] ? (e[10] = -e[10] - 1, e[14] = -e[14]) : (e[10] = -e[10], e[14] = 1 - e[14]);
						}(W), C.setValue(St, "projectionMatrix", W)) : C.setValue(St, "projectionMatrix", t.projectionMatrix), C.setValue(St, "viewMatrix", t.matrixWorldInverse);
						const e = C.map.cameraPosition;
						void 0 !== e && e.setValue(St, j.setFromMatrixPosition(t.matrixWorld)), Q.logarithmicDepthBuffer && C.setValue(St, "logDepthBufFC", 2 / (Math.log(t.far + 1) / Math.LN2)), (i.isMeshPhongMaterial || i.isMeshToonMaterial || i.isMeshLambertMaterial || i.isMeshBasicMaterial || i.isMeshStandardMaterial || i.isShaderMaterial) && C.setValue(St, "isOrthographic", !0 === t.isOrthographicCamera), A !== t && (A = t, w = !0, R = !0);
					}
					if (r.isSkinnedMesh) {
						C.setOptional(St, r, "bindMatrix"), C.setOptional(St, r, "bindMatrixInverse");
						const t = r.skeleton;
						t && (null === t.boneTexture && t.computeBoneTexture(), C.setValue(St, "boneTexture", t.boneTexture, it));
					}
					r.isBatchedMesh && (C.setOptional(St, r, "batchingTexture"), C.setValue(St, "batchingTexture", r._matricesTexture, it), C.setOptional(St, r, "batchingIdTexture"), C.setValue(St, "batchingIdTexture", r._indirectTexture, it), C.setOptional(St, r, "batchingColorTexture"), null !== r._colorsTexture && C.setValue(St, "batchingColorTexture", r._colorsTexture, it));
					const I = n.morphAttributes;
					void 0 === I.position && void 0 === I.normal && void 0 === I.color || gt.update(r, n, S);
					(w || v.receiveShadow !== r.receiveShadow) && (v.receiveShadow = r.receiveShadow, C.setValue(St, "receiveShadow", r.receiveShadow));
					i.isMeshGouraudMaterial && null !== i.envMap && (P.envMap.value = l, P.flipEnvMap.value = l.isCubeTexture && !1 === l.isRenderTargetTexture ? -1 : 1);
					i.isMeshStandardMaterial && null === i.envMap && null !== e.environment && (P.envMapIntensity.value = e.environmentIntensity);
					w && (C.setValue(St, "toneMappingExposure", M.toneMappingExposure), v.needsLights && (U = R, (L = P).ambientLightColor.needsUpdate = U, L.lightProbe.needsUpdate = U, L.directionalLights.needsUpdate = U, L.directionalLightShadows.needsUpdate = U, L.pointLights.needsUpdate = U, L.pointLightShadows.needsUpdate = U, L.spotLights.needsUpdate = U, L.spotLightShadows.needsUpdate = U, L.rectAreaLights.needsUpdate = U, L.hemisphereLights.needsUpdate = U), s && !0 === i.fog && ht.refreshFogUniforms(P, s), ht.refreshMaterialUniforms(P, i, D, N, _.state.transmissionRenderTarget[t.id]), il.upload(St, $t(v), P, it));
					var L, U;
					i.isShaderMaterial && !0 === i.uniformsNeedUpdate && (il.upload(St, $t(v), P, it), i.uniformsNeedUpdate = !1);
					i.isSpriteMaterial && C.setValue(St, "center", r.center);
					if (C.setValue(St, "modelViewMatrix", r.modelViewMatrix), C.setValue(St, "normalMatrix", r.normalMatrix), C.setValue(St, "modelMatrix", r.matrixWorld), i.isShaderMaterial || i.isRawShaderMaterial) {
						const t = i.uniformsGroups;
						for (let e = 0, n = t.length; e < n; e++) {
							const n = t[e];
							Mt.update(n, S), Mt.bind(n, S);
						}
					}
					return S;
				}(t, e, n, i, r);
				tt.setMaterial(i, a);
				let l = n.index, c = 1;
				if (!0 === i.wireframe) {
					if (l = ot.getWireframeAttribute(n), void 0 === l) return;
					c = 2;
				}
				const h = n.drawRange, u = n.attributes.position;
				let d = h.start * c, p = (h.start + h.count) * c;
				null !== s && (d = Math.max(d, s.start * c), p = Math.min(p, (s.start + s.count) * c)), null !== l ? (d = Math.max(d, 0), p = Math.min(p, l.count)) : null != u && (d = Math.max(d, 0), p = Math.min(p, u.count));
				const m = p - d;
				if (m < 0 || m === Infinity) return;
				let f;
				yt.setup(r, i, o, n, l);
				let g = vt;
				if (null !== l && (f = at.get(l), g = _t, g.setIndex(f)), r.isMesh) !0 === i.wireframe ? (tt.setLineWidth(i.wireframeLinewidth * J()), g.setMode(St.LINES)) : g.setMode(St.TRIANGLES);
				else if (r.isLine) {
					let t = i.linewidth;
					void 0 === t && (t = 1), tt.setLineWidth(t * J()), r.isLineSegments ? g.setMode(St.LINES) : r.isLineLoop ? g.setMode(St.LINE_LOOP) : g.setMode(St.LINE_STRIP);
				} else r.isPoints ? g.setMode(St.POINTS) : r.isSprite && g.setMode(St.TRIANGLES);
				if (r.isBatchedMesh) if (null !== r._multiDrawInstances) g.renderMultiDrawInstances(r._multiDrawStarts, r._multiDrawCounts, r._multiDrawCount, r._multiDrawInstances);
				else if ($.get("WEBGL_multi_draw")) g.renderMultiDraw(r._multiDrawStarts, r._multiDrawCounts, r._multiDrawCount);
				else {
					const t = r._multiDrawStarts, e = r._multiDrawCounts, n = r._multiDrawCount, s = l ? at.get(l).bytesPerElement : 1, a = nt.get(i).currentProgram.getUniforms();
					for (let i = 0; i < n; i++) a.setValue(St, "_gl_DrawID", i), g.render(t[i] / s, e[i]);
				}
				else if (r.isInstancedMesh) g.renderInstances(d, m, r.count);
				else if (n.isInstancedBufferGeometry) {
					const t = void 0 !== n._maxInstanceCount ? n._maxInstanceCount : Infinity, e = Math.min(n.instanceCount, t);
					g.renderInstances(d, m, e);
				} else g.render(d, m);
			}, this.compile = function(t, e, n = null) {
				null === n && (n = t), _ = dt.get(n), _.init(e), y.push(_), n.traverseVisible((function(t) {
					t.isLight && t.layers.test(e.layers) && (_.pushLight(t), t.castShadow && _.pushShadow(t));
				})), t !== n && t.traverseVisible((function(t) {
					t.isLight && t.layers.test(e.layers) && (_.pushLight(t), t.castShadow && _.pushShadow(t));
				})), _.setupLights();
				const i = /* @__PURE__ */ new Set();
				return t.traverse((function(t) {
					if (!(t.isMesh || t.isPoints || t.isLine || t.isSprite)) return;
					const e = t.material;
					if (e) if (Array.isArray(e)) for (let r = 0; r < e.length; r++) {
						const s = e[r];
						Bt(s, n, t), i.add(s);
					}
					else Bt(e, n, t), i.add(e);
				})), y.pop(), _ = null, i;
			}, this.compileAsync = function(t, e, n = null) {
				const i = this.compile(t, e, n);
				return new Promise(((e) => {
					function n() {
						i.forEach((function(t) {
							nt.get(t).currentProgram.isReady() && i.delete(t);
						})), 0 !== i.size ? setTimeout(n, 10) : e(t);
					}
					null !== $.get("KHR_parallel_shader_compile") ? n() : setTimeout(n, 10);
				}));
			};
			let zt = null;
			function kt() {
				Ht.stop();
			}
			function Vt() {
				Ht.start();
			}
			const Ht = new ua();
			function Gt(t, e, n, i) {
				if (!1 === t.visible) return;
				if (t.layers.test(e.layers)) {
					if (t.isGroup) n = t.renderOrder;
					else if (t.isLOD) !0 === t.autoUpdate && t.update(e);
					else if (t.isLight) _.pushLight(t), t.castShadow && _.pushShadow(t);
					else if (t.isSprite) {
						if (!t.frustumCulled || V.intersectsSprite(t)) {
							i && q.setFromMatrixPosition(t.matrixWorld).applyMatrix4(X);
							const e = lt.update(t), r = t.material;
							r.visible && v.push(t, e, r, n, q.z, null);
						}
					} else if ((t.isMesh || t.isLine || t.isPoints) && (!t.frustumCulled || V.intersectsObject(t))) {
						const e = lt.update(t), r = t.material;
						if (i && (void 0 !== t.boundingSphere ? (null === t.boundingSphere && t.computeBoundingSphere(), q.copy(t.boundingSphere.center)) : (null === e.boundingSphere && e.computeBoundingSphere(), q.copy(e.boundingSphere.center)), q.applyMatrix4(t.matrixWorld).applyMatrix4(X)), Array.isArray(r)) {
							const i = e.groups;
							for (let s = 0, a = i.length; s < a; s++) {
								const a = i[s], o = r[a.materialIndex];
								o && o.visible && v.push(t, e, o, n, q.z, a);
							}
						} else r.visible && v.push(t, e, r, n, q.z, null);
					}
				}
				const r = t.children;
				for (let t = 0, s = r.length; t < s; t++) Gt(r[t], e, n, i);
			}
			function Wt(t, e, n, i) {
				const r = t.opaque, s = t.transmissive, a = t.transparent;
				_.setupLightsView(n), !0 === H && pt.setGlobalState(M.clippingPlanes, n), i && tt.viewport(R.copy(i)), r.length > 0 && qt(r, e, n), s.length > 0 && qt(s, e, n), a.length > 0 && qt(a, e, n), tt.buffers.depth.setTest(!0), tt.buffers.depth.setMask(!0), tt.buffers.color.setMask(!0), tt.setPolygonOffset(!1);
			}
			function Xt(t, e, n, i) {
				if (null !== (!0 === n.isScene ? n.overrideMaterial : null)) return;
				void 0 === _.state.transmissionRenderTarget[i.id] && (_.state.transmissionRenderTarget[i.id] = new Ei(1, 1, {
					generateMipmaps: !0,
					type: $.has("EXT_color_buffer_half_float") || $.has("EXT_color_buffer_float") ? 1016 : 1009,
					minFilter: 1008,
					samples: 4,
					stencilBuffer: s,
					resolveDepthBuffer: !1,
					resolveStencilBuffer: !1,
					colorSpace: mi.workingColorSpace
				}));
				const r = _.state.transmissionRenderTarget[i.id], a = i.viewport || R;
				r.setSize(a.z, a.w);
				const o = M.getRenderTarget();
				M.setRenderTarget(r), M.getClearColor(I), L = M.getClearAlpha(), L < 1 && M.setClearColor(16777215, .5), M.clear(), Z && ft.render(n);
				const l = M.toneMapping;
				M.toneMapping = 0;
				const c = i.viewport;
				if (void 0 !== i.viewport && (i.viewport = void 0), _.setupLightsView(i), !0 === H && pt.setGlobalState(M.clippingPlanes, i), qt(t, n, i), it.updateMultisampleRenderTarget(r), it.updateRenderTargetMipmap(r), !1 === $.has("WEBGL_multisampled_render_to_texture")) {
					let t = !1;
					for (let r = 0, s = e.length; r < s; r++) {
						const s = e[r], a = s.object, o = s.geometry, l = s.material, c = s.group;
						if (2 === l.side && a.layers.test(i.layers)) {
							const e = l.side;
							l.side = 1, l.needsUpdate = !0, Zt(a, n, i, o, l, c), l.side = e, l.needsUpdate = !0, t = !0;
						}
					}
					!0 === t && (it.updateMultisampleRenderTarget(r), it.updateRenderTargetMipmap(r));
				}
				M.setRenderTarget(o), M.setClearColor(I, L), void 0 !== c && (i.viewport = c), M.toneMapping = l;
			}
			function qt(t, e, n) {
				const i = !0 === e.isScene ? e.overrideMaterial : null;
				for (let r = 0, s = t.length; r < s; r++) {
					const s = t[r], a = s.object, o = s.geometry, l = null === i ? s.material : i, c = s.group;
					a.layers.test(n.layers) && Zt(a, e, n, o, l, c);
				}
			}
			function Zt(t, e, n, i, r, s) {
				t.onBeforeRender(M, e, n, i, r, s), t.modelViewMatrix.multiplyMatrices(n.matrixWorldInverse, t.matrixWorld), t.normalMatrix.getNormalMatrix(t.modelViewMatrix), r.onBeforeRender(M, e, n, i, t, s), !0 === r.transparent && 2 === r.side && !1 === r.forceSinglePass ? (r.side = 1, r.needsUpdate = !0, M.renderBufferDirect(n, e, i, r, t, s), r.side = 0, r.needsUpdate = !0, M.renderBufferDirect(n, e, i, r, t, s), r.side = 2) : M.renderBufferDirect(n, e, i, r, t, s), t.onAfterRender(M, e, n, i, r, s);
			}
			function Kt(t, e, n) {
				!0 !== e.isScene && (e = Y);
				const i = nt.get(t), r = _.state.lights, s = _.state.shadowsArray, a = r.state.version, o = ct.getParameters(t, r.state, s, e, n), l = ct.getProgramCacheKey(o);
				let c = i.programs;
				i.environment = t.isMeshStandardMaterial ? e.environment : null, i.fog = e.fog, i.envMap = (t.isMeshStandardMaterial ? st : rt).get(t.envMap || i.environment), i.envMapRotation = null !== i.environment && null === t.envMap ? e.environmentRotation : t.envMapRotation, void 0 === c && (t.addEventListener("dispose", Ft), c = /* @__PURE__ */ new Map(), i.programs = c);
				let h = c.get(l);
				if (void 0 !== h) {
					if (i.currentProgram === h && i.lightsStateVersion === a) return Qt(t, o), h;
				} else o.uniforms = ct.getUniforms(t), t.onBeforeCompile(o, M), h = ct.acquireProgram(o, l), c.set(l, h), i.uniforms = o.uniforms;
				const u = i.uniforms;
				return (t.isShaderMaterial || t.isRawShaderMaterial) && !0 !== t.clipping || (u.clippingPlanes = pt.uniform), Qt(t, o), i.needsLights = function(t) {
					return t.isMeshLambertMaterial || t.isMeshToonMaterial || t.isMeshPhongMaterial || t.isMeshStandardMaterial || t.isShadowMaterial || t.isShaderMaterial && !0 === t.lights;
				}(t), i.lightsStateVersion = a, i.needsLights && (u.ambientLightColor.value = r.state.ambient, u.lightProbe.value = r.state.probe, u.directionalLights.value = r.state.directional, u.directionalLightShadows.value = r.state.directionalShadow, u.spotLights.value = r.state.spot, u.spotLightShadows.value = r.state.spotShadow, u.rectAreaLights.value = r.state.rectArea, u.ltc_1.value = r.state.rectAreaLTC1, u.ltc_2.value = r.state.rectAreaLTC2, u.pointLights.value = r.state.point, u.pointLightShadows.value = r.state.pointShadow, u.hemisphereLights.value = r.state.hemi, u.directionalShadowMap.value = r.state.directionalShadowMap, u.directionalShadowMatrix.value = r.state.directionalShadowMatrix, u.spotShadowMap.value = r.state.spotShadowMap, u.spotLightMatrix.value = r.state.spotLightMatrix, u.spotLightMap.value = r.state.spotLightMap, u.pointShadowMap.value = r.state.pointShadowMap, u.pointShadowMatrix.value = r.state.pointShadowMatrix), i.currentProgram = h, i.uniformsList = null, h;
			}
			function $t(t) {
				if (null === t.uniformsList) {
					const e = t.currentProgram.getUniforms();
					t.uniformsList = il.seqWithValue(e.seq, t.uniforms);
				}
				return t.uniformsList;
			}
			function Qt(t, e) {
				const n = nt.get(t);
				n.outputColorSpace = e.outputColorSpace, n.batching = e.batching, n.batchingColor = e.batchingColor, n.instancing = e.instancing, n.instancingColor = e.instancingColor, n.instancingMorph = e.instancingMorph, n.skinning = e.skinning, n.morphTargets = e.morphTargets, n.morphNormals = e.morphNormals, n.morphColors = e.morphColors, n.morphTargetsCount = e.morphTargetsCount, n.numClippingPlanes = e.numClippingPlanes, n.numIntersection = e.numClipIntersection, n.vertexAlphas = e.vertexAlphas, n.vertexTangents = e.vertexTangents, n.toneMapping = e.toneMapping;
			}
			Ht.setAnimationLoop((function(t) {
				zt && zt(t);
			})), "undefined" != typeof self && Ht.setContext(self), this.setAnimationLoop = function(t) {
				zt = t, At.setAnimationLoop(t), null === t ? Ht.stop() : Ht.start();
			}, At.addEventListener("sessionstart", kt), At.addEventListener("sessionend", Vt), this.render = function(t, e) {
				if (void 0 !== e && !0 !== e.isCamera) return void console.error("THREE.WebGLRenderer.render: camera is not an instance of THREE.Camera.");
				if (!0 === S) return;
				if (!0 === t.matrixWorldAutoUpdate && t.updateMatrixWorld(), null === e.parent && !0 === e.matrixWorldAutoUpdate && e.updateMatrixWorld(), !0 === At.enabled && !0 === At.isPresenting && (!0 === At.cameraAutoUpdate && At.updateCamera(e), e = At.getCamera()), !0 === t.isScene && t.onBeforeRender(M, t, e, T), _ = dt.get(t, y.length), _.init(e), y.push(_), X.multiplyMatrices(e.projectionMatrix, e.matrixWorldInverse), V.setFromProjectionMatrix(X), G = this.localClippingEnabled, H = pt.init(this.clippingPlanes, G), v = ut.get(t, x.length), v.init(), x.push(v), !0 === At.enabled && !0 === At.isPresenting) {
					const t = M.xr.getDepthSensingMesh();
					null !== t && Gt(t, e, -Infinity, M.sortObjects);
				}
				Gt(t, e, 0, M.sortObjects), v.finish(), !0 === M.sortObjects && v.sort(O, F), Z = !1 === At.enabled || !1 === At.isPresenting || !1 === At.hasDepthSensing(), Z && ft.addToRenderList(v, t), this.info.render.frame++, !0 === H && pt.beginShadows();
				const n = _.state.shadowsArray;
				mt.render(n, t, e), !0 === H && pt.endShadows(), !0 === this.info.autoReset && this.info.reset();
				const i = v.opaque, r = v.transmissive;
				if (_.setupLights(), e.isArrayCamera) {
					const n = e.cameras;
					if (r.length > 0) for (let e = 0, s = n.length; e < s; e++) Xt(i, r, t, n[e]);
					Z && ft.render(t);
					for (let e = 0, i = n.length; e < i; e++) {
						const i = n[e];
						Wt(v, t, i, i.viewport);
					}
				} else r.length > 0 && Xt(i, r, t, e), Z && ft.render(t), Wt(v, t, e);
				null !== T && (it.updateMultisampleRenderTarget(T), it.updateRenderTargetMipmap(T)), !0 === t.isScene && t.onAfterRender(M, t, e), yt.resetDefaultState(), E = -1, A = null, y.pop(), y.length > 0 ? (_ = y[y.length - 1], !0 === H && pt.setGlobalState(M.clippingPlanes, _.state.camera)) : _ = null, x.pop(), v = x.length > 0 ? x[x.length - 1] : null;
			}, this.getActiveCubeFace = function() {
				return b;
			}, this.getActiveMipmapLevel = function() {
				return w;
			}, this.getRenderTarget = function() {
				return T;
			}, this.setRenderTargetTextures = function(t, e, n) {
				nt.get(t.texture).__webglTexture = e, nt.get(t.depthTexture).__webglTexture = n;
				const i = nt.get(t);
				i.__hasExternalTextures = !0, i.__autoAllocateDepthBuffer = void 0 === n, i.__autoAllocateDepthBuffer || !0 === $.has("WEBGL_multisampled_render_to_texture") && (console.warn("THREE.WebGLRenderer: Render-to-texture extension was disabled because an external texture was provided"), i.__useRenderToTexture = !1);
			}, this.setRenderTargetFramebuffer = function(t, e) {
				const n = nt.get(t);
				n.__webglFramebuffer = e, n.__useDefaultFramebuffer = void 0 === e;
			}, this.setRenderTarget = function(t, e = 0, n = 0) {
				T = t, b = e, w = n;
				let i = !0, r = null, s = !1, a = !1;
				if (t) {
					const o = nt.get(t);
					if (void 0 !== o.__useDefaultFramebuffer) tt.bindFramebuffer(St.FRAMEBUFFER, null), i = !1;
					else if (void 0 === o.__webglFramebuffer) it.setupRenderTarget(t);
					else if (o.__hasExternalTextures) it.rebindTextures(t, nt.get(t.texture).__webglTexture, nt.get(t.depthTexture).__webglTexture);
					else if (t.depthBuffer) {
						const e = t.depthTexture;
						if (o.__boundDepthTexture !== e) {
							if (null !== e && nt.has(e) && (t.width !== e.image.width || t.height !== e.image.height)) throw new Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");
							it.setupDepthRenderbuffer(t);
						}
					}
					const l = t.texture;
					(l.isData3DTexture || l.isDataArrayTexture || l.isCompressedArrayTexture) && (a = !0);
					const c = nt.get(t).__webglFramebuffer;
					t.isWebGLCubeRenderTarget ? (r = Array.isArray(c[e]) ? c[e][n] : c[e], s = !0) : r = t.samples > 0 && !1 === it.useMultisampledRTT(t) ? nt.get(t).__webglMultisampledFramebuffer : Array.isArray(c) ? c[n] : c, R.copy(t.viewport), C.copy(t.scissor), P = t.scissorTest;
				} else R.copy(B).multiplyScalar(D).floor(), C.copy(z).multiplyScalar(D).floor(), P = k;
				if (tt.bindFramebuffer(St.FRAMEBUFFER, r) && i && tt.drawBuffers(t, r), tt.viewport(R), tt.scissor(C), tt.setScissorTest(P), s) {
					const i = nt.get(t.texture);
					St.framebufferTexture2D(St.FRAMEBUFFER, St.COLOR_ATTACHMENT0, St.TEXTURE_CUBE_MAP_POSITIVE_X + e, i.__webglTexture, n);
				} else if (a) {
					const i = nt.get(t.texture), r = e || 0;
					St.framebufferTextureLayer(St.FRAMEBUFFER, St.COLOR_ATTACHMENT0, i.__webglTexture, n || 0, r);
				}
				E = -1;
			}, this.readRenderTargetPixels = function(t, e, n, i, r, s, a) {
				if (!t || !t.isWebGLRenderTarget) return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");
				let o = nt.get(t).__webglFramebuffer;
				if (t.isWebGLCubeRenderTarget && void 0 !== a && (o = o[a]), o) {
					tt.bindFramebuffer(St.FRAMEBUFFER, o);
					try {
						const a = t.texture, o = a.format, l = a.type;
						if (!Q.textureFormatReadable(o)) return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");
						if (!Q.textureTypeReadable(l)) return void console.error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");
						e >= 0 && e <= t.width - i && n >= 0 && n <= t.height - r && St.readPixels(e, n, i, r, xt.convert(o), xt.convert(l), s);
					} finally {
						const t = null !== T ? nt.get(T).__webglFramebuffer : null;
						tt.bindFramebuffer(St.FRAMEBUFFER, t);
					}
				}
			}, this.readRenderTargetPixelsAsync = async function(t, e, n, i, r, s, a) {
				if (!t || !t.isWebGLRenderTarget) throw new Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");
				let o = nt.get(t).__webglFramebuffer;
				if (t.isWebGLCubeRenderTarget && void 0 !== a && (o = o[a]), o) {
					const a = t.texture, l = a.format, c = a.type;
					if (!Q.textureFormatReadable(l)) throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");
					if (!Q.textureTypeReadable(c)) throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");
					if (e >= 0 && e <= t.width - i && n >= 0 && n <= t.height - r) {
						tt.bindFramebuffer(St.FRAMEBUFFER, o);
						const t = St.createBuffer();
						St.bindBuffer(St.PIXEL_PACK_BUFFER, t), St.bufferData(St.PIXEL_PACK_BUFFER, s.byteLength, St.STREAM_READ), St.readPixels(e, n, i, r, xt.convert(l), xt.convert(c), 0);
						const a = null !== T ? nt.get(T).__webglFramebuffer : null;
						tt.bindFramebuffer(St.FRAMEBUFFER, a);
						const h = St.fenceSync(St.SYNC_GPU_COMMANDS_COMPLETE, 0);
						return St.flush(), await function(t, e, n) {
							return new Promise((function(i, r) {
								setTimeout((function s() {
									switch (t.clientWaitSync(e, t.SYNC_FLUSH_COMMANDS_BIT, 0)) {
										case t.WAIT_FAILED:
											r();
											break;
										case t.TIMEOUT_EXPIRED:
											setTimeout(s, n);
											break;
										default: i();
									}
								}), n);
							}));
						}(St, h, 4), St.bindBuffer(St.PIXEL_PACK_BUFFER, t), St.getBufferSubData(St.PIXEL_PACK_BUFFER, 0, s), St.deleteBuffer(t), St.deleteSync(h), s;
					}
					throw new Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.");
				}
			}, this.copyFramebufferToTexture = function(t, e = null, n = 0) {
				!0 !== t.isTexture && (ci("WebGLRenderer: copyFramebufferToTexture function signature has changed."), e = arguments[0] || null, t = arguments[1]);
				const i = Math.pow(2, -n), r = Math.floor(t.image.width * i), s = Math.floor(t.image.height * i), a = null !== e ? e.x : 0, o = null !== e ? e.y : 0;
				it.setTexture2D(t, 0), St.copyTexSubImage2D(St.TEXTURE_2D, n, 0, 0, a, o, r, s), tt.unbindTexture();
			}, this.copyTextureToTexture = function(t, e, n = null, i = null, r = 0) {
				let s, a, o, l, c, h;
				!0 !== t.isTexture && (ci("WebGLRenderer: copyTextureToTexture function signature has changed."), i = arguments[0] || null, t = arguments[1], e = arguments[2], r = arguments[3] || 0, n = null), null !== n ? (s = n.max.x - n.min.x, a = n.max.y - n.min.y, o = n.min.x, l = n.min.y) : (s = t.image.width, a = t.image.height, o = 0, l = 0), null !== i ? (c = i.x, h = i.y) : (c = 0, h = 0);
				const u = xt.convert(e.format), d = xt.convert(e.type);
				it.setTexture2D(e, 0), St.pixelStorei(St.UNPACK_FLIP_Y_WEBGL, e.flipY), St.pixelStorei(St.UNPACK_PREMULTIPLY_ALPHA_WEBGL, e.premultiplyAlpha), St.pixelStorei(St.UNPACK_ALIGNMENT, e.unpackAlignment);
				const p = St.getParameter(St.UNPACK_ROW_LENGTH), m = St.getParameter(St.UNPACK_IMAGE_HEIGHT), f = St.getParameter(St.UNPACK_SKIP_PIXELS), g = St.getParameter(St.UNPACK_SKIP_ROWS), v = St.getParameter(St.UNPACK_SKIP_IMAGES), _ = t.isCompressedTexture ? t.mipmaps[r] : t.image;
				St.pixelStorei(St.UNPACK_ROW_LENGTH, _.width), St.pixelStorei(St.UNPACK_IMAGE_HEIGHT, _.height), St.pixelStorei(St.UNPACK_SKIP_PIXELS, o), St.pixelStorei(St.UNPACK_SKIP_ROWS, l), t.isDataTexture ? St.texSubImage2D(St.TEXTURE_2D, r, c, h, s, a, u, d, _.data) : t.isCompressedTexture ? St.compressedTexSubImage2D(St.TEXTURE_2D, r, c, h, _.width, _.height, u, _.data) : St.texSubImage2D(St.TEXTURE_2D, r, c, h, s, a, u, d, _), St.pixelStorei(St.UNPACK_ROW_LENGTH, p), St.pixelStorei(St.UNPACK_IMAGE_HEIGHT, m), St.pixelStorei(St.UNPACK_SKIP_PIXELS, f), St.pixelStorei(St.UNPACK_SKIP_ROWS, g), St.pixelStorei(St.UNPACK_SKIP_IMAGES, v), 0 === r && e.generateMipmaps && St.generateMipmap(St.TEXTURE_2D), tt.unbindTexture();
			}, this.copyTextureToTexture3D = function(t, e, n = null, i = null, r = 0) {
				let s, a, o, l, c, h, u, d, p;
				!0 !== t.isTexture && (ci("WebGLRenderer: copyTextureToTexture3D function signature has changed."), n = arguments[0] || null, i = arguments[1] || null, t = arguments[2], e = arguments[3], r = arguments[4] || 0);
				const m = t.isCompressedTexture ? t.mipmaps[r] : t.image;
				null !== n ? (s = n.max.x - n.min.x, a = n.max.y - n.min.y, o = n.max.z - n.min.z, l = n.min.x, c = n.min.y, h = n.min.z) : (s = m.width, a = m.height, o = m.depth, l = 0, c = 0, h = 0), null !== i ? (u = i.x, d = i.y, p = i.z) : (u = 0, d = 0, p = 0);
				const f = xt.convert(e.format), g = xt.convert(e.type);
				let v;
				if (e.isData3DTexture) it.setTexture3D(e, 0), v = St.TEXTURE_3D;
				else {
					if (!e.isDataArrayTexture && !e.isCompressedArrayTexture) return void console.warn("THREE.WebGLRenderer.copyTextureToTexture3D: only supports THREE.DataTexture3D and THREE.DataTexture2DArray.");
					it.setTexture2DArray(e, 0), v = St.TEXTURE_2D_ARRAY;
				}
				St.pixelStorei(St.UNPACK_FLIP_Y_WEBGL, e.flipY), St.pixelStorei(St.UNPACK_PREMULTIPLY_ALPHA_WEBGL, e.premultiplyAlpha), St.pixelStorei(St.UNPACK_ALIGNMENT, e.unpackAlignment);
				const _ = St.getParameter(St.UNPACK_ROW_LENGTH), x = St.getParameter(St.UNPACK_IMAGE_HEIGHT), y = St.getParameter(St.UNPACK_SKIP_PIXELS), M = St.getParameter(St.UNPACK_SKIP_ROWS), S = St.getParameter(St.UNPACK_SKIP_IMAGES);
				St.pixelStorei(St.UNPACK_ROW_LENGTH, m.width), St.pixelStorei(St.UNPACK_IMAGE_HEIGHT, m.height), St.pixelStorei(St.UNPACK_SKIP_PIXELS, l), St.pixelStorei(St.UNPACK_SKIP_ROWS, c), St.pixelStorei(St.UNPACK_SKIP_IMAGES, h), t.isDataTexture || t.isData3DTexture ? St.texSubImage3D(v, r, u, d, p, s, a, o, f, g, m.data) : e.isCompressedArrayTexture ? St.compressedTexSubImage3D(v, r, u, d, p, s, a, o, f, m.data) : St.texSubImage3D(v, r, u, d, p, s, a, o, f, g, m), St.pixelStorei(St.UNPACK_ROW_LENGTH, _), St.pixelStorei(St.UNPACK_IMAGE_HEIGHT, x), St.pixelStorei(St.UNPACK_SKIP_PIXELS, y), St.pixelStorei(St.UNPACK_SKIP_ROWS, M), St.pixelStorei(St.UNPACK_SKIP_IMAGES, S), 0 === r && e.generateMipmaps && St.generateMipmap(v), tt.unbindTexture();
			}, this.initRenderTarget = function(t) {
				void 0 === nt.get(t).__webglFramebuffer && it.setupRenderTarget(t);
			}, this.initTexture = function(t) {
				t.isCubeTexture ? it.setTextureCube(t, 0) : t.isData3DTexture ? it.setTexture3D(t, 0) : t.isDataArrayTexture || t.isCompressedArrayTexture ? it.setTexture2DArray(t, 0) : it.setTexture2D(t, 0), tt.unbindTexture();
			}, this.resetState = function() {
				b = 0, w = 0, T = null, tt.reset(), yt.reset();
			}, "undefined" != typeof __THREE_DEVTOOLS__ && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", { detail: this }));
		}
		get coordinateSystem() {
			return kn;
		}
		get outputColorSpace() {
			return this._outputColorSpace;
		}
		set outputColorSpace(t) {
			this._outputColorSpace = t;
			const e = this.getContext();
			e.drawingBufferColorSpace = t === "display-p3" ? "display-p3" : "srgb", e.unpackColorSpace = mi.workingColorSpace === "display-p3-linear" ? "display-p3" : "srgb";
		}
	};
	var sc = class sc {
		constructor(t, e = 25e-5) {
			this.isFogExp2 = !0, this.name = "", this.color = new ts(t), this.density = e;
		}
		clone() {
			return new sc(this.color, this.density);
		}
		toJSON() {
			return {
				type: "FogExp2",
				name: this.name,
				color: this.color.getHex(),
				density: this.density
			};
		}
	};
	var ac = class ac {
		constructor(t, e = 1, n = 1e3) {
			this.isFog = !0, this.name = "", this.color = new ts(t), this.near = e, this.far = n;
		}
		clone() {
			return new ac(this.color, this.near, this.far);
		}
		toJSON() {
			return {
				type: "Fog",
				name: this.name,
				color: this.color.getHex(),
				near: this.near,
				far: this.far
			};
		}
	};
	var oc = class extends Dr {
		constructor() {
			super(), this.isScene = !0, this.type = "Scene", this.background = null, this.environment = null, this.fog = null, this.backgroundBlurriness = 0, this.backgroundIntensity = 1, this.backgroundRotation = new _r(), this.environmentIntensity = 1, this.environmentRotation = new _r(), this.overrideMaterial = null, "undefined" != typeof __THREE_DEVTOOLS__ && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe", { detail: this }));
		}
		copy(t, e) {
			return super.copy(t, e), null !== t.background && (this.background = t.background.clone()), null !== t.environment && (this.environment = t.environment.clone()), null !== t.fog && (this.fog = t.fog.clone()), this.backgroundBlurriness = t.backgroundBlurriness, this.backgroundIntensity = t.backgroundIntensity, this.backgroundRotation.copy(t.backgroundRotation), this.environmentIntensity = t.environmentIntensity, this.environmentRotation.copy(t.environmentRotation), null !== t.overrideMaterial && (this.overrideMaterial = t.overrideMaterial.clone()), this.matrixAutoUpdate = t.matrixAutoUpdate, this;
		}
		toJSON(t) {
			const e = super.toJSON(t);
			return null !== this.fog && (e.object.fog = this.fog.toJSON()), this.backgroundBlurriness > 0 && (e.object.backgroundBlurriness = this.backgroundBlurriness), 1 !== this.backgroundIntensity && (e.object.backgroundIntensity = this.backgroundIntensity), e.object.backgroundRotation = this.backgroundRotation.toArray(), 1 !== this.environmentIntensity && (e.object.environmentIntensity = this.environmentIntensity), e.object.environmentRotation = this.environmentRotation.toArray(), e;
		}
	};
	var lc = class {
		constructor(t, e) {
			this.isInterleavedBuffer = !0, this.array = t, this.stride = e, this.count = void 0 !== t ? t.length / e : 0, this.usage = Cn, this.updateRanges = [], this.version = 0, this.uuid = qn();
		}
		onUploadCallback() {}
		set needsUpdate(t) {
			!0 === t && this.version++;
		}
		setUsage(t) {
			return this.usage = t, this;
		}
		addUpdateRange(t, e) {
			this.updateRanges.push({
				start: t,
				count: e
			});
		}
		clearUpdateRanges() {
			this.updateRanges.length = 0;
		}
		copy(t) {
			return this.array = new t.array.constructor(t.array), this.count = t.count, this.stride = t.stride, this.usage = t.usage, this;
		}
		copyAt(t, e, n) {
			t *= this.stride, n *= e.stride;
			for (let i = 0, r = this.stride; i < r; i++) this.array[t + i] = e.array[n + i];
			return this;
		}
		set(t, e = 0) {
			return this.array.set(t, e), this;
		}
		clone(t) {
			void 0 === t.arrayBuffers && (t.arrayBuffers = {}), void 0 === this.array.buffer._uuid && (this.array.buffer._uuid = qn()), void 0 === t.arrayBuffers[this.array.buffer._uuid] && (t.arrayBuffers[this.array.buffer._uuid] = this.array.slice(0).buffer);
			const e = new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]), n = new this.constructor(e, this.stride);
			return n.setUsage(this.usage), n;
		}
		onUpload(t) {
			return this.onUploadCallback = t, this;
		}
		toJSON(t) {
			return void 0 === t.arrayBuffers && (t.arrayBuffers = {}), void 0 === this.array.buffer._uuid && (this.array.buffer._uuid = qn()), void 0 === t.arrayBuffers[this.array.buffer._uuid] && (t.arrayBuffers[this.array.buffer._uuid] = Array.from(new Uint32Array(this.array.buffer))), {
				uuid: this.uuid,
				buffer: this.array.buffer._uuid,
				type: this.array.constructor.name,
				stride: this.stride
			};
		}
	};
	const cc = new Li();
	var hc = class hc {
		constructor(t, e, n, i = !1) {
			this.isInterleavedBufferAttribute = !0, this.name = "", this.data = t, this.itemSize = e, this.offset = n, this.normalized = i;
		}
		get count() {
			return this.data.count;
		}
		get array() {
			return this.data.array;
		}
		set needsUpdate(t) {
			this.data.needsUpdate = t;
		}
		applyMatrix4(t) {
			for (let e = 0, n = this.data.count; e < n; e++) cc.fromBufferAttribute(this, e), cc.applyMatrix4(t), this.setXYZ(e, cc.x, cc.y, cc.z);
			return this;
		}
		applyNormalMatrix(t) {
			for (let e = 0, n = this.count; e < n; e++) cc.fromBufferAttribute(this, e), cc.applyNormalMatrix(t), this.setXYZ(e, cc.x, cc.y, cc.z);
			return this;
		}
		transformDirection(t) {
			for (let e = 0, n = this.count; e < n; e++) cc.fromBufferAttribute(this, e), cc.transformDirection(t), this.setXYZ(e, cc.x, cc.y, cc.z);
			return this;
		}
		getComponent(t, e) {
			let n = this.array[t * this.data.stride + this.offset + e];
			return this.normalized && (n = Kn(n, this.array)), n;
		}
		setComponent(t, e, n) {
			return this.normalized && (n = $n(n, this.array)), this.data.array[t * this.data.stride + this.offset + e] = n, this;
		}
		setX(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.data.array[t * this.data.stride + this.offset] = e, this;
		}
		setY(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.data.array[t * this.data.stride + this.offset + 1] = e, this;
		}
		setZ(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.data.array[t * this.data.stride + this.offset + 2] = e, this;
		}
		setW(t, e) {
			return this.normalized && (e = $n(e, this.array)), this.data.array[t * this.data.stride + this.offset + 3] = e, this;
		}
		getX(t) {
			let e = this.data.array[t * this.data.stride + this.offset];
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		getY(t) {
			let e = this.data.array[t * this.data.stride + this.offset + 1];
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		getZ(t) {
			let e = this.data.array[t * this.data.stride + this.offset + 2];
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		getW(t) {
			let e = this.data.array[t * this.data.stride + this.offset + 3];
			return this.normalized && (e = Kn(e, this.array)), e;
		}
		setXY(t, e, n) {
			return t = t * this.data.stride + this.offset, this.normalized && (e = $n(e, this.array), n = $n(n, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = n, this;
		}
		setXYZ(t, e, n, i) {
			return t = t * this.data.stride + this.offset, this.normalized && (e = $n(e, this.array), n = $n(n, this.array), i = $n(i, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = n, this.data.array[t + 2] = i, this;
		}
		setXYZW(t, e, n, i, r) {
			return t = t * this.data.stride + this.offset, this.normalized && (e = $n(e, this.array), n = $n(n, this.array), i = $n(i, this.array), r = $n(r, this.array)), this.data.array[t + 0] = e, this.data.array[t + 1] = n, this.data.array[t + 2] = i, this.data.array[t + 3] = r, this;
		}
		clone(t) {
			if (void 0 === t) {
				console.log("THREE.InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");
				const t = [];
				for (let e = 0; e < this.count; e++) {
					const n = e * this.data.stride + this.offset;
					for (let e = 0; e < this.itemSize; e++) t.push(this.data.array[n + e]);
				}
				return new ds(new this.array.constructor(t), this.itemSize, this.normalized);
			}
			return void 0 === t.interleavedBuffers && (t.interleavedBuffers = {}), void 0 === t.interleavedBuffers[this.data.uuid] && (t.interleavedBuffers[this.data.uuid] = this.data.clone(t)), new hc(t.interleavedBuffers[this.data.uuid], this.itemSize, this.offset, this.normalized);
		}
		toJSON(t) {
			if (void 0 === t) {
				console.log("THREE.InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");
				const t = [];
				for (let e = 0; e < this.count; e++) {
					const n = e * this.data.stride + this.offset;
					for (let e = 0; e < this.itemSize; e++) t.push(this.data.array[n + e]);
				}
				return {
					itemSize: this.itemSize,
					type: this.array.constructor.name,
					array: t,
					normalized: this.normalized
				};
			}
			return void 0 === t.interleavedBuffers && (t.interleavedBuffers = {}), void 0 === t.interleavedBuffers[this.data.uuid] && (t.interleavedBuffers[this.data.uuid] = this.data.toJSON(t)), {
				isInterleavedBufferAttribute: !0,
				itemSize: this.itemSize,
				data: this.data.uuid,
				offset: this.offset,
				normalized: this.normalized
			};
		}
	};
	var uc = class extends is {
		constructor(t) {
			super(), this.isSpriteMaterial = !0, this.type = "SpriteMaterial", this.color = new ts(16777215), this.map = null, this.alphaMap = null, this.rotation = 0, this.sizeAttenuation = !0, this.transparent = !0, this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.color.copy(t.color), this.map = t.map, this.alphaMap = t.alphaMap, this.rotation = t.rotation, this.sizeAttenuation = t.sizeAttenuation, this.fog = t.fog, this;
		}
	};
	let dc;
	const pc = new Li(), mc = new Li(), fc = new Li(), gc = new ti(), vc = new ti(), _c = new lr(), xc = new Li(), yc = new Li(), Mc = new Li(), Sc = new ti(), bc = new ti(), wc = new ti();
	var Tc = class extends Dr {
		constructor(t = new uc()) {
			if (super(), this.isSprite = !0, this.type = "Sprite", void 0 === dc) {
				dc = new Cs();
				const e = new lc(new Float32Array([
					-.5,
					-.5,
					0,
					0,
					0,
					.5,
					-.5,
					0,
					1,
					0,
					.5,
					.5,
					0,
					1,
					1,
					-.5,
					.5,
					0,
					0,
					1
				]), 5);
				dc.setIndex([
					0,
					1,
					2,
					0,
					2,
					3
				]), dc.setAttribute("position", new hc(e, 3, 0, !1)), dc.setAttribute("uv", new hc(e, 2, 3, !1));
			}
			this.geometry = dc, this.material = t, this.center = new ti(.5, .5);
		}
		raycast(t, e) {
			null === t.camera && console.error("THREE.Sprite: \"Raycaster.camera\" needs to be set in order to raycast against sprites."), mc.setFromMatrixScale(this.matrixWorld), _c.copy(t.camera.matrixWorld), this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse, this.matrixWorld), fc.setFromMatrixPosition(this.modelViewMatrix), t.camera.isPerspectiveCamera && !1 === this.material.sizeAttenuation && mc.multiplyScalar(-fc.z);
			const n = this.material.rotation;
			let i, r;
			0 !== n && (r = Math.cos(n), i = Math.sin(n));
			const s = this.center;
			Ec(xc.set(-.5, -.5, 0), fc, s, mc, i, r), Ec(yc.set(.5, -.5, 0), fc, s, mc, i, r), Ec(Mc.set(.5, .5, 0), fc, s, mc, i, r), Sc.set(0, 0), bc.set(1, 0), wc.set(1, 1);
			let a = t.ray.intersectTriangle(xc, yc, Mc, !1, pc);
			if (null === a && (Ec(yc.set(-.5, .5, 0), fc, s, mc, i, r), bc.set(0, 1), a = t.ray.intersectTriangle(xc, Mc, yc, !1, pc), null === a)) return;
			const o = t.ray.origin.distanceTo(pc);
			o < t.near || o > t.far || e.push({
				distance: o,
				point: pc.clone(),
				uv: Zr.getInterpolation(pc, xc, yc, Mc, Sc, bc, wc, new ti()),
				face: null,
				object: this
			});
		}
		copy(t, e) {
			return super.copy(t, e), void 0 !== t.center && this.center.copy(t.center), this.material = t.material, this;
		}
	};
	function Ec(t, e, n, i, r, s) {
		gc.subVectors(t, n).addScalar(.5).multiply(i), void 0 !== r ? (vc.x = s * gc.x - r * gc.y, vc.y = r * gc.x + s * gc.y) : vc.copy(gc), t.copy(e), t.x += vc.x, t.y += vc.y, t.applyMatrix4(_c);
	}
	const Ac = new Li(), Rc = new Li();
	var Cc = class extends Dr {
		constructor() {
			super(), this._currentLevel = 0, this.type = "LOD", Object.defineProperties(this, {
				levels: {
					enumerable: !0,
					value: []
				},
				isLOD: { value: !0 }
			}), this.autoUpdate = !0;
		}
		copy(t) {
			super.copy(t, !1);
			const e = t.levels;
			for (let t = 0, n = e.length; t < n; t++) {
				const n = e[t];
				this.addLevel(n.object.clone(), n.distance, n.hysteresis);
			}
			return this.autoUpdate = t.autoUpdate, this;
		}
		addLevel(t, e = 0, n = 0) {
			e = Math.abs(e);
			const i = this.levels;
			let r;
			for (r = 0; r < i.length && !(e < i[r].distance); r++);
			return i.splice(r, 0, {
				distance: e,
				hysteresis: n,
				object: t
			}), this.add(t), this;
		}
		removeLevel(t) {
			const e = this.levels;
			for (let n = 0; n < e.length; n++) if (e[n].distance === t) {
				const t = e.splice(n, 1);
				return this.remove(t[0].object), !0;
			}
			return !1;
		}
		getCurrentLevel() {
			return this._currentLevel;
		}
		getObjectForDistance(t) {
			const e = this.levels;
			if (e.length > 0) {
				let n, i;
				for (n = 1, i = e.length; n < i; n++) {
					let i = e[n].distance;
					if (e[n].object.visible && (i -= i * e[n].hysteresis), t < i) break;
				}
				return e[n - 1].object;
			}
			return null;
		}
		raycast(t, e) {
			if (this.levels.length > 0) {
				Ac.setFromMatrixPosition(this.matrixWorld);
				const n = t.ray.origin.distanceTo(Ac);
				this.getObjectForDistance(n).raycast(t, e);
			}
		}
		update(t) {
			const e = this.levels;
			if (e.length > 1) {
				Ac.setFromMatrixPosition(t.matrixWorld), Rc.setFromMatrixPosition(this.matrixWorld);
				const n = Ac.distanceTo(Rc) / t.zoom;
				let i, r;
				for (e[0].object.visible = !0, i = 1, r = e.length; i < r; i++) {
					let t = e[i].distance;
					if (e[i].object.visible && (t -= t * e[i].hysteresis), !(n >= t)) break;
					e[i - 1].object.visible = !1, e[i].object.visible = !0;
				}
				for (this._currentLevel = i - 1; i < r; i++) e[i].object.visible = !1;
			}
		}
		toJSON(t) {
			const e = super.toJSON(t);
			!1 === this.autoUpdate && (e.object.autoUpdate = !1), e.object.levels = [];
			const n = this.levels;
			for (let t = 0, i = n.length; t < i; t++) {
				const i = n[t];
				e.object.levels.push({
					object: i.object.uuid,
					distance: i.distance,
					hysteresis: i.hysteresis
				});
			}
			return e;
		}
	};
	const Pc = new Li(), Ic = new wi(), Lc = new wi(), Uc = new Li(), Nc = new lr(), Dc = new Li(), Oc = new Qi(), Fc = new lr(), Bc = new or();
	var zc = class extends Vs {
		constructor(t, e) {
			super(t, e), this.isSkinnedMesh = !0, this.type = "SkinnedMesh", this.bindMode = st, this.bindMatrix = new lr(), this.bindMatrixInverse = new lr(), this.boundingBox = null, this.boundingSphere = null;
		}
		computeBoundingBox() {
			const t = this.geometry;
			null === this.boundingBox && (this.boundingBox = new Di()), this.boundingBox.makeEmpty();
			const e = t.getAttribute("position");
			for (let t = 0; t < e.count; t++) this.getVertexPosition(t, Dc), this.boundingBox.expandByPoint(Dc);
		}
		computeBoundingSphere() {
			const t = this.geometry;
			null === this.boundingSphere && (this.boundingSphere = new Qi()), this.boundingSphere.makeEmpty();
			const e = t.getAttribute("position");
			for (let t = 0; t < e.count; t++) this.getVertexPosition(t, Dc), this.boundingSphere.expandByPoint(Dc);
		}
		copy(t, e) {
			return super.copy(t, e), this.bindMode = t.bindMode, this.bindMatrix.copy(t.bindMatrix), this.bindMatrixInverse.copy(t.bindMatrixInverse), this.skeleton = t.skeleton, null !== t.boundingBox && (this.boundingBox = t.boundingBox.clone()), null !== t.boundingSphere && (this.boundingSphere = t.boundingSphere.clone()), this;
		}
		raycast(t, e) {
			const n = this.material, i = this.matrixWorld;
			void 0 !== n && (null === this.boundingSphere && this.computeBoundingSphere(), Oc.copy(this.boundingSphere), Oc.applyMatrix4(i), !1 !== t.ray.intersectsSphere(Oc) && (Fc.copy(i).invert(), Bc.copy(t.ray).applyMatrix4(Fc), null !== this.boundingBox && !1 === Bc.intersectsBox(this.boundingBox) || this._computeIntersections(t, e, Bc)));
		}
		getVertexPosition(t, e) {
			return super.getVertexPosition(t, e), this.applyBoneTransform(t, e), e;
		}
		bind(t, e) {
			this.skeleton = t, void 0 === e && (this.updateMatrixWorld(!0), this.skeleton.calculateInverses(), e = this.matrixWorld), this.bindMatrix.copy(e), this.bindMatrixInverse.copy(e).invert();
		}
		pose() {
			this.skeleton.pose();
		}
		normalizeSkinWeights() {
			const t = new wi(), e = this.geometry.attributes.skinWeight;
			for (let n = 0, i = e.count; n < i; n++) {
				t.fromBufferAttribute(e, n);
				const i = 1 / t.manhattanLength();
				i !== Infinity ? t.multiplyScalar(i) : t.set(1, 0, 0, 0), e.setXYZW(n, t.x, t.y, t.z, t.w);
			}
		}
		updateMatrixWorld(t) {
			super.updateMatrixWorld(t), this.bindMode === "attached" ? this.bindMatrixInverse.copy(this.matrixWorld).invert() : this.bindMode === "detached" ? this.bindMatrixInverse.copy(this.bindMatrix).invert() : console.warn("THREE.SkinnedMesh: Unrecognized bindMode: " + this.bindMode);
		}
		applyBoneTransform(t, e) {
			const n = this.skeleton, i = this.geometry;
			Ic.fromBufferAttribute(i.attributes.skinIndex, t), Lc.fromBufferAttribute(i.attributes.skinWeight, t), Pc.copy(e).applyMatrix4(this.bindMatrix), e.set(0, 0, 0);
			for (let t = 0; t < 4; t++) {
				const i = Lc.getComponent(t);
				if (0 !== i) {
					const r = Ic.getComponent(t);
					Nc.multiplyMatrices(n.bones[r].matrixWorld, n.boneInverses[r]), e.addScaledVector(Uc.copy(Pc).applyMatrix4(Nc), i);
				}
			}
			return e.applyMatrix4(this.bindMatrixInverse);
		}
	};
	var kc = class extends Dr {
		constructor() {
			super(), this.isBone = !0, this.type = "Bone";
		}
	};
	var Vc = class extends bi {
		constructor(t = null, e = 1, n = 1, i, r, s, a, o, l = 1003, c = 1003, h, u) {
			super(null, s, a, o, l, c, i, r, h, u), this.isDataTexture = !0, this.image = {
				data: t,
				width: e,
				height: n
			}, this.generateMipmaps = !1, this.flipY = !1, this.unpackAlignment = 1;
		}
	};
	const Hc = new lr(), Gc = new lr();
	var Wc = class Wc {
		constructor(t = [], e = []) {
			this.uuid = qn(), this.bones = t.slice(0), this.boneInverses = e, this.boneMatrices = null, this.boneTexture = null, this.init();
		}
		init() {
			const t = this.bones, e = this.boneInverses;
			if (this.boneMatrices = new Float32Array(16 * t.length), 0 === e.length) this.calculateInverses();
			else if (t.length !== e.length) {
				console.warn("THREE.Skeleton: Number of inverse bone matrices does not match amount of bones."), this.boneInverses = [];
				for (let t = 0, e = this.bones.length; t < e; t++) this.boneInverses.push(new lr());
			}
		}
		calculateInverses() {
			this.boneInverses.length = 0;
			for (let t = 0, e = this.bones.length; t < e; t++) {
				const e = new lr();
				this.bones[t] && e.copy(this.bones[t].matrixWorld).invert(), this.boneInverses.push(e);
			}
		}
		pose() {
			for (let t = 0, e = this.bones.length; t < e; t++) {
				const e = this.bones[t];
				e && e.matrixWorld.copy(this.boneInverses[t]).invert();
			}
			for (let t = 0, e = this.bones.length; t < e; t++) {
				const e = this.bones[t];
				e && (e.parent && e.parent.isBone ? (e.matrix.copy(e.parent.matrixWorld).invert(), e.matrix.multiply(e.matrixWorld)) : e.matrix.copy(e.matrixWorld), e.matrix.decompose(e.position, e.quaternion, e.scale));
			}
		}
		update() {
			const t = this.bones, e = this.boneInverses, n = this.boneMatrices, i = this.boneTexture;
			for (let i = 0, r = t.length; i < r; i++) {
				const r = t[i] ? t[i].matrixWorld : Gc;
				Hc.multiplyMatrices(r, e[i]), Hc.toArray(n, 16 * i);
			}
			null !== i && (i.needsUpdate = !0);
		}
		clone() {
			return new Wc(this.bones, this.boneInverses);
		}
		computeBoneTexture() {
			let t = Math.sqrt(4 * this.bones.length);
			t = 4 * Math.ceil(t / 4), t = Math.max(t, 4);
			const e = new Float32Array(t * t * 4);
			e.set(this.boneMatrices);
			const n = new Vc(e, t, t, kt, Lt);
			return n.needsUpdate = !0, this.boneMatrices = e, this.boneTexture = n, this;
		}
		getBoneByName(t) {
			for (let e = 0, n = this.bones.length; e < n; e++) {
				const n = this.bones[e];
				if (n.name === t) return n;
			}
		}
		dispose() {
			null !== this.boneTexture && (this.boneTexture.dispose(), this.boneTexture = null);
		}
		fromJSON(t, e) {
			this.uuid = t.uuid;
			for (let n = 0, i = t.bones.length; n < i; n++) {
				const i = t.bones[n];
				let r = e[i];
				void 0 === r && (console.warn("THREE.Skeleton: No bone found with UUID:", i), r = new kc()), this.bones.push(r), this.boneInverses.push(new lr().fromArray(t.boneInverses[n]));
			}
			return this.init(), this;
		}
		toJSON() {
			const t = {
				metadata: {
					version: 4.6,
					type: "Skeleton",
					generator: "Skeleton.toJSON"
				},
				bones: [],
				boneInverses: []
			};
			t.uuid = this.uuid;
			const e = this.bones, n = this.boneInverses;
			for (let i = 0, r = e.length; i < r; i++) {
				const r = e[i];
				t.bones.push(r.uuid);
				const s = n[i];
				t.boneInverses.push(s.toArray());
			}
			return t;
		}
	};
	var Xc = class extends ds {
		constructor(t, e, n, i = 1) {
			super(t, e, n), this.isInstancedBufferAttribute = !0, this.meshPerAttribute = i;
		}
		copy(t) {
			return super.copy(t), this.meshPerAttribute = t.meshPerAttribute, this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.meshPerAttribute = this.meshPerAttribute, t.isInstancedBufferAttribute = !0, t;
		}
	};
	const jc = new lr(), qc = new lr(), Yc = [], Zc = new Di(), Jc = new lr(), Kc = new Vs(), $c = new Qi();
	var Qc = class extends Vs {
		constructor(t, e, n) {
			super(t, e), this.isInstancedMesh = !0, this.instanceMatrix = new Xc(new Float32Array(16 * n), 16), this.instanceColor = null, this.morphTexture = null, this.count = n, this.boundingBox = null, this.boundingSphere = null;
			for (let t = 0; t < n; t++) this.setMatrixAt(t, Jc);
		}
		computeBoundingBox() {
			const t = this.geometry, e = this.count;
			null === this.boundingBox && (this.boundingBox = new Di()), null === t.boundingBox && t.computeBoundingBox(), this.boundingBox.makeEmpty();
			for (let n = 0; n < e; n++) this.getMatrixAt(n, jc), Zc.copy(t.boundingBox).applyMatrix4(jc), this.boundingBox.union(Zc);
		}
		computeBoundingSphere() {
			const t = this.geometry, e = this.count;
			null === this.boundingSphere && (this.boundingSphere = new Qi()), null === t.boundingSphere && t.computeBoundingSphere(), this.boundingSphere.makeEmpty();
			for (let n = 0; n < e; n++) this.getMatrixAt(n, jc), $c.copy(t.boundingSphere).applyMatrix4(jc), this.boundingSphere.union($c);
		}
		copy(t, e) {
			return super.copy(t, e), this.instanceMatrix.copy(t.instanceMatrix), null !== t.morphTexture && (this.morphTexture = t.morphTexture.clone()), null !== t.instanceColor && (this.instanceColor = t.instanceColor.clone()), this.count = t.count, null !== t.boundingBox && (this.boundingBox = t.boundingBox.clone()), null !== t.boundingSphere && (this.boundingSphere = t.boundingSphere.clone()), this;
		}
		getColorAt(t, e) {
			e.fromArray(this.instanceColor.array, 3 * t);
		}
		getMatrixAt(t, e) {
			e.fromArray(this.instanceMatrix.array, 16 * t);
		}
		getMorphAt(t, e) {
			const n = e.morphTargetInfluences, i = this.morphTexture.source.data.data, r = t * (n.length + 1) + 1;
			for (let t = 0; t < n.length; t++) n[t] = i[r + t];
		}
		raycast(t, e) {
			const n = this.matrixWorld, i = this.count;
			if (Kc.geometry = this.geometry, Kc.material = this.material, void 0 !== Kc.material && (null === this.boundingSphere && this.computeBoundingSphere(), $c.copy(this.boundingSphere), $c.applyMatrix4(n), !1 !== t.ray.intersectsSphere($c))) for (let r = 0; r < i; r++) {
				this.getMatrixAt(r, jc), qc.multiplyMatrices(n, jc), Kc.matrixWorld = qc, Kc.raycast(t, Yc);
				for (let t = 0, n = Yc.length; t < n; t++) {
					const n = Yc[t];
					n.instanceId = r, n.object = this, e.push(n);
				}
				Yc.length = 0;
			}
		}
		setColorAt(t, e) {
			null === this.instanceColor && (this.instanceColor = new Xc(new Float32Array(3 * this.instanceMatrix.count).fill(1), 3)), e.toArray(this.instanceColor.array, 3 * t);
		}
		setMatrixAt(t, e) {
			e.toArray(this.instanceMatrix.array, 16 * t);
		}
		setMorphAt(t, e) {
			const n = e.morphTargetInfluences, i = n.length + 1;
			null === this.morphTexture && (this.morphTexture = new Vc(new Float32Array(i * this.count), i, this.count, 1028, 1015));
			const r = this.morphTexture.source.data.data;
			let s = 0;
			for (let t = 0; t < n.length; t++) s += n[t];
			const a = this.geometry.morphTargetsRelative ? 1 : 1 - s, o = i * t;
			r[o] = a, r.set(n, o + 1);
		}
		updateMorphTargets() {}
		dispose() {
			return this.dispatchEvent({ type: "dispose" }), null !== this.morphTexture && (this.morphTexture.dispose(), this.morphTexture = null), this;
		}
	};
	function th(t, e) {
		return t.z - e.z;
	}
	function eh(t, e) {
		return e.z - t.z;
	}
	var nh = class {
		constructor() {
			this.index = 0, this.pool = [], this.list = [];
		}
		push(t, e, n) {
			const i = this.pool, r = this.list;
			this.index >= i.length && i.push({
				start: -1,
				count: -1,
				z: -1,
				index: -1
			});
			const s = i[this.index];
			r.push(s), this.index++, s.start = t.start, s.count = t.count, s.z = e, s.index = n;
		}
		reset() {
			this.list.length = 0, this.index = 0;
		}
	};
	const ih = new lr(), rh = new lr(), sh = new lr(), ah = new ts(1, 1, 1), oh = new lr(), lh = new ha(), ch = new Di(), hh = new Qi(), uh = new Li(), dh = new Li(), ph = new Li(), mh = new nh(), fh = new Vs(), gh = [];
	function vh(t, e, n = 0) {
		const i = e.itemSize;
		if (t.isInterleavedBufferAttribute || t.array.constructor !== e.array.constructor) {
			const r = t.count;
			for (let s = 0; s < r; s++) for (let r = 0; r < i; r++) e.setComponent(s + n, r, t.getComponent(s, r));
		} else e.array.set(t.array, n * i);
		e.needsUpdate = !0;
	}
	var _h = class extends Vs {
		get maxInstanceCount() {
			return this._maxInstanceCount;
		}
		constructor(t, e, n = 2 * e, i) {
			super(new Cs(), i), this.isBatchedMesh = !0, this.perObjectFrustumCulled = !0, this.sortObjects = !0, this.boundingBox = null, this.boundingSphere = null, this.customSort = null, this._drawInfo = [], this._availableInstanceIds = [], this._drawRanges = [], this._reservedRanges = [], this._bounds = [], this._maxInstanceCount = t, this._maxVertexCount = e, this._maxIndexCount = n, this._geometryInitialized = !1, this._geometryCount = 0, this._multiDrawCounts = new Int32Array(t), this._multiDrawStarts = new Int32Array(t), this._multiDrawCount = 0, this._multiDrawInstances = null, this._visibilityChanged = !0, this._matricesTexture = null, this._indirectTexture = null, this._colorsTexture = null, this._initMatricesTexture(), this._initIndirectTexture();
		}
		_initMatricesTexture() {
			let t = Math.sqrt(4 * this._maxInstanceCount);
			t = 4 * Math.ceil(t / 4), t = Math.max(t, 4);
			const n = new Vc(new Float32Array(t * t * 4), t, t, kt, Lt);
			this._matricesTexture = n;
		}
		_initIndirectTexture() {
			let t = Math.sqrt(this._maxInstanceCount);
			t = Math.ceil(t);
			const n = new Vc(new Uint32Array(t * t), t, t, jt, It);
			this._indirectTexture = n;
		}
		_initColorsTexture() {
			let t = Math.sqrt(this._maxInstanceCount);
			t = Math.ceil(t);
			const n = new Vc(new Float32Array(t * t * 4).fill(1), t, t, kt, Lt);
			n.colorSpace = mi.workingColorSpace, this._colorsTexture = n;
		}
		_initializeGeometry(t) {
			const e = this.geometry, n = this._maxVertexCount, i = this._maxIndexCount;
			if (!1 === this._geometryInitialized) {
				for (const i in t.attributes) {
					const { array: s, itemSize: a, normalized: o } = t.getAttribute(i), c = new ds(new s.constructor(n * a), a, o);
					e.setAttribute(i, c);
				}
				if (null !== t.getIndex()) {
					const t = n > 65535 ? new Uint32Array(i) : new Uint16Array(i);
					e.setIndex(new ds(t, 1));
				}
				this._geometryInitialized = !0;
			}
		}
		_validateGeometry(t) {
			const e = this.geometry;
			if (Boolean(t.getIndex()) !== Boolean(e.getIndex())) throw new Error("BatchedMesh: All geometries must consistently have \"index\".");
			for (const n in e.attributes) {
				if (!t.hasAttribute(n)) throw new Error(`BatchedMesh: Added geometry missing "${n}". All geometries must have consistent attributes.`);
				const i = t.getAttribute(n), r = e.getAttribute(n);
				if (i.itemSize !== r.itemSize || i.normalized !== r.normalized) throw new Error("BatchedMesh: All attributes must have a consistent itemSize and normalized value.");
			}
		}
		setCustomSort(t) {
			return this.customSort = t, this;
		}
		computeBoundingBox() {
			null === this.boundingBox && (this.boundingBox = new Di());
			const t = this.boundingBox, e = this._drawInfo;
			t.makeEmpty();
			for (let n = 0, i = e.length; n < i; n++) {
				if (!1 === e[n].active) continue;
				const i = e[n].geometryIndex;
				this.getMatrixAt(n, ih), this.getBoundingBoxAt(i, ch).applyMatrix4(ih), t.union(ch);
			}
		}
		computeBoundingSphere() {
			null === this.boundingSphere && (this.boundingSphere = new Qi());
			const t = this.boundingSphere, e = this._drawInfo;
			t.makeEmpty();
			for (let n = 0, i = e.length; n < i; n++) {
				if (!1 === e[n].active) continue;
				const i = e[n].geometryIndex;
				this.getMatrixAt(n, ih), this.getBoundingSphereAt(i, hh).applyMatrix4(ih), t.union(hh);
			}
		}
		addInstance(t) {
			if (this._drawInfo.length >= this.maxInstanceCount && 0 === this._availableInstanceIds.length) throw new Error("BatchedMesh: Maximum item count reached.");
			const e = {
				visible: !0,
				active: !0,
				geometryIndex: t
			};
			let n = null;
			this._availableInstanceIds.length > 0 ? (n = this._availableInstanceIds.pop(), this._drawInfo[n] = e) : (n = this._drawInfo.length, this._drawInfo.push(e));
			const i = this._matricesTexture, r = i.image.data;
			sh.toArray(r, 16 * n), i.needsUpdate = !0;
			const s = this._colorsTexture;
			return s && (ah.toArray(s.image.data, 4 * n), s.needsUpdate = !0), n;
		}
		addGeometry(t, e = -1, n = -1) {
			if (this._initializeGeometry(t), this._validateGeometry(t), this._drawInfo.length >= this._maxInstanceCount) throw new Error("BatchedMesh: Maximum item count reached.");
			const i = {
				vertexStart: -1,
				vertexCount: -1,
				indexStart: -1,
				indexCount: -1
			};
			let r = null;
			const s = this._reservedRanges, a = this._drawRanges, o = this._bounds;
			0 !== this._geometryCount && (r = s[s.length - 1]), i.vertexCount = -1 === e ? t.getAttribute("position").count : e, i.vertexStart = null === r ? 0 : r.vertexStart + r.vertexCount;
			const l = t.getIndex(), c = null !== l;
			if (c && (i.indexCount = -1 === n ? l.count : n, i.indexStart = null === r ? 0 : r.indexStart + r.indexCount), -1 !== i.indexStart && i.indexStart + i.indexCount > this._maxIndexCount || i.vertexStart + i.vertexCount > this._maxVertexCount) throw new Error("BatchedMesh: Reserved space request exceeds the maximum buffer size.");
			const h = this._geometryCount;
			return this._geometryCount++, s.push(i), a.push({
				start: c ? i.indexStart : i.vertexStart,
				count: -1
			}), o.push({
				boxInitialized: !1,
				box: new Di(),
				sphereInitialized: !1,
				sphere: new Qi()
			}), this.setGeometryAt(h, t), h;
		}
		setGeometryAt(t, e) {
			if (t >= this._geometryCount) throw new Error("BatchedMesh: Maximum geometry count reached.");
			this._validateGeometry(e);
			const n = this.geometry, i = null !== n.getIndex(), r = n.getIndex(), s = e.getIndex(), a = this._reservedRanges[t];
			if (i && s.count > a.indexCount || e.attributes.position.count > a.vertexCount) throw new Error("BatchedMesh: Reserved space not large enough for provided geometry.");
			const o = a.vertexStart, l = a.vertexCount;
			for (const t in n.attributes) {
				const i = e.getAttribute(t), r = n.getAttribute(t);
				vh(i, r, o);
				const s = i.itemSize;
				for (let t = i.count, e = l; t < e; t++) {
					const e = o + t;
					for (let t = 0; t < s; t++) r.setComponent(e, t, 0);
				}
				r.needsUpdate = !0, r.addUpdateRange(o * s, l * s);
			}
			if (i) {
				const t = a.indexStart;
				for (let e = 0; e < s.count; e++) r.setX(t + e, o + s.getX(e));
				for (let e = s.count, n = a.indexCount; e < n; e++) r.setX(t + e, o);
				r.needsUpdate = !0, r.addUpdateRange(t, a.indexCount);
			}
			const c = this._bounds[t];
			null !== e.boundingBox ? (c.box.copy(e.boundingBox), c.boxInitialized = !0) : c.boxInitialized = !1, null !== e.boundingSphere ? (c.sphere.copy(e.boundingSphere), c.sphereInitialized = !0) : c.sphereInitialized = !1;
			const h = this._drawRanges[t], u = e.getAttribute("position");
			return h.count = i ? s.count : u.count, this._visibilityChanged = !0, t;
		}
		deleteInstance(t) {
			const e = this._drawInfo;
			return t >= e.length || !1 === e[t].active || (e[t].active = !1, this._availableInstanceIds.push(t), this._visibilityChanged = !0), this;
		}
		getBoundingBoxAt(t, e) {
			if (t >= this._geometryCount) return null;
			const n = this._bounds[t], i = n.box, r = this.geometry;
			if (!1 === n.boxInitialized) {
				i.makeEmpty();
				const e = r.index, s = r.attributes.position, a = this._drawRanges[t];
				for (let t = a.start, n = a.start + a.count; t < n; t++) {
					let n = t;
					e && (n = e.getX(n)), i.expandByPoint(uh.fromBufferAttribute(s, n));
				}
				n.boxInitialized = !0;
			}
			return e.copy(i), e;
		}
		getBoundingSphereAt(t, e) {
			if (t >= this._geometryCount) return null;
			const n = this._bounds[t], i = n.sphere, r = this.geometry;
			if (!1 === n.sphereInitialized) {
				i.makeEmpty(), this.getBoundingBoxAt(t, ch), ch.getCenter(i.center);
				const e = r.index, s = r.attributes.position, a = this._drawRanges[t];
				let o = 0;
				for (let t = a.start, n = a.start + a.count; t < n; t++) {
					let n = t;
					e && (n = e.getX(n)), uh.fromBufferAttribute(s, n), o = Math.max(o, i.center.distanceToSquared(uh));
				}
				i.radius = Math.sqrt(o), n.sphereInitialized = !0;
			}
			return e.copy(i), e;
		}
		setMatrixAt(t, e) {
			const n = this._drawInfo, i = this._matricesTexture, r = this._matricesTexture.image.data;
			return t >= n.length || !1 === n[t].active || (e.toArray(r, 16 * t), i.needsUpdate = !0), this;
		}
		getMatrixAt(t, e) {
			const n = this._drawInfo, i = this._matricesTexture.image.data;
			return t >= n.length || !1 === n[t].active ? null : e.fromArray(i, 16 * t);
		}
		setColorAt(t, e) {
			null === this._colorsTexture && this._initColorsTexture();
			const n = this._colorsTexture, i = this._colorsTexture.image.data, r = this._drawInfo;
			return t >= r.length || !1 === r[t].active || (e.toArray(i, 4 * t), n.needsUpdate = !0), this;
		}
		getColorAt(t, e) {
			const n = this._colorsTexture.image.data, i = this._drawInfo;
			return t >= i.length || !1 === i[t].active ? null : e.fromArray(n, 4 * t);
		}
		setVisibleAt(t, e) {
			const n = this._drawInfo;
			return t >= n.length || !1 === n[t].active || n[t].visible === e || (n[t].visible = e, this._visibilityChanged = !0), this;
		}
		getVisibleAt(t) {
			const e = this._drawInfo;
			return !(t >= e.length || !1 === e[t].active) && e[t].visible;
		}
		setGeometryIdAt(t, e) {
			const n = this._drawInfo;
			return t >= n.length || !1 === n[t].active || e < 0 || e >= this._geometryCount ? null : (n[t].geometryIndex = e, this);
		}
		getGeometryIdAt(t) {
			const e = this._drawInfo;
			return t >= e.length || !1 === e[t].active ? -1 : e[t].geometryIndex;
		}
		getGeometryRangeAt(t, e = {}) {
			if (t < 0 || t >= this._geometryCount) return null;
			const n = this._drawRanges[t];
			return e.start = n.start, e.count = n.count, e;
		}
		raycast(t, e) {
			const n = this._drawInfo, i = this._drawRanges, r = this.matrixWorld, s = this.geometry;
			fh.material = this.material, fh.geometry.index = s.index, fh.geometry.attributes = s.attributes, null === fh.geometry.boundingBox && (fh.geometry.boundingBox = new Di()), null === fh.geometry.boundingSphere && (fh.geometry.boundingSphere = new Qi());
			for (let s = 0, a = n.length; s < a; s++) {
				if (!n[s].visible || !n[s].active) continue;
				const a = n[s].geometryIndex, o = i[a];
				fh.geometry.setDrawRange(o.start, o.count), this.getMatrixAt(s, fh.matrixWorld).premultiply(r), this.getBoundingBoxAt(a, fh.geometry.boundingBox), this.getBoundingSphereAt(a, fh.geometry.boundingSphere), fh.raycast(t, gh);
				for (let t = 0, n = gh.length; t < n; t++) {
					const n = gh[t];
					n.object = this, n.batchId = s, e.push(n);
				}
				gh.length = 0;
			}
			fh.material = null, fh.geometry.index = null, fh.geometry.attributes = {}, fh.geometry.setDrawRange(0, Infinity);
		}
		copy(t) {
			return super.copy(t), this.geometry = t.geometry.clone(), this.perObjectFrustumCulled = t.perObjectFrustumCulled, this.sortObjects = t.sortObjects, this.boundingBox = null !== t.boundingBox ? t.boundingBox.clone() : null, this.boundingSphere = null !== t.boundingSphere ? t.boundingSphere.clone() : null, this._drawRanges = t._drawRanges.map(((t) => ({ ...t }))), this._reservedRanges = t._reservedRanges.map(((t) => ({ ...t }))), this._drawInfo = t._drawInfo.map(((t) => ({ ...t }))), this._bounds = t._bounds.map(((t) => ({
				boxInitialized: t.boxInitialized,
				box: t.box.clone(),
				sphereInitialized: t.sphereInitialized,
				sphere: t.sphere.clone()
			}))), this._maxInstanceCount = t._maxInstanceCount, this._maxVertexCount = t._maxVertexCount, this._maxIndexCount = t._maxIndexCount, this._geometryInitialized = t._geometryInitialized, this._geometryCount = t._geometryCount, this._multiDrawCounts = t._multiDrawCounts.slice(), this._multiDrawStarts = t._multiDrawStarts.slice(), this._matricesTexture = t._matricesTexture.clone(), this._matricesTexture.image.data = this._matricesTexture.image.data.slice(), null !== this._colorsTexture && (this._colorsTexture = t._colorsTexture.clone(), this._colorsTexture.image.data = this._colorsTexture.image.data.slice()), this;
		}
		dispose() {
			return this.geometry.dispose(), this._matricesTexture.dispose(), this._matricesTexture = null, this._indirectTexture.dispose(), this._indirectTexture = null, null !== this._colorsTexture && (this._colorsTexture.dispose(), this._colorsTexture = null), this;
		}
		onBeforeRender(t, e, n, i, r) {
			if (!this._visibilityChanged && !this.perObjectFrustumCulled && !this.sortObjects) return;
			const s = i.getIndex(), a = null === s ? 1 : s.array.BYTES_PER_ELEMENT, o = this._drawInfo, l = this._multiDrawStarts, c = this._multiDrawCounts, h = this._drawRanges, u = this.perObjectFrustumCulled, d = this._indirectTexture, p = d.image.data;
			u && (oh.multiplyMatrices(n.projectionMatrix, n.matrixWorldInverse).multiply(this.matrixWorld), lh.setFromProjectionMatrix(oh, t.coordinateSystem));
			let m = 0;
			if (this.sortObjects) {
				rh.copy(this.matrixWorld).invert(), uh.setFromMatrixPosition(n.matrixWorld).applyMatrix4(rh), dh.set(0, 0, -1).transformDirection(n.matrixWorld).transformDirection(rh);
				for (let t = 0, e = o.length; t < e; t++) if (o[t].visible && o[t].active) {
					const e = o[t].geometryIndex;
					this.getMatrixAt(t, ih), this.getBoundingSphereAt(e, hh).applyMatrix4(ih);
					let n = !1;
					if (u && (n = !lh.intersectsSphere(hh)), !n) {
						const n = ph.subVectors(hh.center, uh).dot(dh);
						mh.push(h[e], n, t);
					}
				}
				const t = mh.list, e = this.customSort;
				null === e ? t.sort(r.transparent ? eh : th) : e.call(this, t, n);
				for (let e = 0, n = t.length; e < n; e++) {
					const n = t[e];
					l[m] = n.start * a, c[m] = n.count, p[m] = n.index, m++;
				}
				mh.reset();
			} else for (let t = 0, e = o.length; t < e; t++) if (o[t].visible && o[t].active) {
				const e = o[t].geometryIndex;
				let n = !1;
				if (u && (this.getMatrixAt(t, ih), this.getBoundingSphereAt(e, hh).applyMatrix4(ih), n = !lh.intersectsSphere(hh)), !n) {
					const n = h[e];
					l[m] = n.start * a, c[m] = n.count, p[m] = t, m++;
				}
			}
			d.needsUpdate = !0, this._multiDrawCount = m, this._visibilityChanged = !1;
		}
		onBeforeShadow(t, e, n, i, r, s) {
			this.onBeforeRender(t, null, i, r, s);
		}
	};
	var xh = class extends is {
		constructor(t) {
			super(), this.isLineBasicMaterial = !0, this.type = "LineBasicMaterial", this.color = new ts(16777215), this.map = null, this.linewidth = 1, this.linecap = "round", this.linejoin = "round", this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.color.copy(t.color), this.map = t.map, this.linewidth = t.linewidth, this.linecap = t.linecap, this.linejoin = t.linejoin, this.fog = t.fog, this;
		}
	};
	const yh = new Li(), Mh = new Li(), Sh = new lr(), bh = new or(), wh = new Qi(), Th = new Li(), Eh = new Li();
	var Ah = class extends Dr {
		constructor(t = new Cs(), e = new xh()) {
			super(), this.isLine = !0, this.type = "Line", this.geometry = t, this.material = e, this.updateMorphTargets();
		}
		copy(t, e) {
			return super.copy(t, e), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this;
		}
		computeLineDistances() {
			const t = this.geometry;
			if (null === t.index) {
				const e = t.attributes.position, n = [0];
				for (let t = 1, i = e.count; t < i; t++) yh.fromBufferAttribute(e, t - 1), Mh.fromBufferAttribute(e, t), n[t] = n[t - 1], n[t] += yh.distanceTo(Mh);
				t.setAttribute("lineDistance", new Ms(n, 1));
			} else console.warn("THREE.Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
			return this;
		}
		raycast(t, e) {
			const n = this.geometry, i = this.matrixWorld, r = t.params.Line.threshold, s = n.drawRange;
			if (null === n.boundingSphere && n.computeBoundingSphere(), wh.copy(n.boundingSphere), wh.applyMatrix4(i), wh.radius += r, !1 === t.ray.intersectsSphere(wh)) return;
			Sh.copy(i).invert(), bh.copy(t.ray).applyMatrix4(Sh);
			const a = r / ((this.scale.x + this.scale.y + this.scale.z) / 3), o = a * a, l = this.isLineSegments ? 2 : 1, c = n.index, h = n.attributes.position;
			if (null !== c) {
				const n = Math.max(0, s.start), i = Math.min(c.count, s.start + s.count);
				for (let r = n, s = i - 1; r < s; r += l) {
					const n = c.getX(r), i = c.getX(r + 1), s = Rh(this, t, bh, o, n, i);
					s && e.push(s);
				}
				if (this.isLineLoop) {
					const r = c.getX(i - 1), s = c.getX(n), a = Rh(this, t, bh, o, r, s);
					a && e.push(a);
				}
			} else {
				const n = Math.max(0, s.start), i = Math.min(h.count, s.start + s.count);
				for (let r = n, s = i - 1; r < s; r += l) {
					const n = Rh(this, t, bh, o, r, r + 1);
					n && e.push(n);
				}
				if (this.isLineLoop) {
					const r = Rh(this, t, bh, o, i - 1, n);
					r && e.push(r);
				}
			}
		}
		updateMorphTargets() {
			const t = this.geometry.morphAttributes, e = Object.keys(t);
			if (e.length > 0) {
				const n = t[e[0]];
				if (void 0 !== n) {
					this.morphTargetInfluences = [], this.morphTargetDictionary = {};
					for (let t = 0, e = n.length; t < e; t++) {
						const e = n[t].name || String(t);
						this.morphTargetInfluences.push(0), this.morphTargetDictionary[e] = t;
					}
				}
			}
		}
	};
	function Rh(t, e, n, i, r, s) {
		const a = t.geometry.attributes.position;
		yh.fromBufferAttribute(a, r), Mh.fromBufferAttribute(a, s);
		if (n.distanceSqToSegment(yh, Mh, Th, Eh) > i) return;
		Th.applyMatrix4(t.matrixWorld);
		const o = e.ray.origin.distanceTo(Th);
		return o < e.near || o > e.far ? void 0 : {
			distance: o,
			point: Eh.clone().applyMatrix4(t.matrixWorld),
			index: r,
			face: null,
			faceIndex: null,
			barycoord: null,
			object: t
		};
	}
	const Ch = new Li(), Ph = new Li();
	var Ih = class extends Ah {
		constructor(t, e) {
			super(t, e), this.isLineSegments = !0, this.type = "LineSegments";
		}
		computeLineDistances() {
			const t = this.geometry;
			if (null === t.index) {
				const e = t.attributes.position, n = [];
				for (let t = 0, i = e.count; t < i; t += 2) Ch.fromBufferAttribute(e, t), Ph.fromBufferAttribute(e, t + 1), n[t] = 0 === t ? 0 : n[t - 1], n[t + 1] = n[t] + Ch.distanceTo(Ph);
				t.setAttribute("lineDistance", new Ms(n, 1));
			} else console.warn("THREE.LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
			return this;
		}
	};
	var Lh = class extends Ah {
		constructor(t, e) {
			super(t, e), this.isLineLoop = !0, this.type = "LineLoop";
		}
	};
	var Uh = class extends is {
		constructor(t) {
			super(), this.isPointsMaterial = !0, this.type = "PointsMaterial", this.color = new ts(16777215), this.map = null, this.alphaMap = null, this.size = 1, this.sizeAttenuation = !0, this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.color.copy(t.color), this.map = t.map, this.alphaMap = t.alphaMap, this.size = t.size, this.sizeAttenuation = t.sizeAttenuation, this.fog = t.fog, this;
		}
	};
	const Nh = new lr(), Dh = new or(), Oh = new Qi(), Fh = new Li();
	var Bh = class extends Dr {
		constructor(t = new Cs(), e = new Uh()) {
			super(), this.isPoints = !0, this.type = "Points", this.geometry = t, this.material = e, this.updateMorphTargets();
		}
		copy(t, e) {
			return super.copy(t, e), this.material = Array.isArray(t.material) ? t.material.slice() : t.material, this.geometry = t.geometry, this;
		}
		raycast(t, e) {
			const n = this.geometry, i = this.matrixWorld, r = t.params.Points.threshold, s = n.drawRange;
			if (null === n.boundingSphere && n.computeBoundingSphere(), Oh.copy(n.boundingSphere), Oh.applyMatrix4(i), Oh.radius += r, !1 === t.ray.intersectsSphere(Oh)) return;
			Nh.copy(i).invert(), Dh.copy(t.ray).applyMatrix4(Nh);
			const a = r / ((this.scale.x + this.scale.y + this.scale.z) / 3), o = a * a, l = n.index, c = n.attributes.position;
			if (null !== l) for (let n = Math.max(0, s.start), r = Math.min(l.count, s.start + s.count); n < r; n++) {
				const r = l.getX(n);
				Fh.fromBufferAttribute(c, r), zh(Fh, r, o, i, t, e, this);
			}
			else for (let n = Math.max(0, s.start), r = Math.min(c.count, s.start + s.count); n < r; n++) Fh.fromBufferAttribute(c, n), zh(Fh, n, o, i, t, e, this);
		}
		updateMorphTargets() {
			const t = this.geometry.morphAttributes, e = Object.keys(t);
			if (e.length > 0) {
				const n = t[e[0]];
				if (void 0 !== n) {
					this.morphTargetInfluences = [], this.morphTargetDictionary = {};
					for (let t = 0, e = n.length; t < e; t++) {
						const e = n[t].name || String(t);
						this.morphTargetInfluences.push(0), this.morphTargetDictionary[e] = t;
					}
				}
			}
		}
	};
	function zh(t, e, n, i, r, s, a) {
		const o = Dh.distanceSqToPoint(t);
		if (o < n) {
			const n = new Li();
			Dh.closestPointToPoint(t, n), n.applyMatrix4(i);
			const l = r.ray.origin.distanceTo(n);
			if (l < r.near || l > r.far) return;
			s.push({
				distance: l,
				distanceToRay: Math.sqrt(o),
				point: n,
				index: e,
				face: null,
				faceIndex: null,
				barycoord: null,
				object: a
			});
		}
	}
	var kh = class extends bi {
		constructor(t, e, n, i, r, s, a, o, l) {
			super(t, e, n, i, r, s, a, o, l), this.isVideoTexture = !0, this.minFilter = void 0 !== s ? s : Mt, this.magFilter = void 0 !== r ? r : Mt, this.generateMipmaps = !1;
			const c = this;
			"requestVideoFrameCallback" in t && t.requestVideoFrameCallback((function e() {
				c.needsUpdate = !0, t.requestVideoFrameCallback(e);
			}));
		}
		clone() {
			return new this.constructor(this.image).copy(this);
		}
		update() {
			const t = this.image;
			!1 === "requestVideoFrameCallback" in t && t.readyState >= t.HAVE_CURRENT_DATA && (this.needsUpdate = !0);
		}
	};
	var Vh = class extends bi {
		constructor(t, e) {
			super({
				width: t,
				height: e
			}), this.isFramebufferTexture = !0, this.magFilter = gt, this.minFilter = gt, this.generateMipmaps = !1, this.needsUpdate = !0;
		}
	};
	var Hh = class extends bi {
		constructor(t, e, n, i, r, s, a, o, l, c, h, u) {
			super(null, s, a, o, l, c, i, r, h, u), this.isCompressedTexture = !0, this.image = {
				width: e,
				height: n
			}, this.mipmaps = t, this.flipY = !1, this.generateMipmaps = !1;
		}
	};
	var Gh = class extends Hh {
		constructor(t, e, n, i, r, s) {
			super(t, e, n, r, s), this.isCompressedArrayTexture = !0, this.image.depth = i, this.wrapR = mt, this.layerUpdates = /* @__PURE__ */ new Set();
		}
		addLayerUpdate(t) {
			this.layerUpdates.add(t);
		}
		clearLayerUpdates() {
			this.layerUpdates.clear();
		}
	};
	var Wh = class extends Hh {
		constructor(t, e, n) {
			super(void 0, t[0].width, t[0].height, e, n, 301), this.isCompressedCubeTexture = !0, this.isCubeTexture = !0, this.image = t;
		}
	};
	var Xh = class extends bi {
		constructor(t, e, n, i, r, s, a, o, l) {
			super(t, e, n, i, r, s, a, o, l), this.isCanvasTexture = !0, this.needsUpdate = !0;
		}
	};
	var jh = class {
		constructor() {
			this.type = "Curve", this.arcLengthDivisions = 200;
		}
		getPoint() {
			return console.warn("THREE.Curve: .getPoint() not implemented."), null;
		}
		getPointAt(t, e) {
			const n = this.getUtoTmapping(t);
			return this.getPoint(n, e);
		}
		getPoints(t = 5) {
			const e = [];
			for (let n = 0; n <= t; n++) e.push(this.getPoint(n / t));
			return e;
		}
		getSpacedPoints(t = 5) {
			const e = [];
			for (let n = 0; n <= t; n++) e.push(this.getPointAt(n / t));
			return e;
		}
		getLength() {
			const t = this.getLengths();
			return t[t.length - 1];
		}
		getLengths(t = this.arcLengthDivisions) {
			if (this.cacheArcLengths && this.cacheArcLengths.length === t + 1 && !this.needsUpdate) return this.cacheArcLengths;
			this.needsUpdate = !1;
			const e = [];
			let n, i = this.getPoint(0), r = 0;
			e.push(0);
			for (let s = 1; s <= t; s++) n = this.getPoint(s / t), r += n.distanceTo(i), e.push(r), i = n;
			return this.cacheArcLengths = e, e;
		}
		updateArcLengths() {
			this.needsUpdate = !0, this.getLengths();
		}
		getUtoTmapping(t, e) {
			const n = this.getLengths();
			let i = 0;
			const r = n.length;
			let s;
			s = e || t * n[r - 1];
			let a, o = 0, l = r - 1;
			for (; o <= l;) if (i = Math.floor(o + (l - o) / 2), a = n[i] - s, a < 0) o = i + 1;
			else {
				if (!(a > 0)) {
					l = i;
					break;
				}
				l = i - 1;
			}
			if (i = l, n[i] === s) return i / (r - 1);
			const c = n[i];
			return (i + (s - c) / (n[i + 1] - c)) / (r - 1);
		}
		getTangent(t, e) {
			const n = 1e-4;
			let i = t - n, r = t + n;
			i < 0 && (i = 0), r > 1 && (r = 1);
			const s = this.getPoint(i), a = this.getPoint(r), o = e || (s.isVector2 ? new ti() : new Li());
			return o.copy(a).sub(s).normalize(), o;
		}
		getTangentAt(t, e) {
			const n = this.getUtoTmapping(t);
			return this.getTangent(n, e);
		}
		computeFrenetFrames(t, e) {
			const n = new Li(), i = [], r = [], s = [], a = new Li(), o = new lr();
			for (let e = 0; e <= t; e++) {
				const n = e / t;
				i[e] = this.getTangentAt(n, new Li());
			}
			r[0] = new Li(), s[0] = new Li();
			let l = Number.MAX_VALUE;
			const c = Math.abs(i[0].x), h = Math.abs(i[0].y), u = Math.abs(i[0].z);
			c <= l && (l = c, n.set(1, 0, 0)), h <= l && (l = h, n.set(0, 1, 0)), u <= l && n.set(0, 0, 1), a.crossVectors(i[0], n).normalize(), r[0].crossVectors(i[0], a), s[0].crossVectors(i[0], r[0]);
			for (let e = 1; e <= t; e++) {
				if (r[e] = r[e - 1].clone(), s[e] = s[e - 1].clone(), a.crossVectors(i[e - 1], i[e]), a.length() > Number.EPSILON) {
					a.normalize();
					const t = Math.acos(Yn(i[e - 1].dot(i[e]), -1, 1));
					r[e].applyMatrix4(o.makeRotationAxis(a, t));
				}
				s[e].crossVectors(i[e], r[e]);
			}
			if (!0 === e) {
				let e = Math.acos(Yn(r[0].dot(r[t]), -1, 1));
				e /= t, i[0].dot(a.crossVectors(r[0], r[t])) > 0 && (e = -e);
				for (let n = 1; n <= t; n++) r[n].applyMatrix4(o.makeRotationAxis(i[n], e * n)), s[n].crossVectors(i[n], r[n]);
			}
			return {
				tangents: i,
				normals: r,
				binormals: s
			};
		}
		clone() {
			return new this.constructor().copy(this);
		}
		copy(t) {
			return this.arcLengthDivisions = t.arcLengthDivisions, this;
		}
		toJSON() {
			const t = { metadata: {
				version: 4.6,
				type: "Curve",
				generator: "Curve.toJSON"
			} };
			return t.arcLengthDivisions = this.arcLengthDivisions, t.type = this.type, t;
		}
		fromJSON(t) {
			return this.arcLengthDivisions = t.arcLengthDivisions, this;
		}
	};
	var qh = class extends jh {
		constructor(t = 0, e = 0, n = 1, i = 1, r = 0, s = 2 * Math.PI, a = !1, o = 0) {
			super(), this.isEllipseCurve = !0, this.type = "EllipseCurve", this.aX = t, this.aY = e, this.xRadius = n, this.yRadius = i, this.aStartAngle = r, this.aEndAngle = s, this.aClockwise = a, this.aRotation = o;
		}
		getPoint(t, e = new ti()) {
			const n = e, i = 2 * Math.PI;
			let r = this.aEndAngle - this.aStartAngle;
			const s = Math.abs(r) < Number.EPSILON;
			for (; r < 0;) r += i;
			for (; r > i;) r -= i;
			r < Number.EPSILON && (r = s ? 0 : i), !0 !== this.aClockwise || s || (r === i ? r = -i : r -= i);
			const a = this.aStartAngle + t * r;
			let o = this.aX + this.xRadius * Math.cos(a), l = this.aY + this.yRadius * Math.sin(a);
			if (0 !== this.aRotation) {
				const t = Math.cos(this.aRotation), e = Math.sin(this.aRotation), n = o - this.aX, i = l - this.aY;
				o = n * t - i * e + this.aX, l = n * e + i * t + this.aY;
			}
			return n.set(o, l);
		}
		copy(t) {
			return super.copy(t), this.aX = t.aX, this.aY = t.aY, this.xRadius = t.xRadius, this.yRadius = t.yRadius, this.aStartAngle = t.aStartAngle, this.aEndAngle = t.aEndAngle, this.aClockwise = t.aClockwise, this.aRotation = t.aRotation, this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.aX = this.aX, t.aY = this.aY, t.xRadius = this.xRadius, t.yRadius = this.yRadius, t.aStartAngle = this.aStartAngle, t.aEndAngle = this.aEndAngle, t.aClockwise = this.aClockwise, t.aRotation = this.aRotation, t;
		}
		fromJSON(t) {
			return super.fromJSON(t), this.aX = t.aX, this.aY = t.aY, this.xRadius = t.xRadius, this.yRadius = t.yRadius, this.aStartAngle = t.aStartAngle, this.aEndAngle = t.aEndAngle, this.aClockwise = t.aClockwise, this.aRotation = t.aRotation, this;
		}
	};
	var Yh = class extends qh {
		constructor(t, e, n, i, r, s) {
			super(t, e, n, n, i, r, s), this.isArcCurve = !0, this.type = "ArcCurve";
		}
	};
	function Zh() {
		let t = 0, e = 0, n = 0, i = 0;
		function r(r, s, a, o) {
			t = r, e = a, n = -3 * r + 3 * s - 2 * a - o, i = 2 * r - 2 * s + a + o;
		}
		return {
			initCatmullRom: function(t, e, n, i, s) {
				r(e, n, s * (n - t), s * (i - e));
			},
			initNonuniformCatmullRom: function(t, e, n, i, s, a, o) {
				let l = (e - t) / s - (n - t) / (s + a) + (n - e) / a, c = (n - e) / a - (i - e) / (a + o) + (i - n) / o;
				l *= a, c *= a, r(e, n, l, c);
			},
			calc: function(r) {
				const s = r * r;
				return t + e * r + n * s + i * (s * r);
			}
		};
	}
	const Jh = new Li(), Kh = new Zh(), $h = new Zh(), Qh = new Zh();
	var tu = class extends jh {
		constructor(t = [], e = !1, n = "centripetal", i = .5) {
			super(), this.isCatmullRomCurve3 = !0, this.type = "CatmullRomCurve3", this.points = t, this.closed = e, this.curveType = n, this.tension = i;
		}
		getPoint(t, e = new Li()) {
			const n = e, i = this.points, r = i.length, s = (r - (this.closed ? 0 : 1)) * t;
			let a, o, l = Math.floor(s), c = s - l;
			this.closed ? l += l > 0 ? 0 : (Math.floor(Math.abs(l) / r) + 1) * r : 0 === c && l === r - 1 && (l = r - 2, c = 1), this.closed || l > 0 ? a = i[(l - 1) % r] : (Jh.subVectors(i[0], i[1]).add(i[0]), a = Jh);
			const h = i[l % r], u = i[(l + 1) % r];
			if (this.closed || l + 2 < r ? o = i[(l + 2) % r] : (Jh.subVectors(i[r - 1], i[r - 2]).add(i[r - 1]), o = Jh), "centripetal" === this.curveType || "chordal" === this.curveType) {
				const t = "chordal" === this.curveType ? .5 : .25;
				let e = Math.pow(a.distanceToSquared(h), t), n = Math.pow(h.distanceToSquared(u), t), i = Math.pow(u.distanceToSquared(o), t);
				n < 1e-4 && (n = 1), e < 1e-4 && (e = n), i < 1e-4 && (i = n), Kh.initNonuniformCatmullRom(a.x, h.x, u.x, o.x, e, n, i), $h.initNonuniformCatmullRom(a.y, h.y, u.y, o.y, e, n, i), Qh.initNonuniformCatmullRom(a.z, h.z, u.z, o.z, e, n, i);
			} else "catmullrom" === this.curveType && (Kh.initCatmullRom(a.x, h.x, u.x, o.x, this.tension), $h.initCatmullRom(a.y, h.y, u.y, o.y, this.tension), Qh.initCatmullRom(a.z, h.z, u.z, o.z, this.tension));
			return n.set(Kh.calc(c), $h.calc(c), Qh.calc(c)), n;
		}
		copy(t) {
			super.copy(t), this.points = [];
			for (let e = 0, n = t.points.length; e < n; e++) {
				const n = t.points[e];
				this.points.push(n.clone());
			}
			return this.closed = t.closed, this.curveType = t.curveType, this.tension = t.tension, this;
		}
		toJSON() {
			const t = super.toJSON();
			t.points = [];
			for (let e = 0, n = this.points.length; e < n; e++) {
				const n = this.points[e];
				t.points.push(n.toArray());
			}
			return t.closed = this.closed, t.curveType = this.curveType, t.tension = this.tension, t;
		}
		fromJSON(t) {
			super.fromJSON(t), this.points = [];
			for (let e = 0, n = t.points.length; e < n; e++) {
				const n = t.points[e];
				this.points.push(new Li().fromArray(n));
			}
			return this.closed = t.closed, this.curveType = t.curveType, this.tension = t.tension, this;
		}
	};
	function eu(t, e, n, i, r) {
		const s = .5 * (i - e), a = .5 * (r - n), o = t * t;
		return (2 * n - 2 * i + s + a) * (t * o) + (-3 * n + 3 * i - 2 * s - a) * o + s * t + n;
	}
	function nu(t, e, n, i) {
		return function(t, e) {
			const n = 1 - t;
			return n * n * e;
		}(t, e) + function(t, e) {
			return 2 * (1 - t) * t * e;
		}(t, n) + function(t, e) {
			return t * t * e;
		}(t, i);
	}
	function iu(t, e, n, i, r) {
		return function(t, e) {
			const n = 1 - t;
			return n * n * n * e;
		}(t, e) + function(t, e) {
			const n = 1 - t;
			return 3 * n * n * t * e;
		}(t, n) + function(t, e) {
			return 3 * (1 - t) * t * t * e;
		}(t, i) + function(t, e) {
			return t * t * t * e;
		}(t, r);
	}
	var ru = class extends jh {
		constructor(t = new ti(), e = new ti(), n = new ti(), i = new ti()) {
			super(), this.isCubicBezierCurve = !0, this.type = "CubicBezierCurve", this.v0 = t, this.v1 = e, this.v2 = n, this.v3 = i;
		}
		getPoint(t, e = new ti()) {
			const n = e, i = this.v0, r = this.v1, s = this.v2, a = this.v3;
			return n.set(iu(t, i.x, r.x, s.x, a.x), iu(t, i.y, r.y, s.y, a.y)), n;
		}
		copy(t) {
			return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this.v3.copy(t.v3), this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t.v3 = this.v3.toArray(), t;
		}
		fromJSON(t) {
			return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this.v3.fromArray(t.v3), this;
		}
	};
	var su = class extends jh {
		constructor(t = new Li(), e = new Li(), n = new Li(), i = new Li()) {
			super(), this.isCubicBezierCurve3 = !0, this.type = "CubicBezierCurve3", this.v0 = t, this.v1 = e, this.v2 = n, this.v3 = i;
		}
		getPoint(t, e = new Li()) {
			const n = e, i = this.v0, r = this.v1, s = this.v2, a = this.v3;
			return n.set(iu(t, i.x, r.x, s.x, a.x), iu(t, i.y, r.y, s.y, a.y), iu(t, i.z, r.z, s.z, a.z)), n;
		}
		copy(t) {
			return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this.v3.copy(t.v3), this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t.v3 = this.v3.toArray(), t;
		}
		fromJSON(t) {
			return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this.v3.fromArray(t.v3), this;
		}
	};
	var au = class extends jh {
		constructor(t = new ti(), e = new ti()) {
			super(), this.isLineCurve = !0, this.type = "LineCurve", this.v1 = t, this.v2 = e;
		}
		getPoint(t, e = new ti()) {
			const n = e;
			return 1 === t ? n.copy(this.v2) : (n.copy(this.v2).sub(this.v1), n.multiplyScalar(t).add(this.v1)), n;
		}
		getPointAt(t, e) {
			return this.getPoint(t, e);
		}
		getTangent(t, e = new ti()) {
			return e.subVectors(this.v2, this.v1).normalize();
		}
		getTangentAt(t, e) {
			return this.getTangent(t, e);
		}
		copy(t) {
			return super.copy(t), this.v1.copy(t.v1), this.v2.copy(t.v2), this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t;
		}
		fromJSON(t) {
			return super.fromJSON(t), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this;
		}
	};
	var ou = class extends jh {
		constructor(t = new Li(), e = new Li()) {
			super(), this.isLineCurve3 = !0, this.type = "LineCurve3", this.v1 = t, this.v2 = e;
		}
		getPoint(t, e = new Li()) {
			const n = e;
			return 1 === t ? n.copy(this.v2) : (n.copy(this.v2).sub(this.v1), n.multiplyScalar(t).add(this.v1)), n;
		}
		getPointAt(t, e) {
			return this.getPoint(t, e);
		}
		getTangent(t, e = new Li()) {
			return e.subVectors(this.v2, this.v1).normalize();
		}
		getTangentAt(t, e) {
			return this.getTangent(t, e);
		}
		copy(t) {
			return super.copy(t), this.v1.copy(t.v1), this.v2.copy(t.v2), this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t;
		}
		fromJSON(t) {
			return super.fromJSON(t), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this;
		}
	};
	var lu = class extends jh {
		constructor(t = new ti(), e = new ti(), n = new ti()) {
			super(), this.isQuadraticBezierCurve = !0, this.type = "QuadraticBezierCurve", this.v0 = t, this.v1 = e, this.v2 = n;
		}
		getPoint(t, e = new ti()) {
			const n = e, i = this.v0, r = this.v1, s = this.v2;
			return n.set(nu(t, i.x, r.x, s.x), nu(t, i.y, r.y, s.y)), n;
		}
		copy(t) {
			return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t;
		}
		fromJSON(t) {
			return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this;
		}
	};
	var cu = class extends jh {
		constructor(t = new Li(), e = new Li(), n = new Li()) {
			super(), this.isQuadraticBezierCurve3 = !0, this.type = "QuadraticBezierCurve3", this.v0 = t, this.v1 = e, this.v2 = n;
		}
		getPoint(t, e = new Li()) {
			const n = e, i = this.v0, r = this.v1, s = this.v2;
			return n.set(nu(t, i.x, r.x, s.x), nu(t, i.y, r.y, s.y), nu(t, i.z, r.z, s.z)), n;
		}
		copy(t) {
			return super.copy(t), this.v0.copy(t.v0), this.v1.copy(t.v1), this.v2.copy(t.v2), this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.v0 = this.v0.toArray(), t.v1 = this.v1.toArray(), t.v2 = this.v2.toArray(), t;
		}
		fromJSON(t) {
			return super.fromJSON(t), this.v0.fromArray(t.v0), this.v1.fromArray(t.v1), this.v2.fromArray(t.v2), this;
		}
	};
	var hu = class extends jh {
		constructor(t = []) {
			super(), this.isSplineCurve = !0, this.type = "SplineCurve", this.points = t;
		}
		getPoint(t, e = new ti()) {
			const n = e, i = this.points, r = (i.length - 1) * t, s = Math.floor(r), a = r - s, o = i[0 === s ? s : s - 1], l = i[s], c = i[s > i.length - 2 ? i.length - 1 : s + 1], h = i[s > i.length - 3 ? i.length - 1 : s + 2];
			return n.set(eu(a, o.x, l.x, c.x, h.x), eu(a, o.y, l.y, c.y, h.y)), n;
		}
		copy(t) {
			super.copy(t), this.points = [];
			for (let e = 0, n = t.points.length; e < n; e++) {
				const n = t.points[e];
				this.points.push(n.clone());
			}
			return this;
		}
		toJSON() {
			const t = super.toJSON();
			t.points = [];
			for (let e = 0, n = this.points.length; e < n; e++) {
				const n = this.points[e];
				t.points.push(n.toArray());
			}
			return t;
		}
		fromJSON(t) {
			super.fromJSON(t), this.points = [];
			for (let e = 0, n = t.points.length; e < n; e++) {
				const n = t.points[e];
				this.points.push(new ti().fromArray(n));
			}
			return this;
		}
	};
	var uu = Object.freeze({
		__proto__: null,
		ArcCurve: Yh,
		CatmullRomCurve3: tu,
		CubicBezierCurve: ru,
		CubicBezierCurve3: su,
		EllipseCurve: qh,
		LineCurve: au,
		LineCurve3: ou,
		QuadraticBezierCurve: lu,
		QuadraticBezierCurve3: cu,
		SplineCurve: hu
	});
	var du = class extends jh {
		constructor() {
			super(), this.type = "CurvePath", this.curves = [], this.autoClose = !1;
		}
		add(t) {
			this.curves.push(t);
		}
		closePath() {
			const t = this.curves[0].getPoint(0), e = this.curves[this.curves.length - 1].getPoint(1);
			if (!t.equals(e)) {
				const n = !0 === t.isVector2 ? "LineCurve" : "LineCurve3";
				this.curves.push(new uu[n](e, t));
			}
			return this;
		}
		getPoint(t, e) {
			const n = t * this.getLength(), i = this.getCurveLengths();
			let r = 0;
			for (; r < i.length;) {
				if (i[r] >= n) {
					const t = i[r] - n, s = this.curves[r], a = s.getLength(), o = 0 === a ? 0 : 1 - t / a;
					return s.getPointAt(o, e);
				}
				r++;
			}
			return null;
		}
		getLength() {
			const t = this.getCurveLengths();
			return t[t.length - 1];
		}
		updateArcLengths() {
			this.needsUpdate = !0, this.cacheLengths = null, this.getCurveLengths();
		}
		getCurveLengths() {
			if (this.cacheLengths && this.cacheLengths.length === this.curves.length) return this.cacheLengths;
			const t = [];
			let e = 0;
			for (let n = 0, i = this.curves.length; n < i; n++) e += this.curves[n].getLength(), t.push(e);
			return this.cacheLengths = t, t;
		}
		getSpacedPoints(t = 40) {
			const e = [];
			for (let n = 0; n <= t; n++) e.push(this.getPoint(n / t));
			return this.autoClose && e.push(e[0]), e;
		}
		getPoints(t = 12) {
			const e = [];
			let n;
			for (let i = 0, r = this.curves; i < r.length; i++) {
				const s = r[i], a = s.isEllipseCurve ? 2 * t : s.isLineCurve || s.isLineCurve3 ? 1 : s.isSplineCurve ? t * s.points.length : t, o = s.getPoints(a);
				for (let t = 0; t < o.length; t++) {
					const i = o[t];
					n && n.equals(i) || (e.push(i), n = i);
				}
			}
			return this.autoClose && e.length > 1 && !e[e.length - 1].equals(e[0]) && e.push(e[0]), e;
		}
		copy(t) {
			super.copy(t), this.curves = [];
			for (let e = 0, n = t.curves.length; e < n; e++) {
				const n = t.curves[e];
				this.curves.push(n.clone());
			}
			return this.autoClose = t.autoClose, this;
		}
		toJSON() {
			const t = super.toJSON();
			t.autoClose = this.autoClose, t.curves = [];
			for (let e = 0, n = this.curves.length; e < n; e++) {
				const n = this.curves[e];
				t.curves.push(n.toJSON());
			}
			return t;
		}
		fromJSON(t) {
			super.fromJSON(t), this.autoClose = t.autoClose, this.curves = [];
			for (let e = 0, n = t.curves.length; e < n; e++) {
				const n = t.curves[e];
				this.curves.push(new uu[n.type]().fromJSON(n));
			}
			return this;
		}
	};
	var pu = class extends du {
		constructor(t) {
			super(), this.type = "Path", this.currentPoint = new ti(), t && this.setFromPoints(t);
		}
		setFromPoints(t) {
			this.moveTo(t[0].x, t[0].y);
			for (let e = 1, n = t.length; e < n; e++) this.lineTo(t[e].x, t[e].y);
			return this;
		}
		moveTo(t, e) {
			return this.currentPoint.set(t, e), this;
		}
		lineTo(t, e) {
			const n = new au(this.currentPoint.clone(), new ti(t, e));
			return this.curves.push(n), this.currentPoint.set(t, e), this;
		}
		quadraticCurveTo(t, e, n, i) {
			const r = new lu(this.currentPoint.clone(), new ti(t, e), new ti(n, i));
			return this.curves.push(r), this.currentPoint.set(n, i), this;
		}
		bezierCurveTo(t, e, n, i, r, s) {
			const a = new ru(this.currentPoint.clone(), new ti(t, e), new ti(n, i), new ti(r, s));
			return this.curves.push(a), this.currentPoint.set(r, s), this;
		}
		splineThru(t) {
			const n = new hu([this.currentPoint.clone()].concat(t));
			return this.curves.push(n), this.currentPoint.copy(t[t.length - 1]), this;
		}
		arc(t, e, n, i, r, s) {
			const a = this.currentPoint.x, o = this.currentPoint.y;
			return this.absarc(t + a, e + o, n, i, r, s), this;
		}
		absarc(t, e, n, i, r, s) {
			return this.absellipse(t, e, n, n, i, r, s), this;
		}
		ellipse(t, e, n, i, r, s, a, o) {
			const l = this.currentPoint.x, c = this.currentPoint.y;
			return this.absellipse(t + l, e + c, n, i, r, s, a, o), this;
		}
		absellipse(t, e, n, i, r, s, a, o) {
			const l = new qh(t, e, n, i, r, s, a, o);
			if (this.curves.length > 0) {
				const t = l.getPoint(0);
				t.equals(this.currentPoint) || this.lineTo(t.x, t.y);
			}
			this.curves.push(l);
			const c = l.getPoint(1);
			return this.currentPoint.copy(c), this;
		}
		copy(t) {
			return super.copy(t), this.currentPoint.copy(t.currentPoint), this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.currentPoint = this.currentPoint.toArray(), t;
		}
		fromJSON(t) {
			return super.fromJSON(t), this.currentPoint.fromArray(t.currentPoint), this;
		}
	};
	var mu = class mu extends Cs {
		constructor(t = [
			new ti(0, -.5),
			new ti(.5, 0),
			new ti(0, .5)
		], e = 12, n = 0, i = 2 * Math.PI) {
			super(), this.type = "LatheGeometry", this.parameters = {
				points: t,
				segments: e,
				phiStart: n,
				phiLength: i
			}, e = Math.floor(e), i = Yn(i, 0, 2 * Math.PI);
			const r = [], s = [], a = [], o = [], l = [], c = 1 / e, h = new Li(), u = new ti(), d = new Li(), p = new Li(), m = new Li();
			let f = 0, g = 0;
			for (let e = 0; e <= t.length - 1; e++) switch (e) {
				case 0:
					f = t[e + 1].x - t[e].x, g = t[e + 1].y - t[e].y, d.x = 1 * g, d.y = -f, d.z = 0 * g, m.copy(d), d.normalize(), o.push(d.x, d.y, d.z);
					break;
				case t.length - 1:
					o.push(m.x, m.y, m.z);
					break;
				default: f = t[e + 1].x - t[e].x, g = t[e + 1].y - t[e].y, d.x = 1 * g, d.y = -f, d.z = 0 * g, p.copy(d), d.x += m.x, d.y += m.y, d.z += m.z, d.normalize(), o.push(d.x, d.y, d.z), m.copy(p);
			}
			for (let r = 0; r <= e; r++) {
				const d = n + r * c * i, p = Math.sin(d), m = Math.cos(d);
				for (let n = 0; n <= t.length - 1; n++) {
					h.x = t[n].x * p, h.y = t[n].y, h.z = t[n].x * m, s.push(h.x, h.y, h.z), u.x = r / e, u.y = n / (t.length - 1), a.push(u.x, u.y);
					const i = o[3 * n + 0] * p, c = o[3 * n + 1], d = o[3 * n + 0] * m;
					l.push(i, c, d);
				}
			}
			for (let n = 0; n < e; n++) for (let e = 0; e < t.length - 1; e++) {
				const i = e + n * t.length, s = i, a = i + t.length, o = i + t.length + 1, l = i + 1;
				r.push(s, a, l), r.push(o, l, a);
			}
			this.setIndex(r), this.setAttribute("position", new Ms(s, 3)), this.setAttribute("uv", new Ms(a, 2)), this.setAttribute("normal", new Ms(l, 3));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new mu(t.points, t.segments, t.phiStart, t.phiLength);
		}
	};
	var fu = class fu extends mu {
		constructor(t = 1, e = 1, n = 4, i = 8) {
			const r = new pu();
			r.absarc(0, -e / 2, t, 1.5 * Math.PI, 0), r.absarc(0, e / 2, t, 0, .5 * Math.PI), super(r.getPoints(n), i), this.type = "CapsuleGeometry", this.parameters = {
				radius: t,
				length: e,
				capSegments: n,
				radialSegments: i
			};
		}
		static fromJSON(t) {
			return new fu(t.radius, t.length, t.capSegments, t.radialSegments);
		}
	};
	var gu = class gu extends Cs {
		constructor(t = 1, e = 32, n = 0, i = 2 * Math.PI) {
			super(), this.type = "CircleGeometry", this.parameters = {
				radius: t,
				segments: e,
				thetaStart: n,
				thetaLength: i
			}, e = Math.max(3, e);
			const r = [], s = [], a = [], o = [], l = new Li(), c = new ti();
			s.push(0, 0, 0), a.push(0, 0, 1), o.push(.5, .5);
			for (let r = 0, h = 3; r <= e; r++, h += 3) {
				const u = n + r / e * i;
				l.x = t * Math.cos(u), l.y = t * Math.sin(u), s.push(l.x, l.y, l.z), a.push(0, 0, 1), c.x = (s[h] / t + 1) / 2, c.y = (s[h + 1] / t + 1) / 2, o.push(c.x, c.y);
			}
			for (let t = 1; t <= e; t++) r.push(t, t + 1, 0);
			this.setIndex(r), this.setAttribute("position", new Ms(s, 3)), this.setAttribute("normal", new Ms(a, 3)), this.setAttribute("uv", new Ms(o, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new gu(t.radius, t.segments, t.thetaStart, t.thetaLength);
		}
	};
	var vu = class vu extends Cs {
		constructor(t = 1, e = 1, n = 1, i = 32, r = 1, s = !1, a = 0, o = 2 * Math.PI) {
			super(), this.type = "CylinderGeometry", this.parameters = {
				radiusTop: t,
				radiusBottom: e,
				height: n,
				radialSegments: i,
				heightSegments: r,
				openEnded: s,
				thetaStart: a,
				thetaLength: o
			};
			const l = this;
			i = Math.floor(i), r = Math.floor(r);
			const c = [], h = [], u = [], d = [];
			let p = 0;
			const m = [], f = n / 2;
			let g = 0;
			function v(n) {
				const r = p, s = new ti(), m = new Li();
				let v = 0;
				const _ = !0 === n ? t : e, x = !0 === n ? 1 : -1;
				for (let t = 1; t <= i; t++) h.push(0, f * x, 0), u.push(0, x, 0), d.push(.5, .5), p++;
				const y = p;
				for (let t = 0; t <= i; t++) {
					const e = t / i * o + a, n = Math.cos(e), r = Math.sin(e);
					m.x = _ * r, m.y = f * x, m.z = _ * n, h.push(m.x, m.y, m.z), u.push(0, x, 0), s.x = .5 * n + .5, s.y = .5 * r * x + .5, d.push(s.x, s.y), p++;
				}
				for (let t = 0; t < i; t++) {
					const e = r + t, i = y + t;
					!0 === n ? c.push(i, i + 1, e) : c.push(i + 1, i, e), v += 3;
				}
				l.addGroup(g, v, !0 === n ? 1 : 2), g += v;
			}
			(function() {
				const s = new Li(), v = new Li();
				let _ = 0;
				const x = (e - t) / n;
				for (let l = 0; l <= r; l++) {
					const c = [], g = l / r, _ = g * (e - t) + t;
					for (let t = 0; t <= i; t++) {
						const e = t / i, r = e * o + a, l = Math.sin(r), m = Math.cos(r);
						v.x = _ * l, v.y = -g * n + f, v.z = _ * m, h.push(v.x, v.y, v.z), s.set(l, x, m).normalize(), u.push(s.x, s.y, s.z), d.push(e, 1 - g), c.push(p++);
					}
					m.push(c);
				}
				for (let n = 0; n < i; n++) for (let i = 0; i < r; i++) {
					const r = m[i][n], s = m[i + 1][n], a = m[i + 1][n + 1], o = m[i][n + 1];
					t > 0 && (c.push(r, s, o), _ += 3), e > 0 && (c.push(s, a, o), _ += 3);
				}
				l.addGroup(g, _, 0), g += _;
			})(), !1 === s && (t > 0 && v(!0), e > 0 && v(!1)), this.setIndex(c), this.setAttribute("position", new Ms(h, 3)), this.setAttribute("normal", new Ms(u, 3)), this.setAttribute("uv", new Ms(d, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new vu(t.radiusTop, t.radiusBottom, t.height, t.radialSegments, t.heightSegments, t.openEnded, t.thetaStart, t.thetaLength);
		}
	};
	var _u = class _u extends vu {
		constructor(t = 1, e = 1, n = 32, i = 1, r = !1, s = 0, a = 2 * Math.PI) {
			super(0, t, e, n, i, r, s, a), this.type = "ConeGeometry", this.parameters = {
				radius: t,
				height: e,
				radialSegments: n,
				heightSegments: i,
				openEnded: r,
				thetaStart: s,
				thetaLength: a
			};
		}
		static fromJSON(t) {
			return new _u(t.radius, t.height, t.radialSegments, t.heightSegments, t.openEnded, t.thetaStart, t.thetaLength);
		}
	};
	var xu = class xu extends Cs {
		constructor(t = [], e = [], n = 1, i = 0) {
			super(), this.type = "PolyhedronGeometry", this.parameters = {
				vertices: t,
				indices: e,
				radius: n,
				detail: i
			};
			const r = [], s = [];
			function a(t, e, n, i) {
				const r = i + 1, s = [];
				for (let i = 0; i <= r; i++) {
					s[i] = [];
					const a = t.clone().lerp(n, i / r), o = e.clone().lerp(n, i / r), l = r - i;
					for (let t = 0; t <= l; t++) s[i][t] = 0 === t && i === r ? a : a.clone().lerp(o, t / l);
				}
				for (let t = 0; t < r; t++) for (let e = 0; e < 2 * (r - t) - 1; e++) {
					const n = Math.floor(e / 2);
					e % 2 == 0 ? (o(s[t][n + 1]), o(s[t + 1][n]), o(s[t][n])) : (o(s[t][n + 1]), o(s[t + 1][n + 1]), o(s[t + 1][n]));
				}
			}
			function o(t) {
				r.push(t.x, t.y, t.z);
			}
			function l(e, n) {
				const i = 3 * e;
				n.x = t[i + 0], n.y = t[i + 1], n.z = t[i + 2];
			}
			function c(t, e, n, i) {
				i < 0 && 1 === t.x && (s[e] = t.x - 1), 0 === n.x && 0 === n.z && (s[e] = i / 2 / Math.PI + .5);
			}
			function h(t) {
				return Math.atan2(t.z, -t.x);
			}
			(function(t) {
				const n = new Li(), i = new Li(), r = new Li();
				for (let s = 0; s < e.length; s += 3) l(e[s + 0], n), l(e[s + 1], i), l(e[s + 2], r), a(n, i, r, t);
			})(i), function(t) {
				const e = new Li();
				for (let n = 0; n < r.length; n += 3) e.x = r[n + 0], e.y = r[n + 1], e.z = r[n + 2], e.normalize().multiplyScalar(t), r[n + 0] = e.x, r[n + 1] = e.y, r[n + 2] = e.z;
			}(n), function() {
				const t = new Li();
				for (let n = 0; n < r.length; n += 3) {
					t.x = r[n + 0], t.y = r[n + 1], t.z = r[n + 2];
					const i = h(t) / 2 / Math.PI + .5, a = (e = t, Math.atan2(-e.y, Math.sqrt(e.x * e.x + e.z * e.z)) / Math.PI + .5);
					s.push(i, 1 - a);
				}
				var e;
				(function() {
					const t = new Li(), e = new Li(), n = new Li(), i = new Li(), a = new ti(), o = new ti(), l = new ti();
					for (let u = 0, d = 0; u < r.length; u += 9, d += 6) {
						t.set(r[u + 0], r[u + 1], r[u + 2]), e.set(r[u + 3], r[u + 4], r[u + 5]), n.set(r[u + 6], r[u + 7], r[u + 8]), a.set(s[d + 0], s[d + 1]), o.set(s[d + 2], s[d + 3]), l.set(s[d + 4], s[d + 5]), i.copy(t).add(e).add(n).divideScalar(3);
						const p = h(i);
						c(a, d + 0, t, p), c(o, d + 2, e, p), c(l, d + 4, n, p);
					}
				})(), function() {
					for (let t = 0; t < s.length; t += 6) {
						const e = s[t + 0], n = s[t + 2], i = s[t + 4];
						Math.max(e, n, i) > .9 && Math.min(e, n, i) < .1 && (e < .2 && (s[t + 0] += 1), n < .2 && (s[t + 2] += 1), i < .2 && (s[t + 4] += 1));
					}
				}();
			}(), this.setAttribute("position", new Ms(r, 3)), this.setAttribute("normal", new Ms(r.slice(), 3)), this.setAttribute("uv", new Ms(s, 2)), 0 === i ? this.computeVertexNormals() : this.normalizeNormals();
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new xu(t.vertices, t.indices, t.radius, t.details);
		}
	};
	var yu = class yu extends xu {
		constructor(t = 1, e = 0) {
			const n = (1 + Math.sqrt(5)) / 2, i = 1 / n;
			super([
				-1,
				-1,
				-1,
				-1,
				-1,
				1,
				-1,
				1,
				-1,
				-1,
				1,
				1,
				1,
				-1,
				-1,
				1,
				-1,
				1,
				1,
				1,
				-1,
				1,
				1,
				1,
				0,
				-i,
				-n,
				0,
				-i,
				n,
				0,
				i,
				-n,
				0,
				i,
				n,
				-i,
				-n,
				0,
				-i,
				n,
				0,
				i,
				-n,
				0,
				i,
				n,
				0,
				-n,
				0,
				-i,
				n,
				0,
				-i,
				-n,
				0,
				i,
				n,
				0,
				i
			], [
				3,
				11,
				7,
				3,
				7,
				15,
				3,
				15,
				13,
				7,
				19,
				17,
				7,
				17,
				6,
				7,
				6,
				15,
				17,
				4,
				8,
				17,
				8,
				10,
				17,
				10,
				6,
				8,
				0,
				16,
				8,
				16,
				2,
				8,
				2,
				10,
				0,
				12,
				1,
				0,
				1,
				18,
				0,
				18,
				16,
				6,
				10,
				2,
				6,
				2,
				13,
				6,
				13,
				15,
				2,
				16,
				18,
				2,
				18,
				3,
				2,
				3,
				13,
				18,
				1,
				9,
				18,
				9,
				11,
				18,
				11,
				3,
				4,
				14,
				12,
				4,
				12,
				0,
				4,
				0,
				8,
				11,
				9,
				5,
				11,
				5,
				19,
				11,
				19,
				7,
				19,
				5,
				14,
				19,
				14,
				4,
				19,
				4,
				17,
				1,
				12,
				14,
				1,
				14,
				5,
				1,
				5,
				9
			], t, e), this.type = "DodecahedronGeometry", this.parameters = {
				radius: t,
				detail: e
			};
		}
		static fromJSON(t) {
			return new yu(t.radius, t.detail);
		}
	};
	const Mu = new Li(), Su = new Li(), bu = new Li(), wu = new Zr();
	var Tu = class extends Cs {
		constructor(t = null, e = 1) {
			if (super(), this.type = "EdgesGeometry", this.parameters = {
				geometry: t,
				thresholdAngle: e
			}, null !== t) {
				const i = Math.pow(10, 4), r = Math.cos(Xn * e), s = t.getIndex(), a = t.getAttribute("position"), o = s ? s.count : a.count, l = [
					0,
					0,
					0
				], c = [
					"a",
					"b",
					"c"
				], h = new Array(3), u = {}, d = [];
				for (let t = 0; t < o; t += 3) {
					s ? (l[0] = s.getX(t), l[1] = s.getX(t + 1), l[2] = s.getX(t + 2)) : (l[0] = t, l[1] = t + 1, l[2] = t + 2);
					const { a: e, b: n, c: o } = wu;
					if (e.fromBufferAttribute(a, l[0]), n.fromBufferAttribute(a, l[1]), o.fromBufferAttribute(a, l[2]), wu.getNormal(bu), h[0] = `${Math.round(e.x * i)},${Math.round(e.y * i)},${Math.round(e.z * i)}`, h[1] = `${Math.round(n.x * i)},${Math.round(n.y * i)},${Math.round(n.z * i)}`, h[2] = `${Math.round(o.x * i)},${Math.round(o.y * i)},${Math.round(o.z * i)}`, h[0] !== h[1] && h[1] !== h[2] && h[2] !== h[0]) for (let t = 0; t < 3; t++) {
						const e = (t + 1) % 3, n = h[t], i = h[e], s = wu[c[t]], a = wu[c[e]], o = `${n}_${i}`, p = `${i}_${n}`;
						p in u && u[p] ? (bu.dot(u[p].normal) <= r && (d.push(s.x, s.y, s.z), d.push(a.x, a.y, a.z)), u[p] = null) : o in u || (u[o] = {
							index0: l[t],
							index1: l[e],
							normal: bu.clone()
						});
					}
				}
				for (const t in u) if (u[t]) {
					const { index0: e, index1: n } = u[t];
					Mu.fromBufferAttribute(a, e), Su.fromBufferAttribute(a, n), d.push(Mu.x, Mu.y, Mu.z), d.push(Su.x, Su.y, Su.z);
				}
				this.setAttribute("position", new Ms(d, 3));
			}
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
	};
	var Eu = class extends pu {
		constructor(t) {
			super(t), this.uuid = qn(), this.type = "Shape", this.holes = [];
		}
		getPointsHoles(t) {
			const e = [];
			for (let n = 0, i = this.holes.length; n < i; n++) e[n] = this.holes[n].getPoints(t);
			return e;
		}
		extractPoints(t) {
			return {
				shape: this.getPoints(t),
				holes: this.getPointsHoles(t)
			};
		}
		copy(t) {
			super.copy(t), this.holes = [];
			for (let e = 0, n = t.holes.length; e < n; e++) {
				const n = t.holes[e];
				this.holes.push(n.clone());
			}
			return this;
		}
		toJSON() {
			const t = super.toJSON();
			t.uuid = this.uuid, t.holes = [];
			for (let e = 0, n = this.holes.length; e < n; e++) {
				const n = this.holes[e];
				t.holes.push(n.toJSON());
			}
			return t;
		}
		fromJSON(t) {
			super.fromJSON(t), this.uuid = t.uuid, this.holes = [];
			for (let e = 0, n = t.holes.length; e < n; e++) {
				const n = t.holes[e];
				this.holes.push(new pu().fromJSON(n));
			}
			return this;
		}
	};
	const Au = function(t, e, n = 2) {
		const i = e && e.length, r = i ? e[0] * n : t.length;
		let s = Ru(t, 0, r, n, !0);
		const a = [];
		if (!s || s.next === s.prev) return a;
		let o, l, c, h, u, d, p;
		if (i && (s = function(t, e, n, i) {
			const r = [];
			let s, a, o, l, c;
			for (s = 0, a = e.length; s < a; s++) o = e[s] * i, l = s < a - 1 ? e[s + 1] * i : t.length, c = Ru(t, o, l, i, !1), c === c.next && (c.steiner = !0), r.push(zu(c));
			for (r.sort(Du), s = 0; s < r.length; s++) n = Ou(r[s], n);
			return n;
		}(t, e, s, n)), t.length > 80 * n) {
			o = c = t[0], l = h = t[1];
			for (let e = n; e < r; e += n) u = t[e], d = t[e + 1], u < o && (o = u), d < l && (l = d), u > c && (c = u), d > h && (h = d);
			p = Math.max(c - o, h - l), p = 0 !== p ? 32767 / p : 0;
		}
		return Pu(s, a, n, o, l, p, 0), a;
	};
	function Ru(t, e, n, i, r) {
		let s, a;
		if (r === function(t, e, n, i) {
			let r = 0;
			for (let s = e, a = n - i; s < n; s += i) r += (t[a] - t[s]) * (t[s + 1] + t[a + 1]), a = s;
			return r;
		}(t, e, n, i) > 0) for (s = e; s < n; s += i) a = Zu(s, t[s], t[s + 1], a);
		else for (s = n - i; s >= e; s -= i) a = Zu(s, t[s], t[s + 1], a);
		return a && Gu(a, a.next) && (Ju(a), a = a.next), a;
	}
	function Cu(t, e) {
		if (!t) return t;
		e || (e = t);
		let n, i = t;
		do
			if (n = !1, i.steiner || !Gu(i, i.next) && 0 !== Hu(i.prev, i, i.next)) i = i.next;
			else {
				if (Ju(i), i = e = i.prev, i === i.next) break;
				n = !0;
			}
		while (n || i !== e);
		return e;
	}
	function Pu(t, e, n, i, r, s, a) {
		if (!t) return;
		!a && s && function(t, e, n, i) {
			let r = t;
			do
				0 === r.z && (r.z = Bu(r.x, r.y, e, n, i)), r.prevZ = r.prev, r.nextZ = r.next, r = r.next;
			while (r !== t);
			r.prevZ.nextZ = null, r.prevZ = null, function(t) {
				let e, n, i, r, s, a, o, l, c = 1;
				do {
					for (n = t, t = null, s = null, a = 0; n;) {
						for (a++, i = n, o = 0, e = 0; e < c && (o++, i = i.nextZ, i); e++);
						for (l = c; o > 0 || l > 0 && i;) 0 !== o && (0 === l || !i || n.z <= i.z) ? (r = n, n = n.nextZ, o--) : (r = i, i = i.nextZ, l--), s ? s.nextZ = r : t = r, r.prevZ = s, s = r;
						n = i;
					}
					s.nextZ = null, c *= 2;
				} while (a > 1);
			}(r);
		}(t, i, r, s);
		let o, l, c = t;
		for (; t.prev !== t.next;) if (o = t.prev, l = t.next, s ? Lu(t, i, r, s) : Iu(t)) e.push(o.i / n | 0), e.push(t.i / n | 0), e.push(l.i / n | 0), Ju(t), t = l.next, c = l.next;
		else if ((t = l) === c) {
			a ? 1 === a ? Pu(t = Uu(Cu(t), e, n), e, n, i, r, s, 2) : 2 === a && Nu(t, e, n, i, r, s) : Pu(Cu(t), e, n, i, r, s, 1);
			break;
		}
	}
	function Iu(t) {
		const e = t.prev, n = t, i = t.next;
		if (Hu(e, n, i) >= 0) return !1;
		const r = e.x, s = n.x, a = i.x, o = e.y, l = n.y, c = i.y, h = r < s ? r < a ? r : a : s < a ? s : a, u = o < l ? o < c ? o : c : l < c ? l : c, d = r > s ? r > a ? r : a : s > a ? s : a, p = o > l ? o > c ? o : c : l > c ? l : c;
		let m = i.next;
		for (; m !== e;) {
			if (m.x >= h && m.x <= d && m.y >= u && m.y <= p && ku(r, o, s, l, a, c, m.x, m.y) && Hu(m.prev, m, m.next) >= 0) return !1;
			m = m.next;
		}
		return !0;
	}
	function Lu(t, e, n, i) {
		const r = t.prev, s = t, a = t.next;
		if (Hu(r, s, a) >= 0) return !1;
		const o = r.x, l = s.x, c = a.x, h = r.y, u = s.y, d = a.y, p = o < l ? o < c ? o : c : l < c ? l : c, m = h < u ? h < d ? h : d : u < d ? u : d, f = o > l ? o > c ? o : c : l > c ? l : c, g = h > u ? h > d ? h : d : u > d ? u : d, v = Bu(p, m, e, n, i), _ = Bu(f, g, e, n, i);
		let x = t.prevZ, y = t.nextZ;
		for (; x && x.z >= v && y && y.z <= _;) {
			if (x.x >= p && x.x <= f && x.y >= m && x.y <= g && x !== r && x !== a && ku(o, h, l, u, c, d, x.x, x.y) && Hu(x.prev, x, x.next) >= 0) return !1;
			if (x = x.prevZ, y.x >= p && y.x <= f && y.y >= m && y.y <= g && y !== r && y !== a && ku(o, h, l, u, c, d, y.x, y.y) && Hu(y.prev, y, y.next) >= 0) return !1;
			y = y.nextZ;
		}
		for (; x && x.z >= v;) {
			if (x.x >= p && x.x <= f && x.y >= m && x.y <= g && x !== r && x !== a && ku(o, h, l, u, c, d, x.x, x.y) && Hu(x.prev, x, x.next) >= 0) return !1;
			x = x.prevZ;
		}
		for (; y && y.z <= _;) {
			if (y.x >= p && y.x <= f && y.y >= m && y.y <= g && y !== r && y !== a && ku(o, h, l, u, c, d, y.x, y.y) && Hu(y.prev, y, y.next) >= 0) return !1;
			y = y.nextZ;
		}
		return !0;
	}
	function Uu(t, e, n) {
		let i = t;
		do {
			const r = i.prev, s = i.next.next;
			!Gu(r, s) && Wu(r, i, i.next, s) && qu(r, s) && qu(s, r) && (e.push(r.i / n | 0), e.push(i.i / n | 0), e.push(s.i / n | 0), Ju(i), Ju(i.next), i = t = s), i = i.next;
		} while (i !== t);
		return Cu(i);
	}
	function Nu(t, e, n, i, r, s) {
		let a = t;
		do {
			let t = a.next.next;
			for (; t !== a.prev;) {
				if (a.i !== t.i && Vu(a, t)) {
					let o = Yu(a, t);
					a = Cu(a, a.next), o = Cu(o, o.next), Pu(a, e, n, i, r, s, 0), Pu(o, e, n, i, r, s, 0);
					return;
				}
				t = t.next;
			}
			a = a.next;
		} while (a !== t);
	}
	function Du(t, e) {
		return t.x - e.x;
	}
	function Ou(t, e) {
		const n = function(t, e) {
			let n, i = e, r = -Infinity;
			const s = t.x, a = t.y;
			do {
				if (a <= i.y && a >= i.next.y && i.next.y !== i.y) {
					const t = i.x + (a - i.y) * (i.next.x - i.x) / (i.next.y - i.y);
					if (t <= s && t > r && (r = t, n = i.x < i.next.x ? i : i.next, t === s)) return n;
				}
				i = i.next;
			} while (i !== e);
			if (!n) return null;
			const o = n, l = n.x, c = n.y;
			let h, u = Infinity;
			i = n;
			do
				s >= i.x && i.x >= l && s !== i.x && ku(a < c ? s : r, a, l, c, a < c ? r : s, a, i.x, i.y) && (h = Math.abs(a - i.y) / (s - i.x), qu(i, t) && (h < u || h === u && (i.x > n.x || i.x === n.x && Fu(n, i))) && (n = i, u = h)), i = i.next;
			while (i !== o);
			return n;
		}(t, e);
		if (!n) return e;
		const i = Yu(n, t);
		return Cu(i, i.next), Cu(n, n.next);
	}
	function Fu(t, e) {
		return Hu(t.prev, t, e.prev) < 0 && Hu(e.next, t, t.next) < 0;
	}
	function Bu(t, e, n, i, r) {
		return (t = 1431655765 & ((t = 858993459 & ((t = 252645135 & ((t = 16711935 & ((t = (t - n) * r | 0) | t << 8)) | t << 4)) | t << 2)) | t << 1)) | (e = 1431655765 & ((e = 858993459 & ((e = 252645135 & ((e = 16711935 & ((e = (e - i) * r | 0) | e << 8)) | e << 4)) | e << 2)) | e << 1)) << 1;
	}
	function zu(t) {
		let e = t, n = t;
		do
			(e.x < n.x || e.x === n.x && e.y < n.y) && (n = e), e = e.next;
		while (e !== t);
		return n;
	}
	function ku(t, e, n, i, r, s, a, o) {
		return (r - a) * (e - o) >= (t - a) * (s - o) && (t - a) * (i - o) >= (n - a) * (e - o) && (n - a) * (s - o) >= (r - a) * (i - o);
	}
	function Vu(t, e) {
		return t.next.i !== e.i && t.prev.i !== e.i && !function(t, e) {
			let n = t;
			do {
				if (n.i !== t.i && n.next.i !== t.i && n.i !== e.i && n.next.i !== e.i && Wu(n, n.next, t, e)) return !0;
				n = n.next;
			} while (n !== t);
			return !1;
		}(t, e) && (qu(t, e) && qu(e, t) && function(t, e) {
			let n = t, i = !1;
			const r = (t.x + e.x) / 2, s = (t.y + e.y) / 2;
			do
				n.y > s != n.next.y > s && n.next.y !== n.y && r < (n.next.x - n.x) * (s - n.y) / (n.next.y - n.y) + n.x && (i = !i), n = n.next;
			while (n !== t);
			return i;
		}(t, e) && (Hu(t.prev, t, e.prev) || Hu(t, e.prev, e)) || Gu(t, e) && Hu(t.prev, t, t.next) > 0 && Hu(e.prev, e, e.next) > 0);
	}
	function Hu(t, e, n) {
		return (e.y - t.y) * (n.x - e.x) - (e.x - t.x) * (n.y - e.y);
	}
	function Gu(t, e) {
		return t.x === e.x && t.y === e.y;
	}
	function Wu(t, e, n, i) {
		const r = ju(Hu(t, e, n)), s = ju(Hu(t, e, i)), a = ju(Hu(n, i, t)), o = ju(Hu(n, i, e));
		return r !== s && a !== o || !(0 !== r || !Xu(t, n, e)) || !(0 !== s || !Xu(t, i, e)) || !(0 !== a || !Xu(n, t, i)) || !(0 !== o || !Xu(n, e, i));
	}
	function Xu(t, e, n) {
		return e.x <= Math.max(t.x, n.x) && e.x >= Math.min(t.x, n.x) && e.y <= Math.max(t.y, n.y) && e.y >= Math.min(t.y, n.y);
	}
	function ju(t) {
		return t > 0 ? 1 : t < 0 ? -1 : 0;
	}
	function qu(t, e) {
		return Hu(t.prev, t, t.next) < 0 ? Hu(t, e, t.next) >= 0 && Hu(t, t.prev, e) >= 0 : Hu(t, e, t.prev) < 0 || Hu(t, t.next, e) < 0;
	}
	function Yu(t, e) {
		const n = new Ku(t.i, t.x, t.y), i = new Ku(e.i, e.x, e.y), r = t.next, s = e.prev;
		return t.next = e, e.prev = t, n.next = r, r.prev = n, i.next = n, n.prev = i, s.next = i, i.prev = s, i;
	}
	function Zu(t, e, n, i) {
		const r = new Ku(t, e, n);
		return i ? (r.next = i.next, r.prev = i, i.next.prev = r, i.next = r) : (r.prev = r, r.next = r), r;
	}
	function Ju(t) {
		t.next.prev = t.prev, t.prev.next = t.next, t.prevZ && (t.prevZ.nextZ = t.nextZ), t.nextZ && (t.nextZ.prevZ = t.prevZ);
	}
	function Ku(t, e, n) {
		this.i = t, this.x = e, this.y = n, this.prev = null, this.next = null, this.z = 0, this.prevZ = null, this.nextZ = null, this.steiner = !1;
	}
	var $u = class $u {
		static area(t) {
			const e = t.length;
			let n = 0;
			for (let i = e - 1, r = 0; r < e; i = r++) n += t[i].x * t[r].y - t[r].x * t[i].y;
			return .5 * n;
		}
		static isClockWise(t) {
			return $u.area(t) < 0;
		}
		static triangulateShape(t, e) {
			const n = [], i = [], r = [];
			Qu(t), td(n, t);
			let s = t.length;
			e.forEach(Qu);
			for (let t = 0; t < e.length; t++) i.push(s), s += e[t].length, td(n, e[t]);
			const a = Au(n, i);
			for (let t = 0; t < a.length; t += 3) r.push(a.slice(t, t + 3));
			return r;
		}
	};
	function Qu(t) {
		const e = t.length;
		e > 2 && t[e - 1].equals(t[0]) && t.pop();
	}
	function td(t, e) {
		for (let n = 0; n < e.length; n++) t.push(e[n].x), t.push(e[n].y);
	}
	var ed = class ed extends Cs {
		constructor(t = new Eu([
			new ti(.5, .5),
			new ti(-.5, .5),
			new ti(-.5, -.5),
			new ti(.5, -.5)
		]), e = {}) {
			super(), this.type = "ExtrudeGeometry", this.parameters = {
				shapes: t,
				options: e
			}, t = Array.isArray(t) ? t : [t];
			const n = this, i = [], r = [];
			for (let e = 0, n = t.length; e < n; e++) s(t[e]);
			function s(t) {
				const s = [], a = void 0 !== e.curveSegments ? e.curveSegments : 12, o = void 0 !== e.steps ? e.steps : 1, l = void 0 !== e.depth ? e.depth : 1;
				let c = void 0 === e.bevelEnabled || e.bevelEnabled, h = void 0 !== e.bevelThickness ? e.bevelThickness : .2, u = void 0 !== e.bevelSize ? e.bevelSize : h - .1, d = void 0 !== e.bevelOffset ? e.bevelOffset : 0, p = void 0 !== e.bevelSegments ? e.bevelSegments : 3;
				const m = e.extrudePath, f = void 0 !== e.UVGenerator ? e.UVGenerator : nd;
				let g, v, _, x, y, M = !1;
				m && (g = m.getSpacedPoints(o), M = !0, c = !1, v = m.computeFrenetFrames(o, !1), _ = new Li(), x = new Li(), y = new Li()), c || (p = 0, h = 0, u = 0, d = 0);
				const S = t.extractPoints(a);
				let b = S.shape;
				const w = S.holes;
				if (!$u.isClockWise(b)) {
					b = b.reverse();
					for (let t = 0, e = w.length; t < e; t++) {
						const e = w[t];
						$u.isClockWise(e) && (w[t] = e.reverse());
					}
				}
				const T = $u.triangulateShape(b, w), E = b;
				for (let t = 0, e = w.length; t < e; t++) {
					const e = w[t];
					b = b.concat(e);
				}
				function A(t, e, n) {
					return e || console.error("THREE.ExtrudeGeometry: vec does not exist"), t.clone().addScaledVector(e, n);
				}
				const R = b.length, C = T.length;
				function P(t, e, n) {
					let i, r, s;
					const a = t.x - e.x, o = t.y - e.y, l = n.x - t.x, c = n.y - t.y, h = a * a + o * o, u = a * c - o * l;
					if (Math.abs(u) > Number.EPSILON) {
						const u = Math.sqrt(h), d = Math.sqrt(l * l + c * c), p = e.x - o / u, m = e.y + a / u, f = ((n.x - c / d - p) * c - (n.y + l / d - m) * l) / (a * c - o * l);
						i = p + a * f - t.x, r = m + o * f - t.y;
						const g = i * i + r * r;
						if (g <= 2) return new ti(i, r);
						s = Math.sqrt(g / 2);
					} else {
						let t = !1;
						a > Number.EPSILON ? l > Number.EPSILON && (t = !0) : a < -Number.EPSILON ? l < -Number.EPSILON && (t = !0) : Math.sign(o) === Math.sign(c) && (t = !0), t ? (i = -o, r = a, s = Math.sqrt(h)) : (i = a, r = o, s = Math.sqrt(h / 2));
					}
					return new ti(i / s, r / s);
				}
				const I = [];
				for (let t = 0, e = E.length, n = e - 1, i = t + 1; t < e; t++, n++, i++) n === e && (n = 0), i === e && (i = 0), I[t] = P(E[t], E[n], E[i]);
				const L = [];
				let U, N = I.concat();
				for (let t = 0, e = w.length; t < e; t++) {
					const e = w[t];
					U = [];
					for (let t = 0, n = e.length, i = n - 1, r = t + 1; t < n; t++, i++, r++) i === n && (i = 0), r === n && (r = 0), U[t] = P(e[t], e[i], e[r]);
					L.push(U), N = N.concat(U);
				}
				for (let t = 0; t < p; t++) {
					const e = t / p, n = h * Math.cos(e * Math.PI / 2), i = u * Math.sin(e * Math.PI / 2) + d;
					for (let t = 0, e = E.length; t < e; t++) {
						const e = A(E[t], I[t], i);
						F(e.x, e.y, -n);
					}
					for (let t = 0, e = w.length; t < e; t++) {
						const e = w[t];
						U = L[t];
						for (let t = 0, r = e.length; t < r; t++) {
							const r = A(e[t], U[t], i);
							F(r.x, r.y, -n);
						}
					}
				}
				const D = u + d;
				for (let t = 0; t < R; t++) {
					const e = c ? A(b[t], N[t], D) : b[t];
					M ? (x.copy(v.normals[0]).multiplyScalar(e.x), _.copy(v.binormals[0]).multiplyScalar(e.y), y.copy(g[0]).add(x).add(_), F(y.x, y.y, y.z)) : F(e.x, e.y, 0);
				}
				for (let t = 1; t <= o; t++) for (let e = 0; e < R; e++) {
					const n = c ? A(b[e], N[e], D) : b[e];
					M ? (x.copy(v.normals[t]).multiplyScalar(n.x), _.copy(v.binormals[t]).multiplyScalar(n.y), y.copy(g[t]).add(x).add(_), F(y.x, y.y, y.z)) : F(n.x, n.y, l / o * t);
				}
				for (let t = p - 1; t >= 0; t--) {
					const e = t / p, n = h * Math.cos(e * Math.PI / 2), i = u * Math.sin(e * Math.PI / 2) + d;
					for (let t = 0, e = E.length; t < e; t++) {
						const e = A(E[t], I[t], i);
						F(e.x, e.y, l + n);
					}
					for (let t = 0, e = w.length; t < e; t++) {
						const e = w[t];
						U = L[t];
						for (let t = 0, r = e.length; t < r; t++) {
							const r = A(e[t], U[t], i);
							M ? F(r.x, r.y + g[o - 1].y, g[o - 1].x + n) : F(r.x, r.y, l + n);
						}
					}
				}
				function O(t, e) {
					let n = t.length;
					for (; --n >= 0;) {
						const i = n;
						let r = n - 1;
						r < 0 && (r = t.length - 1);
						for (let t = 0, n = o + 2 * p; t < n; t++) {
							const n = R * t, s = R * (t + 1);
							z(e + i + n, e + r + n, e + r + s, e + i + s);
						}
					}
				}
				function F(t, e, n) {
					s.push(t), s.push(e), s.push(n);
				}
				function B(t, e, r) {
					k(t), k(e), k(r);
					const s = i.length / 3, a = f.generateTopUV(n, i, s - 3, s - 2, s - 1);
					V(a[0]), V(a[1]), V(a[2]);
				}
				function z(t, e, r, s) {
					k(t), k(e), k(s), k(e), k(r), k(s);
					const a = i.length / 3, o = f.generateSideWallUV(n, i, a - 6, a - 3, a - 2, a - 1);
					V(o[0]), V(o[1]), V(o[3]), V(o[1]), V(o[2]), V(o[3]);
				}
				function k(t) {
					i.push(s[3 * t + 0]), i.push(s[3 * t + 1]), i.push(s[3 * t + 2]);
				}
				function V(t) {
					r.push(t.x), r.push(t.y);
				}
				(function() {
					const t = i.length / 3;
					if (c) {
						let t = 0, e = R * t;
						for (let t = 0; t < C; t++) {
							const n = T[t];
							B(n[2] + e, n[1] + e, n[0] + e);
						}
						t = o + 2 * p, e = R * t;
						for (let t = 0; t < C; t++) {
							const n = T[t];
							B(n[0] + e, n[1] + e, n[2] + e);
						}
					} else {
						for (let t = 0; t < C; t++) {
							const e = T[t];
							B(e[2], e[1], e[0]);
						}
						for (let t = 0; t < C; t++) {
							const e = T[t];
							B(e[0] + R * o, e[1] + R * o, e[2] + R * o);
						}
					}
					n.addGroup(t, i.length / 3 - t, 0);
				})(), function() {
					const t = i.length / 3;
					let e = 0;
					O(E, e), e += E.length;
					for (let t = 0, n = w.length; t < n; t++) {
						const n = w[t];
						O(n, e), e += n.length;
					}
					n.addGroup(t, i.length / 3 - t, 1);
				}();
			}
			this.setAttribute("position", new Ms(i, 3)), this.setAttribute("uv", new Ms(r, 2)), this.computeVertexNormals();
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		toJSON() {
			const t = super.toJSON();
			return function(t, e, n) {
				if (n.shapes = [], Array.isArray(t)) for (let e = 0, i = t.length; e < i; e++) {
					const i = t[e];
					n.shapes.push(i.uuid);
				}
				else n.shapes.push(t.uuid);
				n.options = Object.assign({}, e), void 0 !== e.extrudePath && (n.options.extrudePath = e.extrudePath.toJSON());
				return n;
			}(this.parameters.shapes, this.parameters.options, t);
		}
		static fromJSON(t, e) {
			const n = [];
			for (let i = 0, r = t.shapes.length; i < r; i++) {
				const r = e[t.shapes[i]];
				n.push(r);
			}
			const i = t.options.extrudePath;
			return void 0 !== i && (t.options.extrudePath = new uu[i.type]().fromJSON(i)), new ed(n, t.options);
		}
	};
	const nd = {
		generateTopUV: function(t, e, n, i, r) {
			const s = e[3 * n], a = e[3 * n + 1], o = e[3 * i], l = e[3 * i + 1], c = e[3 * r], h = e[3 * r + 1];
			return [
				new ti(s, a),
				new ti(o, l),
				new ti(c, h)
			];
		},
		generateSideWallUV: function(t, e, n, i, r, s) {
			const a = e[3 * n], o = e[3 * n + 1], l = e[3 * n + 2], c = e[3 * i], h = e[3 * i + 1], u = e[3 * i + 2], d = e[3 * r], p = e[3 * r + 1], m = e[3 * r + 2], f = e[3 * s], g = e[3 * s + 1], v = e[3 * s + 2];
			return Math.abs(o - h) < Math.abs(a - c) ? [
				new ti(a, 1 - l),
				new ti(c, 1 - u),
				new ti(d, 1 - m),
				new ti(f, 1 - v)
			] : [
				new ti(o, 1 - l),
				new ti(h, 1 - u),
				new ti(p, 1 - m),
				new ti(g, 1 - v)
			];
		}
	};
	var id = class id extends xu {
		constructor(t = 1, e = 0) {
			const n = (1 + Math.sqrt(5)) / 2;
			super([
				-1,
				n,
				0,
				1,
				n,
				0,
				-1,
				-n,
				0,
				1,
				-n,
				0,
				0,
				-1,
				n,
				0,
				1,
				n,
				0,
				-1,
				-n,
				0,
				1,
				-n,
				n,
				0,
				-1,
				n,
				0,
				1,
				-n,
				0,
				-1,
				-n,
				0,
				1
			], [
				0,
				11,
				5,
				0,
				5,
				1,
				0,
				1,
				7,
				0,
				7,
				10,
				0,
				10,
				11,
				1,
				5,
				9,
				5,
				11,
				4,
				11,
				10,
				2,
				10,
				7,
				6,
				7,
				1,
				8,
				3,
				9,
				4,
				3,
				4,
				2,
				3,
				2,
				6,
				3,
				6,
				8,
				3,
				8,
				9,
				4,
				9,
				5,
				2,
				4,
				11,
				6,
				2,
				10,
				8,
				6,
				7,
				9,
				8,
				1
			], t, e), this.type = "IcosahedronGeometry", this.parameters = {
				radius: t,
				detail: e
			};
		}
		static fromJSON(t) {
			return new id(t.radius, t.detail);
		}
	};
	var rd = class rd extends xu {
		constructor(t = 1, e = 0) {
			super([
				1,
				0,
				0,
				-1,
				0,
				0,
				0,
				1,
				0,
				0,
				-1,
				0,
				0,
				0,
				1,
				0,
				0,
				-1
			], [
				0,
				2,
				4,
				0,
				4,
				3,
				0,
				3,
				5,
				0,
				5,
				2,
				1,
				2,
				5,
				1,
				5,
				3,
				1,
				3,
				4,
				1,
				4,
				2
			], t, e), this.type = "OctahedronGeometry", this.parameters = {
				radius: t,
				detail: e
			};
		}
		static fromJSON(t) {
			return new rd(t.radius, t.detail);
		}
	};
	var sd = class sd extends Cs {
		constructor(t = .5, e = 1, n = 32, i = 1, r = 0, s = 2 * Math.PI) {
			super(), this.type = "RingGeometry", this.parameters = {
				innerRadius: t,
				outerRadius: e,
				thetaSegments: n,
				phiSegments: i,
				thetaStart: r,
				thetaLength: s
			}, n = Math.max(3, n);
			const a = [], o = [], l = [], c = [];
			let h = t;
			const u = (e - t) / (i = Math.max(1, i)), d = new Li(), p = new ti();
			for (let t = 0; t <= i; t++) {
				for (let t = 0; t <= n; t++) {
					const i = r + t / n * s;
					d.x = h * Math.cos(i), d.y = h * Math.sin(i), o.push(d.x, d.y, d.z), l.push(0, 0, 1), p.x = (d.x / e + 1) / 2, p.y = (d.y / e + 1) / 2, c.push(p.x, p.y);
				}
				h += u;
			}
			for (let t = 0; t < i; t++) {
				const e = t * (n + 1);
				for (let t = 0; t < n; t++) {
					const i = t + e, r = i, s = i + n + 1, o = i + n + 2, l = i + 1;
					a.push(r, s, l), a.push(s, o, l);
				}
			}
			this.setIndex(a), this.setAttribute("position", new Ms(o, 3)), this.setAttribute("normal", new Ms(l, 3)), this.setAttribute("uv", new Ms(c, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new sd(t.innerRadius, t.outerRadius, t.thetaSegments, t.phiSegments, t.thetaStart, t.thetaLength);
		}
	};
	var ad = class ad extends Cs {
		constructor(t = new Eu([
			new ti(0, .5),
			new ti(-.5, -.5),
			new ti(.5, -.5)
		]), e = 12) {
			super(), this.type = "ShapeGeometry", this.parameters = {
				shapes: t,
				curveSegments: e
			};
			const n = [], i = [], r = [], s = [];
			let a = 0, o = 0;
			if (!1 === Array.isArray(t)) l(t);
			else for (let e = 0; e < t.length; e++) l(t[e]), this.addGroup(a, o, e), a += o, o = 0;
			function l(t) {
				const a = i.length / 3, l = t.extractPoints(e);
				let c = l.shape;
				const h = l.holes;
				!1 === $u.isClockWise(c) && (c = c.reverse());
				for (let t = 0, e = h.length; t < e; t++) {
					const e = h[t];
					!0 === $u.isClockWise(e) && (h[t] = e.reverse());
				}
				const u = $u.triangulateShape(c, h);
				for (let t = 0, e = h.length; t < e; t++) {
					const e = h[t];
					c = c.concat(e);
				}
				for (let t = 0, e = c.length; t < e; t++) {
					const e = c[t];
					i.push(e.x, e.y, 0), r.push(0, 0, 1), s.push(e.x, e.y);
				}
				for (let t = 0, e = u.length; t < e; t++) {
					const e = u[t], i = e[0] + a, r = e[1] + a, s = e[2] + a;
					n.push(i, r, s), o += 3;
				}
			}
			this.setIndex(n), this.setAttribute("position", new Ms(i, 3)), this.setAttribute("normal", new Ms(r, 3)), this.setAttribute("uv", new Ms(s, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		toJSON() {
			const t = super.toJSON();
			return function(t, e) {
				if (e.shapes = [], Array.isArray(t)) for (let n = 0, i = t.length; n < i; n++) {
					const i = t[n];
					e.shapes.push(i.uuid);
				}
				else e.shapes.push(t.uuid);
				return e;
			}(this.parameters.shapes, t);
		}
		static fromJSON(t, e) {
			const n = [];
			for (let i = 0, r = t.shapes.length; i < r; i++) {
				const r = e[t.shapes[i]];
				n.push(r);
			}
			return new ad(n, t.curveSegments);
		}
	};
	var od = class od extends Cs {
		constructor(t = 1, e = 32, n = 16, i = 0, r = 2 * Math.PI, s = 0, a = Math.PI) {
			super(), this.type = "SphereGeometry", this.parameters = {
				radius: t,
				widthSegments: e,
				heightSegments: n,
				phiStart: i,
				phiLength: r,
				thetaStart: s,
				thetaLength: a
			}, e = Math.max(3, Math.floor(e)), n = Math.max(2, Math.floor(n));
			const o = Math.min(s + a, Math.PI);
			let l = 0;
			const c = [], h = new Li(), u = new Li(), d = [], p = [], m = [], f = [];
			for (let d = 0; d <= n; d++) {
				const g = [], v = d / n;
				let _ = 0;
				0 === d && 0 === s ? _ = .5 / e : d === n && o === Math.PI && (_ = -.5 / e);
				for (let n = 0; n <= e; n++) {
					const o = n / e;
					h.x = -t * Math.cos(i + o * r) * Math.sin(s + v * a), h.y = t * Math.cos(s + v * a), h.z = t * Math.sin(i + o * r) * Math.sin(s + v * a), p.push(h.x, h.y, h.z), u.copy(h).normalize(), m.push(u.x, u.y, u.z), f.push(o + _, 1 - v), g.push(l++);
				}
				c.push(g);
			}
			for (let t = 0; t < n; t++) for (let i = 0; i < e; i++) {
				const e = c[t][i + 1], r = c[t][i], a = c[t + 1][i], l = c[t + 1][i + 1];
				(0 !== t || s > 0) && d.push(e, r, l), (t !== n - 1 || o < Math.PI) && d.push(r, a, l);
			}
			this.setIndex(d), this.setAttribute("position", new Ms(p, 3)), this.setAttribute("normal", new Ms(m, 3)), this.setAttribute("uv", new Ms(f, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new od(t.radius, t.widthSegments, t.heightSegments, t.phiStart, t.phiLength, t.thetaStart, t.thetaLength);
		}
	};
	var ld = class ld extends xu {
		constructor(t = 1, e = 0) {
			super([
				1,
				1,
				1,
				-1,
				-1,
				1,
				-1,
				1,
				-1,
				1,
				-1,
				-1
			], [
				2,
				1,
				0,
				0,
				3,
				2,
				1,
				3,
				0,
				2,
				3,
				1
			], t, e), this.type = "TetrahedronGeometry", this.parameters = {
				radius: t,
				detail: e
			};
		}
		static fromJSON(t) {
			return new ld(t.radius, t.detail);
		}
	};
	var cd = class cd extends Cs {
		constructor(t = 1, e = .4, n = 12, i = 48, r = 2 * Math.PI) {
			super(), this.type = "TorusGeometry", this.parameters = {
				radius: t,
				tube: e,
				radialSegments: n,
				tubularSegments: i,
				arc: r
			}, n = Math.floor(n), i = Math.floor(i);
			const s = [], a = [], o = [], l = [], c = new Li(), h = new Li(), u = new Li();
			for (let s = 0; s <= n; s++) for (let d = 0; d <= i; d++) {
				const p = d / i * r, m = s / n * Math.PI * 2;
				h.x = (t + e * Math.cos(m)) * Math.cos(p), h.y = (t + e * Math.cos(m)) * Math.sin(p), h.z = e * Math.sin(m), a.push(h.x, h.y, h.z), c.x = t * Math.cos(p), c.y = t * Math.sin(p), u.subVectors(h, c).normalize(), o.push(u.x, u.y, u.z), l.push(d / i), l.push(s / n);
			}
			for (let t = 1; t <= n; t++) for (let e = 1; e <= i; e++) {
				const n = (i + 1) * t + e - 1, r = (i + 1) * (t - 1) + e - 1, a = (i + 1) * (t - 1) + e, o = (i + 1) * t + e;
				s.push(n, r, o), s.push(r, a, o);
			}
			this.setIndex(s), this.setAttribute("position", new Ms(a, 3)), this.setAttribute("normal", new Ms(o, 3)), this.setAttribute("uv", new Ms(l, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new cd(t.radius, t.tube, t.radialSegments, t.tubularSegments, t.arc);
		}
	};
	var hd = class hd extends Cs {
		constructor(t = 1, e = .4, n = 64, i = 8, r = 2, s = 3) {
			super(), this.type = "TorusKnotGeometry", this.parameters = {
				radius: t,
				tube: e,
				tubularSegments: n,
				radialSegments: i,
				p: r,
				q: s
			}, n = Math.floor(n), i = Math.floor(i);
			const a = [], o = [], l = [], c = [], h = new Li(), u = new Li(), d = new Li(), p = new Li(), m = new Li(), f = new Li(), g = new Li();
			for (let a = 0; a <= n; ++a) {
				const _ = a / n * r * Math.PI * 2;
				v(_, r, s, t, d), v(_ + .01, r, s, t, p), f.subVectors(p, d), g.addVectors(p, d), m.crossVectors(f, g), g.crossVectors(m, f), m.normalize(), g.normalize();
				for (let t = 0; t <= i; ++t) {
					const r = t / i * Math.PI * 2, s = -e * Math.cos(r), p = e * Math.sin(r);
					h.x = d.x + (s * g.x + p * m.x), h.y = d.y + (s * g.y + p * m.y), h.z = d.z + (s * g.z + p * m.z), o.push(h.x, h.y, h.z), u.subVectors(h, d).normalize(), l.push(u.x, u.y, u.z), c.push(a / n), c.push(t / i);
				}
			}
			for (let t = 1; t <= n; t++) for (let e = 1; e <= i; e++) {
				const n = (i + 1) * (t - 1) + (e - 1), r = (i + 1) * t + (e - 1), s = (i + 1) * t + e, o = (i + 1) * (t - 1) + e;
				a.push(n, r, o), a.push(r, s, o);
			}
			function v(t, e, n, i, r) {
				const s = Math.cos(t), a = Math.sin(t), o = n / e * t, l = Math.cos(o);
				r.x = i * (2 + l) * .5 * s, r.y = i * (2 + l) * a * .5, r.z = i * Math.sin(o) * .5;
			}
			this.setIndex(a), this.setAttribute("position", new Ms(o, 3)), this.setAttribute("normal", new Ms(l, 3)), this.setAttribute("uv", new Ms(c, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		static fromJSON(t) {
			return new hd(t.radius, t.tube, t.tubularSegments, t.radialSegments, t.p, t.q);
		}
	};
	var ud = class ud extends Cs {
		constructor(t = new cu(new Li(-1, -1, 0), new Li(-1, 1, 0), new Li(1, 1, 0)), e = 64, n = 1, i = 8, r = !1) {
			super(), this.type = "TubeGeometry", this.parameters = {
				path: t,
				tubularSegments: e,
				radius: n,
				radialSegments: i,
				closed: r
			};
			const s = t.computeFrenetFrames(e, r);
			this.tangents = s.tangents, this.normals = s.normals, this.binormals = s.binormals;
			const a = new Li(), o = new Li(), l = new ti();
			let c = new Li();
			const h = [], u = [], d = [], p = [];
			function m(r) {
				c = t.getPointAt(r / e, c);
				const l = s.normals[r], d = s.binormals[r];
				for (let t = 0; t <= i; t++) {
					const e = t / i * Math.PI * 2, r = Math.sin(e), s = -Math.cos(e);
					o.x = s * l.x + r * d.x, o.y = s * l.y + r * d.y, o.z = s * l.z + r * d.z, o.normalize(), u.push(o.x, o.y, o.z), a.x = c.x + n * o.x, a.y = c.y + n * o.y, a.z = c.z + n * o.z, h.push(a.x, a.y, a.z);
				}
			}
			(function() {
				for (let t = 0; t < e; t++) m(t);
				m(!1 === r ? e : 0), function() {
					for (let t = 0; t <= e; t++) for (let n = 0; n <= i; n++) l.x = t / e, l.y = n / i, d.push(l.x, l.y);
				}(), function() {
					for (let t = 1; t <= e; t++) for (let e = 1; e <= i; e++) {
						const n = (i + 1) * (t - 1) + (e - 1), r = (i + 1) * t + (e - 1), s = (i + 1) * t + e, a = (i + 1) * (t - 1) + e;
						p.push(n, r, a), p.push(r, s, a);
					}
				}();
			})(), this.setIndex(p), this.setAttribute("position", new Ms(h, 3)), this.setAttribute("normal", new Ms(u, 3)), this.setAttribute("uv", new Ms(d, 2));
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.path = this.parameters.path.toJSON(), t;
		}
		static fromJSON(t) {
			return new ud(new uu[t.path.type]().fromJSON(t.path), t.tubularSegments, t.radius, t.radialSegments, t.closed);
		}
	};
	var dd = class extends Cs {
		constructor(t = null) {
			if (super(), this.type = "WireframeGeometry", this.parameters = { geometry: t }, null !== t) {
				const e = [], n = /* @__PURE__ */ new Set(), i = new Li(), r = new Li();
				if (null !== t.index) {
					const s = t.attributes.position, a = t.index;
					let o = t.groups;
					0 === o.length && (o = [{
						start: 0,
						count: a.count,
						materialIndex: 0
					}]);
					for (let t = 0, l = o.length; t < l; ++t) {
						const l = o[t], c = l.start;
						for (let t = c, o = c + l.count; t < o; t += 3) for (let o = 0; o < 3; o++) {
							const l = a.getX(t + o), c = a.getX(t + (o + 1) % 3);
							i.fromBufferAttribute(s, l), r.fromBufferAttribute(s, c), !0 === pd(i, r, n) && (e.push(i.x, i.y, i.z), e.push(r.x, r.y, r.z));
						}
					}
				} else {
					const s = t.attributes.position;
					for (let t = 0, a = s.count / 3; t < a; t++) for (let a = 0; a < 3; a++) {
						const o = 3 * t + a, l = 3 * t + (a + 1) % 3;
						i.fromBufferAttribute(s, o), r.fromBufferAttribute(s, l), !0 === pd(i, r, n) && (e.push(i.x, i.y, i.z), e.push(r.x, r.y, r.z));
					}
				}
				this.setAttribute("position", new Ms(e, 3));
			}
		}
		copy(t) {
			return super.copy(t), this.parameters = Object.assign({}, t.parameters), this;
		}
	};
	function pd(t, e, n) {
		const i = `${t.x},${t.y},${t.z}-${e.x},${e.y},${e.z}`, r = `${e.x},${e.y},${e.z}-${t.x},${t.y},${t.z}`;
		return !0 !== n.has(i) && !0 !== n.has(r) && (n.add(i), n.add(r), !0);
	}
	var md = Object.freeze({
		__proto__: null,
		BoxGeometry: Gs,
		CapsuleGeometry: fu,
		CircleGeometry: gu,
		ConeGeometry: _u,
		CylinderGeometry: vu,
		DodecahedronGeometry: yu,
		EdgesGeometry: Tu,
		ExtrudeGeometry: ed,
		IcosahedronGeometry: id,
		LatheGeometry: mu,
		OctahedronGeometry: rd,
		PlaneGeometry: pa,
		PolyhedronGeometry: xu,
		RingGeometry: sd,
		ShapeGeometry: ad,
		SphereGeometry: od,
		TetrahedronGeometry: ld,
		TorusGeometry: cd,
		TorusKnotGeometry: hd,
		TubeGeometry: ud,
		WireframeGeometry: dd
	});
	var fd = class extends is {
		constructor(t) {
			super(), this.isShadowMaterial = !0, this.type = "ShadowMaterial", this.color = new ts(0), this.transparent = !0, this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.color.copy(t.color), this.fog = t.fog, this;
		}
	};
	var gd = class extends Ys {
		constructor(t) {
			super(t), this.isRawShaderMaterial = !0, this.type = "RawShaderMaterial";
		}
	};
	var vd = class extends is {
		constructor(t) {
			super(), this.isMeshStandardMaterial = !0, this.defines = { STANDARD: "" }, this.type = "MeshStandardMaterial", this.color = new ts(16777215), this.roughness = 1, this.metalness = 0, this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new ts(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = 0, this.normalScale = new ti(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.roughnessMap = null, this.metalnessMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new _r(), this.envMapIntensity = 1, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.flatShading = !1, this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.defines = { STANDARD: "" }, this.color.copy(t.color), this.roughness = t.roughness, this.metalness = t.metalness, this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.roughnessMap = t.roughnessMap, this.metalnessMap = t.metalnessMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.envMapIntensity = t.envMapIntensity, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.flatShading = t.flatShading, this.fog = t.fog, this;
		}
	};
	var _d = class extends vd {
		constructor(t) {
			super(), this.isMeshPhysicalMaterial = !0, this.defines = {
				STANDARD: "",
				PHYSICAL: ""
			}, this.type = "MeshPhysicalMaterial", this.anisotropyRotation = 0, this.anisotropyMap = null, this.clearcoatMap = null, this.clearcoatRoughness = 0, this.clearcoatRoughnessMap = null, this.clearcoatNormalScale = new ti(1, 1), this.clearcoatNormalMap = null, this.ior = 1.5, Object.defineProperty(this, "reflectivity", {
				get: function() {
					return Yn(2.5 * (this.ior - 1) / (this.ior + 1), 0, 1);
				},
				set: function(t) {
					this.ior = (1 + .4 * t) / (1 - .4 * t);
				}
			}), this.iridescenceMap = null, this.iridescenceIOR = 1.3, this.iridescenceThicknessRange = [100, 400], this.iridescenceThicknessMap = null, this.sheenColor = new ts(0), this.sheenColorMap = null, this.sheenRoughness = 1, this.sheenRoughnessMap = null, this.transmissionMap = null, this.thickness = 0, this.thicknessMap = null, this.attenuationDistance = Infinity, this.attenuationColor = new ts(1, 1, 1), this.specularIntensity = 1, this.specularIntensityMap = null, this.specularColor = new ts(1, 1, 1), this.specularColorMap = null, this._anisotropy = 0, this._clearcoat = 0, this._dispersion = 0, this._iridescence = 0, this._sheen = 0, this._transmission = 0, this.setValues(t);
		}
		get anisotropy() {
			return this._anisotropy;
		}
		set anisotropy(t) {
			this._anisotropy > 0 != t > 0 && this.version++, this._anisotropy = t;
		}
		get clearcoat() {
			return this._clearcoat;
		}
		set clearcoat(t) {
			this._clearcoat > 0 != t > 0 && this.version++, this._clearcoat = t;
		}
		get iridescence() {
			return this._iridescence;
		}
		set iridescence(t) {
			this._iridescence > 0 != t > 0 && this.version++, this._iridescence = t;
		}
		get dispersion() {
			return this._dispersion;
		}
		set dispersion(t) {
			this._dispersion > 0 != t > 0 && this.version++, this._dispersion = t;
		}
		get sheen() {
			return this._sheen;
		}
		set sheen(t) {
			this._sheen > 0 != t > 0 && this.version++, this._sheen = t;
		}
		get transmission() {
			return this._transmission;
		}
		set transmission(t) {
			this._transmission > 0 != t > 0 && this.version++, this._transmission = t;
		}
		copy(t) {
			return super.copy(t), this.defines = {
				STANDARD: "",
				PHYSICAL: ""
			}, this.anisotropy = t.anisotropy, this.anisotropyRotation = t.anisotropyRotation, this.anisotropyMap = t.anisotropyMap, this.clearcoat = t.clearcoat, this.clearcoatMap = t.clearcoatMap, this.clearcoatRoughness = t.clearcoatRoughness, this.clearcoatRoughnessMap = t.clearcoatRoughnessMap, this.clearcoatNormalMap = t.clearcoatNormalMap, this.clearcoatNormalScale.copy(t.clearcoatNormalScale), this.dispersion = t.dispersion, this.ior = t.ior, this.iridescence = t.iridescence, this.iridescenceMap = t.iridescenceMap, this.iridescenceIOR = t.iridescenceIOR, this.iridescenceThicknessRange = [...t.iridescenceThicknessRange], this.iridescenceThicknessMap = t.iridescenceThicknessMap, this.sheen = t.sheen, this.sheenColor.copy(t.sheenColor), this.sheenColorMap = t.sheenColorMap, this.sheenRoughness = t.sheenRoughness, this.sheenRoughnessMap = t.sheenRoughnessMap, this.transmission = t.transmission, this.transmissionMap = t.transmissionMap, this.thickness = t.thickness, this.thicknessMap = t.thicknessMap, this.attenuationDistance = t.attenuationDistance, this.attenuationColor.copy(t.attenuationColor), this.specularIntensity = t.specularIntensity, this.specularIntensityMap = t.specularIntensityMap, this.specularColor.copy(t.specularColor), this.specularColorMap = t.specularColorMap, this;
		}
	};
	var xd = class extends is {
		constructor(t) {
			super(), this.isMeshPhongMaterial = !0, this.type = "MeshPhongMaterial", this.color = new ts(16777215), this.specular = new ts(1118481), this.shininess = 30, this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new ts(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = 0, this.normalScale = new ti(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.specularMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new _r(), this.combine = 0, this.reflectivity = 1, this.refractionRatio = .98, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.flatShading = !1, this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.color.copy(t.color), this.specular.copy(t.specular), this.shininess = t.shininess, this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.specularMap = t.specularMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.combine = t.combine, this.reflectivity = t.reflectivity, this.refractionRatio = t.refractionRatio, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.flatShading = t.flatShading, this.fog = t.fog, this;
		}
	};
	var yd = class extends is {
		constructor(t) {
			super(), this.isMeshToonMaterial = !0, this.defines = { TOON: "" }, this.type = "MeshToonMaterial", this.color = new ts(16777215), this.map = null, this.gradientMap = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new ts(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = 0, this.normalScale = new ti(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.alphaMap = null, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.color.copy(t.color), this.map = t.map, this.gradientMap = t.gradientMap, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.alphaMap = t.alphaMap, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.fog = t.fog, this;
		}
	};
	var Md = class extends is {
		constructor(t) {
			super(), this.isMeshNormalMaterial = !0, this.type = "MeshNormalMaterial", this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = 0, this.normalScale = new ti(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.wireframe = !1, this.wireframeLinewidth = 1, this.flatShading = !1, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.flatShading = t.flatShading, this;
		}
	};
	var Sd = class extends is {
		constructor(t) {
			super(), this.isMeshLambertMaterial = !0, this.type = "MeshLambertMaterial", this.color = new ts(16777215), this.map = null, this.lightMap = null, this.lightMapIntensity = 1, this.aoMap = null, this.aoMapIntensity = 1, this.emissive = new ts(0), this.emissiveIntensity = 1, this.emissiveMap = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = 0, this.normalScale = new ti(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.specularMap = null, this.alphaMap = null, this.envMap = null, this.envMapRotation = new _r(), this.combine = 0, this.reflectivity = 1, this.refractionRatio = .98, this.wireframe = !1, this.wireframeLinewidth = 1, this.wireframeLinecap = "round", this.wireframeLinejoin = "round", this.flatShading = !1, this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.color.copy(t.color), this.map = t.map, this.lightMap = t.lightMap, this.lightMapIntensity = t.lightMapIntensity, this.aoMap = t.aoMap, this.aoMapIntensity = t.aoMapIntensity, this.emissive.copy(t.emissive), this.emissiveMap = t.emissiveMap, this.emissiveIntensity = t.emissiveIntensity, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.specularMap = t.specularMap, this.alphaMap = t.alphaMap, this.envMap = t.envMap, this.envMapRotation.copy(t.envMapRotation), this.combine = t.combine, this.reflectivity = t.reflectivity, this.refractionRatio = t.refractionRatio, this.wireframe = t.wireframe, this.wireframeLinewidth = t.wireframeLinewidth, this.wireframeLinecap = t.wireframeLinecap, this.wireframeLinejoin = t.wireframeLinejoin, this.flatShading = t.flatShading, this.fog = t.fog, this;
		}
	};
	var bd = class extends is {
		constructor(t) {
			super(), this.isMeshMatcapMaterial = !0, this.defines = { MATCAP: "" }, this.type = "MeshMatcapMaterial", this.color = new ts(16777215), this.matcap = null, this.map = null, this.bumpMap = null, this.bumpScale = 1, this.normalMap = null, this.normalMapType = 0, this.normalScale = new ti(1, 1), this.displacementMap = null, this.displacementScale = 1, this.displacementBias = 0, this.alphaMap = null, this.flatShading = !1, this.fog = !0, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.defines = { MATCAP: "" }, this.color.copy(t.color), this.matcap = t.matcap, this.map = t.map, this.bumpMap = t.bumpMap, this.bumpScale = t.bumpScale, this.normalMap = t.normalMap, this.normalMapType = t.normalMapType, this.normalScale.copy(t.normalScale), this.displacementMap = t.displacementMap, this.displacementScale = t.displacementScale, this.displacementBias = t.displacementBias, this.alphaMap = t.alphaMap, this.flatShading = t.flatShading, this.fog = t.fog, this;
		}
	};
	var wd = class extends xh {
		constructor(t) {
			super(), this.isLineDashedMaterial = !0, this.type = "LineDashedMaterial", this.scale = 1, this.dashSize = 3, this.gapSize = 1, this.setValues(t);
		}
		copy(t) {
			return super.copy(t), this.scale = t.scale, this.dashSize = t.dashSize, this.gapSize = t.gapSize, this;
		}
	};
	function Td(t, e, n) {
		return !t || !n && t.constructor === e ? t : "number" == typeof e.BYTES_PER_ELEMENT ? new e(t) : Array.prototype.slice.call(t);
	}
	function Ed(t) {
		return ArrayBuffer.isView(t) && !(t instanceof DataView);
	}
	function Ad(t) {
		const e = t.length, n = new Array(e);
		for (let t = 0; t !== e; ++t) n[t] = t;
		return n.sort((function(e, n) {
			return t[e] - t[n];
		})), n;
	}
	function Rd(t, e, n) {
		const i = t.length, r = new t.constructor(i);
		for (let s = 0, a = 0; a !== i; ++s) {
			const i = n[s] * e;
			for (let n = 0; n !== e; ++n) r[a++] = t[i + n];
		}
		return r;
	}
	function Cd(t, e, n, i) {
		let r = 1, s = t[0];
		for (; void 0 !== s && void 0 === s[i];) s = t[r++];
		if (void 0 === s) return;
		let a = s[i];
		if (void 0 !== a) if (Array.isArray(a)) do
			a = s[i], void 0 !== a && (e.push(s.time), n.push.apply(n, a)), s = t[r++];
		while (void 0 !== s);
		else if (void 0 !== a.toArray) do
			a = s[i], void 0 !== a && (e.push(s.time), a.toArray(n, n.length)), s = t[r++];
		while (void 0 !== s);
		else do
			a = s[i], void 0 !== a && (e.push(s.time), n.push(a)), s = t[r++];
		while (void 0 !== s);
	}
	const Pd = {
		convertArray: Td,
		isTypedArray: Ed,
		getKeyframeOrder: Ad,
		sortedArray: Rd,
		flattenJSON: Cd,
		subclip: function(t, e, n, i, r = 30) {
			const s = t.clone();
			s.name = e;
			const a = [];
			for (let t = 0; t < s.tracks.length; ++t) {
				const e = s.tracks[t], o = e.getValueSize(), l = [], c = [];
				for (let t = 0; t < e.times.length; ++t) {
					const s = e.times[t] * r;
					if (!(s < n || s >= i)) {
						l.push(e.times[t]);
						for (let n = 0; n < o; ++n) c.push(e.values[t * o + n]);
					}
				}
				0 !== l.length && (e.times = Td(l, e.times.constructor), e.values = Td(c, e.values.constructor), a.push(e));
			}
			s.tracks = a;
			let o = Infinity;
			for (let t = 0; t < s.tracks.length; ++t) o > s.tracks[t].times[0] && (o = s.tracks[t].times[0]);
			for (let t = 0; t < s.tracks.length; ++t) s.tracks[t].shift(-1 * o);
			return s.resetDuration(), s;
		},
		makeClipAdditive: function(t, e = 0, n = t, i = 30) {
			i <= 0 && (i = 30);
			const r = n.tracks.length, s = e / i;
			for (let e = 0; e < r; ++e) {
				const i = n.tracks[e], r = i.ValueTypeName;
				if ("bool" === r || "string" === r) continue;
				const a = t.tracks.find((function(t) {
					return t.name === i.name && t.ValueTypeName === r;
				}));
				if (void 0 === a) continue;
				let o = 0;
				const l = i.getValueSize();
				i.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline && (o = l / 3);
				let c = 0;
				const h = a.getValueSize();
				a.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline && (c = h / 3);
				const u = i.times.length - 1;
				let d;
				if (s <= i.times[0]) {
					const t = o, e = l - o;
					d = i.values.slice(t, e);
				} else if (s >= i.times[u]) {
					const t = u * l + o, e = t + l - o;
					d = i.values.slice(t, e);
				} else {
					const t = i.createInterpolant(), e = o, n = l - o;
					t.evaluate(s), d = t.resultBuffer.slice(e, n);
				}
				if ("quaternion" === r) new Ii().fromArray(d).normalize().conjugate().toArray(d);
				const p = a.times.length;
				for (let t = 0; t < p; ++t) {
					const e = t * h + c;
					if ("quaternion" === r) Ii.multiplyQuaternionsFlat(a.values, e, d, 0, a.values, e);
					else {
						const t = h - 2 * c;
						for (let n = 0; n < t; ++n) a.values[e + n] -= d[n];
					}
				}
			}
			return t.blendMode = ze, t;
		}
	};
	var Id = class {
		constructor(t, e, n, i) {
			this.parameterPositions = t, this._cachedIndex = 0, this.resultBuffer = void 0 !== i ? i : new e.constructor(n), this.sampleValues = e, this.valueSize = n, this.settings = null, this.DefaultSettings_ = {};
		}
		evaluate(t) {
			const e = this.parameterPositions;
			let n = this._cachedIndex, i = e[n], r = e[n - 1];
			t: {
				e: {
					let s;
					n: {
						i: if (!(t < i)) {
							for (let s = n + 2;;) {
								if (void 0 === i) {
									if (t < r) break i;
									return n = e.length, this._cachedIndex = n, this.copySampleValue_(n - 1);
								}
								if (n === s) break;
								if (r = i, i = e[++n], t < i) break e;
							}
							s = e.length;
							break n;
						}
						if (t >= r) break t;
						{
							const a = e[1];
							t < a && (n = 2, r = a);
							for (let s = n - 2;;) {
								if (void 0 === r) return this._cachedIndex = 0, this.copySampleValue_(0);
								if (n === s) break;
								if (i = r, r = e[--n - 1], t >= r) break e;
							}
							s = n, n = 0;
						}
					}
					for (; n < s;) {
						const i = n + s >>> 1;
						t < e[i] ? s = i : n = i + 1;
					}
					if (i = e[n], r = e[n - 1], void 0 === r) return this._cachedIndex = 0, this.copySampleValue_(0);
					if (void 0 === i) return n = e.length, this._cachedIndex = n, this.copySampleValue_(n - 1);
				}
				this._cachedIndex = n, this.intervalChanged_(n, r, i);
			}
			return this.interpolate_(n, r, t, i);
		}
		getSettings_() {
			return this.settings || this.DefaultSettings_;
		}
		copySampleValue_(t) {
			const e = this.resultBuffer, n = this.sampleValues, i = this.valueSize, r = t * i;
			for (let t = 0; t !== i; ++t) e[t] = n[r + t];
			return e;
		}
		interpolate_() {
			throw new Error("call to abstract method");
		}
		intervalChanged_() {}
	};
	var Ld = class extends Id {
		constructor(t, e, n, i) {
			super(t, e, n, i), this._weightPrev = -0, this._offsetPrev = -0, this._weightNext = -0, this._offsetNext = -0, this.DefaultSettings_ = {
				endingStart: De,
				endingEnd: De
			};
		}
		intervalChanged_(t, e, n) {
			const i = this.parameterPositions;
			let r = t - 2, s = t + 1, a = i[r], o = i[s];
			if (void 0 === a) switch (this.getSettings_().endingStart) {
				case Oe:
					r = t, a = 2 * e - n;
					break;
				case Fe:
					r = i.length - 2, a = e + i[r] - i[r + 1];
					break;
				default: r = t, a = n;
			}
			if (void 0 === o) switch (this.getSettings_().endingEnd) {
				case Oe:
					s = t, o = 2 * n - e;
					break;
				case Fe:
					s = 1, o = n + i[1] - i[0];
					break;
				default: s = t - 1, o = e;
			}
			const l = .5 * (n - e), c = this.valueSize;
			this._weightPrev = l / (e - a), this._weightNext = l / (o - n), this._offsetPrev = r * c, this._offsetNext = s * c;
		}
		interpolate_(t, e, n, i) {
			const r = this.resultBuffer, s = this.sampleValues, a = this.valueSize, o = t * a, l = o - a, c = this._offsetPrev, h = this._offsetNext, u = this._weightPrev, d = this._weightNext, p = (n - e) / (i - e), m = p * p, f = m * p, g = -u * f + 2 * u * m - u * p, v = (1 + u) * f + (-1.5 - 2 * u) * m + (-.5 + u) * p + 1, _ = (-1 - d) * f + (1.5 + d) * m + .5 * p, x = d * f - d * m;
			for (let t = 0; t !== a; ++t) r[t] = g * s[c + t] + v * s[l + t] + _ * s[o + t] + x * s[h + t];
			return r;
		}
	};
	var Ud = class extends Id {
		constructor(t, e, n, i) {
			super(t, e, n, i);
		}
		interpolate_(t, e, n, i) {
			const r = this.resultBuffer, s = this.sampleValues, a = this.valueSize, o = t * a, l = o - a, c = (n - e) / (i - e), h = 1 - c;
			for (let t = 0; t !== a; ++t) r[t] = s[l + t] * h + s[o + t] * c;
			return r;
		}
	};
	var Nd = class extends Id {
		constructor(t, e, n, i) {
			super(t, e, n, i);
		}
		interpolate_(t) {
			return this.copySampleValue_(t - 1);
		}
	};
	var Dd = class {
		constructor(t, e, n, i) {
			if (void 0 === t) throw new Error("THREE.KeyframeTrack: track name is undefined");
			if (void 0 === e || 0 === e.length) throw new Error("THREE.KeyframeTrack: no keyframes in track named " + t);
			this.name = t, this.times = Td(e, this.TimeBufferType), this.values = Td(n, this.ValueBufferType), this.setInterpolation(i || this.DefaultInterpolation);
		}
		static toJSON(t) {
			const e = t.constructor;
			let n;
			if (e.toJSON !== this.toJSON) n = e.toJSON(t);
			else {
				n = {
					name: t.name,
					times: Td(t.times, Array),
					values: Td(t.values, Array)
				};
				const e = t.getInterpolation();
				e !== t.DefaultInterpolation && (n.interpolation = e);
			}
			return n.type = t.ValueTypeName, n;
		}
		InterpolantFactoryMethodDiscrete(t) {
			return new Nd(this.times, this.values, this.getValueSize(), t);
		}
		InterpolantFactoryMethodLinear(t) {
			return new Ud(this.times, this.values, this.getValueSize(), t);
		}
		InterpolantFactoryMethodSmooth(t) {
			return new Ld(this.times, this.values, this.getValueSize(), t);
		}
		setInterpolation(t) {
			let e;
			switch (t) {
				case Le:
					e = this.InterpolantFactoryMethodDiscrete;
					break;
				case Ue:
					e = this.InterpolantFactoryMethodLinear;
					break;
				case Ne: e = this.InterpolantFactoryMethodSmooth;
			}
			if (void 0 === e) {
				const e = "unsupported interpolation for " + this.ValueTypeName + " keyframe track named " + this.name;
				if (void 0 === this.createInterpolant) {
					if (t === this.DefaultInterpolation) throw new Error(e);
					this.setInterpolation(this.DefaultInterpolation);
				}
				return console.warn("THREE.KeyframeTrack:", e), this;
			}
			return this.createInterpolant = e, this;
		}
		getInterpolation() {
			switch (this.createInterpolant) {
				case this.InterpolantFactoryMethodDiscrete: return Le;
				case this.InterpolantFactoryMethodLinear: return Ue;
				case this.InterpolantFactoryMethodSmooth: return Ne;
			}
		}
		getValueSize() {
			return this.values.length / this.times.length;
		}
		shift(t) {
			if (0 !== t) {
				const e = this.times;
				for (let n = 0, i = e.length; n !== i; ++n) e[n] += t;
			}
			return this;
		}
		scale(t) {
			if (1 !== t) {
				const e = this.times;
				for (let n = 0, i = e.length; n !== i; ++n) e[n] *= t;
			}
			return this;
		}
		trim(t, e) {
			const n = this.times, i = n.length;
			let r = 0, s = i - 1;
			for (; r !== i && n[r] < t;) ++r;
			for (; -1 !== s && n[s] > e;) --s;
			if (++s, 0 !== r || s !== i) {
				r >= s && (s = Math.max(s, 1), r = s - 1);
				const t = this.getValueSize();
				this.times = n.slice(r, s), this.values = this.values.slice(r * t, s * t);
			}
			return this;
		}
		validate() {
			let t = !0;
			const e = this.getValueSize();
			e - Math.floor(e) != 0 && (console.error("THREE.KeyframeTrack: Invalid value size in track.", this), t = !1);
			const n = this.times, i = this.values, r = n.length;
			0 === r && (console.error("THREE.KeyframeTrack: Track is empty.", this), t = !1);
			let s = null;
			for (let e = 0; e !== r; e++) {
				const i = n[e];
				if ("number" == typeof i && isNaN(i)) {
					console.error("THREE.KeyframeTrack: Time is not a valid number.", this, e, i), t = !1;
					break;
				}
				if (null !== s && s > i) {
					console.error("THREE.KeyframeTrack: Out of order keys.", this, e, i, s), t = !1;
					break;
				}
				s = i;
			}
			if (void 0 !== i && Ed(i)) for (let e = 0, n = i.length; e !== n; ++e) {
				const n = i[e];
				if (isNaN(n)) {
					console.error("THREE.KeyframeTrack: Value is not a valid number.", this, e, n), t = !1;
					break;
				}
			}
			return t;
		}
		optimize() {
			const t = this.times.slice(), e = this.values.slice(), n = this.getValueSize(), i = this.getInterpolation() === Ne, r = t.length - 1;
			let s = 1;
			for (let a = 1; a < r; ++a) {
				let r = !1;
				const o = t[a];
				if (o !== t[a + 1] && (1 !== a || o !== t[0])) if (i) r = !0;
				else {
					const t = a * n, i = t - n, s = t + n;
					for (let a = 0; a !== n; ++a) {
						const n = e[t + a];
						if (n !== e[i + a] || n !== e[s + a]) {
							r = !0;
							break;
						}
					}
				}
				if (r) {
					if (a !== s) {
						t[s] = t[a];
						const i = a * n, r = s * n;
						for (let t = 0; t !== n; ++t) e[r + t] = e[i + t];
					}
					++s;
				}
			}
			if (r > 0) {
				t[s] = t[r];
				for (let t = r * n, i = s * n, a = 0; a !== n; ++a) e[i + a] = e[t + a];
				++s;
			}
			return s !== t.length ? (this.times = t.slice(0, s), this.values = e.slice(0, s * n)) : (this.times = t, this.values = e), this;
		}
		clone() {
			const t = this.times.slice(), e = this.values.slice(), n = new this.constructor(this.name, t, e);
			return n.createInterpolant = this.createInterpolant, n;
		}
	};
	Dd.prototype.TimeBufferType = Float32Array, Dd.prototype.ValueBufferType = Float32Array, Dd.prototype.DefaultInterpolation = Ue;
	var Od = class extends Dd {
		constructor(t, e, n) {
			super(t, e, n);
		}
	};
	Od.prototype.ValueTypeName = "bool", Od.prototype.ValueBufferType = Array, Od.prototype.DefaultInterpolation = Le, Od.prototype.InterpolantFactoryMethodLinear = void 0, Od.prototype.InterpolantFactoryMethodSmooth = void 0;
	var Fd = class extends Dd {};
	Fd.prototype.ValueTypeName = "color";
	var Bd = class extends Dd {};
	Bd.prototype.ValueTypeName = "number";
	var zd = class extends Id {
		constructor(t, e, n, i) {
			super(t, e, n, i);
		}
		interpolate_(t, e, n, i) {
			const r = this.resultBuffer, s = this.sampleValues, a = this.valueSize, o = (n - e) / (i - e);
			let l = t * a;
			for (let t = l + a; l !== t; l += 4) Ii.slerpFlat(r, 0, s, l - a, s, l, o);
			return r;
		}
	};
	var kd = class extends Dd {
		InterpolantFactoryMethodLinear(t) {
			return new zd(this.times, this.values, this.getValueSize(), t);
		}
	};
	kd.prototype.ValueTypeName = "quaternion", kd.prototype.InterpolantFactoryMethodSmooth = void 0;
	var Vd = class extends Dd {
		constructor(t, e, n) {
			super(t, e, n);
		}
	};
	Vd.prototype.ValueTypeName = "string", Vd.prototype.ValueBufferType = Array, Vd.prototype.DefaultInterpolation = Le, Vd.prototype.InterpolantFactoryMethodLinear = void 0, Vd.prototype.InterpolantFactoryMethodSmooth = void 0;
	var Hd = class extends Dd {};
	Hd.prototype.ValueTypeName = "vector";
	var Gd = class {
		constructor(t = "", e = -1, n = [], i = 2500) {
			this.name = t, this.tracks = n, this.duration = e, this.blendMode = i, this.uuid = qn(), this.duration < 0 && this.resetDuration();
		}
		static parse(t) {
			const e = [], n = t.tracks, i = 1 / (t.fps || 1);
			for (let t = 0, r = n.length; t !== r; ++t) e.push(Wd(n[t]).scale(i));
			const r = new this(t.name, t.duration, e, t.blendMode);
			return r.uuid = t.uuid, r;
		}
		static toJSON(t) {
			const e = [], n = t.tracks, i = {
				name: t.name,
				duration: t.duration,
				tracks: e,
				uuid: t.uuid,
				blendMode: t.blendMode
			};
			for (let t = 0, i = n.length; t !== i; ++t) e.push(Dd.toJSON(n[t]));
			return i;
		}
		static CreateFromMorphTargetSequence(t, e, n, i) {
			const r = e.length, s = [];
			for (let t = 0; t < r; t++) {
				let a = [], o = [];
				a.push((t + r - 1) % r, t, (t + 1) % r), o.push(0, 1, 0);
				const l = Ad(a);
				a = Rd(a, 1, l), o = Rd(o, 1, l), i || 0 !== a[0] || (a.push(r), o.push(o[0])), s.push(new Bd(".morphTargetInfluences[" + e[t].name + "]", a, o).scale(1 / n));
			}
			return new this(t, -1, s);
		}
		static findByName(t, e) {
			let n = t;
			if (!Array.isArray(t)) {
				const e = t;
				n = e.geometry && e.geometry.animations || e.animations;
			}
			for (let t = 0; t < n.length; t++) if (n[t].name === e) return n[t];
			return null;
		}
		static CreateClipsFromMorphTargetSequences(t, e, n) {
			const i = {}, r = /^([\w-]*?)([\d]+)$/;
			for (let e = 0, n = t.length; e < n; e++) {
				const n = t[e], s = n.name.match(r);
				if (s && s.length > 1) {
					const t = s[1];
					let e = i[t];
					e || (i[t] = e = []), e.push(n);
				}
			}
			const s = [];
			for (const t in i) s.push(this.CreateFromMorphTargetSequence(t, i[t], e, n));
			return s;
		}
		static parseAnimation(t, e) {
			if (!t) return console.error("THREE.AnimationClip: No animation in JSONLoader data."), null;
			const n = function(t, e, n, i, r) {
				if (0 !== n.length) {
					const s = [], a = [];
					Cd(n, s, a, i), 0 !== s.length && r.push(new t(e, s, a));
				}
			}, i = [], r = t.name || "default", s = t.fps || 30, a = t.blendMode;
			let o = t.length || -1;
			const l = t.hierarchy || [];
			for (let t = 0; t < l.length; t++) {
				const r = l[t].keys;
				if (r && 0 !== r.length) if (r[0].morphTargets) {
					const t = {};
					let e;
					for (e = 0; e < r.length; e++) if (r[e].morphTargets) for (let n = 0; n < r[e].morphTargets.length; n++) t[r[e].morphTargets[n]] = -1;
					for (const n in t) {
						const t = [], s = [];
						for (let i = 0; i !== r[e].morphTargets.length; ++i) {
							const i = r[e];
							t.push(i.time), s.push(i.morphTarget === n ? 1 : 0);
						}
						i.push(new Bd(".morphTargetInfluence[" + n + "]", t, s));
					}
					o = t.length * s;
				} else {
					const s = ".bones[" + e[t].name + "]";
					n(Hd, s + ".position", r, "pos", i), n(kd, s + ".quaternion", r, "rot", i), n(Hd, s + ".scale", r, "scl", i);
				}
			}
			if (0 === i.length) return null;
			return new this(r, o, i, a);
		}
		resetDuration() {
			let t = 0;
			for (let e = 0, n = this.tracks.length; e !== n; ++e) {
				const n = this.tracks[e];
				t = Math.max(t, n.times[n.times.length - 1]);
			}
			return this.duration = t, this;
		}
		trim() {
			for (let t = 0; t < this.tracks.length; t++) this.tracks[t].trim(0, this.duration);
			return this;
		}
		validate() {
			let t = !0;
			for (let e = 0; e < this.tracks.length; e++) t = t && this.tracks[e].validate();
			return t;
		}
		optimize() {
			for (let t = 0; t < this.tracks.length; t++) this.tracks[t].optimize();
			return this;
		}
		clone() {
			const t = [];
			for (let e = 0; e < this.tracks.length; e++) t.push(this.tracks[e].clone());
			return new this.constructor(this.name, this.duration, t, this.blendMode);
		}
		toJSON() {
			return this.constructor.toJSON(this);
		}
	};
	function Wd(t) {
		if (void 0 === t.type) throw new Error("THREE.KeyframeTrack: track type undefined, can not parse");
		const e = function(t) {
			switch (t.toLowerCase()) {
				case "scalar":
				case "double":
				case "float":
				case "number":
				case "integer": return Bd;
				case "vector":
				case "vector2":
				case "vector3":
				case "vector4": return Hd;
				case "color": return Fd;
				case "quaternion": return kd;
				case "bool":
				case "boolean": return Od;
				case "string": return Vd;
			}
			throw new Error("THREE.KeyframeTrack: Unsupported typeName: " + t);
		}(t.type);
		if (void 0 === t.times) {
			const e = [], n = [];
			Cd(t.keys, e, n, "value"), t.times = e, t.values = n;
		}
		return void 0 !== e.parse ? e.parse(t) : new e(t.name, t.times, t.values, t.interpolation);
	}
	const Xd = {
		enabled: !1,
		files: {},
		add: function(t, e) {
			!1 !== this.enabled && (this.files[t] = e);
		},
		get: function(t) {
			if (!1 !== this.enabled) return this.files[t];
		},
		remove: function(t) {
			delete this.files[t];
		},
		clear: function() {
			this.files = {};
		}
	};
	var jd = class {
		constructor(t, e, n) {
			const i = this;
			let r, s = !1, a = 0, o = 0;
			const l = [];
			this.onStart = void 0, this.onLoad = t, this.onProgress = e, this.onError = n, this.itemStart = function(t) {
				o++, !1 === s && void 0 !== i.onStart && i.onStart(t, a, o), s = !0;
			}, this.itemEnd = function(t) {
				a++, void 0 !== i.onProgress && i.onProgress(t, a, o), a === o && (s = !1, void 0 !== i.onLoad && i.onLoad());
			}, this.itemError = function(t) {
				void 0 !== i.onError && i.onError(t);
			}, this.resolveURL = function(t) {
				return r ? r(t) : t;
			}, this.setURLModifier = function(t) {
				return r = t, this;
			}, this.addHandler = function(t, e) {
				return l.push(t, e), this;
			}, this.removeHandler = function(t) {
				const e = l.indexOf(t);
				return -1 !== e && l.splice(e, 2), this;
			}, this.getHandler = function(t) {
				for (let e = 0, n = l.length; e < n; e += 2) {
					const n = l[e], i = l[e + 1];
					if (n.global && (n.lastIndex = 0), n.test(t)) return i;
				}
				return null;
			};
		}
	};
	const qd = new jd();
	var Yd = class {
		constructor(t) {
			this.manager = void 0 !== t ? t : qd, this.crossOrigin = "anonymous", this.withCredentials = !1, this.path = "", this.resourcePath = "", this.requestHeader = {};
		}
		load() {}
		loadAsync(t, e) {
			const n = this;
			return new Promise((function(i, r) {
				n.load(t, i, e, r);
			}));
		}
		parse() {}
		setCrossOrigin(t) {
			return this.crossOrigin = t, this;
		}
		setWithCredentials(t) {
			return this.withCredentials = t, this;
		}
		setPath(t) {
			return this.path = t, this;
		}
		setResourcePath(t) {
			return this.resourcePath = t, this;
		}
		setRequestHeader(t) {
			return this.requestHeader = t, this;
		}
	};
	Yd.DEFAULT_MATERIAL_NAME = "__DEFAULT";
	const Zd = {};
	var Jd = class extends Error {
		constructor(t, e) {
			super(t), this.response = e;
		}
	};
	var Kd = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			void 0 === t && (t = ""), void 0 !== this.path && (t = this.path + t), t = this.manager.resolveURL(t);
			const r = Xd.get(t);
			if (void 0 !== r) return this.manager.itemStart(t), setTimeout((() => {
				e && e(r), this.manager.itemEnd(t);
			}), 0), r;
			if (void 0 !== Zd[t]) return void Zd[t].push({
				onLoad: e,
				onProgress: n,
				onError: i
			});
			Zd[t] = [], Zd[t].push({
				onLoad: e,
				onProgress: n,
				onError: i
			});
			const s = new Request(t, {
				headers: new Headers(this.requestHeader),
				credentials: this.withCredentials ? "include" : "same-origin"
			}), a = this.mimeType, o = this.responseType;
			fetch(s).then(((e) => {
				if (200 === e.status || 0 === e.status) {
					if (0 === e.status && console.warn("THREE.FileLoader: HTTP Status 0 received."), "undefined" == typeof ReadableStream || void 0 === e.body || void 0 === e.body.getReader) return e;
					const n = Zd[t], i = e.body.getReader(), r = e.headers.get("X-File-Size") || e.headers.get("Content-Length"), s = r ? parseInt(r) : 0, a = 0 !== s;
					let o = 0;
					const l = new ReadableStream({ start(t) {
						(function e() {
							i.read().then((({ done: i, value: r }) => {
								if (i) t.close();
								else {
									o += r.byteLength;
									const i = new ProgressEvent("progress", {
										lengthComputable: a,
										loaded: o,
										total: s
									});
									for (let t = 0, e = n.length; t < e; t++) {
										const e = n[t];
										e.onProgress && e.onProgress(i);
									}
									t.enqueue(r), e();
								}
							}), ((e) => {
								t.error(e);
							}));
						})();
					} });
					return new Response(l);
				}
				throw new Jd(`fetch for "${e.url}" responded with ${e.status}: ${e.statusText}`, e);
			})).then(((t) => {
				switch (o) {
					case "arraybuffer": return t.arrayBuffer();
					case "blob": return t.blob();
					case "document": return t.text().then(((t) => new DOMParser().parseFromString(t, a)));
					case "json": return t.json();
					default:
						if (void 0 === a) return t.text();
						{
							const e = /charset="?([^;"\s]*)"?/i.exec(a), n = e && e[1] ? e[1].toLowerCase() : void 0, i = new TextDecoder(n);
							return t.arrayBuffer().then(((t) => i.decode(t)));
						}
				}
			})).then(((e) => {
				Xd.add(t, e);
				const n = Zd[t];
				delete Zd[t];
				for (let t = 0, i = n.length; t < i; t++) {
					const i = n[t];
					i.onLoad && i.onLoad(e);
				}
			})).catch(((e) => {
				const n = Zd[t];
				if (void 0 === n) throw this.manager.itemError(t), e;
				delete Zd[t];
				for (let t = 0, i = n.length; t < i; t++) {
					const i = n[t];
					i.onError && i.onError(e);
				}
				this.manager.itemError(t);
			})).finally((() => {
				this.manager.itemEnd(t);
			})), this.manager.itemStart(t);
		}
		setResponseType(t) {
			return this.responseType = t, this;
		}
		setMimeType(t) {
			return this.mimeType = t, this;
		}
	};
	var $d = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			const r = this, s = new Kd(this.manager);
			s.setPath(this.path), s.setRequestHeader(this.requestHeader), s.setWithCredentials(this.withCredentials), s.load(t, (function(n) {
				try {
					e(r.parse(JSON.parse(n)));
				} catch (e) {
					i ? i(e) : console.error(e), r.manager.itemError(t);
				}
			}), n, i);
		}
		parse(t) {
			const e = [];
			for (let n = 0; n < t.length; n++) {
				const i = Gd.parse(t[n]);
				e.push(i);
			}
			return e;
		}
	};
	var Qd = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			const r = this, s = [], a = new Hh(), o = new Kd(this.manager);
			o.setPath(this.path), o.setResponseType("arraybuffer"), o.setRequestHeader(this.requestHeader), o.setWithCredentials(r.withCredentials);
			let l = 0;
			function c(c) {
				o.load(t[c], (function(t) {
					const n = r.parse(t, !0);
					s[c] = {
						width: n.width,
						height: n.height,
						format: n.format,
						mipmaps: n.mipmaps
					}, l += 1, 6 === l && (1 === n.mipmapCount && (a.minFilter = 1006), a.image = s, a.format = n.format, a.needsUpdate = !0, e && e(a));
				}), n, i);
			}
			if (Array.isArray(t)) for (let e = 0, n = t.length; e < n; ++e) c(e);
			else o.load(t, (function(t) {
				const n = r.parse(t, !0);
				if (n.isCubemap) {
					const t = n.mipmaps.length / n.mipmapCount;
					for (let e = 0; e < t; e++) {
						s[e] = { mipmaps: [] };
						for (let t = 0; t < n.mipmapCount; t++) s[e].mipmaps.push(n.mipmaps[e * n.mipmapCount + t]), s[e].format = n.format, s[e].width = n.width, s[e].height = n.height;
					}
					a.image = s;
				} else a.image.width = n.width, a.image.height = n.height, a.mipmaps = n.mipmaps;
				1 === n.mipmapCount && (a.minFilter = 1006), a.format = n.format, a.needsUpdate = !0, e && e(a);
			}), n, i);
			return a;
		}
	};
	var tp = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			void 0 !== this.path && (t = this.path + t), t = this.manager.resolveURL(t);
			const r = this, s = Xd.get(t);
			if (void 0 !== s) return r.manager.itemStart(t), setTimeout((function() {
				e && e(s), r.manager.itemEnd(t);
			}), 0), s;
			const a = ai("img");
			function o() {
				c(), Xd.add(t, this), e && e(this), r.manager.itemEnd(t);
			}
			function l(e) {
				c(), i && i(e), r.manager.itemError(t), r.manager.itemEnd(t);
			}
			function c() {
				a.removeEventListener("load", o, !1), a.removeEventListener("error", l, !1);
			}
			return a.addEventListener("load", o, !1), a.addEventListener("error", l, !1), "data:" !== t.slice(0, 5) && void 0 !== this.crossOrigin && (a.crossOrigin = this.crossOrigin), r.manager.itemStart(t), a.src = t, a;
		}
	};
	var ep = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			const r = new na();
			r.colorSpace = Je;
			const s = new tp(this.manager);
			s.setCrossOrigin(this.crossOrigin), s.setPath(this.path);
			let a = 0;
			function o(n) {
				s.load(t[n], (function(t) {
					r.images[n] = t, a++, 6 === a && (r.needsUpdate = !0, e && e(r));
				}), void 0, i);
			}
			for (let e = 0; e < t.length; ++e) o(e);
			return r;
		}
	};
	var np = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			const r = this, s = new Vc(), a = new Kd(this.manager);
			return a.setResponseType("arraybuffer"), a.setRequestHeader(this.requestHeader), a.setPath(this.path), a.setWithCredentials(r.withCredentials), a.load(t, (function(t) {
				let n;
				try {
					n = r.parse(t);
				} catch (t) {
					if (void 0 === i) return void console.error(t);
					i(t);
				}
				void 0 !== n.image ? s.image = n.image : void 0 !== n.data && (s.image.width = n.width, s.image.height = n.height, s.image.data = n.data), s.wrapS = void 0 !== n.wrapS ? n.wrapS : mt, s.wrapT = void 0 !== n.wrapT ? n.wrapT : mt, s.magFilter = void 0 !== n.magFilter ? n.magFilter : Mt, s.minFilter = void 0 !== n.minFilter ? n.minFilter : Mt, s.anisotropy = void 0 !== n.anisotropy ? n.anisotropy : 1, void 0 !== n.colorSpace && (s.colorSpace = n.colorSpace), void 0 !== n.flipY && (s.flipY = n.flipY), void 0 !== n.format && (s.format = n.format), void 0 !== n.type && (s.type = n.type), void 0 !== n.mipmaps && (s.mipmaps = n.mipmaps, s.minFilter = 1008), 1 === n.mipmapCount && (s.minFilter = 1006), void 0 !== n.generateMipmaps && (s.generateMipmaps = n.generateMipmaps), s.needsUpdate = !0, e && e(s, n);
			}), n, i), s;
		}
	};
	var ip = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			const r = new bi(), s = new tp(this.manager);
			return s.setCrossOrigin(this.crossOrigin), s.setPath(this.path), s.load(t, (function(t) {
				r.image = t, r.needsUpdate = !0, void 0 !== e && e(r);
			}), n, i), r;
		}
	};
	var rp = class extends Dr {
		constructor(t, e = 1) {
			super(), this.isLight = !0, this.type = "Light", this.color = new ts(t), this.intensity = e;
		}
		dispose() {}
		copy(t, e) {
			return super.copy(t, e), this.color.copy(t.color), this.intensity = t.intensity, this;
		}
		toJSON(t) {
			const e = super.toJSON(t);
			return e.object.color = this.color.getHex(), e.object.intensity = this.intensity, void 0 !== this.groundColor && (e.object.groundColor = this.groundColor.getHex()), void 0 !== this.distance && (e.object.distance = this.distance), void 0 !== this.angle && (e.object.angle = this.angle), void 0 !== this.decay && (e.object.decay = this.decay), void 0 !== this.penumbra && (e.object.penumbra = this.penumbra), void 0 !== this.shadow && (e.object.shadow = this.shadow.toJSON()), void 0 !== this.target && (e.object.target = this.target.uuid), e;
		}
	};
	var sp = class extends rp {
		constructor(t, e, n) {
			super(t, n), this.isHemisphereLight = !0, this.type = "HemisphereLight", this.position.copy(Dr.DEFAULT_UP), this.updateMatrix(), this.groundColor = new ts(e);
		}
		copy(t, e) {
			return super.copy(t, e), this.groundColor.copy(t.groundColor), this;
		}
	};
	const ap = new lr(), op = new Li(), lp = new Li();
	var cp = class {
		constructor(t) {
			this.camera = t, this.intensity = 1, this.bias = 0, this.normalBias = 0, this.radius = 1, this.blurSamples = 8, this.mapSize = new ti(512, 512), this.map = null, this.mapPass = null, this.matrix = new lr(), this.autoUpdate = !0, this.needsUpdate = !1, this._frustum = new ha(), this._frameExtents = new ti(1, 1), this._viewportCount = 1, this._viewports = [new wi(0, 0, 1, 1)];
		}
		getViewportCount() {
			return this._viewportCount;
		}
		getFrustum() {
			return this._frustum;
		}
		updateMatrices(t) {
			const e = this.camera, n = this.matrix;
			op.setFromMatrixPosition(t.matrixWorld), e.position.copy(op), lp.setFromMatrixPosition(t.target.matrixWorld), e.lookAt(lp), e.updateMatrixWorld(), ap.multiplyMatrices(e.projectionMatrix, e.matrixWorldInverse), this._frustum.setFromProjectionMatrix(ap), n.set(.5, 0, 0, .5, 0, .5, 0, .5, 0, 0, .5, .5, 0, 0, 0, 1), n.multiply(ap);
		}
		getViewport(t) {
			return this._viewports[t];
		}
		getFrameExtents() {
			return this._frameExtents;
		}
		dispose() {
			this.map && this.map.dispose(), this.mapPass && this.mapPass.dispose();
		}
		copy(t) {
			return this.camera = t.camera.clone(), this.intensity = t.intensity, this.bias = t.bias, this.radius = t.radius, this.mapSize.copy(t.mapSize), this;
		}
		clone() {
			return new this.constructor().copy(this);
		}
		toJSON() {
			const t = {};
			return 1 !== this.intensity && (t.intensity = this.intensity), 0 !== this.bias && (t.bias = this.bias), 0 !== this.normalBias && (t.normalBias = this.normalBias), 1 !== this.radius && (t.radius = this.radius), 512 === this.mapSize.x && 512 === this.mapSize.y || (t.mapSize = this.mapSize.toArray()), t.camera = this.camera.toJSON(!1).object, delete t.camera.matrix, t;
		}
	};
	var hp = class extends cp {
		constructor() {
			super(new Qs(50, 1, .5, 500)), this.isSpotLightShadow = !0, this.focus = 1;
		}
		updateMatrices(t) {
			const e = this.camera, n = 2 * jn * t.angle * this.focus, i = this.mapSize.width / this.mapSize.height, r = t.distance || e.far;
			n === e.fov && i === e.aspect && r === e.far || (e.fov = n, e.aspect = i, e.far = r, e.updateProjectionMatrix()), super.updateMatrices(t);
		}
		copy(t) {
			return super.copy(t), this.focus = t.focus, this;
		}
	};
	var up = class extends rp {
		constructor(t, e, n = 0, i = Math.PI / 3, r = 0, s = 2) {
			super(t, e), this.isSpotLight = !0, this.type = "SpotLight", this.position.copy(Dr.DEFAULT_UP), this.updateMatrix(), this.target = new Dr(), this.distance = n, this.angle = i, this.penumbra = r, this.decay = s, this.map = null, this.shadow = new hp();
		}
		get power() {
			return this.intensity * Math.PI;
		}
		set power(t) {
			this.intensity = t / Math.PI;
		}
		dispose() {
			this.shadow.dispose();
		}
		copy(t, e) {
			return super.copy(t, e), this.distance = t.distance, this.angle = t.angle, this.penumbra = t.penumbra, this.decay = t.decay, this.target = t.target.clone(), this.shadow = t.shadow.clone(), this;
		}
	};
	const dp = new lr(), pp = new Li(), mp = new Li();
	var fp = class extends cp {
		constructor() {
			super(new Qs(90, 1, .5, 500)), this.isPointLightShadow = !0, this._frameExtents = new ti(4, 2), this._viewportCount = 6, this._viewports = [
				new wi(2, 1, 1, 1),
				new wi(0, 1, 1, 1),
				new wi(3, 1, 1, 1),
				new wi(1, 1, 1, 1),
				new wi(3, 0, 1, 1),
				new wi(1, 0, 1, 1)
			], this._cubeDirections = [
				new Li(1, 0, 0),
				new Li(-1, 0, 0),
				new Li(0, 0, 1),
				new Li(0, 0, -1),
				new Li(0, 1, 0),
				new Li(0, -1, 0)
			], this._cubeUps = [
				new Li(0, 1, 0),
				new Li(0, 1, 0),
				new Li(0, 1, 0),
				new Li(0, 1, 0),
				new Li(0, 0, 1),
				new Li(0, 0, -1)
			];
		}
		updateMatrices(t, e = 0) {
			const n = this.camera, i = this.matrix, r = t.distance || n.far;
			r !== n.far && (n.far = r, n.updateProjectionMatrix()), pp.setFromMatrixPosition(t.matrixWorld), n.position.copy(pp), mp.copy(n.position), mp.add(this._cubeDirections[e]), n.up.copy(this._cubeUps[e]), n.lookAt(mp), n.updateMatrixWorld(), i.makeTranslation(-pp.x, -pp.y, -pp.z), dp.multiplyMatrices(n.projectionMatrix, n.matrixWorldInverse), this._frustum.setFromProjectionMatrix(dp);
		}
	};
	var gp = class extends rp {
		constructor(t, e, n = 0, i = 2) {
			super(t, e), this.isPointLight = !0, this.type = "PointLight", this.distance = n, this.decay = i, this.shadow = new fp();
		}
		get power() {
			return 4 * this.intensity * Math.PI;
		}
		set power(t) {
			this.intensity = t / (4 * Math.PI);
		}
		dispose() {
			this.shadow.dispose();
		}
		copy(t, e) {
			return super.copy(t, e), this.distance = t.distance, this.decay = t.decay, this.shadow = t.shadow.clone(), this;
		}
	};
	var vp = class extends cp {
		constructor() {
			super(new Ea(-5, 5, 5, -5, .5, 500)), this.isDirectionalLightShadow = !0;
		}
	};
	var _p = class extends rp {
		constructor(t, e) {
			super(t, e), this.isDirectionalLight = !0, this.type = "DirectionalLight", this.position.copy(Dr.DEFAULT_UP), this.updateMatrix(), this.target = new Dr(), this.shadow = new vp();
		}
		dispose() {
			this.shadow.dispose();
		}
		copy(t) {
			return super.copy(t), this.target = t.target.clone(), this.shadow = t.shadow.clone(), this;
		}
	};
	var xp = class extends rp {
		constructor(t, e) {
			super(t, e), this.isAmbientLight = !0, this.type = "AmbientLight";
		}
	};
	var yp = class extends rp {
		constructor(t, e, n = 10, i = 10) {
			super(t, e), this.isRectAreaLight = !0, this.type = "RectAreaLight", this.width = n, this.height = i;
		}
		get power() {
			return this.intensity * this.width * this.height * Math.PI;
		}
		set power(t) {
			this.intensity = t / (this.width * this.height * Math.PI);
		}
		copy(t) {
			return super.copy(t), this.width = t.width, this.height = t.height, this;
		}
		toJSON(t) {
			const e = super.toJSON(t);
			return e.object.width = this.width, e.object.height = this.height, e;
		}
	};
	var Mp = class {
		constructor() {
			this.isSphericalHarmonics3 = !0, this.coefficients = [];
			for (let t = 0; t < 9; t++) this.coefficients.push(new Li());
		}
		set(t) {
			for (let e = 0; e < 9; e++) this.coefficients[e].copy(t[e]);
			return this;
		}
		zero() {
			for (let t = 0; t < 9; t++) this.coefficients[t].set(0, 0, 0);
			return this;
		}
		getAt(t, e) {
			const n = t.x, i = t.y, r = t.z, s = this.coefficients;
			return e.copy(s[0]).multiplyScalar(.282095), e.addScaledVector(s[1], .488603 * i), e.addScaledVector(s[2], .488603 * r), e.addScaledVector(s[3], .488603 * n), e.addScaledVector(s[4], n * i * 1.092548), e.addScaledVector(s[5], i * r * 1.092548), e.addScaledVector(s[6], .315392 * (3 * r * r - 1)), e.addScaledVector(s[7], n * r * 1.092548), e.addScaledVector(s[8], .546274 * (n * n - i * i)), e;
		}
		getIrradianceAt(t, e) {
			const n = t.x, i = t.y, r = t.z, s = this.coefficients;
			return e.copy(s[0]).multiplyScalar(.886227), e.addScaledVector(s[1], 1.023328 * i), e.addScaledVector(s[2], 1.023328 * r), e.addScaledVector(s[3], 1.023328 * n), e.addScaledVector(s[4], .858086 * n * i), e.addScaledVector(s[5], .858086 * i * r), e.addScaledVector(s[6], .743125 * r * r - .247708), e.addScaledVector(s[7], .858086 * n * r), e.addScaledVector(s[8], .429043 * (n * n - i * i)), e;
		}
		add(t) {
			for (let e = 0; e < 9; e++) this.coefficients[e].add(t.coefficients[e]);
			return this;
		}
		addScaledSH(t, e) {
			for (let n = 0; n < 9; n++) this.coefficients[n].addScaledVector(t.coefficients[n], e);
			return this;
		}
		scale(t) {
			for (let e = 0; e < 9; e++) this.coefficients[e].multiplyScalar(t);
			return this;
		}
		lerp(t, e) {
			for (let n = 0; n < 9; n++) this.coefficients[n].lerp(t.coefficients[n], e);
			return this;
		}
		equals(t) {
			for (let e = 0; e < 9; e++) if (!this.coefficients[e].equals(t.coefficients[e])) return !1;
			return !0;
		}
		copy(t) {
			return this.set(t.coefficients);
		}
		clone() {
			return new this.constructor().copy(this);
		}
		fromArray(t, e = 0) {
			const n = this.coefficients;
			for (let i = 0; i < 9; i++) n[i].fromArray(t, e + 3 * i);
			return this;
		}
		toArray(t = [], e = 0) {
			const n = this.coefficients;
			for (let i = 0; i < 9; i++) n[i].toArray(t, e + 3 * i);
			return t;
		}
		static getBasisAt(t, e) {
			const n = t.x, i = t.y, r = t.z;
			e[0] = .282095, e[1] = .488603 * i, e[2] = .488603 * r, e[3] = .488603 * n, e[4] = 1.092548 * n * i, e[5] = 1.092548 * i * r, e[6] = .315392 * (3 * r * r - 1), e[7] = 1.092548 * n * r, e[8] = .546274 * (n * n - i * i);
		}
	};
	var Sp = class extends rp {
		constructor(t = new Mp(), e = 1) {
			super(void 0, e), this.isLightProbe = !0, this.sh = t;
		}
		copy(t) {
			return super.copy(t), this.sh.copy(t.sh), this;
		}
		fromJSON(t) {
			return this.intensity = t.intensity, this.sh.fromArray(t.sh), this;
		}
		toJSON(t) {
			const e = super.toJSON(t);
			return e.object.sh = this.sh.toArray(), e;
		}
	};
	var bp = class bp extends Yd {
		constructor(t) {
			super(t), this.textures = {};
		}
		load(t, e, n, i) {
			const r = this, s = new Kd(r.manager);
			s.setPath(r.path), s.setRequestHeader(r.requestHeader), s.setWithCredentials(r.withCredentials), s.load(t, (function(n) {
				try {
					e(r.parse(JSON.parse(n)));
				} catch (e) {
					i ? i(e) : console.error(e), r.manager.itemError(t);
				}
			}), n, i);
		}
		parse(t) {
			const e = this.textures;
			function n(t) {
				return void 0 === e[t] && console.warn("THREE.MaterialLoader: Undefined texture", t), e[t];
			}
			const i = this.createMaterialFromType(t.type);
			if (void 0 !== t.uuid && (i.uuid = t.uuid), void 0 !== t.name && (i.name = t.name), void 0 !== t.color && void 0 !== i.color && i.color.setHex(t.color), void 0 !== t.roughness && (i.roughness = t.roughness), void 0 !== t.metalness && (i.metalness = t.metalness), void 0 !== t.sheen && (i.sheen = t.sheen), void 0 !== t.sheenColor && (i.sheenColor = new ts().setHex(t.sheenColor)), void 0 !== t.sheenRoughness && (i.sheenRoughness = t.sheenRoughness), void 0 !== t.emissive && void 0 !== i.emissive && i.emissive.setHex(t.emissive), void 0 !== t.specular && void 0 !== i.specular && i.specular.setHex(t.specular), void 0 !== t.specularIntensity && (i.specularIntensity = t.specularIntensity), void 0 !== t.specularColor && void 0 !== i.specularColor && i.specularColor.setHex(t.specularColor), void 0 !== t.shininess && (i.shininess = t.shininess), void 0 !== t.clearcoat && (i.clearcoat = t.clearcoat), void 0 !== t.clearcoatRoughness && (i.clearcoatRoughness = t.clearcoatRoughness), void 0 !== t.dispersion && (i.dispersion = t.dispersion), void 0 !== t.iridescence && (i.iridescence = t.iridescence), void 0 !== t.iridescenceIOR && (i.iridescenceIOR = t.iridescenceIOR), void 0 !== t.iridescenceThicknessRange && (i.iridescenceThicknessRange = t.iridescenceThicknessRange), void 0 !== t.transmission && (i.transmission = t.transmission), void 0 !== t.thickness && (i.thickness = t.thickness), void 0 !== t.attenuationDistance && (i.attenuationDistance = t.attenuationDistance), void 0 !== t.attenuationColor && void 0 !== i.attenuationColor && i.attenuationColor.setHex(t.attenuationColor), void 0 !== t.anisotropy && (i.anisotropy = t.anisotropy), void 0 !== t.anisotropyRotation && (i.anisotropyRotation = t.anisotropyRotation), void 0 !== t.fog && (i.fog = t.fog), void 0 !== t.flatShading && (i.flatShading = t.flatShading), void 0 !== t.blending && (i.blending = t.blending), void 0 !== t.combine && (i.combine = t.combine), void 0 !== t.side && (i.side = t.side), void 0 !== t.shadowSide && (i.shadowSide = t.shadowSide), void 0 !== t.opacity && (i.opacity = t.opacity), void 0 !== t.transparent && (i.transparent = t.transparent), void 0 !== t.alphaTest && (i.alphaTest = t.alphaTest), void 0 !== t.alphaHash && (i.alphaHash = t.alphaHash), void 0 !== t.depthFunc && (i.depthFunc = t.depthFunc), void 0 !== t.depthTest && (i.depthTest = t.depthTest), void 0 !== t.depthWrite && (i.depthWrite = t.depthWrite), void 0 !== t.colorWrite && (i.colorWrite = t.colorWrite), void 0 !== t.blendSrc && (i.blendSrc = t.blendSrc), void 0 !== t.blendDst && (i.blendDst = t.blendDst), void 0 !== t.blendEquation && (i.blendEquation = t.blendEquation), void 0 !== t.blendSrcAlpha && (i.blendSrcAlpha = t.blendSrcAlpha), void 0 !== t.blendDstAlpha && (i.blendDstAlpha = t.blendDstAlpha), void 0 !== t.blendEquationAlpha && (i.blendEquationAlpha = t.blendEquationAlpha), void 0 !== t.blendColor && void 0 !== i.blendColor && i.blendColor.setHex(t.blendColor), void 0 !== t.blendAlpha && (i.blendAlpha = t.blendAlpha), void 0 !== t.stencilWriteMask && (i.stencilWriteMask = t.stencilWriteMask), void 0 !== t.stencilFunc && (i.stencilFunc = t.stencilFunc), void 0 !== t.stencilRef && (i.stencilRef = t.stencilRef), void 0 !== t.stencilFuncMask && (i.stencilFuncMask = t.stencilFuncMask), void 0 !== t.stencilFail && (i.stencilFail = t.stencilFail), void 0 !== t.stencilZFail && (i.stencilZFail = t.stencilZFail), void 0 !== t.stencilZPass && (i.stencilZPass = t.stencilZPass), void 0 !== t.stencilWrite && (i.stencilWrite = t.stencilWrite), void 0 !== t.wireframe && (i.wireframe = t.wireframe), void 0 !== t.wireframeLinewidth && (i.wireframeLinewidth = t.wireframeLinewidth), void 0 !== t.wireframeLinecap && (i.wireframeLinecap = t.wireframeLinecap), void 0 !== t.wireframeLinejoin && (i.wireframeLinejoin = t.wireframeLinejoin), void 0 !== t.rotation && (i.rotation = t.rotation), void 0 !== t.linewidth && (i.linewidth = t.linewidth), void 0 !== t.dashSize && (i.dashSize = t.dashSize), void 0 !== t.gapSize && (i.gapSize = t.gapSize), void 0 !== t.scale && (i.scale = t.scale), void 0 !== t.polygonOffset && (i.polygonOffset = t.polygonOffset), void 0 !== t.polygonOffsetFactor && (i.polygonOffsetFactor = t.polygonOffsetFactor), void 0 !== t.polygonOffsetUnits && (i.polygonOffsetUnits = t.polygonOffsetUnits), void 0 !== t.dithering && (i.dithering = t.dithering), void 0 !== t.alphaToCoverage && (i.alphaToCoverage = t.alphaToCoverage), void 0 !== t.premultipliedAlpha && (i.premultipliedAlpha = t.premultipliedAlpha), void 0 !== t.forceSinglePass && (i.forceSinglePass = t.forceSinglePass), void 0 !== t.visible && (i.visible = t.visible), void 0 !== t.toneMapped && (i.toneMapped = t.toneMapped), void 0 !== t.userData && (i.userData = t.userData), void 0 !== t.vertexColors && ("number" == typeof t.vertexColors ? i.vertexColors = t.vertexColors > 0 : i.vertexColors = t.vertexColors), void 0 !== t.uniforms) for (const e in t.uniforms) {
				const r = t.uniforms[e];
				switch (i.uniforms[e] = {}, r.type) {
					case "t":
						i.uniforms[e].value = n(r.value);
						break;
					case "c":
						i.uniforms[e].value = new ts().setHex(r.value);
						break;
					case "v2":
						i.uniforms[e].value = new ti().fromArray(r.value);
						break;
					case "v3":
						i.uniforms[e].value = new Li().fromArray(r.value);
						break;
					case "v4":
						i.uniforms[e].value = new wi().fromArray(r.value);
						break;
					case "m3":
						i.uniforms[e].value = new ei().fromArray(r.value);
						break;
					case "m4":
						i.uniforms[e].value = new lr().fromArray(r.value);
						break;
					default: i.uniforms[e].value = r.value;
				}
			}
			if (void 0 !== t.defines && (i.defines = t.defines), void 0 !== t.vertexShader && (i.vertexShader = t.vertexShader), void 0 !== t.fragmentShader && (i.fragmentShader = t.fragmentShader), void 0 !== t.glslVersion && (i.glslVersion = t.glslVersion), void 0 !== t.extensions) for (const e in t.extensions) i.extensions[e] = t.extensions[e];
			if (void 0 !== t.lights && (i.lights = t.lights), void 0 !== t.clipping && (i.clipping = t.clipping), void 0 !== t.size && (i.size = t.size), void 0 !== t.sizeAttenuation && (i.sizeAttenuation = t.sizeAttenuation), void 0 !== t.map && (i.map = n(t.map)), void 0 !== t.matcap && (i.matcap = n(t.matcap)), void 0 !== t.alphaMap && (i.alphaMap = n(t.alphaMap)), void 0 !== t.bumpMap && (i.bumpMap = n(t.bumpMap)), void 0 !== t.bumpScale && (i.bumpScale = t.bumpScale), void 0 !== t.normalMap && (i.normalMap = n(t.normalMap)), void 0 !== t.normalMapType && (i.normalMapType = t.normalMapType), void 0 !== t.normalScale) {
				let e = t.normalScale;
				!1 === Array.isArray(e) && (e = [e, e]), i.normalScale = new ti().fromArray(e);
			}
			return void 0 !== t.displacementMap && (i.displacementMap = n(t.displacementMap)), void 0 !== t.displacementScale && (i.displacementScale = t.displacementScale), void 0 !== t.displacementBias && (i.displacementBias = t.displacementBias), void 0 !== t.roughnessMap && (i.roughnessMap = n(t.roughnessMap)), void 0 !== t.metalnessMap && (i.metalnessMap = n(t.metalnessMap)), void 0 !== t.emissiveMap && (i.emissiveMap = n(t.emissiveMap)), void 0 !== t.emissiveIntensity && (i.emissiveIntensity = t.emissiveIntensity), void 0 !== t.specularMap && (i.specularMap = n(t.specularMap)), void 0 !== t.specularIntensityMap && (i.specularIntensityMap = n(t.specularIntensityMap)), void 0 !== t.specularColorMap && (i.specularColorMap = n(t.specularColorMap)), void 0 !== t.envMap && (i.envMap = n(t.envMap)), void 0 !== t.envMapRotation && i.envMapRotation.fromArray(t.envMapRotation), void 0 !== t.envMapIntensity && (i.envMapIntensity = t.envMapIntensity), void 0 !== t.reflectivity && (i.reflectivity = t.reflectivity), void 0 !== t.refractionRatio && (i.refractionRatio = t.refractionRatio), void 0 !== t.lightMap && (i.lightMap = n(t.lightMap)), void 0 !== t.lightMapIntensity && (i.lightMapIntensity = t.lightMapIntensity), void 0 !== t.aoMap && (i.aoMap = n(t.aoMap)), void 0 !== t.aoMapIntensity && (i.aoMapIntensity = t.aoMapIntensity), void 0 !== t.gradientMap && (i.gradientMap = n(t.gradientMap)), void 0 !== t.clearcoatMap && (i.clearcoatMap = n(t.clearcoatMap)), void 0 !== t.clearcoatRoughnessMap && (i.clearcoatRoughnessMap = n(t.clearcoatRoughnessMap)), void 0 !== t.clearcoatNormalMap && (i.clearcoatNormalMap = n(t.clearcoatNormalMap)), void 0 !== t.clearcoatNormalScale && (i.clearcoatNormalScale = new ti().fromArray(t.clearcoatNormalScale)), void 0 !== t.iridescenceMap && (i.iridescenceMap = n(t.iridescenceMap)), void 0 !== t.iridescenceThicknessMap && (i.iridescenceThicknessMap = n(t.iridescenceThicknessMap)), void 0 !== t.transmissionMap && (i.transmissionMap = n(t.transmissionMap)), void 0 !== t.thicknessMap && (i.thicknessMap = n(t.thicknessMap)), void 0 !== t.anisotropyMap && (i.anisotropyMap = n(t.anisotropyMap)), void 0 !== t.sheenColorMap && (i.sheenColorMap = n(t.sheenColorMap)), void 0 !== t.sheenRoughnessMap && (i.sheenRoughnessMap = n(t.sheenRoughnessMap)), i;
		}
		setTextures(t) {
			return this.textures = t, this;
		}
		createMaterialFromType(t) {
			return bp.createMaterialFromType(t);
		}
		static createMaterialFromType(t) {
			return new {
				ShadowMaterial: fd,
				SpriteMaterial: uc,
				RawShaderMaterial: gd,
				ShaderMaterial: Ys,
				PointsMaterial: Uh,
				MeshPhysicalMaterial: _d,
				MeshStandardMaterial: vd,
				MeshPhongMaterial: xd,
				MeshToonMaterial: yd,
				MeshNormalMaterial: Md,
				MeshLambertMaterial: Sd,
				MeshDepthMaterial: zl,
				MeshDistanceMaterial: kl,
				MeshBasicMaterial: rs,
				MeshMatcapMaterial: bd,
				LineDashedMaterial: wd,
				LineBasicMaterial: xh,
				Material: is
			}[t]();
		}
	};
	var wp = class {
		static decodeText(t) {
			if (console.warn("THREE.LoaderUtils: decodeText() has been deprecated with r165 and will be removed with r175. Use TextDecoder instead."), "undefined" != typeof TextDecoder) return new TextDecoder().decode(t);
			let e = "";
			for (let n = 0, i = t.length; n < i; n++) e += String.fromCharCode(t[n]);
			try {
				return decodeURIComponent(escape(e));
			} catch (t) {
				return e;
			}
		}
		static extractUrlBase(t) {
			const e = t.lastIndexOf("/");
			return -1 === e ? "./" : t.slice(0, e + 1);
		}
		static resolveURL(t, e) {
			return "string" != typeof t || "" === t ? "" : (/^https?:\/\//i.test(e) && /^\//.test(t) && (e = e.replace(/(^https?:\/\/[^\/]+).*/i, "$1")), /^(https?:)?\/\//i.test(t) || /^data:.*,.*$/i.test(t) || /^blob:.*$/i.test(t) ? t : e + t);
		}
	};
	var Tp = class extends Cs {
		constructor() {
			super(), this.isInstancedBufferGeometry = !0, this.type = "InstancedBufferGeometry", this.instanceCount = Infinity;
		}
		copy(t) {
			return super.copy(t), this.instanceCount = t.instanceCount, this;
		}
		toJSON() {
			const t = super.toJSON();
			return t.instanceCount = this.instanceCount, t.isInstancedBufferGeometry = !0, t;
		}
	};
	var Ep = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			const r = this, s = new Kd(r.manager);
			s.setPath(r.path), s.setRequestHeader(r.requestHeader), s.setWithCredentials(r.withCredentials), s.load(t, (function(n) {
				try {
					e(r.parse(JSON.parse(n)));
				} catch (e) {
					i ? i(e) : console.error(e), r.manager.itemError(t);
				}
			}), n, i);
		}
		parse(t) {
			const e = {}, n = {};
			function i(t, i) {
				if (void 0 !== e[i]) return e[i];
				const r = t.interleavedBuffers[i], s = function(t, e) {
					if (void 0 !== n[e]) return n[e];
					const r = t.arrayBuffers[e], s = new Uint32Array(r).buffer;
					return n[e] = s, s;
				}(t, r.buffer), o = new lc(si(r.type, s), r.stride);
				return o.uuid = r.uuid, e[i] = o, o;
			}
			const r = t.isInstancedBufferGeometry ? new Tp() : new Cs(), s = t.data.index;
			if (void 0 !== s) {
				const t = si(s.type, s.array);
				r.setIndex(new ds(t, 1));
			}
			const a = t.data.attributes;
			for (const e in a) {
				const n = a[e];
				let s;
				if (n.isInterleavedBufferAttribute) s = new hc(i(t.data, n.data), n.itemSize, n.offset, n.normalized);
				else {
					const t = si(n.type, n.array);
					s = new (n.isInstancedBufferAttribute ? Xc : ds)(t, n.itemSize, n.normalized);
				}
				void 0 !== n.name && (s.name = n.name), void 0 !== n.usage && s.setUsage(n.usage), r.setAttribute(e, s);
			}
			const o = t.data.morphAttributes;
			if (o) for (const e in o) {
				const n = o[e], s = [];
				for (let e = 0, r = n.length; e < r; e++) {
					const r = n[e];
					let a;
					if (r.isInterleavedBufferAttribute) a = new hc(i(t.data, r.data), r.itemSize, r.offset, r.normalized);
					else a = new ds(si(r.type, r.array), r.itemSize, r.normalized);
					void 0 !== r.name && (a.name = r.name), s.push(a);
				}
				r.morphAttributes[e] = s;
			}
			t.data.morphTargetsRelative && (r.morphTargetsRelative = !0);
			const l = t.data.groups || t.data.drawcalls || t.data.offsets;
			if (void 0 !== l) for (let t = 0, e = l.length; t !== e; ++t) {
				const e = l[t];
				r.addGroup(e.start, e.count, e.materialIndex);
			}
			const c = t.data.boundingSphere;
			if (void 0 !== c) {
				const t = new Li();
				void 0 !== c.center && t.fromArray(c.center), r.boundingSphere = new Qi(t, c.radius);
			}
			return t.name && (r.name = t.name), t.userData && (r.userData = t.userData), r;
		}
	};
	var Ap = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			const r = this, s = "" === this.path ? wp.extractUrlBase(t) : this.path;
			this.resourcePath = this.resourcePath || s;
			const a = new Kd(this.manager);
			a.setPath(this.path), a.setRequestHeader(this.requestHeader), a.setWithCredentials(this.withCredentials), a.load(t, (function(n) {
				let s = null;
				try {
					s = JSON.parse(n);
				} catch (e) {
					void 0 !== i && i(e), console.error("THREE:ObjectLoader: Can't parse " + t + ".", e.message);
					return;
				}
				const a = s.metadata;
				if (void 0 === a || void 0 === a.type || "geometry" === a.type.toLowerCase()) return void 0 !== i && i(/* @__PURE__ */ new Error("THREE.ObjectLoader: Can't load " + t)), void console.error("THREE.ObjectLoader: Can't load " + t);
				r.parse(s, e);
			}), n, i);
		}
		async loadAsync(t, e) {
			const n = "" === this.path ? wp.extractUrlBase(t) : this.path;
			this.resourcePath = this.resourcePath || n;
			const i = new Kd(this.manager);
			i.setPath(this.path), i.setRequestHeader(this.requestHeader), i.setWithCredentials(this.withCredentials);
			const r = await i.loadAsync(t, e), s = JSON.parse(r), a = s.metadata;
			if (void 0 === a || void 0 === a.type || "geometry" === a.type.toLowerCase()) throw new Error("THREE.ObjectLoader: Can't load " + t);
			return await this.parseAsync(s);
		}
		parse(t, e) {
			const n = this.parseAnimations(t.animations), i = this.parseShapes(t.shapes), r = this.parseGeometries(t.geometries, i), s = this.parseImages(t.images, (function() {
				void 0 !== e && e(l);
			})), a = this.parseTextures(t.textures, s), o = this.parseMaterials(t.materials, a), l = this.parseObject(t.object, r, o, a, n), c = this.parseSkeletons(t.skeletons, l);
			if (this.bindSkeletons(l, c), this.bindLightTargets(l), void 0 !== e) {
				let t = !1;
				for (const e in s) if (s[e].data instanceof HTMLImageElement) {
					t = !0;
					break;
				}
				!1 === t && e(l);
			}
			return l;
		}
		async parseAsync(t) {
			const e = this.parseAnimations(t.animations), n = this.parseShapes(t.shapes), i = this.parseGeometries(t.geometries, n), r = await this.parseImagesAsync(t.images), s = this.parseTextures(t.textures, r), a = this.parseMaterials(t.materials, s), o = this.parseObject(t.object, i, a, s, e), l = this.parseSkeletons(t.skeletons, o);
			return this.bindSkeletons(o, l), this.bindLightTargets(o), o;
		}
		parseShapes(t) {
			const e = {};
			if (void 0 !== t) for (let n = 0, i = t.length; n < i; n++) {
				const i = new Eu().fromJSON(t[n]);
				e[i.uuid] = i;
			}
			return e;
		}
		parseSkeletons(t, e) {
			const n = {}, i = {};
			if (e.traverse((function(t) {
				t.isBone && (i[t.uuid] = t);
			})), void 0 !== t) for (let e = 0, r = t.length; e < r; e++) {
				const r = new Wc().fromJSON(t[e], i);
				n[r.uuid] = r;
			}
			return n;
		}
		parseGeometries(t, e) {
			const n = {};
			if (void 0 !== t) {
				const i = new Ep();
				for (let r = 0, s = t.length; r < s; r++) {
					let s;
					const a = t[r];
					switch (a.type) {
						case "BufferGeometry":
						case "InstancedBufferGeometry":
							s = i.parse(a);
							break;
						default: a.type in md ? s = md[a.type].fromJSON(a, e) : console.warn(`THREE.ObjectLoader: Unsupported geometry type "${a.type}"`);
					}
					s.uuid = a.uuid, void 0 !== a.name && (s.name = a.name), void 0 !== a.userData && (s.userData = a.userData), n[a.uuid] = s;
				}
			}
			return n;
		}
		parseMaterials(t, e) {
			const n = {}, i = {};
			if (void 0 !== t) {
				const r = new bp();
				r.setTextures(e);
				for (let e = 0, s = t.length; e < s; e++) {
					const s = t[e];
					void 0 === n[s.uuid] && (n[s.uuid] = r.parse(s)), i[s.uuid] = n[s.uuid];
				}
			}
			return i;
		}
		parseAnimations(t) {
			const e = {};
			if (void 0 !== t) for (let n = 0; n < t.length; n++) {
				const i = t[n], r = Gd.parse(i);
				e[r.uuid] = r;
			}
			return e;
		}
		parseImages(t, e) {
			const n = this, i = {};
			let r;
			function s(t) {
				if ("string" == typeof t) {
					const e = t;
					return function(t) {
						return n.manager.itemStart(t), r.load(t, (function() {
							n.manager.itemEnd(t);
						}), void 0, (function() {
							n.manager.itemError(t), n.manager.itemEnd(t);
						}));
					}(/^(\/\/)|([a-z]+:(\/\/)?)/i.test(e) ? e : n.resourcePath + e);
				}
				return t.data ? {
					data: si(t.type, t.data),
					width: t.width,
					height: t.height
				} : null;
			}
			if (void 0 !== t && t.length > 0) {
				r = new tp(new jd(e)), r.setCrossOrigin(this.crossOrigin);
				for (let e = 0, n = t.length; e < n; e++) {
					const n = t[e], r = n.url;
					if (Array.isArray(r)) {
						const t = [];
						for (let e = 0, n = r.length; e < n; e++) {
							const n = s(r[e]);
							null !== n && (n instanceof HTMLImageElement ? t.push(n) : t.push(new Vc(n.data, n.width, n.height)));
						}
						i[n.uuid] = new yi(t);
					} else {
						const t = s(n.url);
						i[n.uuid] = new yi(t);
					}
				}
			}
			return i;
		}
		async parseImagesAsync(t) {
			const e = this, n = {};
			let i;
			async function r(t) {
				if ("string" == typeof t) {
					const n = t, r = /^(\/\/)|([a-z]+:(\/\/)?)/i.test(n) ? n : e.resourcePath + n;
					return await i.loadAsync(r);
				}
				return t.data ? {
					data: si(t.type, t.data),
					width: t.width,
					height: t.height
				} : null;
			}
			if (void 0 !== t && t.length > 0) {
				i = new tp(this.manager), i.setCrossOrigin(this.crossOrigin);
				for (let e = 0, i = t.length; e < i; e++) {
					const i = t[e], s = i.url;
					if (Array.isArray(s)) {
						const t = [];
						for (let e = 0, n = s.length; e < n; e++) {
							const n = s[e], i = await r(n);
							null !== i && (i instanceof HTMLImageElement ? t.push(i) : t.push(new Vc(i.data, i.width, i.height)));
						}
						n[i.uuid] = new yi(t);
					} else {
						const t = await r(i.url);
						n[i.uuid] = new yi(t);
					}
				}
			}
			return n;
		}
		parseTextures(t, e) {
			function n(t, e) {
				return "number" == typeof t ? t : (console.warn("THREE.ObjectLoader.parseTexture: Constant should be in numeric form.", t), e[t]);
			}
			const i = {};
			if (void 0 !== t) for (let r = 0, s = t.length; r < s; r++) {
				const s = t[r];
				void 0 === s.image && console.warn("THREE.ObjectLoader: No \"image\" specified for", s.uuid), void 0 === e[s.image] && console.warn("THREE.ObjectLoader: Undefined image", s.image);
				const a = e[s.image], o = a.data;
				let l;
				Array.isArray(o) ? (l = new na(), 6 === o.length && (l.needsUpdate = !0)) : (l = o && o.data ? new Vc() : new bi(), o && (l.needsUpdate = !0)), l.source = a, l.uuid = s.uuid, void 0 !== s.name && (l.name = s.name), void 0 !== s.mapping && (l.mapping = n(s.mapping, Rp)), void 0 !== s.channel && (l.channel = s.channel), void 0 !== s.offset && l.offset.fromArray(s.offset), void 0 !== s.repeat && l.repeat.fromArray(s.repeat), void 0 !== s.center && l.center.fromArray(s.center), void 0 !== s.rotation && (l.rotation = s.rotation), void 0 !== s.wrap && (l.wrapS = n(s.wrap[0], Cp), l.wrapT = n(s.wrap[1], Cp)), void 0 !== s.format && (l.format = s.format), void 0 !== s.internalFormat && (l.internalFormat = s.internalFormat), void 0 !== s.type && (l.type = s.type), void 0 !== s.colorSpace && (l.colorSpace = s.colorSpace), void 0 !== s.minFilter && (l.minFilter = n(s.minFilter, Pp)), void 0 !== s.magFilter && (l.magFilter = n(s.magFilter, Pp)), void 0 !== s.anisotropy && (l.anisotropy = s.anisotropy), void 0 !== s.flipY && (l.flipY = s.flipY), void 0 !== s.generateMipmaps && (l.generateMipmaps = s.generateMipmaps), void 0 !== s.premultiplyAlpha && (l.premultiplyAlpha = s.premultiplyAlpha), void 0 !== s.unpackAlignment && (l.unpackAlignment = s.unpackAlignment), void 0 !== s.compareFunction && (l.compareFunction = s.compareFunction), void 0 !== s.userData && (l.userData = s.userData), i[s.uuid] = l;
			}
			return i;
		}
		parseObject(t, e, n, i, r) {
			let s, a, o;
			function l(t) {
				return void 0 === e[t] && console.warn("THREE.ObjectLoader: Undefined geometry", t), e[t];
			}
			function c(t) {
				if (void 0 !== t) {
					if (Array.isArray(t)) {
						const e = [];
						for (let i = 0, r = t.length; i < r; i++) {
							const r = t[i];
							void 0 === n[r] && console.warn("THREE.ObjectLoader: Undefined material", r), e.push(n[r]);
						}
						return e;
					}
					return void 0 === n[t] && console.warn("THREE.ObjectLoader: Undefined material", t), n[t];
				}
			}
			function h(t) {
				return void 0 === i[t] && console.warn("THREE.ObjectLoader: Undefined texture", t), i[t];
			}
			switch (t.type) {
				case "Scene":
					s = new oc(), void 0 !== t.background && (Number.isInteger(t.background) ? s.background = new ts(t.background) : s.background = h(t.background)), void 0 !== t.environment && (s.environment = h(t.environment)), void 0 !== t.fog && ("Fog" === t.fog.type ? s.fog = new ac(t.fog.color, t.fog.near, t.fog.far) : "FogExp2" === t.fog.type && (s.fog = new sc(t.fog.color, t.fog.density)), "" !== t.fog.name && (s.fog.name = t.fog.name)), void 0 !== t.backgroundBlurriness && (s.backgroundBlurriness = t.backgroundBlurriness), void 0 !== t.backgroundIntensity && (s.backgroundIntensity = t.backgroundIntensity), void 0 !== t.backgroundRotation && s.backgroundRotation.fromArray(t.backgroundRotation), void 0 !== t.environmentIntensity && (s.environmentIntensity = t.environmentIntensity), void 0 !== t.environmentRotation && s.environmentRotation.fromArray(t.environmentRotation);
					break;
				case "PerspectiveCamera":
					s = new Qs(t.fov, t.aspect, t.near, t.far), void 0 !== t.focus && (s.focus = t.focus), void 0 !== t.zoom && (s.zoom = t.zoom), void 0 !== t.filmGauge && (s.filmGauge = t.filmGauge), void 0 !== t.filmOffset && (s.filmOffset = t.filmOffset), void 0 !== t.view && (s.view = Object.assign({}, t.view));
					break;
				case "OrthographicCamera":
					s = new Ea(t.left, t.right, t.top, t.bottom, t.near, t.far), void 0 !== t.zoom && (s.zoom = t.zoom), void 0 !== t.view && (s.view = Object.assign({}, t.view));
					break;
				case "AmbientLight":
					s = new xp(t.color, t.intensity);
					break;
				case "DirectionalLight":
					s = new _p(t.color, t.intensity), s.target = t.target || "";
					break;
				case "PointLight":
					s = new gp(t.color, t.intensity, t.distance, t.decay);
					break;
				case "RectAreaLight":
					s = new yp(t.color, t.intensity, t.width, t.height);
					break;
				case "SpotLight":
					s = new up(t.color, t.intensity, t.distance, t.angle, t.penumbra, t.decay), s.target = t.target || "";
					break;
				case "HemisphereLight":
					s = new sp(t.color, t.groundColor, t.intensity);
					break;
				case "LightProbe":
					s = new Sp().fromJSON(t);
					break;
				case "SkinnedMesh":
					a = l(t.geometry), o = c(t.material), s = new zc(a, o), void 0 !== t.bindMode && (s.bindMode = t.bindMode), void 0 !== t.bindMatrix && s.bindMatrix.fromArray(t.bindMatrix), void 0 !== t.skeleton && (s.skeleton = t.skeleton);
					break;
				case "Mesh":
					a = l(t.geometry), o = c(t.material), s = new Vs(a, o);
					break;
				case "InstancedMesh":
					a = l(t.geometry), o = c(t.material);
					const e = t.count, n = t.instanceMatrix, i = t.instanceColor;
					s = new Qc(a, o, e), s.instanceMatrix = new Xc(new Float32Array(n.array), 16), void 0 !== i && (s.instanceColor = new Xc(new Float32Array(i.array), i.itemSize));
					break;
				case "BatchedMesh":
					a = l(t.geometry), o = c(t.material), s = new _h(t.maxInstanceCount, t.maxVertexCount, t.maxIndexCount, o), s.geometry = a, s.perObjectFrustumCulled = t.perObjectFrustumCulled, s.sortObjects = t.sortObjects, s._drawRanges = t.drawRanges, s._reservedRanges = t.reservedRanges, s._visibility = t.visibility, s._active = t.active, s._bounds = t.bounds.map(((t) => {
						const e = new Di();
						e.min.fromArray(t.boxMin), e.max.fromArray(t.boxMax);
						const n = new Qi();
						return n.radius = t.sphereRadius, n.center.fromArray(t.sphereCenter), {
							boxInitialized: t.boxInitialized,
							box: e,
							sphereInitialized: t.sphereInitialized,
							sphere: n
						};
					})), s._maxInstanceCount = t.maxInstanceCount, s._maxVertexCount = t.maxVertexCount, s._maxIndexCount = t.maxIndexCount, s._geometryInitialized = t.geometryInitialized, s._geometryCount = t.geometryCount, s._matricesTexture = h(t.matricesTexture.uuid), void 0 !== t.colorsTexture && (s._colorsTexture = h(t.colorsTexture.uuid));
					break;
				case "LOD":
					s = new Cc();
					break;
				case "Line":
					s = new Ah(l(t.geometry), c(t.material));
					break;
				case "LineLoop":
					s = new Lh(l(t.geometry), c(t.material));
					break;
				case "LineSegments":
					s = new Ih(l(t.geometry), c(t.material));
					break;
				case "PointCloud":
				case "Points":
					s = new Bh(l(t.geometry), c(t.material));
					break;
				case "Sprite":
					s = new Tc(c(t.material));
					break;
				case "Group":
					s = new Zl();
					break;
				case "Bone":
					s = new kc();
					break;
				default: s = new Dr();
			}
			if (s.uuid = t.uuid, void 0 !== t.name && (s.name = t.name), void 0 !== t.matrix ? (s.matrix.fromArray(t.matrix), void 0 !== t.matrixAutoUpdate && (s.matrixAutoUpdate = t.matrixAutoUpdate), s.matrixAutoUpdate && s.matrix.decompose(s.position, s.quaternion, s.scale)) : (void 0 !== t.position && s.position.fromArray(t.position), void 0 !== t.rotation && s.rotation.fromArray(t.rotation), void 0 !== t.quaternion && s.quaternion.fromArray(t.quaternion), void 0 !== t.scale && s.scale.fromArray(t.scale)), void 0 !== t.up && s.up.fromArray(t.up), void 0 !== t.castShadow && (s.castShadow = t.castShadow), void 0 !== t.receiveShadow && (s.receiveShadow = t.receiveShadow), t.shadow && (void 0 !== t.shadow.intensity && (s.shadow.intensity = t.shadow.intensity), void 0 !== t.shadow.bias && (s.shadow.bias = t.shadow.bias), void 0 !== t.shadow.normalBias && (s.shadow.normalBias = t.shadow.normalBias), void 0 !== t.shadow.radius && (s.shadow.radius = t.shadow.radius), void 0 !== t.shadow.mapSize && s.shadow.mapSize.fromArray(t.shadow.mapSize), void 0 !== t.shadow.camera && (s.shadow.camera = this.parseObject(t.shadow.camera))), void 0 !== t.visible && (s.visible = t.visible), void 0 !== t.frustumCulled && (s.frustumCulled = t.frustumCulled), void 0 !== t.renderOrder && (s.renderOrder = t.renderOrder), void 0 !== t.userData && (s.userData = t.userData), void 0 !== t.layers && (s.layers.mask = t.layers), void 0 !== t.children) {
				const a = t.children;
				for (let t = 0; t < a.length; t++) s.add(this.parseObject(a[t], e, n, i, r));
			}
			if (void 0 !== t.animations) {
				const e = t.animations;
				for (let t = 0; t < e.length; t++) {
					const n = e[t];
					s.animations.push(r[n]);
				}
			}
			if ("LOD" === t.type) {
				void 0 !== t.autoUpdate && (s.autoUpdate = t.autoUpdate);
				const e = t.levels;
				for (let t = 0; t < e.length; t++) {
					const n = e[t], i = s.getObjectByProperty("uuid", n.object);
					void 0 !== i && s.addLevel(i, n.distance, n.hysteresis);
				}
			}
			return s;
		}
		bindSkeletons(t, e) {
			0 !== Object.keys(e).length && t.traverse((function(t) {
				if (!0 === t.isSkinnedMesh && void 0 !== t.skeleton) {
					const n = e[t.skeleton];
					void 0 === n ? console.warn("THREE.ObjectLoader: No skeleton found with UUID:", t.skeleton) : t.bind(n, t.bindMatrix);
				}
			}));
		}
		bindLightTargets(t) {
			t.traverse((function(e) {
				if (e.isDirectionalLight || e.isSpotLight) {
					const n = e.target, i = t.getObjectByProperty("uuid", n);
					e.target = void 0 !== i ? i : new Dr();
				}
			}));
		}
	};
	const Rp = {
		UVMapping: 300,
		CubeReflectionMapping: 301,
		CubeRefractionMapping: 302,
		EquirectangularReflectionMapping: 303,
		EquirectangularRefractionMapping: 304,
		CubeUVReflectionMapping: 306
	}, Cp = {
		RepeatWrapping: pt,
		ClampToEdgeWrapping: mt,
		MirroredRepeatWrapping: ft
	}, Pp = {
		NearestFilter: gt,
		NearestMipmapNearestFilter: vt,
		NearestMipmapLinearFilter: xt,
		LinearFilter: Mt,
		LinearMipmapNearestFilter: St,
		LinearMipmapLinearFilter: wt
	};
	var Ip = class extends Yd {
		constructor(t) {
			super(t), this.isImageBitmapLoader = !0, "undefined" == typeof createImageBitmap && console.warn("THREE.ImageBitmapLoader: createImageBitmap() not supported."), "undefined" == typeof fetch && console.warn("THREE.ImageBitmapLoader: fetch() not supported."), this.options = { premultiplyAlpha: "none" };
		}
		setOptions(t) {
			return this.options = t, this;
		}
		load(t, e, n, i) {
			void 0 === t && (t = ""), void 0 !== this.path && (t = this.path + t), t = this.manager.resolveURL(t);
			const r = this, s = Xd.get(t);
			if (void 0 !== s) return r.manager.itemStart(t), s.then ? void s.then(((n) => {
				e && e(n), r.manager.itemEnd(t);
			})).catch(((t) => {
				i && i(t);
			})) : (setTimeout((function() {
				e && e(s), r.manager.itemEnd(t);
			}), 0), s);
			const a = {};
			a.credentials = "anonymous" === this.crossOrigin ? "same-origin" : "include", a.headers = this.requestHeader;
			const o = fetch(t, a).then((function(t) {
				return t.blob();
			})).then((function(t) {
				return createImageBitmap(t, Object.assign(r.options, { colorSpaceConversion: "none" }));
			})).then((function(n) {
				return Xd.add(t, n), e && e(n), r.manager.itemEnd(t), n;
			})).catch((function(e) {
				i && i(e), Xd.remove(t), r.manager.itemError(t), r.manager.itemEnd(t);
			}));
			Xd.add(t, o), r.manager.itemStart(t);
		}
	};
	let Lp;
	var Up = class {
		static getContext() {
			return void 0 === Lp && (Lp = new (window.AudioContext || window.webkitAudioContext)()), Lp;
		}
		static setContext(t) {
			Lp = t;
		}
	};
	var Np = class extends Yd {
		constructor(t) {
			super(t);
		}
		load(t, e, n, i) {
			const r = this, s = new Kd(this.manager);
			function a(e) {
				i ? i(e) : console.error(e), r.manager.itemError(t);
			}
			s.setResponseType("arraybuffer"), s.setPath(this.path), s.setRequestHeader(this.requestHeader), s.setWithCredentials(this.withCredentials), s.load(t, (function(t) {
				try {
					const n = t.slice(0);
					Up.getContext().decodeAudioData(n, (function(t) {
						e(t);
					})).catch(a);
				} catch (t) {
					a(t);
				}
			}), n, i);
		}
	};
	const Dp = new lr(), Op = new lr(), Fp = new lr();
	var Bp = class {
		constructor() {
			this.type = "StereoCamera", this.aspect = 1, this.eyeSep = .064, this.cameraL = new Qs(), this.cameraL.layers.enable(1), this.cameraL.matrixAutoUpdate = !1, this.cameraR = new Qs(), this.cameraR.layers.enable(2), this.cameraR.matrixAutoUpdate = !1, this._cache = {
				focus: null,
				fov: null,
				aspect: null,
				near: null,
				far: null,
				zoom: null,
				eyeSep: null
			};
		}
		update(t) {
			const e = this._cache;
			if (e.focus !== t.focus || e.fov !== t.fov || e.aspect !== t.aspect * this.aspect || e.near !== t.near || e.far !== t.far || e.zoom !== t.zoom || e.eyeSep !== this.eyeSep) {
				e.focus = t.focus, e.fov = t.fov, e.aspect = t.aspect * this.aspect, e.near = t.near, e.far = t.far, e.zoom = t.zoom, e.eyeSep = this.eyeSep, Fp.copy(t.projectionMatrix);
				const n = e.eyeSep / 2, i = n * e.near / e.focus, r = e.near * Math.tan(Xn * e.fov * .5) / e.zoom;
				let s, a;
				Op.elements[12] = -n, Dp.elements[12] = n, s = -r * e.aspect + i, a = r * e.aspect + i, Fp.elements[0] = 2 * e.near / (a - s), Fp.elements[8] = (a + s) / (a - s), this.cameraL.projectionMatrix.copy(Fp), s = -r * e.aspect - i, a = r * e.aspect - i, Fp.elements[0] = 2 * e.near / (a - s), Fp.elements[8] = (a + s) / (a - s), this.cameraR.projectionMatrix.copy(Fp);
			}
			this.cameraL.matrixWorld.copy(t.matrixWorld).multiply(Op), this.cameraR.matrixWorld.copy(t.matrixWorld).multiply(Dp);
		}
	};
	var zp = class {
		constructor(t = !0) {
			this.autoStart = t, this.startTime = 0, this.oldTime = 0, this.elapsedTime = 0, this.running = !1;
		}
		start() {
			this.startTime = kp(), this.oldTime = this.startTime, this.elapsedTime = 0, this.running = !0;
		}
		stop() {
			this.getElapsedTime(), this.running = !1, this.autoStart = !1;
		}
		getElapsedTime() {
			return this.getDelta(), this.elapsedTime;
		}
		getDelta() {
			let t = 0;
			if (this.autoStart && !this.running) return this.start(), 0;
			if (this.running) {
				const e = kp();
				t = (e - this.oldTime) / 1e3, this.oldTime = e, this.elapsedTime += t;
			}
			return t;
		}
	};
	function kp() {
		return performance.now();
	}
	const Vp = new Li(), Hp = new Ii(), Gp = new Li(), Wp = new Li();
	var Xp = class extends Dr {
		constructor() {
			super(), this.type = "AudioListener", this.context = Up.getContext(), this.gain = this.context.createGain(), this.gain.connect(this.context.destination), this.filter = null, this.timeDelta = 0, this._clock = new zp();
		}
		getInput() {
			return this.gain;
		}
		removeFilter() {
			return null !== this.filter && (this.gain.disconnect(this.filter), this.filter.disconnect(this.context.destination), this.gain.connect(this.context.destination), this.filter = null), this;
		}
		getFilter() {
			return this.filter;
		}
		setFilter(t) {
			return null !== this.filter ? (this.gain.disconnect(this.filter), this.filter.disconnect(this.context.destination)) : this.gain.disconnect(this.context.destination), this.filter = t, this.gain.connect(this.filter), this.filter.connect(this.context.destination), this;
		}
		getMasterVolume() {
			return this.gain.gain.value;
		}
		setMasterVolume(t) {
			return this.gain.gain.setTargetAtTime(t, this.context.currentTime, .01), this;
		}
		updateMatrixWorld(t) {
			super.updateMatrixWorld(t);
			const e = this.context.listener, n = this.up;
			if (this.timeDelta = this._clock.getDelta(), this.matrixWorld.decompose(Vp, Hp, Gp), Wp.set(0, 0, -1).applyQuaternion(Hp), e.positionX) {
				const t = this.context.currentTime + this.timeDelta;
				e.positionX.linearRampToValueAtTime(Vp.x, t), e.positionY.linearRampToValueAtTime(Vp.y, t), e.positionZ.linearRampToValueAtTime(Vp.z, t), e.forwardX.linearRampToValueAtTime(Wp.x, t), e.forwardY.linearRampToValueAtTime(Wp.y, t), e.forwardZ.linearRampToValueAtTime(Wp.z, t), e.upX.linearRampToValueAtTime(n.x, t), e.upY.linearRampToValueAtTime(n.y, t), e.upZ.linearRampToValueAtTime(n.z, t);
			} else e.setPosition(Vp.x, Vp.y, Vp.z), e.setOrientation(Wp.x, Wp.y, Wp.z, n.x, n.y, n.z);
		}
	};
	var jp = class extends Dr {
		constructor(t) {
			super(), this.type = "Audio", this.listener = t, this.context = t.context, this.gain = this.context.createGain(), this.gain.connect(t.getInput()), this.autoplay = !1, this.buffer = null, this.detune = 0, this.loop = !1, this.loopStart = 0, this.loopEnd = 0, this.offset = 0, this.duration = void 0, this.playbackRate = 1, this.isPlaying = !1, this.hasPlaybackControl = !0, this.source = null, this.sourceType = "empty", this._startedAt = 0, this._progress = 0, this._connected = !1, this.filters = [];
		}
		getOutput() {
			return this.gain;
		}
		setNodeSource(t) {
			return this.hasPlaybackControl = !1, this.sourceType = "audioNode", this.source = t, this.connect(), this;
		}
		setMediaElementSource(t) {
			return this.hasPlaybackControl = !1, this.sourceType = "mediaNode", this.source = this.context.createMediaElementSource(t), this.connect(), this;
		}
		setMediaStreamSource(t) {
			return this.hasPlaybackControl = !1, this.sourceType = "mediaStreamNode", this.source = this.context.createMediaStreamSource(t), this.connect(), this;
		}
		setBuffer(t) {
			return this.buffer = t, this.sourceType = "buffer", this.autoplay && this.play(), this;
		}
		play(t = 0) {
			if (!0 === this.isPlaying) return void console.warn("THREE.Audio: Audio is already playing.");
			if (!1 === this.hasPlaybackControl) return void console.warn("THREE.Audio: this Audio has no playback control.");
			this._startedAt = this.context.currentTime + t;
			const e = this.context.createBufferSource();
			return e.buffer = this.buffer, e.loop = this.loop, e.loopStart = this.loopStart, e.loopEnd = this.loopEnd, e.onended = this.onEnded.bind(this), e.start(this._startedAt, this._progress + this.offset, this.duration), this.isPlaying = !0, this.source = e, this.setDetune(this.detune), this.setPlaybackRate(this.playbackRate), this.connect();
		}
		pause() {
			if (!1 !== this.hasPlaybackControl) return !0 === this.isPlaying && (this._progress += Math.max(this.context.currentTime - this._startedAt, 0) * this.playbackRate, !0 === this.loop && (this._progress = this._progress % (this.duration || this.buffer.duration)), this.source.stop(), this.source.onended = null, this.isPlaying = !1), this;
			console.warn("THREE.Audio: this Audio has no playback control.");
		}
		stop(t = 0) {
			if (!1 !== this.hasPlaybackControl) return this._progress = 0, null !== this.source && (this.source.stop(this.context.currentTime + t), this.source.onended = null), this.isPlaying = !1, this;
			console.warn("THREE.Audio: this Audio has no playback control.");
		}
		connect() {
			if (this.filters.length > 0) {
				this.source.connect(this.filters[0]);
				for (let t = 1, e = this.filters.length; t < e; t++) this.filters[t - 1].connect(this.filters[t]);
				this.filters[this.filters.length - 1].connect(this.getOutput());
			} else this.source.connect(this.getOutput());
			return this._connected = !0, this;
		}
		disconnect() {
			if (!1 !== this._connected) {
				if (this.filters.length > 0) {
					this.source.disconnect(this.filters[0]);
					for (let t = 1, e = this.filters.length; t < e; t++) this.filters[t - 1].disconnect(this.filters[t]);
					this.filters[this.filters.length - 1].disconnect(this.getOutput());
				} else this.source.disconnect(this.getOutput());
				return this._connected = !1, this;
			}
		}
		getFilters() {
			return this.filters;
		}
		setFilters(t) {
			return t || (t = []), !0 === this._connected ? (this.disconnect(), this.filters = t.slice(), this.connect()) : this.filters = t.slice(), this;
		}
		setDetune(t) {
			return this.detune = t, !0 === this.isPlaying && void 0 !== this.source.detune && this.source.detune.setTargetAtTime(this.detune, this.context.currentTime, .01), this;
		}
		getDetune() {
			return this.detune;
		}
		getFilter() {
			return this.getFilters()[0];
		}
		setFilter(t) {
			return this.setFilters(t ? [t] : []);
		}
		setPlaybackRate(t) {
			if (!1 !== this.hasPlaybackControl) return this.playbackRate = t, !0 === this.isPlaying && this.source.playbackRate.setTargetAtTime(this.playbackRate, this.context.currentTime, .01), this;
			console.warn("THREE.Audio: this Audio has no playback control.");
		}
		getPlaybackRate() {
			return this.playbackRate;
		}
		onEnded() {
			this.isPlaying = !1;
		}
		getLoop() {
			return !1 === this.hasPlaybackControl ? (console.warn("THREE.Audio: this Audio has no playback control."), !1) : this.loop;
		}
		setLoop(t) {
			if (!1 !== this.hasPlaybackControl) return this.loop = t, !0 === this.isPlaying && (this.source.loop = this.loop), this;
			console.warn("THREE.Audio: this Audio has no playback control.");
		}
		setLoopStart(t) {
			return this.loopStart = t, this;
		}
		setLoopEnd(t) {
			return this.loopEnd = t, this;
		}
		getVolume() {
			return this.gain.gain.value;
		}
		setVolume(t) {
			return this.gain.gain.setTargetAtTime(t, this.context.currentTime, .01), this;
		}
	};
	const qp = new Li(), Yp = new Ii(), Zp = new Li(), Jp = new Li();
	var Kp = class extends jp {
		constructor(t) {
			super(t), this.panner = this.context.createPanner(), this.panner.panningModel = "HRTF", this.panner.connect(this.gain);
		}
		connect() {
			super.connect(), this.panner.connect(this.gain);
		}
		disconnect() {
			super.disconnect(), this.panner.disconnect(this.gain);
		}
		getOutput() {
			return this.panner;
		}
		getRefDistance() {
			return this.panner.refDistance;
		}
		setRefDistance(t) {
			return this.panner.refDistance = t, this;
		}
		getRolloffFactor() {
			return this.panner.rolloffFactor;
		}
		setRolloffFactor(t) {
			return this.panner.rolloffFactor = t, this;
		}
		getDistanceModel() {
			return this.panner.distanceModel;
		}
		setDistanceModel(t) {
			return this.panner.distanceModel = t, this;
		}
		getMaxDistance() {
			return this.panner.maxDistance;
		}
		setMaxDistance(t) {
			return this.panner.maxDistance = t, this;
		}
		setDirectionalCone(t, e, n) {
			return this.panner.coneInnerAngle = t, this.panner.coneOuterAngle = e, this.panner.coneOuterGain = n, this;
		}
		updateMatrixWorld(t) {
			if (super.updateMatrixWorld(t), !0 === this.hasPlaybackControl && !1 === this.isPlaying) return;
			this.matrixWorld.decompose(qp, Yp, Zp), Jp.set(0, 0, 1).applyQuaternion(Yp);
			const e = this.panner;
			if (e.positionX) {
				const t = this.context.currentTime + this.listener.timeDelta;
				e.positionX.linearRampToValueAtTime(qp.x, t), e.positionY.linearRampToValueAtTime(qp.y, t), e.positionZ.linearRampToValueAtTime(qp.z, t), e.orientationX.linearRampToValueAtTime(Jp.x, t), e.orientationY.linearRampToValueAtTime(Jp.y, t), e.orientationZ.linearRampToValueAtTime(Jp.z, t);
			} else e.setPosition(qp.x, qp.y, qp.z), e.setOrientation(Jp.x, Jp.y, Jp.z);
		}
	};
	var $p = class {
		constructor(t, e = 2048) {
			this.analyser = t.context.createAnalyser(), this.analyser.fftSize = e, this.data = new Uint8Array(this.analyser.frequencyBinCount), t.getOutput().connect(this.analyser);
		}
		getFrequencyData() {
			return this.analyser.getByteFrequencyData(this.data), this.data;
		}
		getAverageFrequency() {
			let t = 0;
			const e = this.getFrequencyData();
			for (let n = 0; n < e.length; n++) t += e[n];
			return t / e.length;
		}
	};
	var Qp = class {
		constructor(t, e, n) {
			let i, r, s;
			switch (this.binding = t, this.valueSize = n, e) {
				case "quaternion":
					i = this._slerp, r = this._slerpAdditive, s = this._setAdditiveIdentityQuaternion, this.buffer = new Float64Array(6 * n), this._workIndex = 5;
					break;
				case "string":
				case "bool":
					i = this._select, r = this._select, s = this._setAdditiveIdentityOther, this.buffer = new Array(5 * n);
					break;
				default: i = this._lerp, r = this._lerpAdditive, s = this._setAdditiveIdentityNumeric, this.buffer = new Float64Array(5 * n);
			}
			this._mixBufferRegion = i, this._mixBufferRegionAdditive = r, this._setIdentity = s, this._origIndex = 3, this._addIndex = 4, this.cumulativeWeight = 0, this.cumulativeWeightAdditive = 0, this.useCount = 0, this.referenceCount = 0;
		}
		accumulate(t, e) {
			const n = this.buffer, i = this.valueSize, r = t * i + i;
			let s = this.cumulativeWeight;
			if (0 === s) {
				for (let t = 0; t !== i; ++t) n[r + t] = n[t];
				s = e;
			} else {
				s += e;
				const t = e / s;
				this._mixBufferRegion(n, r, 0, t, i);
			}
			this.cumulativeWeight = s;
		}
		accumulateAdditive(t) {
			const e = this.buffer, n = this.valueSize, i = n * this._addIndex;
			0 === this.cumulativeWeightAdditive && this._setIdentity(), this._mixBufferRegionAdditive(e, i, 0, t, n), this.cumulativeWeightAdditive += t;
		}
		apply(t) {
			const e = this.valueSize, n = this.buffer, i = t * e + e, r = this.cumulativeWeight, s = this.cumulativeWeightAdditive, a = this.binding;
			if (this.cumulativeWeight = 0, this.cumulativeWeightAdditive = 0, r < 1) {
				const t = e * this._origIndex;
				this._mixBufferRegion(n, i, t, 1 - r, e);
			}
			s > 0 && this._mixBufferRegionAdditive(n, i, this._addIndex * e, 1, e);
			for (let t = e, r = e + e; t !== r; ++t) if (n[t] !== n[t + e]) {
				a.setValue(n, i);
				break;
			}
		}
		saveOriginalState() {
			const t = this.binding, e = this.buffer, n = this.valueSize, i = n * this._origIndex;
			t.getValue(e, i);
			for (let t = n, r = i; t !== r; ++t) e[t] = e[i + t % n];
			this._setIdentity(), this.cumulativeWeight = 0, this.cumulativeWeightAdditive = 0;
		}
		restoreOriginalState() {
			const t = 3 * this.valueSize;
			this.binding.setValue(this.buffer, t);
		}
		_setAdditiveIdentityNumeric() {
			const t = this._addIndex * this.valueSize, e = t + this.valueSize;
			for (let n = t; n < e; n++) this.buffer[n] = 0;
		}
		_setAdditiveIdentityQuaternion() {
			this._setAdditiveIdentityNumeric(), this.buffer[this._addIndex * this.valueSize + 3] = 1;
		}
		_setAdditiveIdentityOther() {
			const t = this._origIndex * this.valueSize, e = this._addIndex * this.valueSize;
			for (let n = 0; n < this.valueSize; n++) this.buffer[e + n] = this.buffer[t + n];
		}
		_select(t, e, n, i, r) {
			if (i >= .5) for (let i = 0; i !== r; ++i) t[e + i] = t[n + i];
		}
		_slerp(t, e, n, i) {
			Ii.slerpFlat(t, e, t, e, t, n, i);
		}
		_slerpAdditive(t, e, n, i, r) {
			const s = this._workIndex * r;
			Ii.multiplyQuaternionsFlat(t, s, t, e, t, n), Ii.slerpFlat(t, e, t, e, t, s, i);
		}
		_lerp(t, e, n, i, r) {
			const s = 1 - i;
			for (let a = 0; a !== r; ++a) {
				const r = e + a;
				t[r] = t[r] * s + t[n + a] * i;
			}
		}
		_lerpAdditive(t, e, n, i, r) {
			for (let s = 0; s !== r; ++s) {
				const r = e + s;
				t[r] = t[r] + t[n + s] * i;
			}
		}
	};
	const tm = "\\[\\]\\.:\\/", em = new RegExp("[" + tm + "]", "g"), nm = "[^" + tm + "]", im = "[^" + tm.replace("\\.", "") + "]", rm = new RegExp("^" + /((?:WC+[\/:])*)/.source.replace("WC", nm) + /(WCOD+)?/.source.replace("WCOD", im) + /(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC", nm) + /\.(WC+)(?:\[(.+)\])?/.source.replace("WC", nm) + "$"), sm = [
		"material",
		"materials",
		"bones",
		"map"
	];
	var am = class am {
		constructor(t, e, n) {
			this.path = e, this.parsedPath = n || am.parseTrackName(e), this.node = am.findNode(t, this.parsedPath.nodeName), this.rootNode = t, this.getValue = this._getValue_unbound, this.setValue = this._setValue_unbound;
		}
		static create(t, e, n) {
			return t && t.isAnimationObjectGroup ? new am.Composite(t, e, n) : new am(t, e, n);
		}
		static sanitizeNodeName(t) {
			return t.replace(/\s/g, "_").replace(em, "");
		}
		static parseTrackName(t) {
			const e = rm.exec(t);
			if (null === e) throw new Error("PropertyBinding: Cannot parse trackName: " + t);
			const n = {
				nodeName: e[2],
				objectName: e[3],
				objectIndex: e[4],
				propertyName: e[5],
				propertyIndex: e[6]
			}, i = n.nodeName && n.nodeName.lastIndexOf(".");
			if (void 0 !== i && -1 !== i) {
				const t = n.nodeName.substring(i + 1);
				-1 !== sm.indexOf(t) && (n.nodeName = n.nodeName.substring(0, i), n.objectName = t);
			}
			if (null === n.propertyName || 0 === n.propertyName.length) throw new Error("PropertyBinding: can not parse propertyName from trackName: " + t);
			return n;
		}
		static findNode(t, e) {
			if (void 0 === e || "" === e || "." === e || -1 === e || e === t.name || e === t.uuid) return t;
			if (t.skeleton) {
				const n = t.skeleton.getBoneByName(e);
				if (void 0 !== n) return n;
			}
			if (t.children) {
				const n = function(t) {
					for (let i = 0; i < t.length; i++) {
						const r = t[i];
						if (r.name === e || r.uuid === e) return r;
						const s = n(r.children);
						if (s) return s;
					}
					return null;
				}, i = n(t.children);
				if (i) return i;
			}
			return null;
		}
		_getValue_unavailable() {}
		_setValue_unavailable() {}
		_getValue_direct(t, e) {
			t[e] = this.targetObject[this.propertyName];
		}
		_getValue_array(t, e) {
			const n = this.resolvedProperty;
			for (let i = 0, r = n.length; i !== r; ++i) t[e++] = n[i];
		}
		_getValue_arrayElement(t, e) {
			t[e] = this.resolvedProperty[this.propertyIndex];
		}
		_getValue_toArray(t, e) {
			this.resolvedProperty.toArray(t, e);
		}
		_setValue_direct(t, e) {
			this.targetObject[this.propertyName] = t[e];
		}
		_setValue_direct_setNeedsUpdate(t, e) {
			this.targetObject[this.propertyName] = t[e], this.targetObject.needsUpdate = !0;
		}
		_setValue_direct_setMatrixWorldNeedsUpdate(t, e) {
			this.targetObject[this.propertyName] = t[e], this.targetObject.matrixWorldNeedsUpdate = !0;
		}
		_setValue_array(t, e) {
			const n = this.resolvedProperty;
			for (let i = 0, r = n.length; i !== r; ++i) n[i] = t[e++];
		}
		_setValue_array_setNeedsUpdate(t, e) {
			const n = this.resolvedProperty;
			for (let i = 0, r = n.length; i !== r; ++i) n[i] = t[e++];
			this.targetObject.needsUpdate = !0;
		}
		_setValue_array_setMatrixWorldNeedsUpdate(t, e) {
			const n = this.resolvedProperty;
			for (let i = 0, r = n.length; i !== r; ++i) n[i] = t[e++];
			this.targetObject.matrixWorldNeedsUpdate = !0;
		}
		_setValue_arrayElement(t, e) {
			this.resolvedProperty[this.propertyIndex] = t[e];
		}
		_setValue_arrayElement_setNeedsUpdate(t, e) {
			this.resolvedProperty[this.propertyIndex] = t[e], this.targetObject.needsUpdate = !0;
		}
		_setValue_arrayElement_setMatrixWorldNeedsUpdate(t, e) {
			this.resolvedProperty[this.propertyIndex] = t[e], this.targetObject.matrixWorldNeedsUpdate = !0;
		}
		_setValue_fromArray(t, e) {
			this.resolvedProperty.fromArray(t, e);
		}
		_setValue_fromArray_setNeedsUpdate(t, e) {
			this.resolvedProperty.fromArray(t, e), this.targetObject.needsUpdate = !0;
		}
		_setValue_fromArray_setMatrixWorldNeedsUpdate(t, e) {
			this.resolvedProperty.fromArray(t, e), this.targetObject.matrixWorldNeedsUpdate = !0;
		}
		_getValue_unbound(t, e) {
			this.bind(), this.getValue(t, e);
		}
		_setValue_unbound(t, e) {
			this.bind(), this.setValue(t, e);
		}
		bind() {
			let t = this.node;
			const e = this.parsedPath, n = e.objectName, i = e.propertyName;
			let r = e.propertyIndex;
			if (t || (t = am.findNode(this.rootNode, e.nodeName), this.node = t), this.getValue = this._getValue_unavailable, this.setValue = this._setValue_unavailable, !t) return void console.warn("THREE.PropertyBinding: No target node found for track: " + this.path + ".");
			if (n) {
				let i = e.objectIndex;
				switch (n) {
					case "materials":
						if (!t.material) return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.", this);
						if (!t.material.materials) return void console.error("THREE.PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.", this);
						t = t.material.materials;
						break;
					case "bones":
						if (!t.skeleton) return void console.error("THREE.PropertyBinding: Can not bind to bones as node does not have a skeleton.", this);
						t = t.skeleton.bones;
						for (let e = 0; e < t.length; e++) if (t[e].name === i) {
							i = e;
							break;
						}
						break;
					case "map":
						if ("map" in t) {
							t = t.map;
							break;
						}
						if (!t.material) return void console.error("THREE.PropertyBinding: Can not bind to material as node does not have a material.", this);
						if (!t.material.map) return void console.error("THREE.PropertyBinding: Can not bind to material.map as node.material does not have a map.", this);
						t = t.material.map;
						break;
					default:
						if (void 0 === t[n]) return void console.error("THREE.PropertyBinding: Can not bind to objectName of node undefined.", this);
						t = t[n];
				}
				if (void 0 !== i) {
					if (void 0 === t[i]) return void console.error("THREE.PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.", this, t);
					t = t[i];
				}
			}
			const s = t[i];
			if (void 0 === s) {
				const n = e.nodeName;
				console.error("THREE.PropertyBinding: Trying to update property for track: " + n + "." + i + " but it wasn't found.", t);
				return;
			}
			let a = this.Versioning.None;
			this.targetObject = t, void 0 !== t.needsUpdate ? a = this.Versioning.NeedsUpdate : void 0 !== t.matrixWorldNeedsUpdate && (a = this.Versioning.MatrixWorldNeedsUpdate);
			let o = this.BindingType.Direct;
			if (void 0 !== r) {
				if ("morphTargetInfluences" === i) {
					if (!t.geometry) return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.", this);
					if (!t.geometry.morphAttributes) return void console.error("THREE.PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.", this);
					void 0 !== t.morphTargetDictionary[r] && (r = t.morphTargetDictionary[r]);
				}
				o = this.BindingType.ArrayElement, this.resolvedProperty = s, this.propertyIndex = r;
			} else void 0 !== s.fromArray && void 0 !== s.toArray ? (o = this.BindingType.HasFromToArray, this.resolvedProperty = s) : Array.isArray(s) ? (o = this.BindingType.EntireArray, this.resolvedProperty = s) : this.propertyName = i;
			this.getValue = this.GetterByBindingType[o], this.setValue = this.SetterByBindingTypeAndVersioning[o][a];
		}
		unbind() {
			this.node = null, this.getValue = this._getValue_unbound, this.setValue = this._setValue_unbound;
		}
	};
	am.Composite = class {
		constructor(t, e, n) {
			const i = n || am.parseTrackName(e);
			this._targetGroup = t, this._bindings = t.subscribe_(e, i);
		}
		getValue(t, e) {
			this.bind();
			const n = this._targetGroup.nCachedObjects_, i = this._bindings[n];
			void 0 !== i && i.getValue(t, e);
		}
		setValue(t, e) {
			const n = this._bindings;
			for (let i = this._targetGroup.nCachedObjects_, r = n.length; i !== r; ++i) n[i].setValue(t, e);
		}
		bind() {
			const t = this._bindings;
			for (let e = this._targetGroup.nCachedObjects_, n = t.length; e !== n; ++e) t[e].bind();
		}
		unbind() {
			const t = this._bindings;
			for (let e = this._targetGroup.nCachedObjects_, n = t.length; e !== n; ++e) t[e].unbind();
		}
	}, am.prototype.BindingType = {
		Direct: 0,
		EntireArray: 1,
		ArrayElement: 2,
		HasFromToArray: 3
	}, am.prototype.Versioning = {
		None: 0,
		NeedsUpdate: 1,
		MatrixWorldNeedsUpdate: 2
	}, am.prototype.GetterByBindingType = [
		am.prototype._getValue_direct,
		am.prototype._getValue_array,
		am.prototype._getValue_arrayElement,
		am.prototype._getValue_toArray
	], am.prototype.SetterByBindingTypeAndVersioning = [
		[
			am.prototype._setValue_direct,
			am.prototype._setValue_direct_setNeedsUpdate,
			am.prototype._setValue_direct_setMatrixWorldNeedsUpdate
		],
		[
			am.prototype._setValue_array,
			am.prototype._setValue_array_setNeedsUpdate,
			am.prototype._setValue_array_setMatrixWorldNeedsUpdate
		],
		[
			am.prototype._setValue_arrayElement,
			am.prototype._setValue_arrayElement_setNeedsUpdate,
			am.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate
		],
		[
			am.prototype._setValue_fromArray,
			am.prototype._setValue_fromArray_setNeedsUpdate,
			am.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate
		]
	];
	var om = class {
		constructor() {
			this.isAnimationObjectGroup = !0, this.uuid = qn(), this._objects = Array.prototype.slice.call(arguments), this.nCachedObjects_ = 0;
			const t = {};
			this._indicesByUUID = t;
			for (let e = 0, n = arguments.length; e !== n; ++e) t[arguments[e].uuid] = e;
			this._paths = [], this._parsedPaths = [], this._bindings = [], this._bindingsIndicesByPath = {};
			const e = this;
			this.stats = {
				objects: {
					get total() {
						return e._objects.length;
					},
					get inUse() {
						return this.total - e.nCachedObjects_;
					}
				},
				get bindingsPerObject() {
					return e._bindings.length;
				}
			};
		}
		add() {
			const t = this._objects, e = this._indicesByUUID, n = this._paths, i = this._parsedPaths, r = this._bindings, s = r.length;
			let a, o = t.length, l = this.nCachedObjects_;
			for (let c = 0, h = arguments.length; c !== h; ++c) {
				const h = arguments[c], u = h.uuid;
				let d = e[u];
				if (void 0 === d) {
					d = o++, e[u] = d, t.push(h);
					for (let t = 0, e = s; t !== e; ++t) r[t].push(new am(h, n[t], i[t]));
				} else if (d < l) {
					a = t[d];
					const o = --l, c = t[o];
					e[c.uuid] = d, t[d] = c, e[u] = o, t[o] = h;
					for (let t = 0, e = s; t !== e; ++t) {
						const e = r[t], s = e[o];
						let a = e[d];
						e[d] = s, void 0 === a && (a = new am(h, n[t], i[t])), e[o] = a;
					}
				} else t[d] !== a && console.error("THREE.AnimationObjectGroup: Different objects with the same UUID detected. Clean the caches or recreate your infrastructure when reloading scenes.");
			}
			this.nCachedObjects_ = l;
		}
		remove() {
			const t = this._objects, e = this._indicesByUUID, n = this._bindings, i = n.length;
			let r = this.nCachedObjects_;
			for (let s = 0, a = arguments.length; s !== a; ++s) {
				const a = arguments[s], o = a.uuid, l = e[o];
				if (void 0 !== l && l >= r) {
					const s = r++, c = t[s];
					e[c.uuid] = l, t[l] = c, e[o] = s, t[s] = a;
					for (let t = 0, e = i; t !== e; ++t) {
						const e = n[t], i = e[s], r = e[l];
						e[l] = i, e[s] = r;
					}
				}
			}
			this.nCachedObjects_ = r;
		}
		uncache() {
			const t = this._objects, e = this._indicesByUUID, n = this._bindings, i = n.length;
			let r = this.nCachedObjects_, s = t.length;
			for (let a = 0, o = arguments.length; a !== o; ++a) {
				const o = arguments[a].uuid, l = e[o];
				if (void 0 !== l) if (delete e[o], l < r) {
					const a = --r, o = t[a], c = --s, h = t[c];
					e[o.uuid] = l, t[l] = o, e[h.uuid] = a, t[a] = h, t.pop();
					for (let t = 0, e = i; t !== e; ++t) {
						const e = n[t], i = e[a], r = e[c];
						e[l] = i, e[a] = r, e.pop();
					}
				} else {
					const r = --s, a = t[r];
					r > 0 && (e[a.uuid] = l), t[l] = a, t.pop();
					for (let t = 0, e = i; t !== e; ++t) {
						const e = n[t];
						e[l] = e[r], e.pop();
					}
				}
			}
			this.nCachedObjects_ = r;
		}
		subscribe_(t, e) {
			const n = this._bindingsIndicesByPath;
			let i = n[t];
			const r = this._bindings;
			if (void 0 !== i) return r[i];
			const s = this._paths, a = this._parsedPaths, o = this._objects, l = o.length, c = this.nCachedObjects_, h = new Array(l);
			i = r.length, n[t] = i, s.push(t), a.push(e), r.push(h);
			for (let n = c, i = o.length; n !== i; ++n) {
				const i = o[n];
				h[n] = new am(i, t, e);
			}
			return h;
		}
		unsubscribe_(t) {
			const e = this._bindingsIndicesByPath, n = e[t];
			if (void 0 !== n) {
				const i = this._paths, r = this._parsedPaths, s = this._bindings, a = s.length - 1, o = s[a];
				e[t[a]] = n, s[n] = o, s.pop(), r[n] = r[a], r.pop(), i[n] = i[a], i.pop();
			}
		}
	};
	var lm = class {
		constructor(t, e, n = null, i = e.blendMode) {
			this._mixer = t, this._clip = e, this._localRoot = n, this.blendMode = i;
			const r = e.tracks, s = r.length, a = new Array(s), o = {
				endingStart: De,
				endingEnd: De
			};
			for (let t = 0; t !== s; ++t) {
				const e = r[t].createInterpolant(null);
				a[t] = e, e.settings = o;
			}
			this._interpolantSettings = o, this._interpolants = a, this._propertyBindings = new Array(s), this._cacheIndex = null, this._byClipCacheIndex = null, this._timeScaleInterpolant = null, this._weightInterpolant = null, this.loop = 2201, this._loopCount = -1, this._startTime = null, this.time = 0, this.timeScale = 1, this._effectiveTimeScale = 1, this.weight = 1, this._effectiveWeight = 1, this.repetitions = Infinity, this.paused = !1, this.enabled = !0, this.clampWhenFinished = !1, this.zeroSlopeAtStart = !0, this.zeroSlopeAtEnd = !0;
		}
		play() {
			return this._mixer._activateAction(this), this;
		}
		stop() {
			return this._mixer._deactivateAction(this), this.reset();
		}
		reset() {
			return this.paused = !1, this.enabled = !0, this.time = 0, this._loopCount = -1, this._startTime = null, this.stopFading().stopWarping();
		}
		isRunning() {
			return this.enabled && !this.paused && 0 !== this.timeScale && null === this._startTime && this._mixer._isActiveAction(this);
		}
		isScheduled() {
			return this._mixer._isActiveAction(this);
		}
		startAt(t) {
			return this._startTime = t, this;
		}
		setLoop(t, e) {
			return this.loop = t, this.repetitions = e, this;
		}
		setEffectiveWeight(t) {
			return this.weight = t, this._effectiveWeight = this.enabled ? t : 0, this.stopFading();
		}
		getEffectiveWeight() {
			return this._effectiveWeight;
		}
		fadeIn(t) {
			return this._scheduleFading(t, 0, 1);
		}
		fadeOut(t) {
			return this._scheduleFading(t, 1, 0);
		}
		crossFadeFrom(t, e, n) {
			if (t.fadeOut(e), this.fadeIn(e), n) {
				const n = this._clip.duration, i = t._clip.duration, r = i / n, s = n / i;
				t.warp(1, r, e), this.warp(s, 1, e);
			}
			return this;
		}
		crossFadeTo(t, e, n) {
			return t.crossFadeFrom(this, e, n);
		}
		stopFading() {
			const t = this._weightInterpolant;
			return null !== t && (this._weightInterpolant = null, this._mixer._takeBackControlInterpolant(t)), this;
		}
		setEffectiveTimeScale(t) {
			return this.timeScale = t, this._effectiveTimeScale = this.paused ? 0 : t, this.stopWarping();
		}
		getEffectiveTimeScale() {
			return this._effectiveTimeScale;
		}
		setDuration(t) {
			return this.timeScale = this._clip.duration / t, this.stopWarping();
		}
		syncWith(t) {
			return this.time = t.time, this.timeScale = t.timeScale, this.stopWarping();
		}
		halt(t) {
			return this.warp(this._effectiveTimeScale, 0, t);
		}
		warp(t, e, n) {
			const i = this._mixer, r = i.time, s = this.timeScale;
			let a = this._timeScaleInterpolant;
			null === a && (a = i._lendControlInterpolant(), this._timeScaleInterpolant = a);
			const o = a.parameterPositions, l = a.sampleValues;
			return o[0] = r, o[1] = r + n, l[0] = t / s, l[1] = e / s, this;
		}
		stopWarping() {
			const t = this._timeScaleInterpolant;
			return null !== t && (this._timeScaleInterpolant = null, this._mixer._takeBackControlInterpolant(t)), this;
		}
		getMixer() {
			return this._mixer;
		}
		getClip() {
			return this._clip;
		}
		getRoot() {
			return this._localRoot || this._mixer._root;
		}
		_update(t, e, n, i) {
			if (!this.enabled) return void this._updateWeight(t);
			const r = this._startTime;
			if (null !== r) {
				const i = (t - r) * n;
				i < 0 || 0 === n ? e = 0 : (this._startTime = null, e = n * i);
			}
			e *= this._updateTimeScale(t);
			const s = this._updateTime(e), a = this._updateWeight(t);
			if (a > 0) {
				const t = this._interpolants, e = this._propertyBindings;
				if (this.blendMode === 2501) for (let n = 0, i = t.length; n !== i; ++n) t[n].evaluate(s), e[n].accumulateAdditive(a);
				else for (let n = 0, r = t.length; n !== r; ++n) t[n].evaluate(s), e[n].accumulate(i, a);
			}
		}
		_updateWeight(t) {
			let e = 0;
			if (this.enabled) {
				e = this.weight;
				const n = this._weightInterpolant;
				if (null !== n) {
					const i = n.evaluate(t)[0];
					e *= i, t > n.parameterPositions[1] && (this.stopFading(), 0 === i && (this.enabled = !1));
				}
			}
			return this._effectiveWeight = e, e;
		}
		_updateTimeScale(t) {
			let e = 0;
			if (!this.paused) {
				e = this.timeScale;
				const n = this._timeScaleInterpolant;
				if (null !== n) e *= n.evaluate(t)[0], t > n.parameterPositions[1] && (this.stopWarping(), 0 === e ? this.paused = !0 : this.timeScale = e);
			}
			return this._effectiveTimeScale = e, e;
		}
		_updateTime(t) {
			const e = this._clip.duration, n = this.loop;
			let i = this.time + t, r = this._loopCount;
			const s = 2202 === n;
			if (0 === t) return -1 === r ? i : s && 1 == (1 & r) ? e - i : i;
			if (2200 === n) {
				-1 === r && (this._loopCount = 0, this._setEndings(!0, !0, !1));
				t: {
					if (i >= e) i = e;
					else {
						if (!(i < 0)) {
							this.time = i;
							break t;
						}
						i = 0;
					}
					this.clampWhenFinished ? this.paused = !0 : this.enabled = !1, this.time = i, this._mixer.dispatchEvent({
						type: "finished",
						action: this,
						direction: t < 0 ? -1 : 1
					});
				}
			} else {
				if (-1 === r && (t >= 0 ? (r = 0, this._setEndings(!0, 0 === this.repetitions, s)) : this._setEndings(0 === this.repetitions, !0, s)), i >= e || i < 0) {
					const n = Math.floor(i / e);
					i -= e * n, r += Math.abs(n);
					const a = this.repetitions - r;
					if (a <= 0) this.clampWhenFinished ? this.paused = !0 : this.enabled = !1, i = t > 0 ? e : 0, this.time = i, this._mixer.dispatchEvent({
						type: "finished",
						action: this,
						direction: t > 0 ? 1 : -1
					});
					else {
						if (1 === a) {
							const e = t < 0;
							this._setEndings(e, !e, s);
						} else this._setEndings(!1, !1, s);
						this._loopCount = r, this.time = i, this._mixer.dispatchEvent({
							type: "loop",
							action: this,
							loopDelta: n
						});
					}
				} else this.time = i;
				if (s && 1 == (1 & r)) return e - i;
			}
			return i;
		}
		_setEndings(t, e, n) {
			const i = this._interpolantSettings;
			n ? (i.endingStart = Oe, i.endingEnd = Oe) : (i.endingStart = t ? this.zeroSlopeAtStart ? Oe : De : Fe, i.endingEnd = e ? this.zeroSlopeAtEnd ? Oe : De : Fe);
		}
		_scheduleFading(t, e, n) {
			const i = this._mixer, r = i.time;
			let s = this._weightInterpolant;
			null === s && (s = i._lendControlInterpolant(), this._weightInterpolant = s);
			const a = s.parameterPositions, o = s.sampleValues;
			return a[0] = r, o[0] = e, a[1] = r + t, o[1] = n, this;
		}
	};
	const cm = new Float32Array(1);
	var hm = class extends Hn {
		constructor(t) {
			super(), this._root = t, this._initMemoryManager(), this._accuIndex = 0, this.time = 0, this.timeScale = 1;
		}
		_bindAction(t, e) {
			const n = t._localRoot || this._root, i = t._clip.tracks, r = i.length, s = t._propertyBindings, a = t._interpolants, o = n.uuid, l = this._bindingsByRootAndName;
			let c = l[o];
			void 0 === c && (c = {}, l[o] = c);
			for (let t = 0; t !== r; ++t) {
				const r = i[t], l = r.name;
				let h = c[l];
				if (void 0 !== h) ++h.referenceCount, s[t] = h;
				else {
					if (h = s[t], void 0 !== h) {
						null === h._cacheIndex && (++h.referenceCount, this._addInactiveBinding(h, o, l));
						continue;
					}
					const i = e && e._propertyBindings[t].binding.parsedPath;
					h = new Qp(am.create(n, l, i), r.ValueTypeName, r.getValueSize()), ++h.referenceCount, this._addInactiveBinding(h, o, l), s[t] = h;
				}
				a[t].resultBuffer = h.buffer;
			}
		}
		_activateAction(t) {
			if (!this._isActiveAction(t)) {
				if (null === t._cacheIndex) {
					const e = (t._localRoot || this._root).uuid, n = t._clip.uuid, i = this._actionsByClip[n];
					this._bindAction(t, i && i.knownActions[0]), this._addInactiveAction(t, n, e);
				}
				const e = t._propertyBindings;
				for (let t = 0, n = e.length; t !== n; ++t) {
					const n = e[t];
					0 == n.useCount++ && (this._lendBinding(n), n.saveOriginalState());
				}
				this._lendAction(t);
			}
		}
		_deactivateAction(t) {
			if (this._isActiveAction(t)) {
				const e = t._propertyBindings;
				for (let t = 0, n = e.length; t !== n; ++t) {
					const n = e[t];
					0 == --n.useCount && (n.restoreOriginalState(), this._takeBackBinding(n));
				}
				this._takeBackAction(t);
			}
		}
		_initMemoryManager() {
			this._actions = [], this._nActiveActions = 0, this._actionsByClip = {}, this._bindings = [], this._nActiveBindings = 0, this._bindingsByRootAndName = {}, this._controlInterpolants = [], this._nActiveControlInterpolants = 0;
			const t = this;
			this.stats = {
				actions: {
					get total() {
						return t._actions.length;
					},
					get inUse() {
						return t._nActiveActions;
					}
				},
				bindings: {
					get total() {
						return t._bindings.length;
					},
					get inUse() {
						return t._nActiveBindings;
					}
				},
				controlInterpolants: {
					get total() {
						return t._controlInterpolants.length;
					},
					get inUse() {
						return t._nActiveControlInterpolants;
					}
				}
			};
		}
		_isActiveAction(t) {
			const e = t._cacheIndex;
			return null !== e && e < this._nActiveActions;
		}
		_addInactiveAction(t, e, n) {
			const i = this._actions, r = this._actionsByClip;
			let s = r[e];
			if (void 0 === s) s = {
				knownActions: [t],
				actionByRoot: {}
			}, t._byClipCacheIndex = 0, r[e] = s;
			else {
				const e = s.knownActions;
				t._byClipCacheIndex = e.length, e.push(t);
			}
			t._cacheIndex = i.length, i.push(t), s.actionByRoot[n] = t;
		}
		_removeInactiveAction(t) {
			const e = this._actions, n = e[e.length - 1], i = t._cacheIndex;
			n._cacheIndex = i, e[i] = n, e.pop(), t._cacheIndex = null;
			const r = t._clip.uuid, s = this._actionsByClip, a = s[r], o = a.knownActions, l = o[o.length - 1], c = t._byClipCacheIndex;
			l._byClipCacheIndex = c, o[c] = l, o.pop(), t._byClipCacheIndex = null;
			delete a.actionByRoot[(t._localRoot || this._root).uuid], 0 === o.length && delete s[r], this._removeInactiveBindingsForAction(t);
		}
		_removeInactiveBindingsForAction(t) {
			const e = t._propertyBindings;
			for (let t = 0, n = e.length; t !== n; ++t) {
				const n = e[t];
				0 == --n.referenceCount && this._removeInactiveBinding(n);
			}
		}
		_lendAction(t) {
			const e = this._actions, n = t._cacheIndex, i = this._nActiveActions++, r = e[i];
			t._cacheIndex = i, e[i] = t, r._cacheIndex = n, e[n] = r;
		}
		_takeBackAction(t) {
			const e = this._actions, n = t._cacheIndex, i = --this._nActiveActions, r = e[i];
			t._cacheIndex = i, e[i] = t, r._cacheIndex = n, e[n] = r;
		}
		_addInactiveBinding(t, e, n) {
			const i = this._bindingsByRootAndName, r = this._bindings;
			let s = i[e];
			void 0 === s && (s = {}, i[e] = s), s[n] = t, t._cacheIndex = r.length, r.push(t);
		}
		_removeInactiveBinding(t) {
			const e = this._bindings, n = t.binding, i = n.rootNode.uuid, r = n.path, s = this._bindingsByRootAndName, a = s[i], o = e[e.length - 1], l = t._cacheIndex;
			o._cacheIndex = l, e[l] = o, e.pop(), delete a[r], 0 === Object.keys(a).length && delete s[i];
		}
		_lendBinding(t) {
			const e = this._bindings, n = t._cacheIndex, i = this._nActiveBindings++, r = e[i];
			t._cacheIndex = i, e[i] = t, r._cacheIndex = n, e[n] = r;
		}
		_takeBackBinding(t) {
			const e = this._bindings, n = t._cacheIndex, i = --this._nActiveBindings, r = e[i];
			t._cacheIndex = i, e[i] = t, r._cacheIndex = n, e[n] = r;
		}
		_lendControlInterpolant() {
			const t = this._controlInterpolants, e = this._nActiveControlInterpolants++;
			let n = t[e];
			return void 0 === n && (n = new Ud(new Float32Array(2), new Float32Array(2), 1, cm), n.__cacheIndex = e, t[e] = n), n;
		}
		_takeBackControlInterpolant(t) {
			const e = this._controlInterpolants, n = t.__cacheIndex, i = --this._nActiveControlInterpolants, r = e[i];
			t.__cacheIndex = i, e[i] = t, r.__cacheIndex = n, e[n] = r;
		}
		clipAction(t, e, n) {
			const i = e || this._root, r = i.uuid;
			let s = "string" == typeof t ? Gd.findByName(i, t) : t;
			const a = null !== s ? s.uuid : t, o = this._actionsByClip[a];
			let l = null;
			if (void 0 === n && (n = null !== s ? s.blendMode : 2500), void 0 !== o) {
				const t = o.actionByRoot[r];
				if (void 0 !== t && t.blendMode === n) return t;
				l = o.knownActions[0], null === s && (s = l._clip);
			}
			if (null === s) return null;
			const c = new lm(this, s, e, n);
			return this._bindAction(c, l), this._addInactiveAction(c, a, r), c;
		}
		existingAction(t, e) {
			const n = e || this._root, i = n.uuid, r = "string" == typeof t ? Gd.findByName(n, t) : t, s = r ? r.uuid : t, a = this._actionsByClip[s];
			return void 0 !== a && a.actionByRoot[i] || null;
		}
		stopAllAction() {
			const t = this._actions;
			for (let e = this._nActiveActions - 1; e >= 0; --e) t[e].stop();
			return this;
		}
		update(t) {
			t *= this.timeScale;
			const e = this._actions, n = this._nActiveActions, i = this.time += t, r = Math.sign(t), s = this._accuIndex ^= 1;
			for (let a = 0; a !== n; ++a) e[a]._update(i, t, r, s);
			const a = this._bindings, o = this._nActiveBindings;
			for (let t = 0; t !== o; ++t) a[t].apply(s);
			return this;
		}
		setTime(t) {
			this.time = 0;
			for (let t = 0; t < this._actions.length; t++) this._actions[t].time = 0;
			return this.update(t);
		}
		getRoot() {
			return this._root;
		}
		uncacheClip(t) {
			const e = this._actions, n = t.uuid, i = this._actionsByClip, r = i[n];
			if (void 0 !== r) {
				const t = r.knownActions;
				for (let n = 0, i = t.length; n !== i; ++n) {
					const i = t[n];
					this._deactivateAction(i);
					const r = i._cacheIndex, s = e[e.length - 1];
					i._cacheIndex = null, i._byClipCacheIndex = null, s._cacheIndex = r, e[r] = s, e.pop(), this._removeInactiveBindingsForAction(i);
				}
				delete i[n];
			}
		}
		uncacheRoot(t) {
			const e = t.uuid, n = this._actionsByClip;
			for (const t in n) {
				const i = n[t].actionByRoot[e];
				void 0 !== i && (this._deactivateAction(i), this._removeInactiveAction(i));
			}
			const i = this._bindingsByRootAndName[e];
			if (void 0 !== i) for (const t in i) {
				const e = i[t];
				e.restoreOriginalState(), this._removeInactiveBinding(e);
			}
		}
		uncacheAction(t, e) {
			const n = this.existingAction(t, e);
			null !== n && (this._deactivateAction(n), this._removeInactiveAction(n));
		}
	};
	var um = class um {
		constructor(t) {
			this.value = t;
		}
		clone() {
			return new um(void 0 === this.value.clone ? this.value : this.value.clone());
		}
	};
	let dm = 0;
	var pm = class extends Hn {
		constructor() {
			super(), this.isUniformsGroup = !0, Object.defineProperty(this, "id", { value: dm++ }), this.name = "", this.usage = Cn, this.uniforms = [];
		}
		add(t) {
			return this.uniforms.push(t), this;
		}
		remove(t) {
			const e = this.uniforms.indexOf(t);
			return -1 !== e && this.uniforms.splice(e, 1), this;
		}
		setName(t) {
			return this.name = t, this;
		}
		setUsage(t) {
			return this.usage = t, this;
		}
		dispose() {
			return this.dispatchEvent({ type: "dispose" }), this;
		}
		copy(t) {
			this.name = t.name, this.usage = t.usage;
			const e = t.uniforms;
			this.uniforms.length = 0;
			for (let t = 0, n = e.length; t < n; t++) {
				const n = Array.isArray(e[t]) ? e[t] : [e[t]];
				for (let t = 0; t < n.length; t++) this.uniforms.push(n[t].clone());
			}
			return this;
		}
		clone() {
			return new this.constructor().copy(this);
		}
	};
	var mm = class extends lc {
		constructor(t, e, n = 1) {
			super(t, e), this.isInstancedInterleavedBuffer = !0, this.meshPerAttribute = n;
		}
		copy(t) {
			return super.copy(t), this.meshPerAttribute = t.meshPerAttribute, this;
		}
		clone(t) {
			const e = super.clone(t);
			return e.meshPerAttribute = this.meshPerAttribute, e;
		}
		toJSON(t) {
			const e = super.toJSON(t);
			return e.isInstancedInterleavedBuffer = !0, e.meshPerAttribute = this.meshPerAttribute, e;
		}
	};
	var fm = class {
		constructor(t, e, n, i, r) {
			this.isGLBufferAttribute = !0, this.name = "", this.buffer = t, this.type = e, this.itemSize = n, this.elementSize = i, this.count = r, this.version = 0;
		}
		set needsUpdate(t) {
			!0 === t && this.version++;
		}
		setBuffer(t) {
			return this.buffer = t, this;
		}
		setType(t, e) {
			return this.type = t, this.elementSize = e, this;
		}
		setItemSize(t) {
			return this.itemSize = t, this;
		}
		setCount(t) {
			return this.count = t, this;
		}
	};
	const gm = new lr();
	var vm = class {
		constructor(t, e, n = 0, i = Infinity) {
			this.ray = new or(t, e), this.near = n, this.far = i, this.camera = null, this.layers = new xr(), this.params = {
				Mesh: {},
				Line: { threshold: 1 },
				LOD: {},
				Points: { threshold: 1 },
				Sprite: {}
			};
		}
		set(t, e) {
			this.ray.set(t, e);
		}
		setFromCamera(t, e) {
			e.isPerspectiveCamera ? (this.ray.origin.setFromMatrixPosition(e.matrixWorld), this.ray.direction.set(t.x, t.y, .5).unproject(e).sub(this.ray.origin).normalize(), this.camera = e) : e.isOrthographicCamera ? (this.ray.origin.set(t.x, t.y, (e.near + e.far) / (e.near - e.far)).unproject(e), this.ray.direction.set(0, 0, -1).transformDirection(e.matrixWorld), this.camera = e) : console.error("THREE.Raycaster: Unsupported camera type: " + e.type);
		}
		setFromXRController(t) {
			return gm.identity().extractRotation(t.matrixWorld), this.ray.origin.setFromMatrixPosition(t.matrixWorld), this.ray.direction.set(0, 0, -1).applyMatrix4(gm), this;
		}
		intersectObject(t, e = !0, n = []) {
			return xm(t, this, n, e), n.sort(_m), n;
		}
		intersectObjects(t, e = !0, n = []) {
			for (let i = 0, r = t.length; i < r; i++) xm(t[i], this, n, e);
			return n.sort(_m), n;
		}
	};
	function _m(t, e) {
		return t.distance - e.distance;
	}
	function xm(t, e, n, i) {
		let r = !0;
		if (t.layers.test(e.layers)) !1 === t.raycast(e, n) && (r = !1);
		if (!0 === r && !0 === i) {
			const i = t.children;
			for (let t = 0, r = i.length; t < r; t++) xm(i[t], e, n, !0);
		}
	}
	var ym = class {
		constructor(t = 1, e = 0, n = 0) {
			return this.radius = t, this.phi = e, this.theta = n, this;
		}
		set(t, e, n) {
			return this.radius = t, this.phi = e, this.theta = n, this;
		}
		copy(t) {
			return this.radius = t.radius, this.phi = t.phi, this.theta = t.theta, this;
		}
		makeSafe() {
			const t = 1e-6;
			return this.phi = Math.max(t, Math.min(Math.PI - t, this.phi)), this;
		}
		setFromVector3(t) {
			return this.setFromCartesianCoords(t.x, t.y, t.z);
		}
		setFromCartesianCoords(t, e, n) {
			return this.radius = Math.sqrt(t * t + e * e + n * n), 0 === this.radius ? (this.theta = 0, this.phi = 0) : (this.theta = Math.atan2(t, n), this.phi = Math.acos(Yn(e / this.radius, -1, 1))), this;
		}
		clone() {
			return new this.constructor().copy(this);
		}
	};
	var Mm = class {
		constructor(t = 1, e = 0, n = 0) {
			return this.radius = t, this.theta = e, this.y = n, this;
		}
		set(t, e, n) {
			return this.radius = t, this.theta = e, this.y = n, this;
		}
		copy(t) {
			return this.radius = t.radius, this.theta = t.theta, this.y = t.y, this;
		}
		setFromVector3(t) {
			return this.setFromCartesianCoords(t.x, t.y, t.z);
		}
		setFromCartesianCoords(t, e, n) {
			return this.radius = Math.sqrt(t * t + n * n), this.theta = Math.atan2(t, n), this.y = e, this;
		}
		clone() {
			return new this.constructor().copy(this);
		}
	};
	var Sm = class Sm {
		constructor(t, e, n, i) {
			Sm.prototype.isMatrix2 = !0, this.elements = [
				1,
				0,
				0,
				1
			], void 0 !== t && this.set(t, e, n, i);
		}
		identity() {
			return this.set(1, 0, 0, 1), this;
		}
		fromArray(t, e = 0) {
			for (let n = 0; n < 4; n++) this.elements[n] = t[n + e];
			return this;
		}
		set(t, e, n, i) {
			const r = this.elements;
			return r[0] = t, r[2] = e, r[1] = n, r[3] = i, this;
		}
	};
	const bm = new ti();
	var wm = class {
		constructor(t = new ti(Infinity, Infinity), e = new ti(-Infinity, -Infinity)) {
			this.isBox2 = !0, this.min = t, this.max = e;
		}
		set(t, e) {
			return this.min.copy(t), this.max.copy(e), this;
		}
		setFromPoints(t) {
			this.makeEmpty();
			for (let e = 0, n = t.length; e < n; e++) this.expandByPoint(t[e]);
			return this;
		}
		setFromCenterAndSize(t, e) {
			const n = bm.copy(e).multiplyScalar(.5);
			return this.min.copy(t).sub(n), this.max.copy(t).add(n), this;
		}
		clone() {
			return new this.constructor().copy(this);
		}
		copy(t) {
			return this.min.copy(t.min), this.max.copy(t.max), this;
		}
		makeEmpty() {
			return this.min.x = this.min.y = Infinity, this.max.x = this.max.y = -Infinity, this;
		}
		isEmpty() {
			return this.max.x < this.min.x || this.max.y < this.min.y;
		}
		getCenter(t) {
			return this.isEmpty() ? t.set(0, 0) : t.addVectors(this.min, this.max).multiplyScalar(.5);
		}
		getSize(t) {
			return this.isEmpty() ? t.set(0, 0) : t.subVectors(this.max, this.min);
		}
		expandByPoint(t) {
			return this.min.min(t), this.max.max(t), this;
		}
		expandByVector(t) {
			return this.min.sub(t), this.max.add(t), this;
		}
		expandByScalar(t) {
			return this.min.addScalar(-t), this.max.addScalar(t), this;
		}
		containsPoint(t) {
			return t.x >= this.min.x && t.x <= this.max.x && t.y >= this.min.y && t.y <= this.max.y;
		}
		containsBox(t) {
			return this.min.x <= t.min.x && t.max.x <= this.max.x && this.min.y <= t.min.y && t.max.y <= this.max.y;
		}
		getParameter(t, e) {
			return e.set((t.x - this.min.x) / (this.max.x - this.min.x), (t.y - this.min.y) / (this.max.y - this.min.y));
		}
		intersectsBox(t) {
			return t.max.x >= this.min.x && t.min.x <= this.max.x && t.max.y >= this.min.y && t.min.y <= this.max.y;
		}
		clampPoint(t, e) {
			return e.copy(t).clamp(this.min, this.max);
		}
		distanceToPoint(t) {
			return this.clampPoint(t, bm).distanceTo(t);
		}
		intersect(t) {
			return this.min.max(t.min), this.max.min(t.max), this.isEmpty() && this.makeEmpty(), this;
		}
		union(t) {
			return this.min.min(t.min), this.max.max(t.max), this;
		}
		translate(t) {
			return this.min.add(t), this.max.add(t), this;
		}
		equals(t) {
			return t.min.equals(this.min) && t.max.equals(this.max);
		}
	};
	const Tm = new Li(), Em = new Li();
	var Am = class {
		constructor(t = new Li(), e = new Li()) {
			this.start = t, this.end = e;
		}
		set(t, e) {
			return this.start.copy(t), this.end.copy(e), this;
		}
		copy(t) {
			return this.start.copy(t.start), this.end.copy(t.end), this;
		}
		getCenter(t) {
			return t.addVectors(this.start, this.end).multiplyScalar(.5);
		}
		delta(t) {
			return t.subVectors(this.end, this.start);
		}
		distanceSq() {
			return this.start.distanceToSquared(this.end);
		}
		distance() {
			return this.start.distanceTo(this.end);
		}
		at(t, e) {
			return this.delta(e).multiplyScalar(t).add(this.start);
		}
		closestPointToPointParameter(t, e) {
			Tm.subVectors(t, this.start), Em.subVectors(this.end, this.start);
			const n = Em.dot(Em);
			let i = Em.dot(Tm) / n;
			return e && (i = Yn(i, 0, 1)), i;
		}
		closestPointToPoint(t, e, n) {
			const i = this.closestPointToPointParameter(t, e);
			return this.delta(n).multiplyScalar(i).add(this.start);
		}
		applyMatrix4(t) {
			return this.start.applyMatrix4(t), this.end.applyMatrix4(t), this;
		}
		equals(t) {
			return t.start.equals(this.start) && t.end.equals(this.end);
		}
		clone() {
			return new this.constructor().copy(this);
		}
	};
	const Rm = new Li();
	var Cm = class extends Dr {
		constructor(t, e) {
			super(), this.light = t, this.matrixAutoUpdate = !1, this.color = e, this.type = "SpotLightHelper";
			const n = new Cs(), i = [
				0,
				0,
				0,
				0,
				0,
				1,
				0,
				0,
				0,
				1,
				0,
				1,
				0,
				0,
				0,
				-1,
				0,
				1,
				0,
				0,
				0,
				0,
				1,
				1,
				0,
				0,
				0,
				0,
				-1,
				1
			];
			for (let t = 0, e = 1, n = 32; t < n; t++, e++) {
				const r = t / n * Math.PI * 2, s = e / n * Math.PI * 2;
				i.push(Math.cos(r), Math.sin(r), 1, Math.cos(s), Math.sin(s), 1);
			}
			n.setAttribute("position", new Ms(i, 3));
			const r = new xh({
				fog: !1,
				toneMapped: !1
			});
			this.cone = new Ih(n, r), this.add(this.cone), this.update();
		}
		dispose() {
			this.cone.geometry.dispose(), this.cone.material.dispose();
		}
		update() {
			this.light.updateWorldMatrix(!0, !1), this.light.target.updateWorldMatrix(!0, !1), this.parent ? (this.parent.updateWorldMatrix(!0), this.matrix.copy(this.parent.matrixWorld).invert().multiply(this.light.matrixWorld)) : this.matrix.copy(this.light.matrixWorld), this.matrixWorld.copy(this.light.matrixWorld);
			const t = this.light.distance ? this.light.distance : 1e3, e = t * Math.tan(this.light.angle);
			this.cone.scale.set(e, e, t), Rm.setFromMatrixPosition(this.light.target.matrixWorld), this.cone.lookAt(Rm), void 0 !== this.color ? this.cone.material.color.set(this.color) : this.cone.material.color.copy(this.light.color);
		}
	};
	const Pm = new Li(), Im = new lr(), Lm = new lr();
	var Um = class extends Ih {
		constructor(t) {
			const e = Nm(t), n = new Cs(), i = [], r = [], s = new ts(0, 0, 1), a = new ts(0, 1, 0);
			for (let t = 0; t < e.length; t++) {
				const n = e[t];
				n.parent && n.parent.isBone && (i.push(0, 0, 0), i.push(0, 0, 0), r.push(s.r, s.g, s.b), r.push(a.r, a.g, a.b));
			}
			n.setAttribute("position", new Ms(i, 3)), n.setAttribute("color", new Ms(r, 3));
			super(n, new xh({
				vertexColors: !0,
				depthTest: !1,
				depthWrite: !1,
				toneMapped: !1,
				transparent: !0
			})), this.isSkeletonHelper = !0, this.type = "SkeletonHelper", this.root = t, this.bones = e, this.matrix = t.matrixWorld, this.matrixAutoUpdate = !1;
		}
		updateMatrixWorld(t) {
			const e = this.bones, n = this.geometry, i = n.getAttribute("position");
			Lm.copy(this.root.matrixWorld).invert();
			for (let t = 0, n = 0; t < e.length; t++) {
				const r = e[t];
				r.parent && r.parent.isBone && (Im.multiplyMatrices(Lm, r.matrixWorld), Pm.setFromMatrixPosition(Im), i.setXYZ(n, Pm.x, Pm.y, Pm.z), Im.multiplyMatrices(Lm, r.parent.matrixWorld), Pm.setFromMatrixPosition(Im), i.setXYZ(n + 1, Pm.x, Pm.y, Pm.z), n += 2);
			}
			n.getAttribute("position").needsUpdate = !0, super.updateMatrixWorld(t);
		}
		dispose() {
			this.geometry.dispose(), this.material.dispose();
		}
	};
	function Nm(t) {
		const e = [];
		!0 === t.isBone && e.push(t);
		for (let n = 0; n < t.children.length; n++) e.push.apply(e, Nm(t.children[n]));
		return e;
	}
	var Dm = class extends Vs {
		constructor(t, e, n) {
			super(new od(e, 4, 2), new rs({
				wireframe: !0,
				fog: !1,
				toneMapped: !1
			})), this.light = t, this.color = n, this.type = "PointLightHelper", this.matrix = this.light.matrixWorld, this.matrixAutoUpdate = !1, this.update();
		}
		dispose() {
			this.geometry.dispose(), this.material.dispose();
		}
		update() {
			this.light.updateWorldMatrix(!0, !1), void 0 !== this.color ? this.material.color.set(this.color) : this.material.color.copy(this.light.color);
		}
	};
	const Om = new Li(), Fm = new ts(), Bm = new ts();
	var zm = class extends Dr {
		constructor(t, e, n) {
			super(), this.light = t, this.matrix = t.matrixWorld, this.matrixAutoUpdate = !1, this.color = n, this.type = "HemisphereLightHelper";
			const i = new rd(e);
			i.rotateY(.5 * Math.PI), this.material = new rs({
				wireframe: !0,
				fog: !1,
				toneMapped: !1
			}), void 0 === this.color && (this.material.vertexColors = !0);
			const r = i.getAttribute("position"), s = new Float32Array(3 * r.count);
			i.setAttribute("color", new ds(s, 3)), this.add(new Vs(i, this.material)), this.update();
		}
		dispose() {
			this.children[0].geometry.dispose(), this.children[0].material.dispose();
		}
		update() {
			const t = this.children[0];
			if (void 0 !== this.color) this.material.color.set(this.color);
			else {
				const e = t.geometry.getAttribute("color");
				Fm.copy(this.light.color), Bm.copy(this.light.groundColor);
				for (let t = 0, n = e.count; t < n; t++) {
					const i = t < n / 2 ? Fm : Bm;
					e.setXYZ(t, i.r, i.g, i.b);
				}
				e.needsUpdate = !0;
			}
			this.light.updateWorldMatrix(!0, !1), t.lookAt(Om.setFromMatrixPosition(this.light.matrixWorld).negate());
		}
	};
	var km = class extends Ih {
		constructor(t = 10, e = 10, n = 4473924, i = 8947848) {
			n = new ts(n), i = new ts(i);
			const r = e / 2, s = t / e, a = t / 2, o = [], l = [];
			for (let t = 0, c = 0, h = -a; t <= e; t++, h += s) {
				o.push(-a, 0, h, a, 0, h), o.push(h, 0, -a, h, 0, a);
				const e = t === r ? n : i;
				e.toArray(l, c), c += 3, e.toArray(l, c), c += 3, e.toArray(l, c), c += 3, e.toArray(l, c), c += 3;
			}
			const c = new Cs();
			c.setAttribute("position", new Ms(o, 3)), c.setAttribute("color", new Ms(l, 3));
			super(c, new xh({
				vertexColors: !0,
				toneMapped: !1
			})), this.type = "GridHelper";
		}
		dispose() {
			this.geometry.dispose(), this.material.dispose();
		}
	};
	var Vm = class extends Ih {
		constructor(t = 10, e = 16, n = 8, i = 64, r = 4473924, s = 8947848) {
			r = new ts(r), s = new ts(s);
			const a = [], o = [];
			if (e > 1) for (let n = 0; n < e; n++) {
				const i = n / e * (2 * Math.PI), l = Math.sin(i) * t, c = Math.cos(i) * t;
				a.push(0, 0, 0), a.push(l, 0, c);
				const h = 1 & n ? r : s;
				o.push(h.r, h.g, h.b), o.push(h.r, h.g, h.b);
			}
			for (let e = 0; e < n; e++) {
				const l = 1 & e ? r : s, c = t - t / n * e;
				for (let t = 0; t < i; t++) {
					let e = t / i * (2 * Math.PI), n = Math.sin(e) * c, r = Math.cos(e) * c;
					a.push(n, 0, r), o.push(l.r, l.g, l.b), e = (t + 1) / i * (2 * Math.PI), n = Math.sin(e) * c, r = Math.cos(e) * c, a.push(n, 0, r), o.push(l.r, l.g, l.b);
				}
			}
			const l = new Cs();
			l.setAttribute("position", new Ms(a, 3)), l.setAttribute("color", new Ms(o, 3));
			super(l, new xh({
				vertexColors: !0,
				toneMapped: !1
			})), this.type = "PolarGridHelper";
		}
		dispose() {
			this.geometry.dispose(), this.material.dispose();
		}
	};
	const Hm = new Li(), Gm = new Li(), Wm = new Li();
	var Xm = class extends Dr {
		constructor(t, e, n) {
			super(), this.light = t, this.matrix = t.matrixWorld, this.matrixAutoUpdate = !1, this.color = n, this.type = "DirectionalLightHelper", void 0 === e && (e = 1);
			let i = new Cs();
			i.setAttribute("position", new Ms([
				-e,
				e,
				0,
				e,
				e,
				0,
				e,
				-e,
				0,
				-e,
				-e,
				0,
				-e,
				e,
				0
			], 3));
			const r = new xh({
				fog: !1,
				toneMapped: !1
			});
			this.lightPlane = new Ah(i, r), this.add(this.lightPlane), i = new Cs(), i.setAttribute("position", new Ms([
				0,
				0,
				0,
				0,
				0,
				1
			], 3)), this.targetLine = new Ah(i, r), this.add(this.targetLine), this.update();
		}
		dispose() {
			this.lightPlane.geometry.dispose(), this.lightPlane.material.dispose(), this.targetLine.geometry.dispose(), this.targetLine.material.dispose();
		}
		update() {
			this.light.updateWorldMatrix(!0, !1), this.light.target.updateWorldMatrix(!0, !1), Hm.setFromMatrixPosition(this.light.matrixWorld), Gm.setFromMatrixPosition(this.light.target.matrixWorld), Wm.subVectors(Gm, Hm), this.lightPlane.lookAt(Gm), void 0 !== this.color ? (this.lightPlane.material.color.set(this.color), this.targetLine.material.color.set(this.color)) : (this.lightPlane.material.color.copy(this.light.color), this.targetLine.material.color.copy(this.light.color)), this.targetLine.lookAt(Gm), this.targetLine.scale.z = Wm.length();
		}
	};
	const jm = new Li(), qm = new Zs();
	var Ym = class extends Ih {
		constructor(t) {
			const e = new Cs(), n = new xh({
				color: 16777215,
				vertexColors: !0,
				toneMapped: !1
			}), i = [], r = [], s = {};
			function a(t, e) {
				o(t), o(e);
			}
			function o(t) {
				i.push(0, 0, 0), r.push(0, 0, 0), void 0 === s[t] && (s[t] = []), s[t].push(i.length / 3 - 1);
			}
			a("n1", "n2"), a("n2", "n4"), a("n4", "n3"), a("n3", "n1"), a("f1", "f2"), a("f2", "f4"), a("f4", "f3"), a("f3", "f1"), a("n1", "f1"), a("n2", "f2"), a("n3", "f3"), a("n4", "f4"), a("p", "n1"), a("p", "n2"), a("p", "n3"), a("p", "n4"), a("u1", "u2"), a("u2", "u3"), a("u3", "u1"), a("c", "t"), a("p", "c"), a("cn1", "cn2"), a("cn3", "cn4"), a("cf1", "cf2"), a("cf3", "cf4"), e.setAttribute("position", new Ms(i, 3)), e.setAttribute("color", new Ms(r, 3)), super(e, n), this.type = "CameraHelper", this.camera = t, this.camera.updateProjectionMatrix && this.camera.updateProjectionMatrix(), this.matrix = t.matrixWorld, this.matrixAutoUpdate = !1, this.pointMap = s, this.update();
			const l = new ts(16755200), c = new ts(16711680), h = new ts(43775), u = new ts(16777215), d = new ts(3355443);
			this.setColors(l, c, h, u, d);
		}
		setColors(t, e, n, i, r) {
			const s = this.geometry.getAttribute("color");
			s.setXYZ(0, t.r, t.g, t.b), s.setXYZ(1, t.r, t.g, t.b), s.setXYZ(2, t.r, t.g, t.b), s.setXYZ(3, t.r, t.g, t.b), s.setXYZ(4, t.r, t.g, t.b), s.setXYZ(5, t.r, t.g, t.b), s.setXYZ(6, t.r, t.g, t.b), s.setXYZ(7, t.r, t.g, t.b), s.setXYZ(8, t.r, t.g, t.b), s.setXYZ(9, t.r, t.g, t.b), s.setXYZ(10, t.r, t.g, t.b), s.setXYZ(11, t.r, t.g, t.b), s.setXYZ(12, t.r, t.g, t.b), s.setXYZ(13, t.r, t.g, t.b), s.setXYZ(14, t.r, t.g, t.b), s.setXYZ(15, t.r, t.g, t.b), s.setXYZ(16, t.r, t.g, t.b), s.setXYZ(17, t.r, t.g, t.b), s.setXYZ(18, t.r, t.g, t.b), s.setXYZ(19, t.r, t.g, t.b), s.setXYZ(20, t.r, t.g, t.b), s.setXYZ(21, t.r, t.g, t.b), s.setXYZ(22, t.r, t.g, t.b), s.setXYZ(23, t.r, t.g, t.b), s.setXYZ(24, e.r, e.g, e.b), s.setXYZ(25, e.r, e.g, e.b), s.setXYZ(26, e.r, e.g, e.b), s.setXYZ(27, e.r, e.g, e.b), s.setXYZ(28, e.r, e.g, e.b), s.setXYZ(29, e.r, e.g, e.b), s.setXYZ(30, e.r, e.g, e.b), s.setXYZ(31, e.r, e.g, e.b), s.setXYZ(32, n.r, n.g, n.b), s.setXYZ(33, n.r, n.g, n.b), s.setXYZ(34, n.r, n.g, n.b), s.setXYZ(35, n.r, n.g, n.b), s.setXYZ(36, n.r, n.g, n.b), s.setXYZ(37, n.r, n.g, n.b), s.setXYZ(38, i.r, i.g, i.b), s.setXYZ(39, i.r, i.g, i.b), s.setXYZ(40, r.r, r.g, r.b), s.setXYZ(41, r.r, r.g, r.b), s.setXYZ(42, r.r, r.g, r.b), s.setXYZ(43, r.r, r.g, r.b), s.setXYZ(44, r.r, r.g, r.b), s.setXYZ(45, r.r, r.g, r.b), s.setXYZ(46, r.r, r.g, r.b), s.setXYZ(47, r.r, r.g, r.b), s.setXYZ(48, r.r, r.g, r.b), s.setXYZ(49, r.r, r.g, r.b), s.needsUpdate = !0;
		}
		update() {
			const t = this.geometry, e = this.pointMap;
			qm.projectionMatrixInverse.copy(this.camera.projectionMatrixInverse), Zm("c", e, t, qm, 0, 0, -1), Zm("t", e, t, qm, 0, 0, 1), Zm("n1", e, t, qm, -1, -1, -1), Zm("n2", e, t, qm, 1, -1, -1), Zm("n3", e, t, qm, -1, 1, -1), Zm("n4", e, t, qm, 1, 1, -1), Zm("f1", e, t, qm, -1, -1, 1), Zm("f2", e, t, qm, 1, -1, 1), Zm("f3", e, t, qm, -1, 1, 1), Zm("f4", e, t, qm, 1, 1, 1), Zm("u1", e, t, qm, .7, 1.1, -1), Zm("u2", e, t, qm, -.7, 1.1, -1), Zm("u3", e, t, qm, 0, 2, -1), Zm("cf1", e, t, qm, -1, 0, 1), Zm("cf2", e, t, qm, 1, 0, 1), Zm("cf3", e, t, qm, 0, -1, 1), Zm("cf4", e, t, qm, 0, 1, 1), Zm("cn1", e, t, qm, -1, 0, -1), Zm("cn2", e, t, qm, 1, 0, -1), Zm("cn3", e, t, qm, 0, -1, -1), Zm("cn4", e, t, qm, 0, 1, -1), t.getAttribute("position").needsUpdate = !0;
		}
		dispose() {
			this.geometry.dispose(), this.material.dispose();
		}
	};
	function Zm(t, e, n, i, r, s, a) {
		jm.set(r, s, a).unproject(i);
		const o = e[t];
		if (void 0 !== o) {
			const t = n.getAttribute("position");
			for (let e = 0, n = o.length; e < n; e++) t.setXYZ(o[e], jm.x, jm.y, jm.z);
		}
	}
	const Jm = new Di();
	var Km = class extends Ih {
		constructor(t, e = 16776960) {
			const n = new Uint16Array([
				0,
				1,
				1,
				2,
				2,
				3,
				3,
				0,
				4,
				5,
				5,
				6,
				6,
				7,
				7,
				4,
				0,
				4,
				1,
				5,
				2,
				6,
				3,
				7
			]), i = new Float32Array(24), r = new Cs();
			r.setIndex(new ds(n, 1)), r.setAttribute("position", new ds(i, 3)), super(r, new xh({
				color: e,
				toneMapped: !1
			})), this.object = t, this.type = "BoxHelper", this.matrixAutoUpdate = !1, this.update();
		}
		update(t) {
			if (void 0 !== t && console.warn("THREE.BoxHelper: .update() has no longer arguments."), void 0 !== this.object && Jm.setFromObject(this.object), Jm.isEmpty()) return;
			const e = Jm.min, n = Jm.max, i = this.geometry.attributes.position, r = i.array;
			r[0] = n.x, r[1] = n.y, r[2] = n.z, r[3] = e.x, r[4] = n.y, r[5] = n.z, r[6] = e.x, r[7] = e.y, r[8] = n.z, r[9] = n.x, r[10] = e.y, r[11] = n.z, r[12] = n.x, r[13] = n.y, r[14] = e.z, r[15] = e.x, r[16] = n.y, r[17] = e.z, r[18] = e.x, r[19] = e.y, r[20] = e.z, r[21] = n.x, r[22] = e.y, r[23] = e.z, i.needsUpdate = !0, this.geometry.computeBoundingSphere();
		}
		setFromObject(t) {
			return this.object = t, this.update(), this;
		}
		copy(t, e) {
			return super.copy(t, e), this.object = t.object, this;
		}
		dispose() {
			this.geometry.dispose(), this.material.dispose();
		}
	};
	var $m = class extends Ih {
		constructor(t, e = 16776960) {
			const n = new Uint16Array([
				0,
				1,
				1,
				2,
				2,
				3,
				3,
				0,
				4,
				5,
				5,
				6,
				6,
				7,
				7,
				4,
				0,
				4,
				1,
				5,
				2,
				6,
				3,
				7
			]), i = new Cs();
			i.setIndex(new ds(n, 1)), i.setAttribute("position", new Ms([
				1,
				1,
				1,
				-1,
				1,
				1,
				-1,
				-1,
				1,
				1,
				-1,
				1,
				1,
				1,
				-1,
				-1,
				1,
				-1,
				-1,
				-1,
				-1,
				1,
				-1,
				-1
			], 3)), super(i, new xh({
				color: e,
				toneMapped: !1
			})), this.box = t, this.type = "Box3Helper", this.geometry.computeBoundingSphere();
		}
		updateMatrixWorld(t) {
			const e = this.box;
			e.isEmpty() || (e.getCenter(this.position), e.getSize(this.scale), this.scale.multiplyScalar(.5), super.updateMatrixWorld(t));
		}
		dispose() {
			this.geometry.dispose(), this.material.dispose();
		}
	};
	var Qm = class extends Ah {
		constructor(t, e = 1, n = 16776960) {
			const i = n, r = new Cs();
			r.setAttribute("position", new Ms([
				1,
				-1,
				0,
				-1,
				1,
				0,
				-1,
				-1,
				0,
				1,
				1,
				0,
				-1,
				1,
				0,
				-1,
				-1,
				0,
				1,
				-1,
				0,
				1,
				1,
				0
			], 3)), r.computeBoundingSphere(), super(r, new xh({
				color: i,
				toneMapped: !1
			})), this.type = "PlaneHelper", this.plane = t, this.size = e;
			const s = new Cs();
			s.setAttribute("position", new Ms([
				1,
				1,
				0,
				-1,
				1,
				0,
				-1,
				-1,
				0,
				1,
				1,
				0,
				-1,
				-1,
				0,
				1,
				-1,
				0
			], 3)), s.computeBoundingSphere(), this.add(new Vs(s, new rs({
				color: i,
				opacity: .2,
				transparent: !0,
				depthWrite: !1,
				toneMapped: !1
			})));
		}
		updateMatrixWorld(t) {
			this.position.set(0, 0, 0), this.scale.set(.5 * this.size, .5 * this.size, 1), this.lookAt(this.plane.normal), this.translateZ(-this.plane.constant), super.updateMatrixWorld(t);
		}
		dispose() {
			this.geometry.dispose(), this.material.dispose(), this.children[0].geometry.dispose(), this.children[0].material.dispose();
		}
	};
	const tf = new Li();
	let ef, nf;
	var rf = class extends Dr {
		constructor(t = new Li(0, 0, 1), e = new Li(0, 0, 0), n = 1, i = 16776960, r = .2 * n, s = .2 * r) {
			super(), this.type = "ArrowHelper", void 0 === ef && (ef = new Cs(), ef.setAttribute("position", new Ms([
				0,
				0,
				0,
				0,
				1,
				0
			], 3)), nf = new vu(0, .5, 1, 5, 1), nf.translate(0, -.5, 0)), this.position.copy(e), this.line = new Ah(ef, new xh({
				color: i,
				toneMapped: !1
			})), this.line.matrixAutoUpdate = !1, this.add(this.line), this.cone = new Vs(nf, new rs({
				color: i,
				toneMapped: !1
			})), this.cone.matrixAutoUpdate = !1, this.add(this.cone), this.setDirection(t), this.setLength(n, r, s);
		}
		setDirection(t) {
			if (t.y > .99999) this.quaternion.set(0, 0, 0, 1);
			else if (t.y < -.99999) this.quaternion.set(1, 0, 0, 0);
			else {
				tf.set(t.z, 0, -t.x).normalize();
				const e = Math.acos(t.y);
				this.quaternion.setFromAxisAngle(tf, e);
			}
		}
		setLength(t, e = .2 * t, n = .2 * e) {
			this.line.scale.set(1, Math.max(1e-4, t - e), 1), this.line.updateMatrix(), this.cone.scale.set(n, e, n), this.cone.position.y = t, this.cone.updateMatrix();
		}
		setColor(t) {
			this.line.material.color.set(t), this.cone.material.color.set(t);
		}
		copy(t) {
			return super.copy(t, !1), this.line.copy(t.line), this.cone.copy(t.cone), this;
		}
		dispose() {
			this.line.geometry.dispose(), this.line.material.dispose(), this.cone.geometry.dispose(), this.cone.material.dispose();
		}
	};
	var sf = class extends Ih {
		constructor(t = 1) {
			const e = [
				0,
				0,
				0,
				t,
				0,
				0,
				0,
				0,
				0,
				0,
				t,
				0,
				0,
				0,
				0,
				0,
				0,
				t
			], n = new Cs();
			n.setAttribute("position", new Ms(e, 3)), n.setAttribute("color", new Ms([
				1,
				0,
				0,
				1,
				.6,
				0,
				0,
				1,
				0,
				.6,
				1,
				0,
				0,
				0,
				1,
				0,
				.6,
				1
			], 3));
			super(n, new xh({
				vertexColors: !0,
				toneMapped: !1
			})), this.type = "AxesHelper";
		}
		setColors(t, e, n) {
			const i = new ts(), r = this.geometry.attributes.color.array;
			return i.set(t), i.toArray(r, 0), i.toArray(r, 3), i.set(e), i.toArray(r, 6), i.toArray(r, 9), i.set(n), i.toArray(r, 12), i.toArray(r, 15), this.geometry.attributes.color.needsUpdate = !0, this;
		}
		dispose() {
			this.geometry.dispose(), this.material.dispose();
		}
	};
	var af = class {
		constructor() {
			this.type = "ShapePath", this.color = new ts(), this.subPaths = [], this.currentPath = null;
		}
		moveTo(t, e) {
			return this.currentPath = new pu(), this.subPaths.push(this.currentPath), this.currentPath.moveTo(t, e), this;
		}
		lineTo(t, e) {
			return this.currentPath.lineTo(t, e), this;
		}
		quadraticCurveTo(t, e, n, i) {
			return this.currentPath.quadraticCurveTo(t, e, n, i), this;
		}
		bezierCurveTo(t, e, n, i, r, s) {
			return this.currentPath.bezierCurveTo(t, e, n, i, r, s), this;
		}
		splineThru(t) {
			return this.currentPath.splineThru(t), this;
		}
		toShapes(t) {
			function e(t, e) {
				const n = e.length;
				let i = !1;
				for (let r = n - 1, s = 0; s < n; r = s++) {
					let n = e[r], a = e[s], o = a.x - n.x, l = a.y - n.y;
					if (Math.abs(l) > Number.EPSILON) {
						if (l < 0 && (n = e[s], o = -o, a = e[r], l = -l), t.y < n.y || t.y > a.y) continue;
						if (t.y === n.y) {
							if (t.x === n.x) return !0;
						} else {
							const e = l * (t.x - n.x) - o * (t.y - n.y);
							if (0 === e) return !0;
							if (e < 0) continue;
							i = !i;
						}
					} else {
						if (t.y !== n.y) continue;
						if (a.x <= t.x && t.x <= n.x || n.x <= t.x && t.x <= a.x) return !0;
					}
				}
				return i;
			}
			const n = $u.isClockWise, i = this.subPaths;
			if (0 === i.length) return [];
			let r, s, a;
			const o = [];
			if (1 === i.length) return s = i[0], a = new Eu(), a.curves = s.curves, o.push(a), o;
			let l = !n(i[0].getPoints());
			l = t ? !l : l;
			const c = [], h = [];
			let u, d, p = [], m = 0;
			h[m] = void 0, p[m] = [];
			for (let e = 0, a = i.length; e < a; e++) s = i[e], u = s.getPoints(), r = n(u), r = t ? !r : r, r ? (!l && h[m] && m++, h[m] = {
				s: new Eu(),
				p: u
			}, h[m].s.curves = s.curves, l && m++, p[m] = []) : p[m].push({
				h: s,
				p: u[0]
			});
			if (!h[0]) return function(t) {
				const e = [];
				for (let n = 0, i = t.length; n < i; n++) {
					const i = t[n], r = new Eu();
					r.curves = i.curves, e.push(r);
				}
				return e;
			}(i);
			if (h.length > 1) {
				let t = !1, n = 0;
				for (let t = 0, e = h.length; t < e; t++) c[t] = [];
				for (let i = 0, r = h.length; i < r; i++) {
					const r = p[i];
					for (let s = 0; s < r.length; s++) {
						const a = r[s];
						let o = !0;
						for (let r = 0; r < h.length; r++) e(a.p, h[r].p) && (i !== r && n++, o ? (o = !1, c[r].push(a)) : t = !0);
						o && c[i].push(a);
					}
				}
				n > 0 && !1 === t && (p = c);
			}
			for (let t = 0, e = h.length; t < e; t++) {
				a = h[t].s, o.push(a), d = p[t];
				for (let t = 0, e = d.length; t < e; t++) a.holes.push(d[t].h);
			}
			return o;
		}
	};
	var of = class extends Hn {
		constructor(t, e = null) {
			super(), this.object = t, this.domElement = e, this.enabled = !0, this.state = -1, this.keys = {}, this.mouseButtons = {
				LEFT: null,
				MIDDLE: null,
				RIGHT: null
			}, this.touches = {
				ONE: null,
				TWO: null
			};
		}
		connect() {}
		disconnect() {}
		dispose() {}
		update() {}
	};
	var lf = class extends Ei {
		constructor(t = 1, e = 1, n = 1, i = {}) {
			console.warn("THREE.WebGLMultipleRenderTargets has been deprecated and will be removed in r172. Use THREE.WebGLRenderTarget and set the \"count\" parameter to enable MRT."), super(t, e, {
				...i,
				count: n
			}), this.isWebGLMultipleRenderTargets = !0;
		}
		get texture() {
			return this.textures;
		}
	};
	"undefined" != typeof __THREE_DEVTOOLS__ && __THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register", { detail: { revision: "169" } })), "undefined" != typeof window && (window.__THREE__ ? console.warn("WARNING: Multiple instances of Three.js being imported.") : window.__THREE__ = "169");
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/shaders/common.js
	const baseVert = `
  varying vec2 vUv;
  void main() {
    vUv = uv;
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
	const fluidVert = `
  varying vec2 vUv;
  varying vec2 vL;
  varying vec2 vR;
  varying vec2 vT;
  varying vec2 vB;
  uniform vec2 texelSize;

  void main() {
    vUv = uv;
    vL = vUv - vec2(texelSize.x, 0.0);
    vR = vUv + vec2(texelSize.x, 0.0);
    vT = vUv + vec2(0.0, texelSize.y);
    vB = vUv - vec2(0.0, texelSize.y);
    gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
  }
`;
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/shaders/fluid.js
	const clearFrag = `
  uniform sampler2D uTexture;
  uniform float value;
  varying vec2 vUv;
  void main() {
    gl_FragColor = value * texture2D(uTexture, vUv);
  }
`;
	const splatFrag = `
  uniform sampler2D uTarget;
  uniform float aspectRatio;
  uniform vec3 color;
  uniform vec2 point;
  uniform float radius;
  varying vec2 vUv;

  void main() {
    vec2 p = vUv - point;
    p.x *= aspectRatio;
    vec3 splat = exp(-dot(p, p) / radius) * color;
    vec3 base = texture2D(uTarget, vUv).xyz;
    gl_FragColor = vec4(base + splat, 1.0);
  }
`;
	const advectFrag = `
  uniform sampler2D uVelocity;
  uniform sampler2D uSource;
  uniform vec2 texelSize;
  uniform float dt;
  uniform float dissipation;
  varying vec2 vUv;

  vec4 bilerp(sampler2D sam, vec2 uv, vec2 tsize) {
    vec2 st = uv / tsize - 0.5;
    vec2 iuv = floor(st);
    vec2 fuv = fract(st);
    vec4 a = texture2D(sam, (iuv + vec2(0.5, 0.5)) * tsize);
    vec4 b = texture2D(sam, (iuv + vec2(1.5, 0.5)) * tsize);
    vec4 c = texture2D(sam, (iuv + vec2(0.5, 1.5)) * tsize);
    vec4 d = texture2D(sam, (iuv + vec2(1.5, 1.5)) * tsize);
    return mix(mix(a, b, fuv.x), mix(c, d, fuv.x), fuv.y);
  }

  void main() {
    vec2 coord = vUv - dt * bilerp(uVelocity, vUv, texelSize).xy * texelSize;
    gl_FragColor = dissipation * bilerp(uSource, coord, texelSize);
  }
`;
	const divergenceFrag = `
  uniform sampler2D uVelocity;
  varying vec2 vUv;
  varying vec2 vL;
  varying vec2 vR;
  varying vec2 vT;
  varying vec2 vB;

  void main() {
    float L = texture2D(uVelocity, vL).x;
    float R = texture2D(uVelocity, vR).x;
    float T = texture2D(uVelocity, vT).y;
    float B = texture2D(uVelocity, vB).y;
    vec2 C = texture2D(uVelocity, vUv).xy;
    if (vL.x < 0.0) { L = -C.x; }
    if (vR.x > 1.0) { R = -C.x; }
    if (vT.y > 1.0) { T = -C.y; }
    if (vB.y < 0.0) { B = -C.y; }
    float div = 0.5 * (R - L + T - B);
    gl_FragColor = vec4(div, 0.0, 0.0, 1.0);
  }
`;
	const curlFrag = `
  uniform sampler2D uVelocity;
  varying vec2 vUv;
  varying vec2 vL;
  varying vec2 vR;
  varying vec2 vT;
  varying vec2 vB;

  void main() {
    float L = texture2D(uVelocity, vL).y;
    float R = texture2D(uVelocity, vR).y;
    float T = texture2D(uVelocity, vT).x;
    float B = texture2D(uVelocity, vB).x;
    float vorticity = R - L - T + B;
    gl_FragColor = vec4(0.5 * vorticity, 0.0, 0.0, 1.0);
  }
`;
	const vorticityFrag = `
  uniform sampler2D uVelocity;
  uniform sampler2D uCurl;
  uniform float curl;
  uniform float dt;
  varying vec2 vUv;
  varying vec2 vL;
  varying vec2 vR;
  varying vec2 vT;
  varying vec2 vB;

  void main() {
    float L = texture2D(uCurl, vL).x;
    float R = texture2D(uCurl, vR).x;
    float T = texture2D(uCurl, vT).x;
    float B = texture2D(uCurl, vB).x;
    float C = texture2D(uCurl, vUv).x;

    vec2 force = 0.5 * vec2(abs(T) - abs(B), abs(R) - abs(L));
    force /= length(force) + 0.0001;
    force *= curl * C;
    force.y *= -1.0;

    vec2 velocity = texture2D(uVelocity, vUv).xy;
    velocity += force * dt;
    velocity = min(max(velocity, -1000.0), 1000.0);
    gl_FragColor = vec4(velocity, 0.0, 1.0);
  }
`;
	const pressureFrag = `
  uniform sampler2D uPressure;
  uniform sampler2D uDivergence;
  varying vec2 vUv;
  varying vec2 vL;
  varying vec2 vR;
  varying vec2 vT;
  varying vec2 vB;

  void main() {
    float L = texture2D(uPressure, vL).x;
    float R = texture2D(uPressure, vR).x;
    float T = texture2D(uPressure, vT).x;
    float B = texture2D(uPressure, vB).x;
    float divergence = texture2D(uDivergence, vUv).x;
    float pressure = (L + R + B + T - divergence) * 0.25;
    gl_FragColor = vec4(pressure, 0.0, 0.0, 1.0);
  }
`;
	const gradientSubtractFrag = `
  uniform sampler2D uPressure;
  uniform sampler2D uVelocity;
  varying vec2 vUv;
  varying vec2 vL;
  varying vec2 vR;
  varying vec2 vT;
  varying vec2 vB;

  void main() {
    float L = texture2D(uPressure, vL).x;
    float R = texture2D(uPressure, vR).x;
    float T = texture2D(uPressure, vT).x;
    float B = texture2D(uPressure, vB).x;
    vec2 velocity = texture2D(uVelocity, vUv).xy;
    velocity.xy -= vec2(R - L, T - B);
    gl_FragColor = vec4(velocity, 0.0, 1.0);
  }
`;
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/shaders/logo.js
	const logoFrag = `
  precision highp float;
  varying vec2 vUv;

  uniform vec2 resolution;
  uniform float time;
  uniform float ringInner;     // central void radius (carved out of the bands)
  uniform float ringOuter;     // overall scale (S amplitude / vertical reach)
  uniform float ringSoftness;  // soft edge half-width
  uniform float ringRotation;
  uniform float breath;
  uniform float ringFill;

  // Re-used as free dials for the emblem:
  //   nodeA.z = band thickness (half-width)
  //   nodeB.z = side-wedge size scale (0 = off)
  //   nodeC.x = tip cut angle (radians) for sharp angular terminals
  uniform vec3 nodeA;
  uniform vec3 nodeB;
  uniform vec3 nodeC;
  uniform vec3 nodePhases;

  const float PI = 3.14159265359;

  // Distance to a circular arc segment.
  //   C = arc centre, r = arc radius, [a0, a1] = angular range (a0 < a1).
  // If p's angle (relative to C) is within range, distance is |dist - r|.
  // Otherwise we return distance to the nearest of the two endpoints.
  // This is an unsigned distance to the curve (not a band yet).
  float arcCurveDist(vec2 p, vec2 C, float r, float a0, float a1) {
    vec2 d = p - C;
    float ang = atan(d.y, d.x);
    float ac = 0.5 * (a0 + a1);
    float aw = 0.5 * (a1 - a0);
    float wrapped = atan(sin(ang - ac), cos(ang - ac));
    if (abs(wrapped) <= aw) {
      return abs(length(d) - r);
    }
    // Outside angular range: distance to the closer endpoint.
    float side = sign(wrapped);
    vec2 endPt = C + r * vec2(cos(ac + side * aw), sin(ac + side * aw));
    return length(p - endPt);
  }

  // Distance to one yin-yang-style S-curve consisting of two tangent
  // half-circle arcs that, together, form a smooth "S" running from
  // (-R, 0) through (0, 0) to (+R, 0). The two sub-arcs are:
  //   left arc:  centre (-R/2, 0), radius R/2, lower half (angle 180→360)
  //   right arc: centre (+R/2, 0), radius R/2, upper half (angle 0→180)
  // Together these glue at (0, 0) tangentially.
  float yinYangSDist(vec2 p, float R) {
    float r = 0.5 * R;
    // left arc: lower half (angle range [-PI, 0])
    float dL = arcCurveDist(p, vec2(-r, 0.0), r, -PI, 0.0);
    // right arc: upper half (angle range [0, PI])
    float dR = arcCurveDist(p, vec2(+r, 0.0), r, 0.0, PI);
    return min(dL, dR);
  }

  // Smooth min for nice halftone joins.
  float smin(float a, float b, float k) {
    float h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
    return mix(b, a, h) - k * h * (1.0 - h);
  }

  void main() {
    vec2 px = vUv * resolution;
    vec2 center = resolution * 0.5;
    float minDim = min(resolution.x, resolution.y);
    vec2 p = (px - center) / minDim;

    // global slow rotation
    float cs = cos(ringRotation), sn = sin(ringRotation);
    p = mat2(cs, -sn, sn, cs) * p;

    // breathing pulse on the whole emblem
    float pulse = 1.0 + breath * sin(time * 0.8) * 0.03;
    p /= pulse;

    // parameters
    float R    = ringOuter;          // outer reach of the emblem (= R in the math)
    float hole = ringInner;          // central void radius (carves a clean middle)
    float th   = nodeA.z;            // band half-thickness
    float wedgeScale = nodeB.z;      // 0 disables side wedges
    float tipCut = nodeC.x;          // tip cut angle (radians)

    // Two yin-yang-style S-curves: one horizontal (running left↔right) and a
    // second one rotated by 90° (running top↔bottom). Together they wrap the
    // central void exactly the way the reference logo does: two thick bands
    // interlocking with a clean circular hole in the middle and four tips
    // pointing diagonally outwards.
    //
    // Each band is the unsigned distance to the curve, minus the half
    // thickness th. Negative ⇒ inside the band; positive ⇒ outside.
    float dH = yinYangSDist(p, R) - th;
    vec2 pV = vec2(-p.y, p.x);                        // 90° rotation of p
    float dV = yinYangSDist(pV, R) - th;
    float main_d = smin(dH, dV, 0.012);

    // Sharp angled terminal cuts at the four endpoints (±R, 0) and (0, ±R).
    // The S-curve tangent at each endpoint runs along ±y (for the horizontal
    // S) or ±x (for the vertical S), so the natural cut planes have normals
    // along ±x or ±y. We tilt them by tipCut for the angled-tip look.
    if (tipCut > 0.001) {
      float ct = cos(tipCut), st = sin(tipCut);
      // horizontal S: tip at (+R, 0). Tangent ≈ +y at this end → cut normal ≈ +x.
      vec2 nR = vec2(ct, +st);
      main_d = max(main_d, dot(p - vec2(+R, 0.0), nR));
      // tip at (-R, 0): cut normal ≈ -x
      vec2 nL = vec2(-ct, -st);
      main_d = max(main_d, dot(p - vec2(-R, 0.0), nL));
      // vertical S: tip at (0, +R)
      vec2 nT = vec2(-st, ct);
      main_d = max(main_d, dot(p - vec2(0.0, +R), nT));
      // tip at (0, -R)
      vec2 nB = vec2(+st, -ct);
      main_d = max(main_d, dot(p - vec2(0.0, -R), nB));
    }

    // Carve a clean circular void at the centre.
    if (hole > 0.001) {
      float voidD = length(p) - hole;
      main_d = max(main_d, -voidD);
    }

    // Side wedges: two small detached S-curve slivers further out along ±x,
    // visually echoing the main flow. They sit just outside the main lobes'
    // horizontal tips at (±R, 0).
    float wedge_d = 1e9;
    if (wedgeScale > 0.001) {
      float wR = R * 0.32;
      float wTh = th * 0.55;
      float wOff = R * 1.18;
      vec2 prr = p - vec2(+wOff, 0.0);
      vec2 plr = p - vec2(-wOff, 0.0);
      float dr = yinYangSDist(prr, wR) - wTh;
      float dl = yinYangSDist(plr, wR) - wTh;
      wedge_d = min(dr, dl);
    }

    // Wedges as a separate (un-smoothed) union so they stay visually detached.
    float d = (wedgeScale > 0.001) ? min(main_d, wedge_d) : main_d;

    // Convert to soft luminance mask.
    float shape = 1.0 - smoothstep(-ringSoftness, ringSoftness, d);

    // Optional inner-fill mode (variant 10 — fills the central hole too).
    if (ringFill > 0.5) {
      float diskFill = 1.0 - smoothstep(R * 0.5 - ringSoftness, R * 0.5 + ringSoftness, length(p));
      shape = max(shape, diskFill);
    }

    gl_FragColor = vec4(vec3(shape), 1.0);
  }
`;
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/shaders/display.js
	const displayFrag = `
  uniform sampler2D uDye;
  uniform sampler2D uShape;
  uniform float fluidStrength;
  uniform float gridCellSize;
  uniform float dotRadius;
  uniform float minDotRadius;
  uniform vec2 videoResolution;
  uniform float time;
  uniform float animSpeed;
  uniform float gamma;
  uniform int gridLayout; // 0=straight, 1=radial, 2=alternating-grid
  uniform vec3 dotColor;
  uniform float dotAlphaMultiplier;
  uniform bool dotsEnabled;
  // shape sampling controls (used to add subtle breath/rotation to a static logo mask)
  uniform float shapeRotation;   // radians, applied as in-uv rotation around (0.5, 0.5)
  uniform float shapeBreath;     // -1..+1, scales the uv offset (negative = expand)
  uniform float shapeScale;      // 1.0 = mask fills its protected square exactly. >1.0 shrinks the visible logo (samples further out into the mask's empty padding).
  // Radial vignette controls. With falloffStrength = 0 the whole effect is
  // a no-op (vignette resolves to 1.0 everywhere). Defaults applied via
  // hero/defaultConfig.js give every variant a gentle edge fade so the
  // central logo region dominates and mouse smears visibly weaken at corners.
  uniform float falloffStrength;  // 0..1 — how much edges fade (0 = off)
  uniform float falloffRadius;    // 0..0.7 — protected centre core (no fade inside)
  uniform float falloffEnd;       // 0..1.4 — distance where fade reaches max (corner ≈ 0.707)
  varying vec2 vUv;

  float random(vec2 st) {
    return fract(sin(dot(st.xy, vec2(12.9898, 78.233))) * 43758.5453123);
  }

  void main() {
    vec2 gridPos;
    vec2 cellCenter;
    vec2 cellIndex;
    vec2 centerUv;
    float distanceFromCenter;

    if (gridLayout == 1) {
      // Radial layout
      vec2 pixelPos = vUv * videoResolution;
      vec2 center = videoResolution * 0.5;
      float minDim = min(videoResolution.x, videoResolution.y);
      vec2 normalizedPos = (pixelPos - center) / minDim;

      float angle = atan(normalizedPos.y, normalizedPos.x);
      float radius = length(normalizedPos) * minDim;

      float ringIndex = floor(radius / gridCellSize);
      vec2 dotCenterNormalized;
      float dotIndex;

      if (ringIndex < 0.5) {
        dotCenterNormalized = vec2(0.0, 0.0);
        dotIndex = 0.0;
      } else {
        float ringRadius = ringIndex * gridCellSize;
        float circumference = 6.28318 * ringRadius;
        float numDotsInRing = max(1.0, floor(circumference / gridCellSize));
        float anglePerDot = 6.28318 / numDotsInRing;
        dotIndex = floor(angle / anglePerDot);

        float dotAngle = (dotIndex + 0.5) * anglePerDot;
        float dotR = (ringIndex + 0.5) * gridCellSize;
        dotCenterNormalized = vec2(cos(dotAngle), sin(dotAngle)) * (dotR / minDim);
      }

      vec2 dotCenterPixel = dotCenterNormalized * minDim + center;
      vec2 toDotNormalized = normalizedPos - dotCenterNormalized;
      distanceFromCenter = length(toDotNormalized) * minDim;
      centerUv = dotCenterPixel / videoResolution;
      cellIndex = vec2(ringIndex, dotIndex);
      gridPos = vec2(0.0);
      cellCenter = vec2(0.0);

    } else if (gridLayout == 2) {
      cellIndex = floor(vUv * videoResolution / gridCellSize);
      float rowOffset = mod(cellIndex.y, 2.0) * gridCellSize * 0.5;
      vec2 offsetPixel = vUv * videoResolution + vec2(rowOffset, 0.0);
      cellIndex = floor(offsetPixel / gridCellSize);
      centerUv = ((cellIndex + 0.5) * gridCellSize - vec2(rowOffset, 0.0)) / videoResolution;
      gridPos = mod(offsetPixel, gridCellSize);
      cellCenter = vec2(gridCellSize * 0.5);
      distanceFromCenter = length(gridPos - cellCenter);

    } else {
      gridPos = mod(vUv * videoResolution, gridCellSize);
      cellCenter = vec2(gridCellSize * 0.5);
      cellIndex = floor(vUv * videoResolution / gridCellSize);
      centerUv = ((cellIndex + 0.5) * gridCellSize) / videoResolution;
      distanceFromCenter = length(gridPos - cellCenter);
    }

    // Sample the logo mask. The mask is a 1024² SQUARE bitmap so we
    // aspect-correct shapeUv: scale x by width/minDim so the logo stays
    // square-shaped regardless of viewport ratio (instead of smearing
    // horizontally across the whole hero). The mask itself bakes in
    // ~11% padding (INSET=0.78 in buildLogoMaskTexture).
    vec2 shapeUv = centerUv - vec2(0.5);
    float minDim = min(videoResolution.x, videoResolution.y);
    shapeUv.x *= videoResolution.x / minDim;
    shapeUv.y *= videoResolution.y / minDim;
    float scs = cos(shapeRotation), sns = sin(shapeRotation);
    shapeUv = mat2(scs, -sns, sns, scs) * shapeUv;
    shapeUv *= (1.0 - shapeBreath * 0.04); // breath is in [-1,1]
    shapeUv *= shapeScale;                  // >1 = logo appears smaller
    shapeUv += vec2(0.5);
    vec4 shape = texture2D(uShape, shapeUv);
    vec4 dye = texture2D(uDye, centerUv);

    vec3 shapeGammaCorrected = pow(shape.rgb, vec3(gamma));
    vec3 scaledDye = dye.rgb * fluidStrength;
    scaledDye = pow(scaledDye + 0.001, vec3(0.7));
    vec3 blendedColor = shapeGammaCorrected + scaledDye;

    float luminance = dot(blendedColor, vec3(0.299, 0.587, 0.114));

    // Radial vignette factor. Centre of the canvas (vUv = 0.5,0.5) maps to
    // distance 0; the corners map to ~0.707 (after aspect-correction below
    // they map to slightly more on widescreen). falloffRadius defines a
    // protected core where the multiplier stays at 1.0, then we smoothstep
    // down to (1.0 - falloffStrength) by falloffEnd. With falloffStrength
    // = 0 the mix collapses back to 1.0 everywhere — no-op.
    vec2 falloffUv = vUv - vec2(0.5);
    falloffUv.x *= videoResolution.x / min(videoResolution.x, videoResolution.y);
    falloffUv.y *= videoResolution.y / min(videoResolution.x, videoResolution.y);
    float distFromMid = length(falloffUv);
    float vignette = 1.0 - smoothstep(falloffRadius, falloffEnd, distFromMid) * falloffStrength;

    // Apply vignette to luminance BEFORE dot sizing — this is what makes the
    // halftone fade-out look natural: edge dots get progressively smaller AND
    // sparser AND dimmer in lockstep, instead of just getting more transparent
    // (which would show as a hard ring of small but solid dots).
    luminance *= vignette;

    if (!dotsEnabled) {
      gl_FragColor = vec4(dotColor, luminance * dotAlphaMultiplier);
      return;
    }

    float randomValue = random(cellIndex);
    float phase = randomValue * 6.28318;
    float scaleAnimation = sin(time * animSpeed + phase) * 0.5 + 0.5;
    float randomScale = 1.0 - (scaleAnimation * 0.5);

    float luminanceMinScale = min(minDotRadius / dotRadius, 1.0);
    float finalScale = (luminanceMinScale + (luminance * (1.0 - luminanceMinScale))) * randomScale;
    float scaledRadius = dotRadius * finalScale;

    float maxRadius = gridCellSize * 0.5;
    scaledRadius = min(scaledRadius, maxRadius);

    float edgeWidth = 0.5;
    float dotMask = 1.0 - smoothstep(scaledRadius - edgeWidth, scaledRadius + edgeWidth, distanceFromCenter);

    float luminanceCutoff = smoothstep(0.0, 0.1, luminance);
    float finalAlpha = dotMask * luminance * luminanceCutoff * dotAlphaMultiplier;

    gl_FragColor = vec4(dotColor, finalAlpha);
  }
`;
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/hero/defaultConfig.js
	const defaultShaderConfig = {
		dotsEnabled: true,
		dotSize: 8,
		minDotSize: 1,
		dotMargin: 0,
		dotColor: "#e0f6ff",
		dotAlphaMultiplier: 1,
		gridLayout: "straight",
		animSpeed: 4,
		gamma: .9,
		backgroundColor: "#000000",
		ringInner: .16,
		ringOuter: .62,
		ringSoftness: .012,
		ringRotationSpeed: 0,
		ringFill: 0,
		breath: 1,
		nodes: [
			{
				angle: 0,
				dist: 0,
				radius: .085
			},
			{
				angle: 0,
				dist: 0,
				radius: 1
			},
			{
				angle: Math.PI / 6,
				dist: 0,
				radius: 0
			}
		],
		disableFluid: false,
		fluidCurl: 100,
		fluidVelocityDissipation: .93,
		fluidDyeDissipation: .95,
		fluidSplatRadius: .006,
		fluidPressureIterations: 1,
		fluidStrength: .15,
		falloffStrength: .95,
		falloffRadius: .32,
		falloffEnd: 1.05,
		maskFeather: 6,
		shapeScale: 1.25,
		baseFPS: 60,
		disabledOnMobile: false
	};
	const GRID_LAYOUTS = {
		straight: 0,
		radial: 1,
		"alternating-grid": 2
	};
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/hero/logoMask.js
	function buildLogoMaskTexture(THREE, config) {
		const SIZE = 1024;
		const cv = document.createElement("canvas");
		cv.width = cv.height = SIZE;
		const ctx = cv.getContext("2d");
		ctx.fillStyle = "#000";
		ctx.fillRect(0, 0, SIZE, SIZE);
		const REF = 666;
		const INSET = .78;
		const s = SIZE * INSET / REF;
		const PAD = (SIZE - SIZE * INSET) / 2;
		const x = (v) => PAD + v * s;
		const y = (v) => PAD + v * s;
		function drawLongRibbon(p) {
			p.moveTo(x(407), y(15));
			p.lineTo(x(457), y(64));
			p.bezierCurveTo(x(427), y(95), x(427), y(130), x(445), y(166));
			p.bezierCurveTo(x(458), y(192), x(482), y(219), x(494), y(256));
			p.bezierCurveTo(x(518), y(329), x(467), y(415), x(344), y(440));
			p.bezierCurveTo(x(338), y(418), x(330), y(396), x(320), y(373));
			p.bezierCurveTo(x(368), y(383), x(416), y(361), x(431), y(319));
			p.bezierCurveTo(x(447), y(273), x(421), y(233), x(399), y(198));
			p.bezierCurveTo(x(377), y(161), x(358), y(123), x(367), y(76));
			p.bezierCurveTo(x(372), y(51), x(386), y(29), x(407), y(15));
			p.closePath();
		}
		function drawShortMark(p) {
			p.moveTo(x(501), y(216));
			p.bezierCurveTo(x(538), y(226), x(570), y(217), x(593), y(197));
			p.lineTo(x(641), y(245));
			p.bezierCurveTo(x(609), y(274), x(571), y(291), x(526), y(290));
			p.bezierCurveTo(x(523), y(266), x(514), y(240), x(501), y(216));
			p.closePath();
		}
		function drawHalf(rotation, offsetX, offsetY) {
			ctx.save();
			ctx.translate(offsetX * s, offsetY * s);
			ctx.translate(SIZE / 2, SIZE / 2);
			ctx.rotate(rotation);
			ctx.translate(-SIZE / 2, -SIZE / 2);
			ctx.fillStyle = "#fff";
			const ribbon = new Path2D();
			drawLongRibbon(ribbon);
			ctx.fill(ribbon);
			const mark = new Path2D();
			drawShortMark(mark);
			ctx.fill(mark);
			ctx.restore();
		}
		drawHalf(0, 0, 0);
		drawHalf(Math.PI, 28, -94);
		softBlur(ctx, SIZE, config.maskFeather ?? 6);
		if (typeof window !== "undefined") {
			window.__lastLogoMaskCanvas = cv;
			if (location.search.includes("peek=1")) {
				const tryAttach = () => {
					if (!document.body) {
						setTimeout(tryAttach, 50);
						return;
					}
					const old = document.getElementById("__evomap_peek");
					if (old) old.remove();
					const img = document.createElement("img");
					img.id = "__evomap_peek";
					img.src = cv.toDataURL();
					img.style.cssText = "position:fixed;left:8px;top:8px;width:316px;height:316px;border:2px solid #f0f;background:#000;z-index:99999;";
					document.body.appendChild(img);
				};
				tryAttach();
			}
		}
		const tex = new THREE.CanvasTexture(cv);
		tex.minFilter = THREE.LinearFilter;
		tex.magFilter = THREE.LinearFilter;
		tex.wrapS = tex.wrapT = THREE.ClampToEdgeWrapping;
		tex.generateMipmaps = false;
		tex.colorSpace = THREE.LinearSRGBColorSpace;
		tex.needsUpdate = true;
		return tex;
	}
	function softBlur(ctx, size, radius) {
		if (radius <= 0) return;
		const tmp = document.createElement("canvas");
		tmp.width = tmp.height = size;
		const tctx = tmp.getContext("2d");
		tctx.filter = `blur(${radius}px)`;
		tctx.drawImage(ctx.canvas, 0, 0);
		tctx.filter = "none";
		ctx.clearRect(0, 0, size, size);
		ctx.fillStyle = "#000";
		ctx.fillRect(0, 0, size, size);
		ctx.drawImage(tmp, 0, 0);
	}
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/hero/videoSource.js
	function createVideoSource(THREE, container, src) {
		let videoEl = null;
		let videoTexture = null;
		try {
			videoEl = document.createElement("video");
			videoEl.src = src;
			videoEl.crossOrigin = "anonymous";
			videoEl.muted = true;
			videoEl.loop = true;
			videoEl.playsInline = true;
			videoEl.autoplay = true;
			videoEl.setAttribute("muted", "");
			videoEl.setAttribute("playsinline", "");
			videoEl.style.display = "none";
			container.appendChild(videoEl);
			const playPromise = videoEl.play();
			if (playPromise && typeof playPromise.catch === "function") playPromise.catch((err) => console.warn("[evomap] video autoplay blocked", err));
			videoTexture = new THREE.VideoTexture(videoEl);
			videoTexture.minFilter = THREE.LinearFilter;
			videoTexture.magFilter = THREE.LinearFilter;
			videoTexture.wrapS = videoTexture.wrapT = THREE.ClampToEdgeWrapping;
			videoTexture.generateMipmaps = false;
			videoTexture.colorSpace = THREE.SRGBColorSpace;
			return {
				videoEl,
				videoTexture
			};
		} catch (err) {
			console.error("[evomap] video source setup failed", err);
			if (videoEl?.parentNode) videoEl.parentNode.removeChild(videoEl);
			return {
				videoEl: null,
				videoTexture: null
			};
		}
	}
	function teardownVideoSource(videoEl) {
		if (!videoEl) return;
		try {
			videoEl.pause();
			videoEl.removeAttribute("src");
			videoEl.load();
		} catch (e) {}
		if (videoEl.parentNode) videoEl.parentNode.removeChild(videoEl);
	}
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/hero/createHero.js
	function hexToRgb$1(hex) {
		const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
		return m ? {
			r: parseInt(m[1], 16) / 255,
			g: parseInt(m[2], 16) / 255,
			b: parseInt(m[3], 16) / 255
		} : {
			r: 1,
			g: 1,
			b: 1
		};
	}
	function makeDoubleRT(width, height) {
		const opts = {
			minFilter: Mt,
			magFilter: Mt,
			format: kt,
			type: Ut,
			depthBuffer: false,
			stencilBuffer: false
		};
		return {
			read: new Ei(width, height, opts),
			write: new Ei(width, height, opts),
			swap() {
				const t = this.read;
				this.read = this.write;
				this.write = t;
			}
		};
	}
	function makeRT(width, height, type = Ut) {
		return new Ei(width, height, {
			minFilter: Mt,
			magFilter: Mt,
			format: kt,
			type,
			depthBuffer: false,
			stencilBuffer: false
		});
	}
	function createDottedVideo(container, userConfig = {}) {
		const config = {
			...defaultShaderConfig,
			...userConfig
		};
		const width = container.clientWidth;
		const height = container.clientHeight;
		const renderer = new rc({
			antialias: false,
			alpha: true
		});
		renderer.setSize(width, height);
		renderer.setPixelRatio(Math.min(2, window.devicePixelRatio || 1));
		container.appendChild(renderer.domElement);
		let shapeRT = makeRT(width, height, Et);
		const offscreenScene = new oc();
		const offscreenCamera = new Ea(-1, 1, 1, -1, 0, 1);
		const fullQuad = new pa(2, 2);
		const logoMaterial = new Ys({
			vertexShader: baseVert,
			fragmentShader: logoFrag,
			uniforms: {
				resolution: { value: new ti(width, height) },
				time: { value: 0 },
				ringInner: { value: config.ringInner },
				ringOuter: { value: config.ringOuter },
				ringSoftness: { value: config.ringSoftness },
				ringRotation: { value: 0 },
				ringFill: { value: config.ringFill },
				breath: { value: config.breath },
				nodeA: { value: new Li(config.nodes[0].angle, config.nodes[0].dist, config.nodes[0].radius) },
				nodeB: { value: new Li(config.nodes[1].angle, config.nodes[1].dist, config.nodes[1].radius) },
				nodeC: { value: new Li(config.nodes[2].angle, config.nodes[2].dist, config.nodes[2].radius) },
				nodePhases: { value: new Li(0, 2.1, 4.2) }
			}
		});
		const offscreenMesh = new Vs(fullQuad, logoMaterial);
		offscreenScene.add(offscreenMesh);
		const simW = Math.floor(width / 2);
		const simH = Math.floor(height / 2);
		let fluidScene = null;
		let fluidCamera = null;
		let fluidQuad = null;
		let velocityRT = null;
		let dyeRT = null;
		let pressureRT = null;
		let divergenceRT = null;
		let curlRT = null;
		let texelSize = null;
		let clearMat = null, splatMat = null, advectMat = null, divergenceMat = null, curlMat = null, vorticityMat = null, pressureMat = null, gradientSubtractMat = null;
		if (!config.disableFluid) {
			fluidScene = new oc();
			fluidCamera = new Ea(-1, 1, 1, -1, 0, 1);
			fluidQuad = new pa(2, 2);
			velocityRT = makeDoubleRT(simW, simH);
			dyeRT = makeDoubleRT(simW, simH);
			pressureRT = makeDoubleRT(simW, simH);
			divergenceRT = makeRT(simW, simH);
			curlRT = makeRT(simW, simH);
			texelSize = new ti(1 / simW, 1 / simH);
			const aspectRatio = width / height;
			clearMat = new Ys({
				vertexShader: baseVert,
				fragmentShader: clearFrag,
				uniforms: {
					uTexture: { value: null },
					value: { value: .98 }
				}
			});
			splatMat = new Ys({
				vertexShader: baseVert,
				fragmentShader: splatFrag,
				uniforms: {
					uTarget: { value: null },
					aspectRatio: { value: aspectRatio },
					color: { value: new Li(0, 0, 0) },
					point: { value: new ti(0, 0) },
					radius: { value: config.fluidSplatRadius }
				}
			});
			advectMat = new Ys({
				vertexShader: baseVert,
				fragmentShader: advectFrag,
				uniforms: {
					uVelocity: { value: null },
					uSource: { value: null },
					texelSize: { value: texelSize },
					dt: { value: .016 },
					dissipation: { value: .98 }
				}
			});
			divergenceMat = new Ys({
				vertexShader: fluidVert,
				fragmentShader: divergenceFrag,
				uniforms: {
					uVelocity: { value: null },
					texelSize: { value: texelSize }
				}
			});
			curlMat = new Ys({
				vertexShader: fluidVert,
				fragmentShader: curlFrag,
				uniforms: {
					uVelocity: { value: null },
					texelSize: { value: texelSize }
				}
			});
			vorticityMat = new Ys({
				vertexShader: fluidVert,
				fragmentShader: vorticityFrag,
				uniforms: {
					uVelocity: { value: null },
					uCurl: { value: null },
					curl: { value: config.fluidCurl },
					dt: { value: .016 },
					texelSize: { value: texelSize }
				}
			});
			pressureMat = new Ys({
				vertexShader: fluidVert,
				fragmentShader: pressureFrag,
				uniforms: {
					uPressure: { value: null },
					uDivergence: { value: null },
					texelSize: { value: texelSize }
				}
			});
			gradientSubtractMat = new Ys({
				vertexShader: fluidVert,
				fragmentShader: gradientSubtractFrag,
				uniforms: {
					uPressure: { value: null },
					uVelocity: { value: null },
					texelSize: { value: texelSize }
				}
			});
		}
		const cellSize = config.dotSize + config.dotMargin;
		const gridLayoutId = GRID_LAYOUTS[config.gridLayout] ?? 0;
		const dotRgb = hexToRgb$1(config.dotColor);
		const displayMaterial = new Ys({
			vertexShader: baseVert,
			fragmentShader: displayFrag,
			uniforms: {
				uDye: { value: null },
				uShape: { value: shapeRT.texture },
				fluidStrength: { value: config.fluidStrength },
				gridCellSize: { value: cellSize },
				gridLayout: { value: gridLayoutId },
				dotRadius: { value: config.dotSize / 2 },
				minDotRadius: { value: config.minDotSize / 2 },
				videoResolution: { value: new ti(width, height) },
				time: { value: 0 },
				animSpeed: { value: config.animSpeed },
				gamma: { value: config.gamma },
				dotColor: { value: new Li(dotRgb.r, dotRgb.g, dotRgb.b) },
				dotAlphaMultiplier: { value: config.dotAlphaMultiplier },
				dotsEnabled: { value: config.dotsEnabled },
				shapeRotation: { value: 0 },
				shapeBreath: { value: 0 },
				shapeScale: { value: config.shapeScale },
				falloffStrength: { value: config.falloffStrength },
				falloffRadius: { value: config.falloffRadius },
				falloffEnd: { value: config.falloffEnd }
			},
			transparent: true
		});
		const displayScene = new oc();
		const displayCamera = new Ea(-width / 2, width / 2, height / 2, -height / 2, .1, 1e3);
		displayCamera.position.z = 1;
		let displayGeometry = new pa(width, height);
		const displayMesh = new Vs(displayGeometry, displayMaterial);
		displayScene.add(displayMesh);
		let maskTexture = null;
		let videoEl = null;
		let videoTexture = null;
		if (config.videoSource) {
			const v = createVideoSource(three_module_min_exports, container, config.videoSource);
			videoEl = v.videoEl;
			videoTexture = v.videoTexture;
			if (videoTexture) displayMaterial.uniforms.uShape.value = videoTexture;
		} else if (config.useShapeMask !== false) try {
			maskTexture = buildLogoMaskTexture(three_module_min_exports, config);
			displayMaterial.uniforms.uShape.value = maskTexture;
		} catch (err) {
			console.error("[evomap] buildLogoMaskTexture failed", err);
			maskTexture = null;
		}
		let fluidMesh = null;
		if (!config.disableFluid && fluidScene) {
			fluidMesh = new Vs(fluidQuad, new rs());
			fluidScene.add(fluidMesh);
		}
		const blit = config.disableFluid ? null : (material, target) => {
			fluidMesh.material = material;
			renderer.setRenderTarget(target);
			renderer.render(fluidScene, fluidCamera);
		};
		const splat = config.disableFluid ? null : ({ x, y, dx, dy, color }) => {
			const point = new ti(x / width, 1 - y / height);
			splatMat.uniforms.uTarget.value = velocityRT.read.texture;
			splatMat.uniforms.point.value = point;
			splatMat.uniforms.color.value.set(dx, -dy, 0);
			splatMat.uniforms.radius.value = .003;
			blit(splatMat, velocityRT.write);
			velocityRT.swap();
			splatMat.uniforms.uTarget.value = dyeRT.read.texture;
			splatMat.uniforms.color.value = color;
			splatMat.uniforms.radius.value = config.fluidSplatRadius;
			blit(splatMat, dyeRT.write);
			dyeRT.swap();
		};
		let lastX = -1, lastY = -1, lastMoveTime = 0;
		const onPointerMove = (e) => {
			if (!splat) return;
			const rect = renderer.domElement.getBoundingClientRect();
			const x = e.clientX - rect.left;
			const y = e.clientY - rect.top;
			if (lastX >= 0 && lastY >= 0) {
				splat({
					x,
					y,
					dx: (x - lastX) * 10,
					dy: (y - lastY) * 10,
					color: new Li(.5, .5, .5)
				});
				lastMoveTime = Date.now();
			}
			lastX = x;
			lastY = y;
		};
		const onPointerLeave = () => {
			lastX = -1;
			lastY = -1;
		};
		if (!config.disableFluid) {
			renderer.domElement.addEventListener("pointermove", onPointerMove);
			renderer.domElement.addEventListener("pointerleave", onPointerLeave);
		}
		let prevFrameTime = Date.now();
		let prevRenderTime = Date.now();
		const startTime = Date.now();
		const baseFPS = config.baseFPS || 60;
		const fluidStep = 1 / 60;
		let accumulator = 0;
		let rafId = null;
		let isVisible = true;
		const tick = () => {
			rafId = requestAnimationFrame(tick);
			if (!isVisible) return;
			const now = Date.now();
			const dt = Math.min((now - prevFrameTime) / 1e3, .1);
			prevFrameTime = now;
			accumulator += dt;
			const targetFps = config.disableFluid || now - lastMoveTime > 2e3 ? Math.min(30, baseFPS) : baseFPS;
			if (now - prevRenderTime < 1e3 / targetFps) return;
			prevRenderTime = now;
			const tSec = (now - startTime) * .001;
			if (!!!(maskTexture || videoTexture)) {
				logoMaterial.uniforms.time.value = tSec;
				logoMaterial.uniforms.ringRotation.value = tSec * config.ringRotationSpeed;
				renderer.setRenderTarget(shapeRT);
				renderer.render(offscreenScene, offscreenCamera);
			}
			displayMaterial.uniforms.shapeRotation.value = tSec * config.ringRotationSpeed;
			displayMaterial.uniforms.shapeBreath.value = config.breath * Math.sin(tSec * .8);
			if (!config.disableFluid) while (accumulator >= fluidStep) {
				curlMat.uniforms.uVelocity.value = velocityRT.read.texture;
				blit(curlMat, curlRT);
				vorticityMat.uniforms.uVelocity.value = velocityRT.read.texture;
				vorticityMat.uniforms.uCurl.value = curlRT.texture;
				vorticityMat.uniforms.dt.value = fluidStep;
				blit(vorticityMat, velocityRT.write);
				velocityRT.swap();
				divergenceMat.uniforms.uVelocity.value = velocityRT.read.texture;
				blit(divergenceMat, divergenceRT);
				clearMat.uniforms.uTexture.value = pressureRT.read.texture;
				clearMat.uniforms.value.value = 0;
				blit(clearMat, pressureRT.write);
				pressureRT.swap();
				pressureMat.uniforms.uDivergence.value = divergenceRT.texture;
				for (let i = 0; i < config.fluidPressureIterations; i++) {
					pressureMat.uniforms.uPressure.value = pressureRT.read.texture;
					blit(pressureMat, pressureRT.write);
					pressureRT.swap();
				}
				gradientSubtractMat.uniforms.uPressure.value = pressureRT.read.texture;
				gradientSubtractMat.uniforms.uVelocity.value = velocityRT.read.texture;
				blit(gradientSubtractMat, velocityRT.write);
				velocityRT.swap();
				advectMat.uniforms.uVelocity.value = velocityRT.read.texture;
				advectMat.uniforms.uSource.value = velocityRT.read.texture;
				advectMat.uniforms.dt.value = fluidStep;
				advectMat.uniforms.dissipation.value = config.fluidVelocityDissipation;
				blit(advectMat, velocityRT.write);
				velocityRT.swap();
				advectMat.uniforms.uVelocity.value = velocityRT.read.texture;
				advectMat.uniforms.uSource.value = dyeRT.read.texture;
				advectMat.uniforms.dissipation.value = config.fluidDyeDissipation;
				blit(advectMat, dyeRT.write);
				dyeRT.swap();
				accumulator -= fluidStep;
			}
			displayMaterial.uniforms.time.value = tSec;
			if (!config.disableFluid && dyeRT) displayMaterial.uniforms.uDye.value = dyeRT.read.texture;
			if (!maskTexture && !videoTexture) displayMaterial.uniforms.uShape.value = shapeRT.texture;
			renderer.setRenderTarget(null);
			renderer.render(displayScene, displayCamera);
		};
		const intersectionObs = new IntersectionObserver((entries) => {
			for (const entry of entries) {
				isVisible = entry.isIntersecting;
				if (isVisible) {
					prevFrameTime = Date.now();
					prevRenderTime = Date.now();
					accumulator = 0;
				}
			}
		}, { threshold: 0 });
		intersectionObs.observe(container);
		const resizeObs = new ResizeObserver((entries) => {
			for (const entry of entries) {
				const w = entry.contentRect.width;
				const h = entry.contentRect.height;
				if (w === 0 || h === 0) return;
				displayCamera.left = -w / 2;
				displayCamera.right = w / 2;
				displayCamera.top = h / 2;
				displayCamera.bottom = -h / 2;
				displayCamera.updateProjectionMatrix();
				renderer.setSize(w, h);
				displayGeometry.dispose();
				displayGeometry = new pa(w, h);
				displayMesh.geometry = displayGeometry;
				if (!config.disableFluid && splatMat) splatMat.uniforms.aspectRatio.value = w / h;
				displayMaterial.uniforms.videoResolution.value.set(w, h);
				shapeRT.dispose();
				shapeRT = makeRT(w, h, Et);
				if (!maskTexture && !videoTexture) displayMaterial.uniforms.uShape.value = shapeRT.texture;
				logoMaterial.uniforms.resolution.value.set(w, h);
			}
		});
		resizeObs.observe(container);
		Promise.resolve().then(() => {
			tick();
		});
		const cleanup = () => {
			intersectionObs.disconnect();
			resizeObs.disconnect();
			cancelAnimationFrame(rafId);
			if (!config.disableFluid) {
				renderer.domElement.removeEventListener("pointermove", onPointerMove);
				renderer.domElement.removeEventListener("pointerleave", onPointerLeave);
				velocityRT?.read.dispose();
				velocityRT?.write.dispose();
				dyeRT?.read.dispose();
				dyeRT?.write.dispose();
				pressureRT?.read.dispose();
				pressureRT?.write.dispose();
				divergenceRT?.dispose();
				curlRT?.dispose();
				clearMat?.dispose();
				splatMat?.dispose();
				advectMat?.dispose();
				divergenceMat?.dispose();
				curlMat?.dispose();
				vorticityMat?.dispose();
				pressureMat?.dispose();
				gradientSubtractMat?.dispose();
				if (fluidMesh) {
					fluidMesh.material.dispose();
					fluidMesh.geometry.dispose();
				}
				fluidQuad?.dispose();
				fluidScene?.clear();
			}
			shapeRT.dispose();
			logoMaterial.dispose();
			offscreenMesh.geometry.dispose();
			maskTexture?.dispose();
			videoTexture?.dispose();
			teardownVideoSource(videoEl);
			offscreenScene.clear();
			displayMaterial.dispose();
			displayGeometry.dispose();
			displayScene.clear();
			const lc = renderer.getContext().getExtension("WEBGL_lose_context");
			if (lc) lc.loseContext();
			renderer.dispose();
			const canvas = container.querySelector("canvas");
			if (canvas) container.removeChild(canvas);
		};
		return {
			renderer,
			displayMaterial,
			logoMaterial,
			splatMaterial: splatMat,
			cleanup
		};
	}
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/hero/noise3D.js
	const F3 = 1 / 3;
	const G3 = 1 / 6;
	const grad3 = new Float32Array([
		1,
		1,
		0,
		-1,
		1,
		0,
		1,
		-1,
		0,
		-1,
		-1,
		0,
		1,
		0,
		1,
		-1,
		0,
		1,
		1,
		0,
		-1,
		-1,
		0,
		-1,
		0,
		1,
		1,
		0,
		-1,
		1,
		0,
		1,
		-1,
		0,
		-1,
		-1
	]);
	const p = new Uint8Array(256);
	for (let i = 0; i < 256; i++) p[i] = Math.floor(Math.random() * 256);
	const perm = new Uint8Array(512);
	const permMod12 = new Uint8Array(512);
	for (let i = 0; i < 512; i++) {
		perm[i] = p[i & 255];
		permMod12[i] = perm[i] % 12 * 3;
	}
	function noise3D(xin, yin, zin) {
		let n0, n1, n2, n3;
		const s = (xin + yin + zin) * F3;
		const i = Math.floor(xin + s);
		const j = Math.floor(yin + s);
		const k = Math.floor(zin + s);
		const t = (i + j + k) * G3;
		const X0 = i - t;
		const Y0 = j - t;
		const Z0 = k - t;
		const x0 = xin - X0;
		const y0 = yin - Y0;
		const z0 = zin - Z0;
		let i1, j1, k1;
		let i2, j2, k2;
		if (x0 >= y0) if (y0 >= z0) {
			i1 = 1;
			j1 = 0;
			k1 = 0;
			i2 = 1;
			j2 = 1;
			k2 = 0;
		} else if (x0 >= z0) {
			i1 = 1;
			j1 = 0;
			k1 = 0;
			i2 = 1;
			j2 = 0;
			k2 = 1;
		} else {
			i1 = 0;
			j1 = 0;
			k1 = 1;
			i2 = 1;
			j2 = 0;
			k2 = 1;
		}
		else if (y0 < z0) {
			i1 = 0;
			j1 = 0;
			k1 = 1;
			i2 = 0;
			j2 = 1;
			k2 = 1;
		} else if (x0 < z0) {
			i1 = 0;
			j1 = 1;
			k1 = 0;
			i2 = 0;
			j2 = 1;
			k2 = 1;
		} else {
			i1 = 0;
			j1 = 1;
			k1 = 0;
			i2 = 1;
			j2 = 1;
			k2 = 0;
		}
		const x1 = x0 - i1 + G3;
		const y1 = y0 - j1 + G3;
		const z1 = z0 - k1 + G3;
		const x2 = x0 - i2 + 2 * G3;
		const y2 = y0 - j2 + 2 * G3;
		const z2 = z0 - k2 + 2 * G3;
		const x3 = x0 - 1 + 3 * G3;
		const y3 = y0 - 1 + 3 * G3;
		const z3 = z0 - 1 + 3 * G3;
		const ii = i & 255;
		const jj = j & 255;
		const kk = k & 255;
		let t0 = .6 - x0 * x0 - y0 * y0 - z0 * z0;
		if (t0 < 0) n0 = 0;
		else {
			const gi0 = permMod12[ii + perm[jj + perm[kk]]];
			t0 *= t0;
			n0 = t0 * t0 * (grad3[gi0] * x0 + grad3[gi0 + 1] * y0 + grad3[gi0 + 2] * z0);
		}
		let t1 = .6 - x1 * x1 - y1 * y1 - z1 * z1;
		if (t1 < 0) n1 = 0;
		else {
			const gi1 = permMod12[ii + i1 + perm[jj + j1 + perm[kk + k1]]];
			t1 *= t1;
			n1 = t1 * t1 * (grad3[gi1] * x1 + grad3[gi1 + 1] * y1 + grad3[gi1 + 2] * z1);
		}
		let t2 = .6 - x2 * x2 - y2 * y2 - z2 * z2;
		if (t2 < 0) n2 = 0;
		else {
			const gi2 = permMod12[ii + i2 + perm[jj + j2 + perm[kk + k2]]];
			t2 *= t2;
			n2 = t2 * t2 * (grad3[gi2] * x2 + grad3[gi2 + 1] * y2 + grad3[gi2 + 2] * z2);
		}
		let t3 = .6 - x3 * x3 - y3 * y3 - z3 * z3;
		if (t3 < 0) n3 = 0;
		else {
			const gi3 = permMod12[ii + 1 + perm[jj + 1 + perm[kk + 1]]];
			t3 *= t3;
			n3 = t3 * t3 * (grad3[gi3] * x3 + grad3[gi3 + 1] * y3 + grad3[gi3 + 2] * z3);
		}
		return 32 * (n0 + n1 + n2 + n3);
	}
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/hero/createCellularHero.js
	const cellularDefaultConfig = {
		gridSpacing: 35,
		cellMaxRadius: 14,
		membraneStrokeWidth: .7,
		membraneOpacity: .7,
		nucleusSize: 2.5,
		connectionOpacity: .1,
		ghostTrail: .25,
		globalSpeed: .9,
		nucleusSpeed: .01,
		nucleusCountRatio: .14,
		initialSeedRatio: .025,
		initialSeedRadius: .22,
		activationGrow: .25,
		activationDecay: .01,
		clusterCohesion: .15,
		cohesionRatio: .65,
		wanderSparsity: 1.3,
		boidsWeight: .2,
		nucleusMaxPerCell: 4,
		nucleusSplitProb: .005,
		homeostasisRate: .02,
		randomSpawnProb: .05,
		membraneGrowSpeed: .15,
		membraneDecaySpeed: .05,
		bgColor: "#050505",
		membraneColor: "#ffffff",
		nucleusColor: "#ffffff",
		connectionColor: "#ffffff",
		vignetteStrength: .35,
		initialUniform: false,
		rightBias: 0,
		rightBiasRamp: 6,
		leftLoadFactor: .5
	};
	function hexToRgb(hex) {
		const m = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
		return m ? `${parseInt(m[1], 16)}, ${parseInt(m[2], 16)}, ${parseInt(m[3], 16)}` : "255, 255, 255";
	}
	function createCellularHero(container, userConfig = {}) {
		const config = {
			...cellularDefaultConfig,
			...userConfig
		};
		const canvas = document.createElement("canvas");
		canvas.style.position = "absolute";
		canvas.style.inset = "0";
		canvas.style.display = "block";
		canvas.style.touchAction = "none";
		container.appendChild(canvas);
		const ctx = canvas.getContext("2d", { alpha: true });
		if (!ctx) return { cleanup() {
			canvas.remove();
		} };
		let width = 0;
		let height = 0;
		let dpr = window.devicePixelRatio || 1;
		let nodes = [];
		let nuclei = [];
		let lastSpacing = 0;
		let time = 0;
		let raf = 0;
		let stopped = false;
		let bootMs = 0;
		let isPointerDown = false;
		let lastAddedNodeId = -1;
		function initGrid() {
			nodes = [];
			nuclei = [];
			let id = 0;
			const sp = config.gridSpacing;
			const cols = Math.ceil(width / sp) + 2;
			const rows = Math.ceil(height / sp) + 2;
			for (let r = -1; r < rows; r++) for (let c = -1; c < cols; c++) nodes.push({
				id: id++,
				x: c * sp,
				y: r * sp,
				col: c,
				row: r,
				activation: 0,
				membraneRadius: 0,
				neighbors: []
			});
			for (const node of nodes) for (const other of nodes) {
				if (other === node) continue;
				const dx = Math.abs(other.col - node.col);
				const dy = Math.abs(other.row - node.row);
				if (dx <= 1 && dy <= 1) node.neighbors.push(other);
			}
			const target = nodes.length * config.initialSeedRatio;
			if (config.initialUniform) {
				const seedCount = Math.max(1, target | 0);
				const patchCount = 3 + (Math.random() * 3 | 0);
				const patches = [];
				const minSep = Math.min(width, height) * .18;
				let guard = 0;
				while (patches.length < patchCount && guard++ < 60) {
					const px = Math.random() < .6 ? width * (.05 + Math.random() * .4) : width * (.45 + Math.random() * .4);
					const py = height * (.1 + Math.random() * .8);
					if (patches.some((q) => Math.hypot(px - q.x, py - q.y) < minSep)) continue;
					const radius = Math.min(width, height) * (.06 + Math.random() * .04);
					patches.push({
						x: px,
						y: py,
						radius
					});
				}
				if (patches.length === 0) patches.push({
					x: width * .4,
					y: height * .5,
					radius: Math.min(width, height) * .1
				});
				const interiorByPatch = patches.map((patch) => {
					const cands = [];
					for (const node of nodes) {
						if (node.x < 0 || node.y < 0) continue;
						if (node.x > width || node.y > height) continue;
						const d = Math.hypot(node.x - patch.x, node.y - patch.y);
						if (d <= patch.radius) cands.push({
							node,
							d
						});
					}
					return cands;
				});
				const totalCands = interiorByPatch.reduce((acc, list) => acc + list.length, 0);
				for (let i = 0; i < patches.length; i++) {
					const list = interiorByPatch[i];
					if (list.length === 0) continue;
					const share = totalCands > 0 ? Math.round(seedCount * list.length / totalCands) : Math.floor(seedCount / patches.length);
					const used = /* @__PURE__ */ new Set();
					let placed = 0;
					let attempts = 0;
					while (placed < share && attempts++ < share * 4) {
						const pick = list[Math.random() * list.length | 0];
						const t = pick.d / patches[i].radius;
						const accept = 1 - Math.pow(t, 1.5);
						if (Math.random() > accept) continue;
						if (used.has(pick.node.id)) continue;
						used.add(pick.node.id);
						nuclei.push({
							currentNode: pick.node,
							nextNode: pick.node,
							progress: 0
						});
						placed++;
					}
				}
				return;
			}
			const cx = width / 2;
			const cy = height / 2;
			const maxR = Math.min(width, height) * config.initialSeedRadius;
			const blobFreq = 1.8 / maxR;
			const candidates = [];
			for (const node of nodes) {
				const dx = node.x - cx;
				const dy = node.y - cy;
				const dist = Math.hypot(dx, dy);
				if (dist > maxR) continue;
				const falloff = 1 - dist / maxR;
				const score = falloff * falloff * (.55 + (noise3D(node.x * blobFreq, node.y * blobFreq, 0) + 1) * .5 * .5);
				if (score > .45) candidates.push({
					node,
					score
				});
			}
			candidates.sort((a, b) => b.score - a.score);
			const seedCount = Math.min(target | 0, candidates.length);
			for (let i = 0; i < seedCount; i++) {
				const node = candidates[i].node;
				nuclei.push({
					currentNode: node,
					nextNode: node,
					progress: 0
				});
			}
		}
		function resize() {
			const rect = container.getBoundingClientRect();
			if (rect.width === 0 || rect.height === 0) return;
			dpr = window.devicePixelRatio || 1;
			width = rect.width;
			height = rect.height;
			canvas.width = width * dpr;
			canvas.height = height * dpr;
			canvas.style.width = width + "px";
			canvas.style.height = height + "px";
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			initGrid();
			lastSpacing = config.gridSpacing;
		}
		function spawnNucleusAt(px, py) {
			const sp = config.gridSpacing;
			const col = Math.round(px / sp);
			const row = Math.round(py / sp);
			const node = nodes.find((n) => n.col === col && n.row === row);
			if (node && node.id !== lastAddedNodeId) {
				nuclei.push({
					currentNode: node,
					nextNode: node,
					progress: 1
				});
				lastAddedNodeId = node.id;
			}
		}
		function pointerToCanvas(e) {
			const rect = canvas.getBoundingClientRect();
			return {
				x: e.clientX - rect.left,
				y: e.clientY - rect.top
			};
		}
		const onPointerDown = (e) => {
			isPointerDown = true;
			const { x, y } = pointerToCanvas(e);
			spawnNucleusAt(x, y);
		};
		const onPointerMove = (e) => {
			if (!isPointerDown) return;
			const { x, y } = pointerToCanvas(e);
			spawnNucleusAt(x, y);
		};
		const onPointerUp = () => {
			isPointerDown = false;
			lastAddedNodeId = -1;
		};
		canvas.addEventListener("pointerdown", onPointerDown);
		canvas.addEventListener("pointermove", onPointerMove);
		window.addEventListener("pointerup", onPointerUp);
		const ro = new ResizeObserver(() => resize());
		ro.observe(container);
		resize();
		function step() {
			const p = config;
			time += .01 * p.globalSpeed;
			if (bootMs === 0) bootMs = performance.now();
			let bias = 0;
			if (p.rightBias > 0) {
				const ramp = Math.max(.001, p.rightBiasRamp);
				const t01 = Math.min(1, (performance.now() - bootMs) / 1e3 / ramp);
				const ease = t01 * t01 * (3 - 2 * t01);
				bias = p.rightBias * ease;
			}
			let comX = width / 2;
			let comY = height / 2;
			if (nuclei.length > 0) {
				let sx = 0;
				let sy = 0;
				for (const n of nuclei) {
					sx += n.currentNode.x;
					sy += n.currentNode.y;
				}
				comX = sx / nuclei.length;
				comY = sy / nuclei.length;
			}
			if (bias > 0) {
				const targetX = width * (.5 + .05 * bias);
				comX = comX * (1 - bias * .5) + targetX * bias * .5;
			}
			for (const n of nuclei) {
				n.progress += p.nucleusSpeed * p.globalSpeed;
				if (n.progress >= 1) {
					n.currentNode = n.nextNode;
					n.progress = 0;
					if (Math.random() < p.nucleusSplitProb && nuclei.length < nodes.length * p.nucleusCountRatio * 2) {
						const cands = n.currentNode.neighbors;
						if (cands.length > 0) nuclei.push({
							currentNode: n.currentNode,
							nextNode: cands[Math.random() * cands.length | 0],
							progress: 0
						});
					}
				}
			}
			const byNode = /* @__PURE__ */ new Map();
			for (const n of nuclei) {
				const list = byNode.get(n.currentNode.id) || [];
				list.push(n);
				byNode.set(n.currentNode.id, list);
			}
			const next = [];
			byNode.forEach((list) => {
				if (list.length > p.nucleusMaxPerCell) next.push(...list.slice(0, p.nucleusMaxPerCell));
				else next.push(...list);
			});
			nuclei = next;
			const diff = nodes.length * p.nucleusCountRatio - nuclei.length;
			const pickBiased = (preferHigh) => {
				if (nuclei.length === 0) return -1;
				if (bias <= 0) return Math.random() * nuclei.length | 0;
				const ord = nuclei.map((n, i) => [i, n.currentNode.x]).sort((a, b) => a[1] - b[1]);
				const exp = 1 + 3 * bias;
				const r = Math.random();
				const t = preferHigh ? 1 - Math.pow(1 - r, exp) : Math.pow(r, exp);
				return ord[Math.min(ord.length - 1, t * ord.length | 0)][0];
			};
			if (diff > 0 && p.homeostasisRate > 0) {
				const spawn = Math.min(2, Math.ceil(diff * p.homeostasisRate * .1));
				for (let i = 0; i < spawn; i++) if (nuclei.length > 0 && Math.random() >= p.randomSpawnProb) {
					const parent = nuclei[pickBiased(true)];
					nuclei.push({
						currentNode: parent.currentNode,
						nextNode: parent.currentNode,
						progress: 1
					});
				} else if (nodes.length > 0) {
					const node = nodes[Math.random() * nodes.length | 0];
					nuclei.push({
						currentNode: node,
						nextNode: node,
						progress: 1
					});
				}
			} else if (diff < 0 && p.homeostasisRate > 0) {
				const kill = Math.min(5, Math.ceil(-diff * p.homeostasisRate * .1));
				for (let i = 0; i < kill && nuclei.length > 0; i++) {
					const k = pickBiased(false);
					if (k >= 0) nuclei.splice(k, 1);
				}
			}
			if (bias > 0 && p.leftLoadFactor > 0 && nuclei.length > 4) {
				let leftCount = 0;
				let leftNodeCount = 0;
				const halfX = width * .5;
				for (const n of nuclei) if (n.currentNode.x < halfX) leftCount++;
				for (const node of nodes) if (node.x >= 0 && node.x < halfX && node.y >= 0 && node.y <= height) leftNodeCount++;
				const leftBudget = leftNodeCount * p.nucleusCountRatio * p.leftLoadFactor;
				if (leftCount > leftBudget + 1) {
					const leftIdx = [];
					for (let i = 0; i < nuclei.length; i++) if (nuclei[i].currentNode.x < halfX) leftIdx.push(i);
					if (leftIdx.length > 0) {
						const k = leftIdx[Math.random() * leftIdx.length | 0];
						const pool = nodes.filter((n) => n.x >= halfX + 20);
						if (pool.length > 0) {
							const dest = pool[Math.random() * pool.length | 0];
							nuclei.splice(k, 1);
							nuclei.push({
								currentNode: dest,
								nextNode: dest,
								progress: 1
							});
						}
					}
				} else if (leftCount < leftBudget * .5) {
					const rightIdx = [];
					for (let i = 0; i < nuclei.length; i++) if (nuclei[i].currentNode.x >= halfX) rightIdx.push(i);
					if (rightIdx.length > 0) {
						const k = rightIdx[Math.random() * rightIdx.length | 0];
						const leftPool = nodes.filter((n) => n.x >= 0 && n.x < halfX - 20 && n.y >= 0 && n.y <= height);
						if (leftPool.length > 0) {
							const dest = leftPool[Math.random() * leftPool.length | 0];
							nuclei.splice(k, 1);
							nuclei.push({
								currentNode: dest,
								nextNode: dest,
								progress: 1
							});
						}
					}
				}
			}
			for (let idx = 0; idx < nuclei.length; idx++) {
				const n = nuclei[idx];
				if (n.progress !== 0) {
					n.currentNode.activation += p.activationGrow * p.globalSpeed;
					n.nextNode.activation += p.activationGrow * n.progress * p.globalSpeed;
					continue;
				}
				const cands = n.currentNode.neighbors;
				if (cands.length === 0) continue;
				const freq = .01 * p.wanderSparsity;
				const nx = noise3D(n.currentNode.x * freq, n.currentNode.y * freq, time * .5);
				const ny = noise3D(n.currentNode.x * freq + 100, n.currentNode.y * freq, time * .5);
				let dirX = 0;
				let dirY = 0;
				if (p.clusterCohesion > 0) {
					const tx = comX - n.currentNode.x;
					const ty = comY - n.currentNode.y;
					const d = Math.hypot(tx, ty);
					if (d > .001) {
						dirX = tx / d;
						dirY = ty / d;
					}
				}
				let bX = 0;
				let bY = 0;
				if (p.boidsWeight > 0) {
					let sepX = 0, sepY = 0, aliX = 0, aliY = 0, cohX = 0, cohY = 0;
					let nb = 0;
					const radius = p.gridSpacing * 4;
					const sepR = p.gridSpacing * 1.5;
					for (const o of nuclei) {
						if (o === n) continue;
						const ox = o.currentNode.x - n.currentNode.x;
						const oy = o.currentNode.y - n.currentNode.y;
						const d = Math.hypot(ox, oy);
						if (d > .001 && d < radius) {
							nb++;
							aliX += o.nextNode.x - o.currentNode.x;
							aliY += o.nextNode.y - o.currentNode.y;
							cohX += o.currentNode.x;
							cohY += o.currentNode.y;
							if (d < sepR) {
								sepX -= ox / d / d;
								sepY -= oy / d / d;
							}
						}
					}
					if (nb > 0) {
						aliX /= nb;
						aliY /= nb;
						cohX = cohX / nb - n.currentNode.x;
						cohY = cohY / nb - n.currentNode.y;
						const lA = Math.hypot(aliX, aliY) + .001;
						const lC = Math.hypot(cohX, cohY) + .001;
						const lS = Math.hypot(sepX, sepY) + .001;
						bX = aliX / lA + cohX / lC + sepX / lS * 1.5;
						bY = aliY / lA + cohY / lC + sepY / lS * 1.5;
						const lB = Math.hypot(bX, bY) + .001;
						bX /= lB;
						bY /= lB;
					}
				}
				const wCoh = idx / nuclei.length < p.cohesionRatio ? p.clusterCohesion : 0;
				const wBoids = p.boidsWeight;
				const wNoise = 1 - wCoh - wBoids * .5;
				const indivX = noise3D(idx * .1, time * .5, 0) * .3;
				const indivY = noise3D(time * .5, idx * .1, 100) * .3;
				const cX = nx * wNoise + dirX * wCoh + indivX * wNoise + bX * wBoids;
				const cY = ny * wNoise + dirY * wCoh + indivY * wNoise + bY * wBoids;
				let best = cands[0];
				let bestScore = -Infinity;
				for (const cand of cands) {
					const dx = cand.col - n.currentNode.col;
					const dy = cand.row - n.currentNode.row;
					const len = Math.hypot(dx, dy) || 1;
					const score = dx / len * cX + dy / len * cY;
					if (score > bestScore) {
						bestScore = score;
						best = cand;
					}
				}
				n.nextNode = best;
				n.currentNode.activation += p.activationGrow * p.globalSpeed;
			}
			for (const node of nodes) {
				node.activation -= p.activationDecay * p.globalSpeed;
				if (node.activation < 0) node.activation = 0;
				else if (node.activation > 1.2) node.activation = 1.2;
				const targetR = (node.activation > 1 ? 1 : node.activation) * p.cellMaxRadius;
				const speed = targetR > node.membraneRadius ? p.membraneGrowSpeed : p.membraneDecaySpeed;
				node.membraneRadius += (targetR - node.membraneRadius) * speed * p.globalSpeed;
			}
		}
		function draw() {
			const p = config;
			const memRgb = hexToRgb(p.membraneColor);
			const connRgb = hexToRgb(p.connectionColor);
			const nucRgb = hexToRgb(p.nucleusColor);
			if (p.ghostTrail > 0 && p.ghostTrail < 1) {
				ctx.globalCompositeOperation = "destination-out";
				ctx.fillStyle = `rgba(0, 0, 0, ${1 - p.ghostTrail})`;
				ctx.fillRect(0, 0, width, height);
				ctx.globalCompositeOperation = "source-over";
			} else if (p.ghostTrail >= 1) {} else ctx.clearRect(0, 0, width, height);
			ctx.lineWidth = p.membraneStrokeWidth;
			if (p.connectionOpacity > 0) for (const node of nodes) {
				if (node.activation < .1) continue;
				for (const nb of node.neighbors) {
					if (nb.id <= node.id || nb.activation < .1) continue;
					const op = Math.min(node.activation, nb.activation) * p.connectionOpacity;
					if (op < .02) continue;
					ctx.beginPath();
					ctx.moveTo(node.x, node.y);
					ctx.lineTo(nb.x, nb.y);
					ctx.strokeStyle = `rgba(${connRgb}, ${op})`;
					ctx.stroke();
				}
			}
			for (const node of nodes) {
				if (node.membraneRadius < .5) continue;
				const op = Math.max(0, Math.min(1, node.activation * p.membraneOpacity));
				if (op < .02) continue;
				ctx.beginPath();
				ctx.arc(node.x, node.y, node.membraneRadius, 0, Math.PI * 2);
				ctx.strokeStyle = `rgba(${memRgb}, ${op})`;
				ctx.stroke();
				if (node.activation > .5) {
					ctx.beginPath();
					ctx.arc(node.x, node.y, p.nucleusSize * Math.min(1, node.activation) * .7, 0, Math.PI * 2);
					ctx.fillStyle = `rgba(${nucRgb}, ${op * .5})`;
					ctx.fill();
				}
			}
			ctx.fillStyle = p.nucleusColor;
			for (const n of nuclei) {
				const x = n.currentNode.x + (n.nextNode.x - n.currentNode.x) * n.progress;
				const y = n.currentNode.y + (n.nextNode.y - n.currentNode.y) * n.progress;
				ctx.beginPath();
				ctx.arc(x, y, p.nucleusSize, 0, Math.PI * 2);
				ctx.fill();
			}
			if (p.vignetteStrength > 0) {
				const cx = width / 2;
				const cy = height / 2;
				const r = Math.hypot(cx, cy);
				const grad = ctx.createRadialGradient(cx, cy, r * .35, cx, cy, r);
				grad.addColorStop(0, "rgba(0,0,0,0)");
				grad.addColorStop(1, `rgba(0,0,0,${p.vignetteStrength})`);
				ctx.globalCompositeOperation = "destination-out";
				ctx.fillStyle = grad;
				ctx.fillRect(0, 0, width, height);
				ctx.globalCompositeOperation = "source-over";
			}
		}
		const render = () => {
			if (stopped) return;
			if (lastSpacing !== config.gridSpacing) {
				initGrid();
				lastSpacing = config.gridSpacing;
				ctx.clearRect(0, 0, width, height);
			}
			step();
			draw();
			raf = requestAnimationFrame(render);
		};
		render();
		return {
			cleanup() {
				stopped = true;
				cancelAnimationFrame(raf);
				if (ro) ro.disconnect();
				canvas.removeEventListener("pointerdown", onPointerDown);
				canvas.removeEventListener("pointermove", onPointerMove);
				window.removeEventListener("pointerup", onPointerUp);
				canvas.remove();
			},
			config
		};
	}
	const baseShape = {
		ringInner: .16,
		ringOuter: .62,
		ringSoftness: .012,
		ringRotationSpeed: 0,
		breath: 1,
		ringFill: 0,
		nodes: [
			{
				angle: 0,
				dist: 0,
				radius: .085
			},
			{
				angle: 0,
				dist: 0,
				radius: 1
			},
			{
				angle: Math.PI / 6,
				dist: 0,
				radius: 0
			}
		]
	};
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/variants/index.js
	const variants = [
		{
			id: "aurora",
			name: "02 · Aurora",
			tagline: "Signal-blue + lime CTA",
			shaderConfig: {
				...baseShape,
				dotColor: "#ffffff",
				dotSize: 6,
				dotMargin: 1,
				minDotSize: .8,
				gridLayout: "straight",
				gamma: .85,
				animSpeed: 3,
				fluidStrength: .22,
				dotAlphaMultiplier: 1.1,
				ringRotationSpeed: .05
			},
			theme: {
				"--bg-from": "#1a3fa8",
				"--bg-via": "#0e2470",
				"--bg-to": "#091a4a",
				"--bg-mode": "linear",
				"--text": "#ffffff",
				"--text-soft": "rgba(255,255,255,0.78)",
				"--ring": "rgba(255,255,255,0.08)",
				"--cta-bg": "#d4ff3a",
				"--cta-fg": "#0e2470",
				"--cta-shadow": "0 0 32px rgba(212,255,58,0.35)",
				"--accent": "#d4ff3a"
			},
			copy: {
				eyebrow: "OPEN A2A",
				lineA: "Agents discover.",
				lineB: "Capabilities flow.",
				body: "Skills, capsules, and bounties — addressed and routed across an open agent fabric.",
				cta: "Connect a node"
			}
		},
		{
			id: "matrix",
			name: "04 · Matrix",
			tagline: "Terminal green on black",
			shaderConfig: {
				...baseShape,
				ringSoftness: .008,
				dotColor: "#00ff88",
				dotSize: 5,
				dotMargin: 1,
				minDotSize: .5,
				gridLayout: "alternating-grid",
				gamma: .7,
				animSpeed: 6,
				fluidStrength: .12,
				dotAlphaMultiplier: 1.3,
				ringRotationSpeed: .08,
				breath: .6
			},
			theme: {
				"--bg-from": "#000000",
				"--bg-via": "#001a0d",
				"--bg-to": "#000000",
				"--bg-mode": "radial",
				"--text": "#00ff88",
				"--text-soft": "rgba(0,255,136,0.7)",
				"--ring": "rgba(0,255,136,0.1)",
				"--cta-bg": "transparent",
				"--cta-fg": "#00ff88",
				"--cta-border": "1px solid #00ff88",
				"--cta-shadow": "0 0 24px rgba(0,255,136,0.4)",
				"--accent": "#00ff88",
				"--font-mono": "1"
			},
			copy: {
				eyebrow: "// NODE.ONLINE",
				lineA: "Every agent",
				lineB: "is a coordinate.",
				body: "Discover by capability, not by URL. Route by intent, not by docs.",
				cta: "$ evomap up"
			}
		},
		{
			id: "cyberpunk",
			name: "05 · Cyberpunk",
			tagline: "Neon magenta + cyan",
			shaderConfig: {
				...baseShape,
				dotColor: "#ff3df0",
				dotSize: 7,
				dotMargin: 0,
				minDotSize: 1,
				gridLayout: "radial",
				gamma: .85,
				animSpeed: 5,
				fluidStrength: .28,
				dotAlphaMultiplier: 1.2,
				ringRotationSpeed: .12,
				breath: 1.6
			},
			theme: {
				"--bg-from": "#1a0033",
				"--bg-via": "#3d0a5c",
				"--bg-to": "#0a0014",
				"--bg-mode": "radial",
				"--text": "#ffffff",
				"--text-soft": "rgba(255,255,255,0.78)",
				"--ring": "rgba(255,61,240,0.12)",
				"--cta-bg": "#00ffe5",
				"--cta-fg": "#1a0033",
				"--cta-shadow": "0 0 36px rgba(0,255,229,0.5)",
				"--accent": "#00ffe5"
			},
			copy: {
				eyebrow: "RUNTIME 2049",
				lineA: "Skills you can",
				lineB: "publish, fork, and earn from.",
				body: "Capsules of experience that travel between agents — credits as fuel, capabilities as currency.",
				cta: "Jack in →"
			}
		},
		{
			id: "newspaper",
			name: "06 · Newspaper",
			tagline: "Print halftone (no fluid)",
			shaderConfig: {
				...baseShape,
				dotColor: "#0a0a0a",
				dotSize: 9,
				dotMargin: 1,
				minDotSize: 1.4,
				gridLayout: "straight",
				gamma: 1.1,
				animSpeed: 1,
				fluidStrength: 0,
				disableFluid: true,
				dotAlphaMultiplier: 1.4,
				ringRotationSpeed: 0,
				breath: 0
			},
			theme: {
				"--bg-from": "#f5efe6",
				"--bg-via": "#ede4d3",
				"--bg-to": "#f5efe6",
				"--bg-mode": "linear",
				"--text": "#0a0a0a",
				"--text-soft": "rgba(10,10,10,0.65)",
				"--ring": "rgba(10,10,10,0.08)",
				"--cta-bg": "#0a0a0a",
				"--cta-fg": "#f5efe6",
				"--cta-shadow": "none",
				"--accent": "#0a0a0a",
				"--font-serif": "1",
				"--cta-radius": "0px"
			},
			copy: {
				eyebrow: "EST. 2026 · VOL I",
				lineA: "Map of",
				lineB: "agent economies.",
				body: "Set in newsprint. The only static node in a moving network.",
				cta: "Read the issue"
			}
		},
		{
			id: "solar",
			name: "07 · Solar",
			tagline: "Burning sun (radial dots)",
			shaderConfig: {
				...baseShape,
				dotColor: "#ffd166",
				dotSize: 7,
				dotMargin: 0,
				minDotSize: .8,
				gridLayout: "radial",
				gamma: .8,
				animSpeed: 5,
				fluidStrength: .22,
				fluidCurl: 150,
				ringRotationSpeed: .18,
				breath: 1.8
			},
			theme: {
				"--bg-from": "#1a0500",
				"--bg-via": "#5c0e0a",
				"--bg-to": "#0a0200",
				"--bg-mode": "radial",
				"--text": "#fff3d6",
				"--text-soft": "rgba(255,243,214,0.78)",
				"--ring": "rgba(255,209,102,0.1)",
				"--cta-bg": "#ffd166",
				"--cta-fg": "#3a0c00",
				"--cta-shadow": "0 0 48px rgba(255,209,102,0.4)",
				"--accent": "#ffd166"
			},
			copy: {
				eyebrow: "PEAK LOAD",
				lineA: "Idle tokens,",
				lineB: "earning credits.",
				body: "Even at peak, capacity is a graph. Use it, share it, get paid.",
				cta: "Run a bounty"
			}
		},
		{
			id: "mint",
			name: "08 · Mint Brick",
			tagline: "Calm pastel, brick pattern",
			shaderConfig: {
				...baseShape,
				dotColor: "#0d4f3c",
				dotSize: 6,
				dotMargin: 2,
				minDotSize: .8,
				gridLayout: "alternating-grid",
				gamma: 1,
				animSpeed: 2,
				fluidStrength: .1,
				fluidVelocityDissipation: .96,
				ringRotationSpeed: .025,
				breath: .8
			},
			theme: {
				"--bg-from": "#e8fff5",
				"--bg-via": "#c5f0db",
				"--bg-to": "#a3e0c4",
				"--bg-mode": "linear-vertical",
				"--text": "#0d4f3c",
				"--text-soft": "rgba(13,79,60,0.7)",
				"--ring": "rgba(13,79,60,0.08)",
				"--cta-bg": "#0d4f3c",
				"--cta-fg": "#e8fff5",
				"--cta-shadow": "none",
				"--accent": "#0d4f3c"
			},
			copy: {
				eyebrow: "FRESH",
				lineA: "Quiet routing.",
				lineB: "Loud reuse.",
				body: "When skills are addressable, agents stop redoing each other's work.",
				cta: "Share a skill"
			}
		},
		{
			id: "neutral",
			name: "09 · Neutral Mono",
			tagline: "Minimal greyscale",
			shaderConfig: {
				...baseShape,
				dotColor: "#222222",
				dotSize: 6,
				dotMargin: 1,
				minDotSize: 1,
				gridLayout: "straight",
				gamma: 1,
				animSpeed: 1.5,
				fluidStrength: .14,
				ringRotationSpeed: .02,
				breath: .6
			},
			theme: {
				"--bg-from": "#f3f3f3",
				"--bg-via": "#eaeaea",
				"--bg-to": "#dddddd",
				"--bg-mode": "linear-vertical",
				"--text": "#0a0a0a",
				"--text-soft": "rgba(10,10,10,0.6)",
				"--ring": "rgba(10,10,10,0.08)",
				"--cta-bg": "transparent",
				"--cta-fg": "#0a0a0a",
				"--cta-border": "1.5px solid #0a0a0a",
				"--cta-shadow": "none",
				"--accent": "#0a0a0a"
			},
			copy: {
				eyebrow: "",
				lineA: "Less docs.",
				lineB: "More discovery.",
				body: "An open address space for agent capability — quiet, deterministic, composable.",
				cta: "Get started"
			}
		},
		{
			id: "cellular",
			name: "12 · Cellular Field",
			tagline: "Cluster of agents — wandering, splitting, signalling",
			engine: "cellular",
			shaderConfig: {
				gridSpacing: 38,
				cellMaxRadius: 19,
				membraneStrokeWidth: .7,
				membraneOpacity: .7,
				nucleusSize: 2.5,
				connectionOpacity: .12,
				ghostTrail: .18,
				globalSpeed: .9,
				nucleusSpeed: .012,
				nucleusCountRatio: .12,
				clusterCohesion: .18,
				cohesionRatio: .6,
				boidsWeight: .25,
				wanderSparsity: 1.4,
				nucleusSplitProb: .006,
				homeostasisRate: .025,
				randomSpawnProb: .005,
				membraneColor: "#bfe9ff",
				nucleusColor: "#ffffff",
				connectionColor: "#9fd5ff",
				bgColor: "#020611",
				vignetteStrength: .45,
				initialUniform: true,
				initialSeedRatio: .025,
				rightBias: .4,
				rightBiasRamp: 6,
				leftLoadFactor: .7
			},
			theme: {
				"--bg-from": "#0a1632",
				"--bg-via": "#020611",
				"--bg-to": "#000000",
				"--bg-mode": "radial",
				"--text": "#e8f4ff",
				"--text-soft": "rgba(232,244,255,0.72)",
				"--ring": "rgba(190,233,255,0.05)",
				"--cta-bg": "#bfe9ff",
				"--cta-fg": "#06122e",
				"--cta-shadow": "0 0 32px rgba(190,233,255,0.25)",
				"--accent": "#bfe9ff"
			},
			copy: {
				eyebrow: "AGENT FIELD",
				lineA: "A million nuclei,",
				lineB: "one cluster.",
				body: "Each agent wanders, splits, and signals — and out of those simple rules a living network emerges.",
				cta: "Touch to seed nuclei"
			}
		}
	];
	//#endregion
	//#region ../tmp/evomap-themes-stage-rB27Xs/src/main.js
	const heroContainer = document.getElementById("hero-dotted-video");
	const switcherList = document.getElementById("switcher-list");
	const switcherTagline = document.getElementById("switcher-tagline");
	const switcherToggleCount = document.getElementById("switcher-toggle-count");
	const switcherToggle = document.getElementById("switcher-toggle");
	const contentToggle = document.getElementById("content-toggle");
	let currentInstance = null;
	let currentIndex = 0;
	const URL_PARAM = "v";
	const urlParams = new URLSearchParams(location.search);
	const embedOverride = urlParams.get("embed");
	const isEmbedded = embedOverride === "1" || embedOverride !== "0" && window.self !== window.top;
	function indexFromUrl() {
		const raw = urlParams.get(URL_PARAM);
		if (!raw) return null;
		const byId = variants.findIndex((v) => v.id === raw);
		if (byId >= 0) return byId;
		const asNum = parseInt(raw, 10);
		if (!Number.isNaN(asNum) && asNum >= 1 && asNum <= variants.length) return asNum - 1;
		return null;
	}
	function syncUrl(idx) {
		if (isEmbedded) return;
		const v = variants[idx];
		if (!v) return;
		const url = new URL(location.href);
		url.searchParams.set(URL_PARAM, v.id);
		if (url.toString() !== location.href) history.replaceState({ variantIndex: idx }, "", url.toString());
	}
	variants.forEach((v, idx) => {
		const li = document.createElement("li");
		li.className = "switcher-item";
		li.dataset.index = String(idx);
		li.innerHTML = `
        <span class="switcher-item-num">${String(idx + 1).padStart(2, "0")}</span>
        <span class="switcher-item-name">${v.name.replace(/^\d+\s·\s/, "")}</span>
    `;
		li.addEventListener("click", () => applyVariant(idx));
		switcherList.appendChild(li);
	});
	function applyVariant(idx) {
		const v = variants[idx];
		if (!v) return;
		currentIndex = idx;
		const root = document.documentElement;
		Object.entries(v.theme).forEach(([k, val]) => root.style.setProperty(k, val));
		[
			"--cta-border",
			"--font-mono",
			"--font-serif",
			"--cta-radius"
		].forEach((k) => {
			if (!(k in v.theme)) root.style.removeProperty(k);
		});
		document.body.dataset.variant = String(idx);
		document.body.dataset.variantId = v.id;
		if (currentInstance) {
			try {
				currentInstance.cleanup();
			} catch (e) {
				console.warn("cleanup error:", e);
			}
			currentInstance = null;
		}
		heroContainer.querySelectorAll("canvas").forEach((c) => c.remove());
		if (v.engine === "cellular") currentInstance = createCellularHero(heroContainer, v.shaderConfig);
		else currentInstance = createDottedVideo(heroContainer, {
			...v.shaderConfig,
			useShapeMask: !urlParams.has("nomask")
		});
		window.__hero = currentInstance;
		switcherList.querySelectorAll(".switcher-item").forEach((el, i) => {
			el.classList.toggle("is-active", i === idx);
		});
		switcherTagline.textContent = v.tagline;
		switcherToggleCount.textContent = `${String(idx + 1).padStart(2, "0")} / ${variants.length}`;
		syncUrl(idx);
	}
	switcherToggle.addEventListener("click", () => {
		document.getElementById("switcher").classList.toggle("is-open");
	});
	contentToggle.addEventListener("click", () => {
		const next = contentToggle.getAttribute("aria-pressed") !== "true";
		contentToggle.setAttribute("aria-pressed", String(next));
		document.body.classList.toggle("content-hidden", !next);
	});
	const SKILL_REGISTRATION_URL = "https://evomap.ai/skill.md";
	const ctaTextEl = document.getElementById("cta-text");
	if (ctaTextEl) {
		const linkEl = document.createElement("a");
		linkEl.href = SKILL_REGISTRATION_URL;
		linkEl.target = "_blank";
		linkEl.rel = "noopener";
		linkEl.textContent = SKILL_REGISTRATION_URL;
		ctaTextEl.append("Read ", linkEl, " to register and join EvoMap.");
	}
	document.querySelector(".cta-pill")?.addEventListener("click", async (e) => {
		const link = SKILL_REGISTRATION_URL;
		if (!(e.target.closest(".copy-btn") || e.target.closest(".cta-text"))) return;
		if (e.target.closest("a")) return;
		try {
			await navigator.clipboard.writeText(link);
			const btn = document.querySelector(".copy-btn");
			if (btn) {
				btn.classList.add("copied");
				setTimeout(() => btn.classList.remove("copied"), 1200);
			}
		} catch (err) {
			console.warn("clipboard error:", err);
		}
	});
	if (!isEmbedded) window.addEventListener("keydown", (e) => {
		const t = e.target;
		if (t instanceof Element && t.matches("input, textarea, [contenteditable='true']")) return;
		if (e.key >= "1" && e.key <= "9") applyVariant(parseInt(e.key, 10) - 1);
		else if (e.key === "ArrowRight") applyVariant((currentIndex + 1) % variants.length);
		else if (e.key === "ArrowLeft") applyVariant((currentIndex - 1 + variants.length) % variants.length);
	});
	if (isEmbedded) document.body.dataset.embed = "1";
	applyVariant(indexFromUrl() ?? 0);
	if (!isEmbedded && window.matchMedia("(min-width: 768px)").matches) document.getElementById("switcher").classList.add("is-open");
	window.addEventListener("popstate", () => {
		const idx = indexFromUrl();
		if (idx !== null && idx !== currentIndex) applyVariant(idx);
	});
	//#endregion
})();
